﻿// Base API URL (same-origin, deployment-path safe)
let baseApiUrl;
let appBaseUrl;
const FAS_TIME_ZONE = 'Asia/Manila';
let fasServerClockOffsetMs = 0;
let fasServerClockSynced = false;

// Keep staff portals on the shared desktop shell. Student pages retain their
// native full-width top navigation, including the logo at its starting edge.
(function initPortalShellLayout() {
    const portalMatch = window.location.pathname.match(/\/pages\/(admin|manager|instructor|student)\//i);
    if (!portalMatch) return;

    // Admin pages use admin_responsive.js, while student pages intentionally
    // keep their brand in the full-width top navigation.
    if (['admin', 'student'].includes(portalMatch[1].toLowerCase())) return;

    const styleId = 'fas-portal-shell-layout';
    if (!document.getElementById(styleId)) {
        const style = document.createElement('style');
        style.id = styleId;
        style.textContent = `
            .fas-sidebar-brand {
                display: none;
            }

            @media (min-width: 1024px) {
                body.fas-portal-shell {
                    --fas-sidebar-width: 18rem;
                }

                body.fas-portal-shell > nav.fas-portal-topbar:not(#adminDashboardTopNav) {
                    top: 0 !important;
                    right: 0 !important;
                    left: var(--fas-sidebar-width) !important;
                    width: auto !important;
                    height: 4rem !important;
                    min-height: 4rem !important;
                    padding-top: .75rem !important;
                    padding-bottom: .75rem !important;
                }

                body.fas-portal-shell > aside.fas-portal-sidebar {
                    top: 0 !important;
                    bottom: 0 !important;
                    height: 100dvh !important;
                    padding-top: 0 !important;
                    z-index: 60 !important;
                }

                .fas-sidebar-brand {
                    position: sticky;
                    top: 0;
                    z-index: 5;
                    display: flex;
                    flex: 0 0 4rem;
                    height: 4rem;
                    align-items: center;
                    justify-content: center;
                    padding: .65rem 1.5rem;
                    border-bottom: 1px solid rgba(255, 255, 255, .1);
                    background: #0b0c0f;
                    box-sizing: border-box;
                }

                .fas-sidebar-brand img {
                    display: block;
                    width: auto;
                    height: 2.5rem !important;
                    max-width: 100%;
                    object-fit: contain;
                    filter: brightness(2);
                }

                body.fas-portal-shell > nav.fas-portal-topbar .fas-topbar-brand {
                    display: none !important;
                }

                html:not(.dark) body.fas-student-shell .fas-sidebar-brand {
                    border-bottom-color: rgb(228 228 231);
                    background: #fff;
                }

                html:not(.dark) body.fas-student-shell .fas-sidebar-brand img {
                    filter: none;
                }
            }
        `;
        document.head.appendChild(style);
    }

    const mountShell = () => {
        const topbar = Array.from(document.querySelectorAll('body > nav')).find((nav) =>
            nav.classList.contains('fixed') && nav.querySelector('img[src*="fas-logo"]')
        );
        const sidebar = document.querySelector('body > aside.fixed');
        if (!topbar || !sidebar || sidebar.querySelector(':scope > .fas-sidebar-brand')) return;

        const logoImage = topbar.querySelector('img[src*="fas-logo"]');
        if (!logoImage) return;

        const portalRole = portalMatch[1].toLowerCase();
        document.body.classList.add('fas-portal-shell', `fas-${portalRole}-shell`);
        if (portalRole === 'student') {
            document.body.classList.add('fas-student-shell');
        }
        topbar.classList.add('fas-portal-topbar');
        sidebar.classList.add('fas-portal-sidebar');

        const topbarBrand = logoImage.closest('a') || logoImage;
        topbarBrand.classList.add('fas-topbar-brand');
        const brand = document.createElement('div');
        brand.className = 'fas-sidebar-brand';
        const brandLink = document.createElement('a');
        const dashboardTargets = {
            admin: 'admin_dashboard.html',
            manager: 'manager_dashboard.html',
            instructor: 'instructor_dashboard.html',
            student: 'student_dashboard.html'
        };
        brandLink.href = dashboardTargets[portalRole];
        brandLink.setAttribute('aria-label', 'Go to dashboard');
        const clonedLogo = logoImage.cloneNode(true);
        clonedLogo.removeAttribute('id');
        brandLink.appendChild(clonedLogo);
        brand.appendChild(brandLink);
        sidebar.prepend(brand);
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', mountShell, { once: true });
    } else {
        mountShell();
    }
})();

function getCalendarNow() {
    return new Date(Date.now() + fasServerClockOffsetMs);
}

function getManilaDateParts(date) {
    const sourceDate = date instanceof Date ? date : getCalendarNow();
    try {
        const parts = new Intl.DateTimeFormat('en-CA', {
            timeZone: FAS_TIME_ZONE,
            year: 'numeric', month: '2-digit', day: '2-digit',
            hour: '2-digit', minute: '2-digit', second: '2-digit', hourCycle: 'h23'
        }).formatToParts(sourceDate).reduce((result, part) => {
            if (part.type !== 'literal') result[part.type] = part.value;
            return result;
        }, {});
        return {
            year: Number(parts.year), month: Number(parts.month), day: Number(parts.day),
            hour: Number(parts.hour), minute: Number(parts.minute), second: Number(parts.second)
        };
    } catch (_) {
        const manila = new Date(sourceDate.getTime() + (8 * 60 * 60 * 1000));
        return {
            year: manila.getUTCFullYear(), month: manila.getUTCMonth() + 1, day: manila.getUTCDate(),
            hour: manila.getUTCHours(), minute: manila.getUTCMinutes(), second: manila.getUTCSeconds()
        };
    }
}

function getManilaYmd(date) {
    const parts = getManilaDateParts(date);
    return `${parts.year}-${String(parts.month).padStart(2, '0')}-${String(parts.day).padStart(2, '0')}`;
}

function getManilaMonthKey(date) {
    return getManilaYmd(date).slice(0, 7);
}

function addDaysToYmd(ymd, days) {
    const [year, month, day] = String(ymd || '').split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, day + Number(days || 0), 12));
    return `${date.getUTCFullYear()}-${String(date.getUTCMonth() + 1).padStart(2, '0')}-${String(date.getUTCDate()).padStart(2, '0')}`;
}

window.FAS_TIME_ZONE = FAS_TIME_ZONE;
window.getCalendarNow = getCalendarNow;
window.getManilaDateParts = getManilaDateParts;
window.getManilaYmd = getManilaYmd;
window.getManilaMonthKey = getManilaMonthKey;
window.addDaysToYmd = addDaysToYmd;
(function initApiBaseUrl() {
    // Derive app base from where this script is served (works even if folder is renamed).
    const defaultAppBaseUrl = (() => {
        try {
            const scriptSrc = document.currentScript && document.currentScript.src ? document.currentScript.src : '';
            const scriptUrl = new URL(scriptSrc, window.location.href);
            // Expected: {origin}/{app}/js/index.js
            const basePath = scriptUrl.pathname.replace(/\/js\/index\.js$/i, '');
            return `${scriptUrl.origin}${basePath}`.replace(/\/$/, '');
        } catch (e) {
            // Last-resort fallback for legacy deployments
            return `${window.location.origin}/FAS_music`;
        }
    })();

    appBaseUrl = defaultAppBaseUrl;
    const defaultApiUrl = `${defaultAppBaseUrl}/api`;
    let storedApiUrl = '';

    try {
        storedApiUrl = sessionStorage.getItem("baseAPIUrl") || '';
    } catch (e) {
        storedApiUrl = '';
    }

    // Prefer stored URL only when it's same-origin or relative
    if (storedApiUrl) {
        try {
            const resolved = new URL(storedApiUrl, window.location.origin);
            if (resolved.origin === window.location.origin) {
                baseApiUrl = resolved.href.replace(/\/$/, '');
            } else {
                baseApiUrl = defaultApiUrl;
            }
        } catch (e) {
            baseApiUrl = defaultApiUrl;
        }
    } else {
        baseApiUrl = defaultApiUrl;
    }

    // Keep global access explicit for inline page scripts
    window.baseApiUrl = baseApiUrl;
    window.appBaseUrl = appBaseUrl;

    // The calendar's "today" follows the application server, which is set to
    // Asia/Manila. The local clock is only a fallback if this small sync call
    // is unavailable (for example, while offline).
    window.fasServerTimeReady = fetch(`${baseApiUrl}/server_time.php`, { credentials: 'same-origin' })
        .then((response) => response.ok ? response.json() : null)
        .then((payload) => {
            const serverEpochMs = Date.parse(String(payload?.now || ''));
            if (!Number.isNaN(serverEpochMs)) {
                fasServerClockOffsetMs = serverEpochMs - Date.now();
                fasServerClockSynced = true;
            }
            return fasServerClockSynced;
        })
        .catch(() => false);

    // Wire axios if available
    if (typeof axios !== 'undefined') {
        axios.defaults.baseURL = baseApiUrl;
        axios.defaults.withCredentials = true;
        axios.defaults.headers.common['Content-Type'] = 'application/json';
        axios.defaults.validateStatus = () => true;

        // Minimal debug help for endpoint/method mismatches (e.g., 405 "Method not allowed")
        try {
            if (!window.__fasAxiosInterceptorInstalled) {
                window.__fasAxiosInterceptorInstalled = true;
                axios.interceptors.request.use((config) => {
                    try {
                        const storedUser = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
                        if (storedUser && storedUser.user_id) {
                            config.headers = config.headers || {};
                            config.headers['X-FAS-Client-User-Id'] = String(storedUser.user_id);
                            config.headers['X-FAS-Client-Role'] = String(storedUser.role_name || '');
                        }
                    } catch (e) {
                        // Ignore header injection failures.
                    }
                    return config;
                });
                axios.interceptors.response.use(
                    (response) => {
                        try {
                            const authCode = String(response?.data?.auth_code || '').toUpperCase();
                            const handledAuthCodes = [
                                'AUTH_REQUIRED',
                                'SESSION_INVALID',
                                'CLIENT_SESSION_MISMATCH',
                                'ACCOUNT_INACTIVE'
                            ];
                            const isAuthFailure = [401, 409, 440].includes(Number(response?.status || 0))
                                && (
                                    handledAuthCodes.includes(authCode)
                                    || response?.data?.authentication_required
                                    || response?.data?.session_invalidated
                                );
                            const isOnLoginPage = /\/(fas_music\/?)?(index\.html)?$/i.test(window.location.pathname);
                            if (isAuthFailure && !isOnLoginPage && typeof Auth !== 'undefined' && Auth.handleSessionInvalidation) {
                                Auth.handleSessionInvalidation(
                                    response?.data?.error || 'Your session is no longer active. Please log in again.'
                                );
                            }
                        } catch (e) {
                            // Ignore auth redirect failures and still return the response.
                        }
                        if (response && typeof response.status === 'number' && response.status >= 400) {
                            const method = (response.config?.method || '').toUpperCase();
                            const url = response.config?.url || '';
                            const serverError = response.data?.error || response.data?.message || '';
                            console.warn(`[API ${response.status}] ${method} ${url}${serverError ? ` -> ${serverError}` : ''}`);
                        }
                        return response;
                    },
                    (error) => {
                        const method = (error?.config?.method || '').toUpperCase();
                        const url = error?.config?.url || '';
                        console.warn(`[API ERROR] ${method} ${url}`, error);
                        return Promise.reject(error);
                    }
                );
            }
        } catch (e) {
            // Ignore interceptor failures
        }
    }
})();

// Let students and guardians verify newly selected proof files without leaving
// the form. Event delegation also covers enrollment dialogs rendered later.
(function initSelectedProofPreview() {
    const previewableInputIds = new Set([
        'regPayProof',
        'regAgeProof',
        'guardian-new-registration-proof',
        'guardian-new-id-proof',
        'studentRequestPaymentProof'
    ]);
    const existingButtonIds = {
        regPayProof: 'regPayProofViewBtn',
        regAgeProof: 'regAgeProofViewBtn'
    };
    let activeObjectUrl = '';

    const closePreview = () => {
        const modal = document.getElementById('selectedProofPreviewModal');
        if (!modal) return;
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        const image = modal.querySelector('[data-proof-preview-image]');
        const frame = modal.querySelector('[data-proof-preview-frame]');
        if (image) image.removeAttribute('src');
        if (frame) frame.removeAttribute('src');
        if (activeObjectUrl) {
            URL.revokeObjectURL(activeObjectUrl);
            activeObjectUrl = '';
        }
    };

    const ensureModal = () => {
        let modal = document.getElementById('selectedProofPreviewModal');
        if (modal) return modal;

        modal = document.createElement('div');
        modal.id = 'selectedProofPreviewModal';
        modal.className = 'fixed inset-0 hidden items-center justify-center bg-black/75 p-3 backdrop-blur-sm sm:p-5';
        modal.style.zIndex = '20000';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'selectedProofPreviewTitle');
        modal.innerHTML = `
            <div class="flex max-h-[92vh] w-full max-w-4xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-zinc-900">
                <div class="flex items-center justify-between gap-3 border-b border-zinc-200 px-4 py-3 dark:border-white/10">
                    <div class="min-w-0">
                        <p class="text-[10px] font-bold uppercase tracking-widest text-gold-600">Selected file</p>
                        <p id="selectedProofPreviewTitle" class="truncate text-sm font-semibold text-zinc-900 dark:text-white"></p>
                    </div>
                    <button type="button" data-proof-preview-close aria-label="Close preview" class="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-zinc-200 text-zinc-500 hover:bg-zinc-100 dark:border-white/10 dark:text-zinc-300 dark:hover:bg-white/10">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="flex min-h-[260px] flex-1 items-center justify-center overflow-auto bg-zinc-100 p-3 dark:bg-black/30 sm:min-h-[420px]">
                    <img data-proof-preview-image alt="Selected proof preview" class="hidden max-h-[75vh] max-w-full object-contain">
                    <iframe data-proof-preview-frame title="Selected PDF preview" class="hidden h-[72vh] w-full rounded-lg bg-white"></iframe>
                    <p data-proof-preview-message class="hidden px-5 text-center text-sm text-zinc-600 dark:text-zinc-300"></p>
                </div>
            </div>`;
        document.body.appendChild(modal);
        modal.addEventListener('click', (event) => {
            if (event.target === modal || event.target.closest('[data-proof-preview-close]')) closePreview();
        });
        return modal;
    };

    const openPreview = (file) => {
        if (!(file instanceof File)) return;
        closePreview();
        const modal = ensureModal();
        const title = modal.querySelector('#selectedProofPreviewTitle');
        const image = modal.querySelector('[data-proof-preview-image]');
        const frame = modal.querySelector('[data-proof-preview-frame]');
        const message = modal.querySelector('[data-proof-preview-message]');
        const isPdf = file.type === 'application/pdf' || /\.pdf$/i.test(file.name);
        const isImage = file.type.startsWith('image/') || /\.(jpe?g|png|webp)$/i.test(file.name);

        title.textContent = file.name;
        image.classList.add('hidden');
        frame.classList.add('hidden');
        message.classList.add('hidden');
        activeObjectUrl = URL.createObjectURL(file);
        if (isPdf) {
            frame.src = activeObjectUrl;
            frame.classList.remove('hidden');
        } else if (isImage) {
            image.src = activeObjectUrl;
            image.classList.remove('hidden');
        } else {
            URL.revokeObjectURL(activeObjectUrl);
            activeObjectUrl = '';
            message.textContent = 'A preview is not available for this file type. Please choose a JPG, PNG, WEBP, or PDF file.';
            message.classList.remove('hidden');
        }
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    };

    const previewButtonFor = (input) => {
        const existingId = existingButtonIds[input.id];
        let button = existingId ? document.getElementById(existingId) : null;
        if (button) return button;
        button = document.createElement('button');
        button.type = 'button';
        button.className = 'mt-2 hidden max-w-full items-center gap-1.5 text-left text-xs font-semibold text-gold-600 hover:underline dark:text-gold-400';
        button.dataset.selectedProofPreviewButton = input.id;
        const namedDisplay = input.id === 'studentRequestPaymentProof'
            ? (document.getElementById('studentRequestProofFileName') || document.getElementById('guardianEnrollmentProofName'))
            : null;
        const anchor = namedDisplay || (input.classList.contains('hidden') ? input.closest('label') : input);
        anchor?.insertAdjacentElement('afterend', button);
        return button;
    };

    document.addEventListener('change', (event) => {
        const input = event.target;
        if (!(input instanceof HTMLInputElement) || input.type !== 'file' || !previewableInputIds.has(input.id)) return;
        const file = input.files?.[0] || null;
        const button = previewButtonFor(input);
        if (!button) return;
        button.textContent = file ? `View selected file: ${file.name}` : '';
        button.classList.toggle('hidden', !file);
        button.classList.toggle('inline-flex', Boolean(file));
        button.onclick = file ? () => openPreview(input.files?.[0]) : null;
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape' && !document.getElementById('selectedProofPreviewModal')?.classList.contains('hidden')) {
            event.preventDefault();
            event.stopImmediatePropagation();
            closePreview();
        }
    }, true);

    window.openSelectedProofFilePreview = openPreview;
})();

// Keep password feedback consistent across account creation, reset, and
// change-password forms. The observer also covers dialogs rendered later by
// SweetAlert and role-specific page scripts.
(function initSharedPasswordStrengthMeters() {
    const MANAGED_REFERENCE_IDS = new Set([
        'registerPassword',
        'guardian-new-password',
        'guardian-custom-password'
    ]);

    const normalizePasswordFieldKey = (input) => String([
        input?.id,
        input?.name,
        input?.getAttribute?.('autocomplete'),
        input?.getAttribute?.('placeholder')
    ].filter(Boolean).join(' ')).toLowerCase();

    const isNewPasswordField = (input) => {
        if (!(input instanceof HTMLInputElement) || input.type !== 'password') return false;
        if (MANAGED_REFERENCE_IDS.has(input.id) || input.dataset.passwordStrengthReady === '1') return false;

        const key = normalizePasswordFieldKey(input);
        if (/confirm|current|old|login/.test(key)) return false;
        if (/new|create|set|password/.test(key) === false) return false;

        const scope = input.closest('form, .swal2-popup, [role="dialog"], .fixed') || document;
        return Array.from(scope.querySelectorAll('input[type="password"]')).some((candidate) => {
            if (candidate === input) return false;
            return /confirm/.test(normalizePasswordFieldKey(candidate));
        });
    };

    const getStrengthState = (password) => {
        if (!password) return { label: 'Password strength', color: '#d4d4d8', filled: 0 };

        let score = 0;
        if (password.length >= 8) score++;
        if (/[A-Z]/.test(password)) score++;
        if (/[a-z]/.test(password)) score++;
        if (/[0-9]/.test(password)) score++;
        if (/[!@#$%^&*]/.test(password)) score++;

        if (score <= 2) return { label: 'Weak password', color: '#ef4444', filled: 1 };
        if (score <= 4) return { label: 'Medium password', color: '#eab308', filled: 3 };
        return { label: 'Strong password', color: '#16a34a', filled: 4 };
    };

    const enhancePasswordField = (input) => {
        if (!isNewPasswordField(input)) return;
        input.dataset.passwordStrengthReady = '1';

        const meter = document.createElement('div');
        meter.className = 'fas-password-strength';
        meter.setAttribute('aria-live', 'polite');
        meter.style.cssText = 'margin-top:8px;padding:10px 12px;border:1px solid #e4e4e7;border-radius:12px;background:#fafafa;text-align:left;';
        meter.innerHTML = `
            <div style="display:flex;gap:5px" aria-hidden="true">
                <span data-strength-bar style="height:4px;flex:1;border-radius:999px;background:#d4d4d8"></span>
                <span data-strength-bar style="height:4px;flex:1;border-radius:999px;background:#d4d4d8"></span>
                <span data-strength-bar style="height:4px;flex:1;border-radius:999px;background:#d4d4d8"></span>
                <span data-strength-bar style="height:4px;flex:1;border-radius:999px;background:#d4d4d8"></span>
            </div>
            <p data-strength-label style="margin:6px 0 0;font-size:12px;line-height:1.25;color:#71717a">Password strength</p>`;
        input.insertAdjacentElement('afterend', meter);

        const bars = Array.from(meter.querySelectorAll('[data-strength-bar]'));
        const label = meter.querySelector('[data-strength-label]');
        const update = () => {
            const state = getStrengthState(String(input.value || ''));
            bars.forEach((bar, index) => {
                bar.style.background = index < state.filled ? state.color : '#d4d4d8';
            });
            label.textContent = state.label;
            label.style.color = state.filled ? state.color : '#71717a';
        };

        input.addEventListener('input', update);
        update();
    };

    const scan = (root = document) => {
        if (root instanceof HTMLInputElement && root.type === 'password') {
            enhancePasswordField(root);
        }
        if (root.querySelectorAll) {
            root.querySelectorAll('input[type="password"]').forEach(enhancePasswordField);
        }
    };

    const start = () => {
        scan(document);
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => mutation.addedNodes.forEach((node) => {
                if (node.nodeType === Node.ELEMENT_NODE) scan(node);
            }));
        });
        observer.observe(document.body, { childList: true, subtree: true });
    };

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', start, { once: true });
    } else {
        start();
    }
})();

let currentStudentId = null;
let currentPaymentRedirectUrl = '';
let currentPaymentSource = '';
let currentRegistration = null;
let pendingRequestsById = {};
let studentDashboardPortalState = null;
let studentDashboardMetaState = null;
let studentRegistrationRestartNotice = false;
let _studentPerformanceRadarChartInstance = null;

// Remove credentials saved by older versions of the student registration flow.
try {
    localStorage.removeItem('student_registration_password');
    sessionStorage.removeItem('student_registration_password');
    localStorage.removeItem('user');
    sessionStorage.removeItem('user');
} catch (e) {
    // Storage can be disabled in some browsers.
}

function normalizeRoleName(role) {
    return String(role || '').trim().toLowerCase().replace(/\s+/g, ' ');
}

function getRoleCategory(role) {
    const normalizedRole = normalizeRoleName(role);
    if (['admin', 'superadmin', 'super admin', 'administrator'].includes(normalizedRole)) {
        return 'admin';
    }
    if (['manager', 'branch manager'].includes(normalizedRole)) {
        return 'manager';
    }
    if (['staff', 'desk', 'front desk'].includes(normalizedRole)) {
        return 'staff';
    }
    if (['instructor', 'instructors', 'teacher', 'teachers'].includes(normalizedRole)) {
        return 'instructor';
    }
    if (normalizedRole === 'student') {
        return 'student';
    }
    if (['guardian', 'guardians'].includes(normalizedRole)) {
        return 'guardian';
    }
    return normalizedRole;
}

// Authentication Utility (integrated) - with storage access protection
const Auth = {
    _sessionValidationPromise: null,
    _sessionInvalidationHandled: false,

    // ── BroadcastChannel for instant cross-tab logout / login sync ──────────
    // Falls back gracefully in browsers that don't support BroadcastChannel.
    _channel: (() => {
        try {
            return typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('fas_auth') : null;
        } catch (e) {
            return null;
        }
    })(),

    _initChannel() {
        if (!this._channel) return;
        this._channel.onmessage = (event) => {
            const msg = event.data || {};
            if (msg.type === 'logout') {
                // Another tab logged out — silently clear local data and redirect.
                this._sessionInvalidationHandled = true;
                this.clearStoredUser();
                this.redirectToLogin();
            } else if (msg.type === 'login' && msg.user) {
                // Another tab logged in — adopt that user so this tab is also authenticated.
                this._sessionInvalidationHandled = false;
                this._writeLocalUser(msg.user);
            }
        };
    },

    _broadcastLogout() {
        try { if (this._channel) this._channel.postMessage({ type: 'logout' }); } catch (e) { /* ignore */ }
        // localStorage fallback for Safari / older browsers that lack BroadcastChannel.
        try { localStorage.setItem('fas_session_logout', '1'); } catch (e) { /* ignore */ }
        try { localStorage.removeItem('fas_session_logout'); }   catch (e) { /* ignore */ }
    },

    _broadcastLogin(user) {
        try { if (this._channel) this._channel.postMessage({ type: 'login', user }); } catch (e) { /* ignore */ }
    },

    // ── Low-level localStorage read/write (shared across all same-browser tabs) ──
    _publicUser(user) {
        if (!user || typeof user !== 'object' || !Number(user.user_id)) return null;
        const allowed = ['user_id', 'username', 'first_name', 'last_name', 'email', 'phone',
            'status', 'role_name', 'role_id', 'branch_id', 'branch_name',
            'student_id', 'guardian_id', 'teacher_id'];
        return Object.fromEntries(allowed.filter(key => Object.prototype.hasOwnProperty.call(user, key))
            .map(key => [key, user[key]]));
    },

    _readLocalUser() {
        try {
            const str = localStorage.getItem('fas_user');
            if (!str) return null;
            const parsed = JSON.parse(str);
            const safeUser = this._publicUser(parsed);
            if (safeUser && JSON.stringify(safeUser) !== str) this._writeLocalUser(safeUser);
            return safeUser;
        } catch (e) {
            return null;
        }
    },

    _writeLocalUser(user) {
        try {
            const safeUser = this._publicUser(user);
            if (safeUser) localStorage.setItem('fas_user', JSON.stringify(safeUser));
        } catch (e) {
            console.warn('Unable to save user to localStorage. Storage access may be blocked.');
        }
    },

    _clearLocalUser() {
        try { localStorage.removeItem('fas_user'); }                         catch (e) { /* ignore */ }
        try { localStorage.removeItem('user'); }                             catch (e) { /* ignore */ }
        try { localStorage.removeItem('student_registration_password'); }    catch (e) { /* ignore */ }
        try { sessionStorage.removeItem('user'); }                           catch (e) { /* ignore */ }
        try { sessionStorage.removeItem('student_registration_password'); }  catch (e) { /* ignore */ }
        try {
            const privateStatePrefixes = ['fas_freeze_restored_', 'fas_guardian_session_', 'fas_student_session_completed_'];
            for (let index = localStorage.length - 1; index >= 0; index--) {
                const key = localStorage.key(index);
                if (key && privateStatePrefixes.some(prefix => key.startsWith(prefix))) localStorage.removeItem(key);
            }
        } catch (e) { /* ignore */ }
    },

    // ── Public API ───────────────────────────────────────────────────────────

    // Returns the currently logged-in user from shared localStorage (synchronous,
    // works across all tabs in the same browser).
    getUser() {
        return this._readLocalUser();
    },

    // Persists the logged-in user and notifies all other tabs.
    setUser(user) {
        this._sessionInvalidationHandled = false;
        const safeUser = this._publicUser(user);
        this._writeLocalUser(safeUser);
        this._broadcastLogin(safeUser);
    },

    // Wipes stored user data from all storage mechanisms.
    clearStoredUser() {
        this._clearLocalUser();
    },

    redirectToLogin() {
        const appBase = (typeof appBaseUrl === 'string' && appBaseUrl)
            ? appBaseUrl
            : ((typeof baseApiUrl === 'string' && baseApiUrl.endsWith('/api'))
                ? baseApiUrl.slice(0, -4)
                : `${window.location.origin}/FAS_music`);
        window.location.href = `${appBase}/index.html`;
    },

    handleSessionInvalidation(message) {
        if (this._sessionInvalidationHandled) {
            return;
        }
        this._sessionInvalidationHandled = true;
        this.clearStoredUser();

        const redirect = () => this.redirectToLogin();
        if (typeof Swal !== 'undefined' && !/\/(fas_music\/?)?(index\.html)?$/i.test(window.location.pathname)) {
            Swal.fire({
                icon: 'warning',
                title: 'Session Ended',
                text: message || 'Your session is no longer active. Please log in again.',
                confirmButtonColor: '#b8860b',
                allowOutsideClick: false,
                allowEscapeKey: false
            }).then(redirect);
        } else {
            redirect();
        }
    },

    // Contacts the server to verify the signed authentication cookie is still valid.
    // If the server returns a user record, that becomes the authoritative copy
    // and is pushed to localStorage (and broadcast to other tabs via setUser).
    async validateServerSession(options = {}) {
        // Skip session validation on public pages
        if (window.isPublicPage) {
            return { valid: false, reason: 'public_page_no_session' };
        }

        if (this._sessionValidationPromise) {
            return this._sessionValidationPromise;
        }

        const { silent = false } = options;
        this._sessionValidationPromise = (async () => {
            try {
                const response = await axios.get(`${baseApiUrl}/users.php?action=session`, {
                    validateStatus: () => true
                });
                const data = response.data || {};
                if (response.status === 200 && data.success && data.user) {
                    this.setUser(data.user);
                    return { valid: true, user: data.user };
                }

                if (!silent) {
                    this.handleSessionInvalidation(
                        data.error || 'Your session is no longer active. Please log in again.'
                    );
                }
                return { valid: false, reason: data.auth_code || 'session_invalid' };
            } catch (error) {
                if (!silent) {
                    this.handleSessionInvalidation('Unable to verify your session. Please log in again.');
                }
                return { valid: false, reason: 'session_validation_failed', error };
            } finally {
                this._sessionValidationPromise = null;
            }
        })();

        return this._sessionValidationPromise;
    },

    // Logs out the current user: notifies the server, clears local storage,
    // broadcasts to all other tabs, then redirects to login.
    logout() {
        this._sessionInvalidationHandled = true;
        this._broadcastLogout();

        const redirect = () => {
            this.clearStoredUser();
            this.redirectToLogin();
        };

        if (typeof axios !== 'undefined') {
            axios.post(`${baseApiUrl}/users.php?action=logout`, {}, { validateStatus: () => true })
                .catch(() => {})
                .finally(redirect);
            return;
        }

        redirect();
    },

    isAuthenticated() {
        return this.getUser() !== null;
    },

    hasRole(role) {
        const user = this.getUser();
        if (!user) return false;
        const actualRole = getRoleCategory(user.role_name);
        const targetRole = getRoleCategory(role);
        return actualRole === targetRole || actualRole === 'admin';
    }
};

// Initialise the cross-tab broadcast channel listener immediately.
Auth._initChannel();
Auth._readLocalUser(); // Rewrite any older stored profile without sensitive fields.

// ── localStorage storage-event fallback for browsers without BroadcastChannel ──
// (BroadcastChannel does NOT fire for the tab that wrote the key, so this is safe.)
window.addEventListener('storage', (e) => {
    if (e.key === 'fas_session_logout' && e.newValue === '1') {
        Auth._sessionInvalidationHandled = true;
        Auth.clearStoredUser();
        Auth.redirectToLogin();
    }
    // When another tab logs in and writes fas_user, adopt that user here too.
    if (e.key === 'fas_user' && e.newValue) {
        try {
            const user = JSON.parse(e.newValue);
            if (user && typeof user === 'object') {
                Auth._sessionInvalidationHandled = false;
                // No need to call setUser (would re-broadcast); just update local state.
                // The page will use the updated localStorage on its next getUser() call.
            }
        } catch (_) { /* ignore */ }
    }
});

function isProtectedPortalPage() {
    return /\/pages\//i.test(window.location.pathname);
}

function getProtectedPortalPolicy() {
    const pathname = String(window.location.pathname || '').replace(/\\/g, '/').toLowerCase();
    if (pathname.includes('/pages/admin/')) {
        return { role: 'admin', label: 'Admin' };
    }
    if (pathname.includes('/pages/manager/')) {
        return { role: 'branch', label: 'Manager' };
    }
    if (pathname.includes('/pages/desk/')) {
        return { role: 'branch', label: 'Desk/Manager' };
    }
    if (pathname.includes('/pages/instructor/')) {
        return { role: 'instructor', label: 'Instructor' };
    }
    if (pathname.includes('/pages/student/')) {
        return { role: 'student', label: 'Student' };
    }
    if (pathname.includes('/pages/guardian/')) {
        return { role: 'guardian', label: 'Guardian' };
    }
    return null;
}

function isRoleAllowedForPolicy(roleCategory, policyRole) {
    if (policyRole === 'branch') {
        return roleCategory === 'manager' || roleCategory === 'staff';
    }
    return roleCategory === policyRole;
}

// On protected pages:
//  1. If localStorage already has the user (e.g. existing tab or after login) → validate with server.
//  2. If localStorage is empty (e.g. freshly opened Tab 2) → ask the server; it will return the
//     active session because the browser's HttpOnly JWT cookie is shared across all tabs.
async function ensureProtectedPageSession() {
    if (!isProtectedPortalPage()) {
        return;
    }

    const policy = getProtectedPortalPolicy();
    const root = document.body || document.documentElement;
    if (root) {
        root.style.visibility = 'hidden';
    }

    const localUser = Auth.getUser();
    let result = null;

    if (localUser) {
        // User found in localStorage — verify the server-side authentication state.
        result = await Auth.validateServerSession({ silent: true });
    } else {
        // No local user (new tab, incognito carry-over, etc.) — try to hydrate from
        // the signed JWT cookie. The cookie is automatically sent by the browser.
        result = await Auth.validateServerSession({ silent: true });
    }

    const user = result?.user || Auth.getUser();
    const roleCategory = getRoleCategory(user?.role_name);
    const allowed = !policy || isRoleAllowedForPolicy(roleCategory, policy.role);

    if (!result?.valid || !allowed) {
        if (root) {
            root.style.visibility = '';
        }
        if (policy && !allowed && result?.valid) {
            Auth.handleSessionInvalidation(`You must be logged in as ${policy.label} to access this page.`);
        } else {
            // Authentication is gone or invalid — redirect to login.
            Auth.redirectToLogin();
        }
        return;
    }

    if (root) {
        root.style.visibility = '';
    }
}

window.__fasAuthReady = ensureProtectedPageSession();

// ========== INDEX.HTML FUNCTIONS ==========

// Toggle Login Modal
function toggleLoginModal(show) {
    const modal = document.getElementById('loginModal');
    if (!modal) return;

    if (show) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    } else {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        // Reset form
        const form = document.getElementById('loginForm');
        if (form) form.reset();
        const msg = document.getElementById('loginMessage');
        if (msg) msg.classList.add('hidden');
    }
}

// Toggle Register Modal
function toggleRegisterModal(show) {
    const modal = document.getElementById('registerModal');
    if (!modal) return;

    if (show) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    } else {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        // Reset form
        const form = document.getElementById('registerForm');
        if (form) form.reset();
        const msg = document.getElementById('registerMessage');
        if (msg) msg.classList.add('hidden');
        const checkbox = document.getElementById('parentAgreementCheckbox');
        if (checkbox) checkbox.checked = false;
        syncParentAgreementConsentState();
    }
}

// Toggle Parent Agreement Modal
function toggleParentAgreementModal(show) {
    const modal = document.getElementById('parentAgreementModal');
    if (!modal) return;

    if (show) {
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    } else {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
    }
}

// Keep the registration button gated behind the acknowledgment checkbox
function syncParentAgreementConsentState() {
    const checkbox = document.getElementById('parentAgreementCheckbox');
    const button = document.getElementById('registerSubmitBtn');
    if (!checkbox || !button) return;

    const disabled = !checkbox.checked;
    button.disabled = disabled;
    button.classList.toggle('opacity-60', disabled);
    button.classList.toggle('cursor-not-allowed', disabled);
}

// Make the modal helpers available to inline onclick handlers.
window.toggleParentAgreementModal = toggleParentAgreementModal;
window.syncParentAgreementConsentState = syncParentAgreementConsentState;

// Toggle Password Visibility
function togglePassword(inputId, iconId) {
    const input = document.getElementById(inputId);
    const icon = document.getElementById(iconId);

    if (!input || !icon) return;

    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

// Validate Password Policy
function validatePassword() {
    const password = document.getElementById('registerPassword')?.value || '';
    const requirements = {
        length: password.length >= 8,
        uppercase: /[A-Z]/.test(password),
        lowercase: /[a-z]/.test(password),
        number: /[0-9]/.test(password),
        special: /[!@#$%^&*]/.test(password)
    };

    // Update requirement indicators
    updateRequirement('req-length', requirements.length);
    updateRequirement('req-uppercase', requirements.uppercase);
    updateRequirement('req-lowercase', requirements.lowercase);
    updateRequirement('req-number', requirements.number);
    updateRequirement('req-special', requirements.special);

    const strengthBars = Array.from(document.querySelectorAll('[data-register-strength-bar]'));
    const strengthText = document.getElementById('registerPasswordStrengthText');
    const score = Object.values(requirements).filter(Boolean).length;
    let strengthLabel = 'Password strength';
    let strengthColor = '#d4d4d8';
    let filledBars = 0;

    if (password && score <= 2) {
        strengthLabel = 'Weak password';
        strengthColor = '#ef4444';
        filledBars = 1;
    } else if (password && score <= 4) {
        strengthLabel = 'Medium password';
        strengthColor = '#eab308';
        filledBars = 3;
    } else if (password) {
        strengthLabel = 'Strong password';
        strengthColor = '#16a34a';
        filledBars = 4;
    }

    strengthBars.forEach((bar, index) => {
        bar.style.backgroundColor = index < filledBars ? strengthColor : '#d4d4d8';
    });
    if (strengthText) {
        strengthText.textContent = strengthLabel;
        strengthText.style.color = filledBars ? strengthColor : '';
    }

    // Validate password match if confirm field has value
    if (document.getElementById('registerPasswordConfirm')?.value) {
        validatePasswordMatch();
    }

    return Object.values(requirements).every(req => req === true);
}

// Update requirement indicator
function updateRequirement(id, met) {
    const element = document.getElementById(id);
    if (!element) return;

    const icon = element.querySelector('i');
    if (met) {
        icon.classList.remove('fa-circle', 'text-zinc-300', 'text-zinc-600');
        icon.classList.add('fa-check-circle', 'text-green-500');
    } else {
        icon.classList.remove('fa-check-circle', 'text-green-500');
        icon.classList.add('fa-circle', 'text-zinc-300');
    }
}

// Validate Password Match
function validatePasswordMatch() {
    const password = document.getElementById('registerPassword')?.value || '';
    const confirm = document.getElementById('registerPasswordConfirm')?.value || '';
    const matchDiv = document.getElementById('passwordMatch');

    if (!matchDiv) return;

    if (confirm.length === 0) {
        matchDiv.textContent = '';
        matchDiv.className = 'mt-2 text-xs';
        return;
    }

    if (password === confirm) {
        matchDiv.textContent = '✓ Passwords match';
        matchDiv.className = 'mt-2 text-xs text-green-500';
        return true;
    } else {
        matchDiv.textContent = '✗ Passwords do not match';
        matchDiv.className = 'mt-2 text-xs text-red-500';
        return false;
    }
}

// Mobile Menu Toggle
function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobile-menu');
    const menuIcon = document.getElementById('menu-icon');

    if (!mobileMenu || !menuIcon) return;

    if (mobileMenu.classList.contains('hidden')) {
        mobileMenu.classList.remove('hidden');
        menuIcon.classList.remove('fa-bars');
        menuIcon.classList.add('fa-times');
    } else {
        mobileMenu.classList.add('hidden');
        menuIcon.classList.remove('fa-times');
        menuIcon.classList.add('fa-bars');
    }
}

function escapeAuthHtml(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function getPremiumAuthVisual(type) {
    const normalized = ['success', 'error', 'info'].includes(type) ? type : 'error';
    const visuals = {
        success: {
            label: 'Success',
            color: '#059669'
        },
        error: {
            label: 'Action needed',
            color: '#e11d48'
        },
        info: {
            label: 'Notice',
            color: '#b8860b'
        }
    };
    return visuals[normalized];
}

function hexToLottieColor(hex) {
    const normalized = String(hex || '#b8860b').replace('#', '');
    const full = normalized.length === 3
        ? normalized.split('').map((char) => char + char).join('')
        : normalized.padEnd(6, '0').slice(0, 6);
    return [0, 2, 4].map((start) => parseInt(full.slice(start, start + 2), 16) / 255).concat(1);
}

function buildAuthLottieSrc(type) {
    const visual = getPremiumAuthVisual(type);
    const color = hexToLottieColor(visual.color);
    const mutedColor = type === 'error' ? hexToLottieColor('#ffe4e6') : (type === 'success' ? hexToLottieColor('#d1fae5') : hexToLottieColor('#fef3c7'));
    const animation = {
        v: '5.7.4',
        fr: 30,
        ip: 0,
        op: 90,
        w: 140,
        h: 140,
        nm: 'Auth music status',
        ddd: 0,
        assets: [],
        layers: [
            {
                ddd: 0,
                ind: 1,
                ty: 4,
                nm: 'Soft ring',
                sr: 1,
                ks: {
                    o: { a: 0, k: 100 },
                    r: { a: 0, k: 0 },
                    p: { a: 0, k: [70, 70, 0] },
                    a: { a: 0, k: [0, 0, 0] },
                    s: { a: 0, k: [100, 100, 100] }
                },
                shapes: [{
                    ty: 'gr',
                    it: [
                        { ty: 'el', p: { a: 0, k: [0, 0] }, s: { a: 0, k: [90, 90] } },
                        { ty: 'st', c: { a: 0, k: mutedColor }, o: { a: 0, k: 100 }, w: { a: 0, k: 8 }, lc: 2, lj: 2 },
                        { ty: 'tr', p: { a: 0, k: [0, 0] }, a: { a: 0, k: [0, 0] }, s: { a: 0, k: [100, 100] }, r: { a: 0, k: 0 }, o: { a: 0, k: 100 } }
                    ]
                }],
                ip: 0,
                op: 90,
                st: 0,
                bm: 0
            },
            {
                ddd: 0,
                ind: 2,
                ty: 4,
                nm: 'Loading ring',
                sr: 1,
                ks: {
                    o: { a: 0, k: 100 },
                    r: { a: 1, k: [{ t: 0, s: [0] }, { t: 90, s: [720] }] },
                    p: { a: 0, k: [70, 70, 0] },
                    a: { a: 0, k: [0, 0, 0] },
                    s: { a: 0, k: [100, 100, 100] }
                },
                shapes: [{
                    ty: 'gr',
                    it: [
                        { ty: 'el', p: { a: 0, k: [0, 0] }, s: { a: 0, k: [90, 90] } },
                        { ty: 'st', c: { a: 0, k: color }, o: { a: 0, k: 100 }, w: { a: 0, k: 8 }, lc: 2, lj: 2 },
                        { ty: 'tm', s: { a: 0, k: 8 }, e: { a: 0, k: 66 }, o: { a: 0, k: 0 } },
                        { ty: 'tr', p: { a: 0, k: [0, 0] }, a: { a: 0, k: [0, 0] }, s: { a: 0, k: [100, 100] }, r: { a: 0, k: 0 }, o: { a: 0, k: 100 } }
                    ]
                }],
                ip: 0,
                op: 90,
                st: 0,
                bm: 0
            },
            {
                ddd: 0,
                ind: 3,
                ty: 4,
                nm: 'Music note',
                sr: 1,
                ks: {
                    o: { a: 0, k: 100 },
                    r: { a: 0, k: -8 },
                    p: { a: 0, k: [70, 66, 0] },
                    a: { a: 0, k: [0, 0, 0] },
                    s: { a: 1, k: [{ t: 0, s: [72, 72, 100] }, { t: 14, s: [112, 112, 100] }, { t: 26, s: [100, 100, 100] }, { t: 90, s: [100, 100, 100] }] }
                },
                shapes: [{
                    ty: 'gr',
                    it: [
                        { ty: 'el', p: { a: 0, k: [-14, 23] }, s: { a: 0, k: [28, 22] } },
                        { ty: 'fl', c: { a: 0, k: color }, o: { a: 0, k: 100 }, r: 1 },
                        { ty: 'rc', p: { a: 0, k: [0, 0] }, s: { a: 0, k: [8, 58] }, r: { a: 0, k: 4 } },
                        { ty: 'fl', c: { a: 0, k: color }, o: { a: 0, k: 100 }, r: 1 },
                        {
                            ty: 'sh',
                            ks: {
                                a: 0,
                                k: {
                                    i: [[0, 0], [0, 0], [0, 0], [0, 0]],
                                    o: [[0, 0], [0, 0], [0, 0], [0, 0]],
                                    v: [[4, -28], [34, -18], [34, -5], [4, -14]],
                                    c: true
                                }
                            }
                        },
                        { ty: 'fl', c: { a: 0, k: color }, o: { a: 0, k: 100 }, r: 1 },
                        { ty: 'tr', p: { a: 0, k: [8, 0] }, a: { a: 0, k: [0, 0] }, s: { a: 0, k: [100, 100] }, r: { a: 0, k: 0 }, o: { a: 0, k: 100 } }
                    ]
                }],
                ip: 0,
                op: 90,
                st: 0,
                bm: 0
            }
        ]
    };

    return `data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(animation))}`;
}

function buildPremiumAuthHtml({ type = 'error', title = '', message = '', context = 'login' }) {
    const lottieSrc = buildAuthLottieSrc(type);
    const safeTitle = escapeAuthHtml(title || (type === 'success' ? 'Success' : type === 'info' ? 'Notice' : 'Something went wrong'));
    const safeMessage = escapeAuthHtml(message);

    return `
        <div class="auth-premium-card">
            <div class="auth-premium-lottie-wrap auth-premium-lottie-${type}">
                <lottie-player class="auth-premium-lottie" src="${lottieSrc}" background="transparent" speed="1" loop autoplay></lottie-player>
                <span class="auth-premium-note" aria-hidden="true">
                    <i class="fas fa-music"></i>
                </span>
            </div>
            <h2 class="auth-premium-title">${safeTitle}</h2>
            <p class="auth-premium-message">${safeMessage}</p>
        </div>
    `;
}

function showPremiumAuthMessage(options = {}) {
    const type = ['success', 'error', 'info'].includes(options.type) ? options.type : 'error';
    if (typeof Swal !== 'undefined') {
        const hasTimerOption = Object.prototype.hasOwnProperty.call(options, 'timer');
        return Swal.fire({
            html: buildPremiumAuthHtml({ ...options, type }),
            width: 'auto',
            padding: 0,
            background: 'transparent',
            icon: undefined,
            showConfirmButton: options.showConfirmButton ?? type !== 'success',
            confirmButtonText: options.confirmButtonText || 'Got it',
            timer: hasTimerOption ? options.timer : (type === 'success' ? 1600 : undefined),
            timerProgressBar: options.timerProgressBar ?? type === 'success',
            buttonsStyling: false,
            showClass: {
                popup: 'auth-premium-show'
            },
            hideClass: {
                popup: 'auth-premium-hide'
            },
            customClass: {
                popup: `auth-premium-popup auth-premium-${type}`,
                htmlContainer: 'auth-premium-html',
                confirmButton: 'auth-premium-confirm',
                timerProgressBar: 'auth-premium-progress'
            }
        });
    }

    alert(options.message || options.title || 'Authentication message');
    return Promise.resolve();
}

// Show Message Helper (SweetAlert)
function showLoginMessage(message, type = 'error', title = '') {
    return showPremiumAuthMessage({
        type,
        context: 'login',
        title: title || (type === 'success' ? 'Login Successful' : type === 'info' ? 'Account Notice' : 'Login Failed'),
        message,
        detail: type === 'success' ? 'Preparing your dashboard.' : 'Please review your credentials and try again.'
    });
}

function showRegisterMessage(message, type = 'error', title = '') {
    return showPremiumAuthMessage({
        type,
        context: 'register',
        title: title || (type === 'success' ? 'Account Created' : type === 'info' ? 'Registration Notice' : 'Registration Failed'),
        message,
        detail: type === 'success' ? 'Check your email verification step next.' : 'Please review the highlighted registration details.',
        showConfirmButton: type === 'success' ? true : undefined,
        timer: type === 'success' ? null : undefined,
        timerProgressBar: type === 'success' ? false : undefined,
        confirmButtonText: type === 'success' ? 'Continue' : undefined
    });
}

async function promptEmailVerification(email, initialCode = '') {
    const verificationEmail = String(email || '').trim();
    let currentCode = String(initialCode || '').trim();
    if (!verificationEmail) {
        showRegisterMessage('Email address is required for verification.', 'error');
        return false;
    }

    if (typeof Swal === 'undefined') {
        showRegisterMessage('Verification code prompt is unavailable.', 'error');
        return false;
    }

    // ── Helper: build and show the 6-box OTP dialog ───────────────
    function showOtpDialog(prefill = '') {
        const digits = (prefill + '      ').slice(0, 6).split('');
        return Swal.fire({
            title: 'Verify Your Email',
            html: `
                <p class="swal2-html-container" style="margin:0 0 20px;font-size:0.95rem;color:#6b7280;">
                    We sent a 6-digit code to<br>
                    <strong style="color:#0f172a">${verificationEmail}</strong>
                </p>
                <div id="otpBoxes" style="display:flex;justify-content:center;gap:10px;margin:0 auto 6px;">
                    ${[0,1,2,3,4,5].map(i => `
                    <input id="otp${i}" type="text" inputmode="numeric" maxlength="1"
                        value="${digits[i].trim()}"
                        style="width:48px;height:56px;border:2px solid #e2e8f0;border-radius:12px;
                               text-align:center;font-size:1.5rem;font-weight:700;color:#0f172a;
                               outline:none;transition:border-color .15s,box-shadow .15s;
                               background:#f8fafc;"
                        oninput="
                            this.value=this.value.replace(/[^0-9]/g,'').slice(-1);
                            if(this.value){
                                var n=document.getElementById('otp${i < 5 ? i+1 : i}');
                                if(n){n.focus();n.select();}
                            }
                        "
                        onkeydown="
                            if(event.key==='Backspace'&&!this.value){
                                var p=document.getElementById('otp${i > 0 ? i-1 : 0}');
                                if(p){p.focus();p.select();}
                            }
                            if(event.key==='ArrowLeft'){
                                var p=document.getElementById('otp${i > 0 ? i-1 : 0}');
                                if(p){p.focus();p.select();}
                            }
                            if(event.key==='ArrowRight'){
                                var n=document.getElementById('otp${i < 5 ? i+1 : 5}');
                                if(n){n.focus();n.select();}
                            }
                        "
                        onfocus="this.style.borderColor='#d4af37';this.style.boxShadow='0 0 0 3px rgba(212,175,55,0.2)';"
                        onblur="this.style.borderColor='#e2e8f0';this.style.boxShadow='none';"
                        onpaste="
                            event.preventDefault();
                            var p=event.clipboardData.getData('text').replace(/[^0-9]/g,'').slice(0,6);
                            for(var k=0;k<6;k++){
                                var b=document.getElementById('otp'+k);
                                if(b) b.value=p[k]||'';
                            }
                            var last=document.getElementById('otp'+(Math.min(p.length,5)));
                            if(last){last.focus();last.select();}
                        "
                    >
                    `).join('')}
                </div>
                <p style="font-size:0.75rem;color:#94a3b8;text-align:center;margin-top:4px;">
                    Check your spam folder if you don't see it.
                </p>
            `,
            showCancelButton: true,
            showDenyButton: true,
            confirmButtonText: '<i class="fas fa-check" style="margin-right:6px"></i>Verify',
            denyButtonText: '<i class="fas fa-rotate-right" style="margin-right:6px"></i>Resend',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#b8860b',
            denyButtonColor: '#475569',
            cancelButtonColor: '#6b7280',
            allowOutsideClick: false,
            focusConfirm: false,
            didOpen: () => {
                // Focus first empty box, or first box if prefilled
                const first = document.getElementById('otp0');
                if (first) {
                    first.focus();
                    if (first.value) first.select();
                }
            },
            preConfirm: () => {
                const code = [0,1,2,3,4,5]
                    .map(i => (document.getElementById('otp'+i)?.value || '').trim())
                    .join('');
                if (code.length !== 6 || !/^\d{6}$/.test(code)) {
                    Swal.showValidationMessage('Please enter all 6 digits.');
                    return false;
                }
                return code;
            }
        });
    }

    // ── Main loop ──────────────────────────────────────────────────
    while (true) {
        const result = await showOtpDialog(currentCode);

        if (result.isDismissed) {
            return false;
        }

        if (result.isDenied) {
            try {
                const resendResponse = await axios.post(
                    `${baseApiUrl}/users.php?action=resend-email-verification`,
                    { email: verificationEmail },
                    { validateStatus: () => true }
                );
                const resendData = resendResponse.data || {};
                if (resendResponse.status === 200 && resendData.success) {
                    if (!resendData.verification_email_sent) {
                        throw new Error(resendData.mail_error || resendData.message || 'Unable to send verification email.');
                    }
                    await Swal.fire({
                        icon: 'success',
                        title: 'Code Resent',
                        text: resendData.message || 'A new verification code has been sent to your email.',
                        confirmButtonColor: '#b8860b'
                    });
                } else {
                    throw new Error(resendData.error || 'Unable to resend verification code.');
                }
            } catch (error) {
                const message = error?.response?.data?.error || error?.message || 'Unable to resend verification code.';
                await Swal.fire({
                    icon: 'error',
                    title: 'Resend Failed',
                    text: message,
                    confirmButtonColor: '#b8860b'
                });
            }
            currentCode = '';
            continue;
        }

        const code = String(result.value || '').trim();
        if (!code) { currentCode = ''; continue; }

        try {
            const verifyResponse = await axios.post(
                `${baseApiUrl}/users.php?action=verify-email`,
                { email: verificationEmail, code },
                { validateStatus: () => true }
            );
            const verifyData = verifyResponse.data || {};

            if (verifyResponse.status === 200 && verifyData.success) {
                await Swal.fire({
                    icon: 'success',
                    title: 'Email Verified',
                    text: verifyData.message || 'Your email has been verified successfully.',
                    confirmButtonColor: '#b8860b'
                });
                return true;
            }

            const message = verifyData.error || verifyData.message || 'Verification failed. Please try again.';
            await Swal.fire({
                icon: 'error',
                title: 'Incorrect Code',
                text: message,
                confirmButtonColor: '#b8860b'
            });
            currentCode = '';

            if (verifyData.resend_required) { continue; }
        } catch (error) {
            const message = error?.response?.data?.error || error?.message || 'Verification failed. Please try again.';
            await Swal.fire({
                icon: 'error',
                title: 'Verification Failed',
                text: message,
                confirmButtonColor: '#b8860b'
            });
            currentCode = '';
        }
    }
}

// Login Form Handler
function initLoginForm() {
    const loginForm = document.getElementById('loginForm');
    if (!loginForm) return;

    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const username = document.getElementById('loginUsername')?.value.trim();
        const password = document.getElementById('loginPassword')?.value;
        const loginBtn = document.getElementById('loginBtn');
        const loginBtnText = document.getElementById('loginBtnText');
        const loginBtnIcon = document.getElementById('loginBtnIcon');

        if (!username || !password) {
            showLoginMessage('Please enter your Student ID or guardian email, plus your password.', 'error');
            return;
        }

        // Disable button
        if (loginBtn) loginBtn.disabled = true;
        if (loginBtnText) loginBtnText.textContent = 'Signing in...';
        if (loginBtnIcon) {
            loginBtnIcon.classList.add('fa-spinner', 'fa-spin');
            loginBtnIcon.classList.remove('fa-sign-in-alt');
        }

        try {
            const response = await axios.post(
                `${baseApiUrl}/users.php?action=login`,
                { username, password },
                { validateStatus: () => true }
            );
            const data = response.data || {};

            if (response.status === 200 && data.success && data.user) {
                // Temporary passwords issued by an administrator must be replaced
                // before the user can continue to a dashboard.
                if (data.must_change_password) {
                    const passwordChanged = await promptPasswordChange(data.user, password);

                    if (!passwordChanged) {
                        if (loginBtn) loginBtn.disabled = false;
                        if (loginBtnText) loginBtnText.textContent = 'Sign In';
                        if (loginBtnIcon) {
                            loginBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                            loginBtnIcon.classList.add('fa-sign-in-alt');
                        }
                        return;
                    }

                    // The login request created a server session so the password
                    // change could be authenticated. End it before asking the user
                    // to sign in with the new password.
                    await axios.post(`${baseApiUrl}/users.php?action=logout`, {}, {
                        validateStatus: () => true
                    });
                    Auth.clearStoredUser();

                    // Ask user to log in again after password change
                    Swal.fire({
                        icon: 'success',
                        title: 'Please Login Again',
                        text: 'Use your new password to login.',
                        confirmButtonColor: '#b8860b'
                    });

                    if (loginBtn) loginBtn.disabled = false;
                    if (loginBtnText) loginBtnText.textContent = 'Sign In';
                    if (loginBtnIcon) {
                        loginBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                        loginBtnIcon.classList.add('fa-sign-in-alt');
                    }
                    return;
                }

                // Store the public user profile for navigation and display.
                Auth.setUser(data.user);

                showLoginMessage('Welcome back. Redirecting to your dashboard...', 'success', 'Login Successful');

                // Redirect based on role
                setTimeout(() => {
                    const roleCategory = getRoleCategory(data.user.role_name);
                    if (roleCategory === 'admin') {
                        window.location.href = 'pages/admin/admin_dashboard.html';
                    } else if (roleCategory === 'manager') {
                        window.location.href = 'pages/manager/manager_dashboard.html';
                    } else if (roleCategory === 'staff') {
                        window.location.href = 'pages/desk/desk_attendance.html';
                    } else if (roleCategory === 'instructor') {
                        window.location.href = 'pages/instructor/instructor_dashboard.html';
                    } else if (roleCategory === 'student') {
                        window.location.href = 'pages/student/student_dashboard.html';
                    } else if (roleCategory === 'guardian') {
                        window.location.href = 'pages/guardian/guardian_dashboard.html';
                    } else {
                        window.location.href = 'index.html';
                    }
                }, 1500);
            } else {
                const apiMessage = data && typeof data === 'object' ? data.error : '';
                const status = response.status;
                if (status === 403 && data && data.verification_required) {
                    await promptEmailVerification(data.verification_email || username);
                    if (loginBtn) loginBtn.disabled = false;
                    if (loginBtnText) loginBtnText.textContent = 'Sign In';
                    if (loginBtnIcon) {
                        loginBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                        loginBtnIcon.classList.add('fa-sign-in-alt');
                    }
                    return;
                }
                const message = (data && data.warning_message)
                    ? data.warning_message
                    : apiMessage
                        ? apiMessage
                        : status === 401
                            ? 'Invalid username or password.'
                            : status === 423
                                ? 'Your account has been deactivated. Please contact the administrator.'
                                : status === 403
                                    ? 'Your account was deactivated. Please contact the administrator.'
                                    : 'An error occurred. Please try again.';

                const isNotice = status === 403
                    || status === 423
                    || data?.warning
                    || /pending|deactivated|locked/i.test(message);
                const title = isNotice ? 'Account Notice' : status === 401 ? 'Login Failed' : 'Error';
                const icon = isNotice ? 'info' : 'error';

                showLoginMessage(message, icon === 'info' ? 'info' : 'error', title || 'Account Notice');
                if (loginBtn) loginBtn.disabled = false;
                if (loginBtnText) loginBtnText.textContent = 'Sign In';
                if (loginBtnIcon) {
                    loginBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                    loginBtnIcon.classList.add('fa-sign-in-alt');
                }
            }
        } catch (error) {
            const status = error?.response?.status;
            const apiMessage = error?.response?.data?.error;
            if (status === 403 && error?.response?.data?.verification_required) {
                await promptEmailVerification(error?.response?.data?.verification_email || username);
                if (loginBtn) loginBtn.disabled = false;
                if (loginBtnText) loginBtnText.textContent = 'Sign In';
                if (loginBtnIcon) {
                    loginBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                    loginBtnIcon.classList.add('fa-sign-in-alt');
                }
                return;
            }
            const message = error?.response?.data?.warning_message
                ? error.response.data.warning_message
                : apiMessage
                    ? apiMessage
                    : status === 401
                        ? 'Invalid username or password.'
                        : status === 423
                            ? 'Your account has been deactivated. Please contact the administrator.'
                            : status === 403
                                ? 'Your account was deactivated. Please contact the administrator.'
                                : 'An error occurred. Please try again.';
            console.error('Login error:', error);
            const isNotice = status === 403
                || status === 423
                || error?.response?.data?.warning
                || /pending|deactivated|locked/i.test(message);
            const title = isNotice ? 'Account Notice' : status === 401 ? 'Login Failed' : 'Error';
            const icon = isNotice ? 'info' : 'error';
            showLoginMessage(message, icon === 'info' ? 'info' : 'error', title || 'Account Notice');
            if (loginBtn) loginBtn.disabled = false;
            if (loginBtnText) loginBtnText.textContent = 'Sign In';
            if (loginBtnIcon) {
                loginBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                loginBtnIcon.classList.add('fa-sign-in-alt');
            }
        }
    });
}

// Register Form Handler
function initRegisterForm() {
    const registerForm = document.getElementById('registerForm');
    if (!registerForm) return;

    if (registerForm.dataset.mode === 'basic') {
        const passwordInput = document.getElementById('registerPassword');
        const passwordConfirmInput = document.getElementById('registerPasswordConfirm');
        const emailInput = document.getElementById('student_email');
        const agreementCheckbox = document.getElementById('parentAgreementCheckbox');

        if (passwordInput) {
            passwordInput.addEventListener('input', function() {
                validatePassword();
            });
        }

        if (passwordConfirmInput) {
            passwordConfirmInput.addEventListener('input', function() {
                validatePasswordMatch();
            });
        }

        if (emailInput) {
            emailInput.addEventListener('input', function() {
                validateEmail(this);
            });
        }

        if (agreementCheckbox) {
            agreementCheckbox.addEventListener('change', syncParentAgreementConsentState);
            syncParentAgreementConsentState();
        }

        registerForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            if (registerForm.dataset.submitting === '1') return;
            registerForm.dataset.submitting = '1';

            if (!agreementCheckbox?.checked) {
                showRegisterMessage('Please review and acknowledge the Parent Agreement before continuing.', 'error');
                toggleParentAgreementModal(true);
                registerForm.dataset.submitting = '0';
                return;
            }

            if (!validatePassword()) {
                showRegisterMessage('Please ensure your password meets all requirements.', 'error');
                registerForm.dataset.submitting = '0';
                return;
            }

            if (!validatePasswordMatch()) {
                showRegisterMessage('Passwords do not match. Please try again.', 'error');
                registerForm.dataset.submitting = '0';
                return;
            }

            const emailInputEl = document.getElementById('student_email');
            if (emailInputEl && !validateEmail(emailInputEl)) {
                showRegisterMessage('Please enter a valid email address.', 'error');
                registerForm.dataset.submitting = '0';
                return;
            }

            const payload = {
                student_first_name: registerForm.student_first_name?.value.trim() || '',
                student_last_name: registerForm.student_last_name?.value.trim() || '',
                student_email: registerForm.student_email?.value.trim() || '',
                student_phone: window.FasIntlPhone?.getValue(registerForm.student_phone) || registerForm.student_phone?.value.trim() || '',
                branch_id: registerForm.branch_id?.value || '',
                password: registerForm.password?.value || ''
            };

            const registerBtn = document.getElementById('registerSubmitBtn');
            const registerBtnText = document.getElementById('registerSubmitBtnText');
            const registerBtnIcon = document.getElementById('registerSubmitBtnIcon');
            if (registerBtn) registerBtn.disabled = true;
            if (registerBtnText) registerBtnText.textContent = 'Creating account...';
            if (registerBtnIcon) {
                registerBtnIcon.classList.add('fa-spinner', 'fa-spin');
                registerBtnIcon.classList.remove('fa-arrow-right');
            }

            try {
                const response = await axios.post(`${baseApiUrl}/online_register.php?action=register`, payload);
                const data = response.data || {};

                if (response.status === 200 && data.success) {
                    const verificationEmail = data.verification_email || payload.student_email;
                    registerForm.reset();
                    toggleRegisterModal(false);
                    await Swal.fire({
                        icon: 'success',
                        title: 'Check Your Email',
                        html: `
                            <p class="text-sm leading-6 text-slate-600">
                                We sent a verification code to<br>
                                <strong class="text-slate-900">${escapeHtml(verificationEmail)}</strong>.
                            </p>
                        `,
                        width: '30rem',
                        padding: '1.5rem',
                        confirmButtonText: 'Continue',
                        confirmButtonColor: '#b8860b'
                    });
                    await showRegisterMessage(
                        data.message || 'Your student account was created.',
                        'success',
                        'Account Created'
                    );
                    await promptEmailVerification(verificationEmail);
                } else {
                    showRegisterMessage(data.error || 'Registration failed. Please try again.', 'error');
                }
            } catch (error) {
                console.error('Basic registration error:', error);
                const serverError = error?.response?.data?.error;
                const message = serverError || error?.message || 'Network error. Please try again.';
                showRegisterMessage(message, 'error');
                await Swal.fire({
                    icon: 'error',
                    title: 'Account Not Created',
                    text: message,
                    confirmButtonColor: '#b8860b'
                });
            } finally {
                registerForm.dataset.submitting = '0';
                if (registerBtn) registerBtn.disabled = false;
                if (registerBtnText) registerBtnText.textContent = 'Create Account';
                if (registerBtnIcon) {
                    registerBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                    registerBtnIcon.classList.add('fa-arrow-right');
                }
            }
        });
        return;
    }

    // Registration now collects only student + guardian + account details.
    // Package/instrument availing is done later in the student dashboard.

    // Add event listeners for password validation
    const passwordInput = document.getElementById('registerPassword');
    const passwordConfirmInput = document.getElementById('registerPasswordConfirm');
    const emailInput = document.getElementById('student_email');
    const agreementCheckbox = document.getElementById('parentAgreementCheckbox');

    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            validatePassword();
        });
    }

    if (passwordConfirmInput) {
        passwordConfirmInput.addEventListener('input', function() {
            validatePasswordMatch();
        });
    }

    if (emailInput) {
        emailInput.addEventListener('input', function() {
            validateEmail(this);
        });
    }

    if (agreementCheckbox) {
        agreementCheckbox.addEventListener('change', syncParentAgreementConsentState);
        syncParentAgreementConsentState();
    }

    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        // Prevent double submit
        if (registerForm.dataset.submitting === '1') return;
        registerForm.dataset.submitting = '1';

        if (!agreementCheckbox?.checked) {
            showRegisterMessage('Please review and acknowledge the Parent Agreement before continuing.', 'error');
            toggleParentAgreementModal(true);
            registerForm.dataset.submitting = '0';
            return;
        }

        // Validate password policy
        if (!validatePassword()) {
            showRegisterMessage('Please ensure your password meets all requirements.', 'error');
            registerForm.dataset.submitting = '0';
            return;
        }

        // Validate password match
        if (!validatePasswordMatch()) {
            showRegisterMessage('Passwords do not match. Please try again.', 'error');
            registerForm.dataset.submitting = '0';
            return;
        }

        // Validate email
        const emailInput = document.getElementById('student_email');
        if (emailInput && !validateEmail(emailInput)) {
            showRegisterMessage('Please enter a valid email address.', 'error');
            emailInput.focus();
            registerForm.dataset.submitting = '0';
            return;
        }

        const formData = new FormData(registerForm);

        // Skip confirmation field; backend only needs the actual password.
        formData.delete('password_confirm');

        // Ensure age is calculated if date of birth is provided.
        const dateOfBirth = formData.get('student_date_of_birth');
        const currentAge = formData.get('student_age');
        if (dateOfBirth && !currentAge) {
            calculateAge(dateOfBirth);
            const ageEl = document.getElementById('student_age');
            if (ageEl?.value) {
                formData.set('student_age', ageEl.value);
            }
        }

        // Initial registration fee is fixed.
        formData.set('registration_source', 'public');
        formData.set('registration_fee_amount', '1000');

        // Use email as username if not provided.
        const usernameVal = String(formData.get('username') || '').trim();
        const studentEmailVal = String(formData.get('student_email') || '').trim();
        if (!usernameVal && studentEmailVal) {
            formData.set('username', studentEmailVal);
        }

        const registerBtn = document.getElementById('registerSubmitBtn');
        const registerBtnText = document.getElementById('registerSubmitBtnText');
        const registerBtnIcon = document.getElementById('registerSubmitBtnIcon');

        // Disable button
        if (registerBtn) registerBtn.disabled = true;
        if (registerBtnText) registerBtnText.textContent = 'Submitting...';
        if (registerBtnIcon) {
            registerBtnIcon.classList.add('fa-spinner', 'fa-spin');
            registerBtnIcon.classList.remove('fa-paper-plane');
        }

        try {
            const response = await axios.post(`${baseApiUrl}/users.php?action=register`, formData, {
                headers: { 'Content-Type': 'multipart/form-data' }
            });

            const responseText = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
            let result;
            try {
                result = typeof response.data === 'string' ? JSON.parse(responseText) : response.data;
            } catch (parseErr) {
                console.error('Registration 400 - Response was not JSON:', responseText);
                showRegisterMessage('Registration failed. The server returned an invalid response. Check the browser console (F12) for details.', 'error');
                registerForm.dataset.submitting = '0';
                return;
            }

            if (result.success) {
                registerForm.dataset.submitting = '0';
                const emailSent = Boolean(result.verification_email_sent);
                const registerNotice = !emailSent && result.mail_error
                    ? `${result.message || 'Registration submitted successfully.'} ${result.mail_error}`
                    : (result.message || 'Registration submitted successfully! Your account is pending admin approval.');
                showRegisterMessage(registerNotice, emailSent ? 'success' : 'info');
                registerForm.reset();

                // Reset password validation indicators
                if (document.getElementById('passwordRequirements')) {
                    ['req-length', 'req-uppercase', 'req-lowercase', 'req-number', 'req-special'].forEach(id => {
                        const el = document.getElementById(id);
                        if (el) {
                            const icon = el.querySelector('i');
                            if (icon) {
                                icon.classList.remove('fa-check-circle', 'text-green-500');
                                icon.classList.add('fa-circle', 'text-zinc-600');
                            }
                        }
                    });
                }
                if (document.getElementById('passwordMatch')) {
                    document.getElementById('passwordMatch').textContent = '';
                    document.getElementById('passwordMatch').className = 'mt-2 text-xs';
                }

                // Show success message with SweetAlert
                Swal.fire({
                    icon: emailSent ? 'success' : 'warning',
                    title: 'Registration Submitted!',
                    html: `Your registration has been submitted successfully.<br><br>
                           <strong>Status:</strong> Pending Admin Approval<br>
                           <strong>Registration Fee:</strong> ₱1,000.00<br>
                           <strong>Username / Student ID:</strong> ${result.student_login_identifier || result.username || studentEmailVal}<br><br>
                           ${!emailSent && result.mail_error ? `<strong>Email notice:</strong> ${escapeHtml(result.mail_error)}<br><br>` : ''}
                           Once approved, you can log in and choose your package/instruments from your dashboard.`,
                    confirmButtonColor: '#b8860b'
                });
            } else {
                const errMsg = result.error || 'Registration failed. Please try again.';
                console.error('Registration failed (400):', errMsg, result);
                showRegisterMessage(errMsg, 'error');
            }
        } catch (error) {
            console.error('Registration error:', error);
            const serverError = error?.response?.data?.error;
            showRegisterMessage(serverError || 'Registration was not saved. Please try again.', 'error');
        } finally {
            registerForm.dataset.submitting = '0';
            if (registerBtn) registerBtn.disabled = false;
            if (registerBtnText) registerBtnText.textContent = 'Submit Registration';
            if (registerBtnIcon) {
                registerBtnIcon.classList.remove('fa-spinner', 'fa-spin');
                registerBtnIcon.classList.add('fa-paper-plane');
            }
        }
    });
}

// Load Session Packages
let sessionPackages = [];
async function loadSessionPackages() {
    const select = document.getElementById('sessionPackage');
    if (!select) return;

    try {
        const response = await axios.get(`${baseApiUrl}/sessions.php?action=get-packages`);
        const data = response.data;

        if (data.success && data.packages) {
            sessionPackages = data.packages.filter(pkg => Number(pkg.sessions || 0) === 12);
            select.innerHTML = '<option value="">Select Package</option>';
            sessionPackages.forEach(pkg => {
                const option = document.createElement('option');
                option.value = pkg.package_id;
                option.textContent = `${pkg.package_name} (${pkg.sessions} sessions, ${pkg.max_instruments} instrument${pkg.max_instruments > 1 ? 's' : ''})`;
                option.setAttribute('data-sessions', pkg.sessions);
                option.setAttribute('data-max-instruments', pkg.max_instruments);
                option.setAttribute('data-price', (pkg.price != null && !isNaN(pkg.price)) ? String(pkg.price) : '0');
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to load session packages:', error);
        // Fallback to default packages
        sessionPackages = [
            { package_id: 1, sessions: 12, max_instruments: 1, price: 7450 }
        ];
        select.innerHTML = `
            <option value="">Select Package</option>
            <option value="1" data-sessions="12" data-max-instruments="1" data-price="7450">Basic (12 Sessions, 1 instrument)</option>
        `;
    }
}

// Load Instruments for Registration
let availableInstruments = [];
async function loadInstrumentsForRegistration(branchId) {
    if (!branchId) {
        const container = document.getElementById('instrumentsContainer');
        if (container) container.innerHTML = '<p class="text-sm text-zinc-500">Select a branch first</p>';
        return;
    }

    try {
        const response = await axios.get(`${baseApiUrl}/instruments.php?action=get-instruments&branch_id=${branchId}`);
        const data = response.data;

        if (data.success && data.instruments) {
            availableInstruments = data.instruments;
            updateInstrumentSelection();
        } else {
            const container = document.getElementById('instrumentsContainer');
            if (container) container.innerHTML = '<p class="text-sm text-red-400">No instruments available for this branch</p>';
        }
    } catch (error) {
        console.error('Failed to load instruments:', error);
        const container = document.getElementById('instrumentsContainer');
        if (container) container.innerHTML = '<p class="text-sm text-red-400">Failed to load instruments</p>';
    }
}

// Get unique instrument types from available instruments (for branch)
function getAvailableTypes() {
    const seen = new Set();
    const types = [];
    availableInstruments.forEach(inst => {
        const id = inst.type_id;
        const name = inst.type_name || 'Other';
        if (id != null && !seen.has(id)) {
            seen.add(id);
            types.push({ type_id: id, type_name: name });
        }
    });
    return types.sort((a, b) => (a.type_name || '').localeCompare(b.type_name || ''));
}

// Get instruments filtered by type_id
function getInstrumentsByType(typeId) {
    if (!typeId) return [];
    return availableInstruments.filter(inst => inst.type_id == typeId);
}

// Update Instrument Selection UI: Type dropdown first, then Instrument dropdown (filtered by type)
function updateInstrumentSelection() {
    const container = document.getElementById('instrumentsContainer');
    if (!container) return;

    const sessionPackageSelect = document.getElementById('sessionPackage');
    if (!sessionPackageSelect || !sessionPackageSelect.value) {
        container.innerHTML = '<p class="text-sm text-zinc-500">Select a session package first</p>';
        return;
    }

    const selectedOption = sessionPackageSelect.options[sessionPackageSelect.selectedIndex];
    const maxInstruments = parseInt(selectedOption.getAttribute('data-max-instruments') || '1');

    if (availableInstruments.length === 0) {
        container.innerHTML = '<p class="text-sm text-zinc-500">Select a branch to see available instruments</p>';
        return;
    }

    const types = getAvailableTypes();
    const typeOptionsHtml = types.map(t =>
        `<option value="${t.type_id}">${escapeHtml(t.type_name)}</option>`
    ).join('');

    let html = '';
    for (let i = 1; i <= maxInstruments; i++) {
        const slotLabel = maxInstruments === 1 ? 'Instrument Type' : `Instrument Type ${i}`;
        html += `
            <div class="p-3 bg-zinc-900/50 rounded-lg border border-zinc-700 space-y-2">
                <label class="block text-sm font-medium text-zinc-300">${slotLabel} *</label>
                <div>
                    <label class="block text-xs text-zinc-500 mb-1">Type</label>
                    <select class="instrument-type-select w-full px-4 py-2 bg-zinc-900 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-gold-400" data-slot="${i}" onchange="onInstrumentTypeChange(${i})">
                        <option value="">Select type...</option>
                        ${typeOptionsHtml}
                    </select>
                </div>
                <p class="text-xs text-zinc-400">An available instrument from this type will be assigned automatically.</p>
            </div>
        `;
    }
    container.innerHTML = html;
}

function onInstrumentTypeChange(slot) {
    const typeSelect = document.querySelector(`select.instrument-type-select[data-slot="${slot}"]`);
    if (!typeSelect) return;

    const typeId = typeSelect.value;
    onInstrumentDropdownChange();
}

function onInstrumentDropdownChange() {
    const selects = document.querySelectorAll('select.instrument-select');
    if (!selects.length) return;
    const used = new Set();
    selects.forEach(select => {
        const val = select.value;
        if (val) used.add(val);
    });
    selects.forEach(select => {
        const currentVal = select.value;
        Array.from(select.options).forEach(opt => {
            if (opt.value === '') return;
            const othersUsed = used.has(opt.value) && opt.value !== currentVal;
            opt.disabled = othersUsed;
        });
    });
    calculateTotalFee();
}

// Validate Instrument Selection (dropdowns) - ensure at least one selected, no duplicates
function validateInstrumentSelection() {
    calculateTotalFee();
}

// Calculate Total Fee
function calculateTotalFee() {
    const registrationFee = 1000;
    const sessionPackageSelect = document.getElementById('sessionPackage');
    const paymentTypeSelect = document.getElementById('paymentType');

    if (!sessionPackageSelect || !sessionPackageSelect.value || !paymentTypeSelect || !paymentTypeSelect.value) {
        const sessionFeeEl = document.getElementById('sessionFeeDisplay');
        const totalEl = document.getElementById('totalAmountDisplay');
        const feeInput = document.getElementById('registration_fee_amount');
        if (sessionFeeEl) sessionFeeEl.textContent = '₱0.00';
        if (totalEl) totalEl.textContent = `₱${registrationFee.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
        if (feeInput) feeInput.value = registrationFee;
        return registrationFee;
    }

    const selectedOption = sessionPackageSelect.options[sessionPackageSelect.selectedIndex];
    const sessions = parseInt(selectedOption.getAttribute('data-sessions') || '0');
    const paymentType = paymentTypeSelect.value;
    const basePrice = parseFloat(selectedOption.getAttribute('data-price') || '0');

    // Check if saxophone is selected (from dropdowns)
    const selectedInstruments = getStudentRequestSelectedInstrumentIds();
    const hasSaxophone = selectedInstruments.some(id => {
        const instrument = availableInstruments.find(inst => inst.instrument_id === id);
        return instrument && (instrument.instrument_name.toLowerCase().includes('saxophone') ||
                             instrument.type_name?.toLowerCase().includes('saxophone'));
    });

    let sessionFee = 0;
    // Use database price when available (tbl_session_packages.price)
    if (basePrice > 0) {
        if (paymentType === 'downpayment') {
            // Ratios from original: 12 sessions 3000/7450, 20 sessions 5000/11800
            const downpaymentRatio = sessions === 12 ? (3000 / 7450) : (sessions === 20 ? (5000 / 11800) : 0.42);
            sessionFee = Math.round(basePrice * downpaymentRatio);
        } else if (paymentType === 'fullpayment') {
            if (hasSaxophone) {
                // Saxophone premium: 12 sessions 8100/7450, 20 sessions 13000/11800
                const saxophoneMultiplier = sessions === 12 ? (8100 / 7450) : (sessions === 20 ? (13000 / 11800) : 1.09);
                sessionFee = Math.round(basePrice * saxophoneMultiplier);
            } else {
                sessionFee = basePrice;
            }
        }
    } else {
        // Fallback when price not in DB (legacy)
        if (paymentType === 'downpayment') {
            if (sessions === 12) sessionFee = 3000;
            else if (sessions === 20) sessionFee = 5000;
        } else if (paymentType === 'fullpayment') {
            if (hasSaxophone) {
                if (sessions === 12) sessionFee = 8100;
                else if (sessions === 20) sessionFee = 13000;
            } else {
                if (sessions === 12) sessionFee = 7450;
                else if (sessions === 20) sessionFee = 11800;
            }
        }
    }

    const total = registrationFee + sessionFee;

    const sessionFeeEl = document.getElementById('sessionFeeDisplay');
    const totalEl = document.getElementById('totalAmountDisplay');
    const feeInput = document.getElementById('registration_fee_amount');

    if (sessionFeeEl) sessionFeeEl.textContent = `₱${sessionFee.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    if (totalEl) totalEl.textContent = `₱${total.toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}`;
    if (feeInput) feeInput.value = total;

    return total;
}

// Escape HTML helper
function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function cleanSessionNoteText(text, fallback = '—') {
    const raw = String(text || '').trim();
    if (!raw) return fallback;

    const systemNotes = new Set([
        'completed from manual attendance',
        'completed from attendance check-in',
        'completed from qr attendance',
        'attendance recorded'
    ]);
    const seen = new Set();
    const parts = raw
        .split('|')
        .map(part => part.trim())
        .filter(part => {
            if (!part) return false;
            const key = part.toLowerCase();
            if (systemNotes.has(key)) return false;
            if (seen.has(key)) return false;
            seen.add(key);
            return true;
        });

    return parts.length ? parts.join(' | ') : fallback;
}

// Calculate Age from Date of Birth
function calculateAge(dateOfBirth) {
    if (!dateOfBirth) {
        document.getElementById('calculatedAge').textContent = 'Enter date of birth to calculate age';
        document.getElementById('calculatedAge').className = 'text-zinc-400 italic';
        document.getElementById('student_age').value = '';
        return;
    }

    const birthDate = new Date(dateOfBirth);
    const today = new Date();
    let age = today.getFullYear() - birthDate.getFullYear();
    const monthDiff = today.getMonth() - birthDate.getMonth();

    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birthDate.getDate())) {
        age--;
    }

    if (age < 0) {
        document.getElementById('calculatedAge').textContent = 'Invalid date - future date selected';
        document.getElementById('calculatedAge').className = 'text-red-400';
        document.getElementById('student_age').value = '';
        return;
    }

    document.getElementById('calculatedAge').textContent = `${age} years old`;
    document.getElementById('calculatedAge').className = 'text-gold-400 font-semibold';
    document.getElementById('student_age').value = age;
}

// Validate Email with Strict Pattern
function validateEmail(input) {
    const email = input.value.trim();
    const emailValidation = document.getElementById('emailValidation');

    if (!emailValidation) {
        return email.length > 0 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
    }

    if (email.length === 0) {
        emailValidation.textContent = '';
        emailValidation.className = 'mt-1 text-xs';
        return false;
    }

    // Allow standard addresses (including Gmail +tags)
    const emailPattern = /^[a-zA-Z0-9]([a-zA-Z0-9._+\-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;

    if (!emailPattern.test(email)) {
        emailValidation.textContent = '✗ Please enter a valid email address (e.g., name@domain.com)';
        emailValidation.className = 'mt-1 text-xs text-red-500';
        input.classList.add('border-red-500');
        input.classList.remove('border-zinc-700', 'border-gold-400');
        return false;
    }

    // Additional checks
    if (email.length > 254) {
        emailValidation.textContent = '✗ Email address is too long (max 254 characters)';
        emailValidation.className = 'mt-1 text-xs text-red-500';
        input.classList.add('border-red-500');
        input.classList.remove('border-zinc-700', 'border-gold-400');
        return false;
    }

    const [localPart, domain] = email.split('@');
    if (localPart.length > 64) {
        emailValidation.textContent = '✗ Email local part is too long (max 64 characters)';
        emailValidation.className = 'mt-1 text-xs text-red-500';
        input.classList.add('border-red-500');
        input.classList.remove('border-zinc-700', 'border-gold-400');
        return false;
    }

    if (domain && domain.length > 253) {
        emailValidation.textContent = '✗ Email domain is too long';
        emailValidation.className = 'mt-1 text-xs text-red-500';
        input.classList.add('border-red-500');
        input.classList.remove('border-zinc-700', 'border-gold-400');
        return false;
    }

    emailValidation.textContent = '✓ Valid email address';
    emailValidation.className = 'mt-1 text-xs text-green-500';
    input.classList.remove('border-red-500');
    input.classList.add('border-green-500');
    return true;
}

// Initialize Date Picker
function initDatePicker() {
    const dateInput = document.getElementById('student_date_of_birth');
    const datePickerBtn = document.getElementById('datePickerBtn');
    if (!dateInput) return;

    if (typeof flatpickr === 'undefined') {
        console.error('Flatpickr is not loaded');
        return;
    }

    const currentTheme = (localStorage.getItem('theme') || 'light').toLowerCase();
    const isDark = currentTheme === 'dark';

    const flatpickrInstance = flatpickr(dateInput, {
        dateFormat: "Y-m-d",
        maxDate: "today",
        minDate: "1900-01-01", // reasonable birth year limit
        defaultDate: null,

        allowInput: false,
        clickOpens: true,

        /* 🔥 KEY SETTINGS FOR EASY BIRTHDATE PICKING */
        monthSelectorType: "dropdown", // enables year dropdown
        yearSelectorType: "dropdown",  // explicit year dropdown
        shorthandCurrentMonth: false,

        animate: true,
        theme: isDark ? "dark" : "light",

        appendTo: document.body,

        onChange: function (selectedDates, dateStr) {
            if (dateStr) {
                dateInput.value = dateStr;
                calculateAge(dateStr);
            }
        },

        onReady: function (_, __, instance) {
            if (instance.calendarContainer) {
                instance.calendarContainer.style.zIndex = '10001';
                instance.calendarContainer.classList.add('border', 'border-gold-500');
                if (isDark) {
                    instance.calendarContainer.classList.add('bg-zinc-900');
                } else {
                    instance.calendarContainer.classList.add('bg-white');
                }
            }
        },

        onOpen: function (_, __, instance) {
            if (instance.calendarContainer) {
                instance.calendarContainer.style.zIndex = '10001';
            }
        }
    });

    /* Calendar icon button */
    if (datePickerBtn) {
        datePickerBtn.addEventListener('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            flatpickrInstance.open();
        });
    }

    /* Input open behavior */
    ['click', 'focus'].forEach(event => {
        dateInput.addEventListener(event, function (e) {
            e.preventDefault();
            flatpickrInstance.open();
        });
    });
}
// Load Branches for Registration Form
async function loadBranches() {
    const branchSelect = document.getElementById('branch_id');
    if (!branchSelect) return;

    try {
        const response = await axios.get(`${baseApiUrl}/branch.php?action=get-branches`);
        const data = response.data;

        if (data.success && data.branches) {
            // Clear existing options
            branchSelect.innerHTML = '<option value="">Select Branch</option>';

            // Add branches to dropdown
            data.branches.forEach(branch => {
                const option = document.createElement('option');
                option.value = branch.branch_id;
                option.textContent = branch.branch_name;
                branchSelect.appendChild(option);
            });
        } else {
            branchSelect.innerHTML = '<option value="">No branches available</option>';
            console.error('Failed to load branches:', data.error);
        }
    } catch (error) {
        console.error('Error loading branches:', error);
        branchSelect.innerHTML = '<option value="">Error loading branches</option>';
    }
}

async function populateBranchSelect(selectEl, selectedId = null) {
    if (!selectEl) return;
    try {
        const response = await axios.get(`${baseApiUrl}/branch.php?action=get-branches`);
        const data = response.data;
        if (data.success && data.branches) {
            selectEl.innerHTML = '<option value="">Select Branch</option>';
            data.branches.forEach(branch => {
                const option = document.createElement('option');
                option.value = branch.branch_id;
                option.textContent = branch.branch_name;
                if (selectedId && String(branch.branch_id) === String(selectedId)) {
                    option.selected = true;
                }
                selectEl.appendChild(option);
            });
        } else {
            selectEl.innerHTML = '<option value="">No branches available</option>';
        }
    } catch (error) {
        console.error('Error loading branches:', error);
        selectEl.innerHTML = '<option value="">Error loading branches</option>';
    }
}

// Load pending package/enrollment requests (used by admin enrollments/sessions views)
async function loadPendingRequests() {
    const tableBody = document.getElementById('pendingRequestsTable');
    const countEl = document.getElementById('pendingRequestCount');
    if (!tableBody) return;

    try {
        const branchFilter = document.getElementById('branchFilter');
        let url = `${baseApiUrl}/students.php?action=get-pending-package-requests`;
        if (branchFilter && branchFilter.value) {
            url += `&branch_id=${branchFilter.value}`;
        }

        const response = await axios.get(url);
        const data = response.data;
        const requests = data.success && Array.isArray(data.requests) ? data.requests : [];

        if (countEl) countEl.textContent = `${requests.length} pending`;

        if (!requests.length) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="7" class="px-6 py-8 text-center text-slate-500">
                        <i class="fas fa-inbox text-2xl mb-2 text-gold-500/60"></i>
                        <p>No pending student requests.</p>
                    </td>
                </tr>`;
            return;
        }

        pendingRequestsById = {};
        const isAdminEnrollmentsPage = /admin_enrollments\.html$/i.test(window.location.pathname || '');
        const adminEnrollmentsAllowActions = !!window.adminEnrollmentsAllowActions;

        tableBody.innerHTML = requests.map(r => {
            pendingRequestsById[String(r.request_id)] = r;
            const studentName = `${escapeHtml(r.first_name || '')} ${escapeHtml(r.last_name || '')}`.trim();
            const pkg = escapeHtml(r.package_name || '—');
            const instruments = Array.isArray(r.instruments) && r.instruments.length
                ? r.instruments.map(i => escapeHtml(i.type_name || i.instrument_name || 'Instrument')).join(', ')
                : '—';
            const paymentType = escapeHtml(r.payment_type || 'Partial Payment');
            const payableNow = Number(r.payable_now || 0);
            const paymentCellHtml = `
                    <div class="space-y-2">
                        <div class="font-semibold text-slate-800">${paymentType}</div>
                        <button type="button" onclick="openPendingRequestPaymentModal(${Number(r.request_id)})" class="inline-flex items-center rounded-lg border border-slate-200 bg-slate-50 px-2.5 py-1.5 text-xs font-bold text-slate-700 hover:bg-slate-100 transition">
                            Payment Info
                        </button>
                    </div>
                `;
            return `
                <tr class="hover:bg-slate-50/80 transition">
                    <td class="px-6 py-4">
                        <div class="font-medium text-slate-900">${studentName || 'Student'}</div>
                        <div class="text-sm text-slate-500">${escapeHtml(r.email || '')}</div>
                        <div class="text-xs text-slate-400">${escapeHtml(r.branch_name || '')}</div>
                    </td>
                    <td class="px-6 py-4 text-sm text-slate-700">${pkg}</td>
                    <td class="px-6 py-4 text-sm text-slate-700">${instruments}</td>
                    <td class="px-6 py-4 text-sm text-slate-700">Based on instructor availability</td>
                    <td class="px-6 py-4 text-sm text-slate-700">${paymentCellHtml}</td>
                    <td class="px-6 py-4 text-sm font-semibold text-gold-600">${formatCurrencyPHP(payableNow)}</td>
                    <td class="px-6 py-4">
                        ${isAdminEnrollmentsPage && !adminEnrollmentsAllowActions
                            ? `<button onclick="openPendingRequestViewModal(${Number(r.request_id)})" class="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-bold">
                                View
                            </button>`
                            : `<div class="flex items-center gap-2">
                                <button onclick="openPendingRequestViewModal(${Number(r.request_id)})" class="px-3 py-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-slate-200 text-xs font-bold">
                                    View
                                </button>
                                <button onclick="(window.onPendingRequestAssignClick || openAssignRequestModal)(${Number(r.request_id)})" class="px-3 py-1.5 rounded-lg bg-green-100 text-green-700 hover:bg-green-200 text-xs font-bold">
                                    ${window.pendingRequestActionLabel || 'Assign & Approve'}
                                </button>
                                <button onclick="rejectStudentRequest(${Number(r.request_id)})" class="px-3 py-1.5 rounded-lg bg-red-100 text-red-700 hover:bg-red-200 text-xs font-bold">
                                    Reject
                                </button>
                            </div>`}
                    </td>
                </tr>`;
        }).join('');
    } catch (error) {
        console.error('Failed to load pending package requests:', error);
        if (countEl) countEl.textContent = 'Error';
        tableBody.innerHTML = `
            <tr>
                <td colspan="7" class="px-6 py-8 text-center text-red-500">
                    <i class="fas fa-exclamation-circle text-2xl mb-2"></i>
                    <p>Failed to load pending requests.</p>
                </td>
            </tr>`;
    }
}

        function openPendingRequestViewModal(requestId) {
            const req = pendingRequestsById[String(requestId)];
            if (!req) {
                showMessage('Request not found.', 'error');
                return;
            }

            const studentName = `${escapeHtml(req.first_name || '')} ${escapeHtml(req.last_name || '')}`.trim() || 'Student';
            const instruments = Array.isArray(req.instruments) && req.instruments.length
                ? req.instruments.map(i => escapeHtml(i.type_name || i.instrument_name || 'Instrument')).join(', ')
                : '—';
    const paymentType = escapeHtml(req.payment_type || 'Partial Payment');
    const paymentMethod = escapeHtml(req.payment_method || '—');
    const payableNow = Number(req.payable_now || 0);
    const packageAmount = Number(req.requested_amount || req.package_price || 0);
    const proofHtml = req.payment_proof_path
        ? `<a href="${escapeHtml(buildPublicFileUrl(req.payment_proof_path))}" target="_blank" rel="noopener" class="text-sm text-blue-600 underline">View payment proof</a>`
        : '<span class="text-sm text-slate-500">No payment proof</span>';

    Swal.fire({
        title: 'Enrollment Request',
        width: 760,
        confirmButtonText: 'Close',
        html: `
            <div class="text-left space-y-4 text-sm text-slate-700">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div><span class="font-semibold text-slate-900">Student:</span> ${studentName}</div>
                    <div><span class="font-semibold text-slate-900">Branch:</span> ${escapeHtml(req.branch_name || '—')}</div>
                    <div><span class="font-semibold text-slate-900">Package:</span> ${escapeHtml(req.package_name || '—')}</div>
                            <div><span class="font-semibold text-slate-900">Selected Instrument Type:</span> ${instruments}</div>
                    <div><span class="font-semibold text-slate-900">Schedule Basis:</span> Instructor availability</div>
                    <div><span class="font-semibold text-slate-900">Payment Type:</span> ${paymentType}</div>
                    <div><span class="font-semibold text-slate-900">Payment Method:</span> ${paymentMethod}</div>
                    <div><span class="font-semibold text-slate-900">Amount Paid:</span> ${formatCurrencyPHP(payableNow)}</div>
                    <div><span class="font-semibold text-slate-900">Package Amount:</span> ${formatCurrencyPHP(packageAmount)}</div>
                </div>
                <div><span class="font-semibold text-slate-900">Proof of Payment:</span> ${proofHtml}</div>
            </div>
        `
    });
}

async function rejectStudentRequest(requestId) {
    if (!requestId) return;
    const input = await Swal.fire({
        icon: 'warning',
        title: 'Reject request?',
        text: 'You can add an optional reason for the student.',
        input: 'text',
        inputPlaceholder: 'Reason (optional)',
        showCancelButton: true,
        confirmButtonText: 'Reject',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#dc2626'
    });
    if (!input.isConfirmed) return;

    try {
        const response = await axios.post(`${baseApiUrl}/students.php`, {
            action: 'reject-package-request',
            request_id: Number(requestId),
            admin_notes: input.value || ''
        });
        const data = response.data;
        if (data.success) {
            showMessage(data.message || 'Request rejected.', 'success');
            loadPendingRequests();
        } else {
            showMessage(data.error || 'Failed to reject request.', 'error');
        }
    } catch (error) {
        showMessage('Network error while rejecting request.', 'error');
    }
}

// Initialize index.html functions
function initIndexPage() {
    initLoginForm();
    initRegisterForm();
    initDatePicker();
    loadBranches();
    initScrollAnimations();
    syncParentAgreementConsentState();
}

// Initialize scroll animations for About section
function initScrollAnimations() {
    const animateElements = document.querySelectorAll('.scroll-animate');

    if (animateElements.length === 0) return;

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                // Add staggered animation for multiple elements
                const elements = Array.from(entry.target.parentElement?.querySelectorAll('.scroll-animate') || [entry.target]);
                elements.forEach((el, index) => {
                    setTimeout(() => {
                        el.classList.add('visible');
                    }, index * 150); // 150ms delay between each element
                });

                // Stop observing once animated
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.3, // Trigger when 30% of element is visible
        rootMargin: '0px 0px -50px 0px' // Trigger slightly before element comes into full view
    });

    animateElements.forEach(el => observer.observe(el));
}

// Prompt user to change password on first login (when using a default/temporary password)
async function promptPasswordChange(user, currentPassword) {
    try {
        const { value: formValues } = await Swal.fire({
            title: 'Create a new password',
            html: `
                <div class="fas-change-password-form">
                    <div class="fas-change-password-notice">
                        <i class="fas fa-shield-halved" aria-hidden="true"></i>
                        <p>Your administrator issued a temporary password. Create a secure password that only you know.</p>
                    </div>

                    <label class="fas-change-password-label" for="swal-new-password">New password</label>
                    <div class="fas-change-password-field">
                        <input id="swal-new-password" data-password-strength-ready="1" type="password" autocomplete="new-password" placeholder="Enter a new password">
                        <button type="button" data-password-toggle="swal-new-password" aria-label="Show new password">
                            <i class="fas fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>

                    <div class="fas-password-requirements" aria-live="polite">
                        <p id="password-requirement-summary">0 of 5 password requirements met</p>
                        <ul>
                            <li data-password-rule="length"><span>○</span>8 or more characters</li>
                            <li data-password-rule="uppercase"><span>○</span>One uppercase letter</li>
                            <li data-password-rule="lowercase"><span>○</span>One lowercase letter</li>
                            <li data-password-rule="number"><span>○</span>One number</li>
                            <li data-password-rule="special"><span>○</span>One special character (!@#$%^&*)</li>
                        </ul>
                    </div>

                    <label class="fas-change-password-label" for="swal-confirm-password">Confirm new password</label>
                    <div class="fas-change-password-field">
                        <input id="swal-confirm-password" data-password-strength-ready="1" type="password" autocomplete="new-password" placeholder="Enter the same password again">
                        <button type="button" data-password-toggle="swal-confirm-password" aria-label="Show confirmed password">
                            <i class="fas fa-eye" aria-hidden="true"></i>
                        </button>
                    </div>
                    <p id="password-match-feedback" class="fas-password-match-feedback" aria-live="polite">Re-enter your new password to confirm it.</p>
                </div>`,
            focusConfirm: false,
            confirmButtonText: '<i class="fas fa-lock" aria-hidden="true"></i><span>Update Password</span>',
            allowOutsideClick: false,
            allowEscapeKey: false,
            customClass: {
                popup: 'fas-change-password-popup',
                title: 'fas-change-password-title',
                htmlContainer: 'fas-change-password-content',
                confirmButton: 'fas-change-password-confirm'
            },
            didOpen: () => {
                const newInput = document.getElementById('swal-new-password');
                const confirmInput = document.getElementById('swal-confirm-password');
                const matchFeedback = document.getElementById('password-match-feedback');
                const requirementSummary = document.getElementById('password-requirement-summary');
                const tests = {
                    length: value => value.length >= 8,
                    uppercase: value => /[A-Z]/.test(value),
                    lowercase: value => /[a-z]/.test(value),
                    number: value => /[0-9]/.test(value),
                    special: value => /[!@#$%^&*]/.test(value)
                };

                const updateFeedback = () => {
                    const password = newInput?.value || '';
                    const confirmation = confirmInput?.value || '';
                    let completed = 0;
                    Object.entries(tests).forEach(([rule, test]) => {
                        const item = document.querySelector(`[data-password-rule="${rule}"]`);
                        const passed = test(password);
                        if (passed) completed++;
                        item?.classList.toggle('is-met', passed);
                        const icon = item?.querySelector('span');
                        if (icon) icon.textContent = passed ? '✓' : '○';
                    });

                    if (requirementSummary) {
                        requirementSummary.textContent = completed === 5
                            ? 'Great — your password meets every requirement.'
                            : `${completed} of 5 password requirements met`;
                        requirementSummary.classList.toggle('is-complete', completed === 5);
                    }

                    if (!matchFeedback) return;
                    if (!confirmation) {
                        matchFeedback.textContent = 'Re-enter your new password to confirm it.';
                        matchFeedback.className = 'fas-password-match-feedback';
                    } else if (password === confirmation) {
                        matchFeedback.textContent = '✓ Passwords match';
                        matchFeedback.className = 'fas-password-match-feedback is-match';
                    } else {
                        matchFeedback.textContent = 'Passwords do not match yet.';
                        matchFeedback.className = 'fas-password-match-feedback is-mismatch';
                    }

                    const confirmButton = Swal.getConfirmButton();
                    if (confirmButton) {
                        confirmButton.disabled = completed !== 5 || !confirmation || password !== confirmation;
                    }
                };

                document.querySelectorAll('[data-password-toggle]').forEach(button => {
                    button.addEventListener('click', () => {
                        const input = document.getElementById(button.dataset.passwordToggle || '');
                        if (!input) return;
                        const show = input.type === 'password';
                        input.type = show ? 'text' : 'password';
                        button.setAttribute('aria-label', `${show ? 'Hide' : 'Show'} password`);
                        button.querySelector('i')?.classList.toggle('fa-eye', !show);
                        button.querySelector('i')?.classList.toggle('fa-eye-slash', show);
                    });
                });
                newInput?.addEventListener('input', updateFeedback);
                confirmInput?.addEventListener('input', updateFeedback);
                updateFeedback();
                newInput?.focus();
            },
            preConfirm: () => {
                const newPass = document.getElementById('swal-new-password').value || '';
                const confirmPass = document.getElementById('swal-confirm-password').value || '';

                if (!newPass || !confirmPass) {
                    Swal.showValidationMessage('Please fill in both password fields');
                    return false;
                }
                if (newPass !== confirmPass) {
                    Swal.showValidationMessage('Passwords do not match');
                    return false;
                }
                if (newPass.length < 8 ||
                    !/[A-Z]/.test(newPass) ||
                    !/[a-z]/.test(newPass) ||
                    !/[0-9]/.test(newPass) ||
                    !/[!@#$%^&*]/.test(newPass)) {
                    Swal.showValidationMessage('Password must meet all complexity requirements.');
                    return false;
                }

                return { newPassword: newPass };
            }
        });

        if (!formValues) {
            return false;
        }

        const response = await axios.post(`${baseApiUrl}/users.php?action=change-password`, {
            user_id: user.user_id,
            old_password: currentPassword,
            new_password: formValues.newPassword
        });

        const result = response.data;

        if (!result.success) {
            await Swal.fire({
                icon: 'error',
                title: 'Password Change Failed',
                text: result.error || 'Unable to change password. Please try again.',
                confirmButtonColor: '#b8860b'
            });
            return false;
        }

        await Swal.fire({
            icon: 'success',
            title: 'Password Updated',
            text: 'Your password has been changed successfully.',
            confirmButtonColor: '#b8860b'
        });
        return true;
    } catch (err) {
        console.error('Error changing password:', err);
        await Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'An unexpected error occurred. Please try again.',
            confirmButtonColor: '#b8860b'
        });
        return false;
    }
}

// ========== ADMIN PAGE FUNCTIONS ==========

// Check authentication
function checkAuth() {
    const user = Auth.getUser();
    if (!user || getRoleCategory(user.role_name) !== 'admin') {
        Swal.fire({
            icon: 'warning',
            title: 'Access Denied',
            text: 'You must be logged in as an Admin to access this page.',
            confirmButtonColor: '#b8860b',
            confirmButtonText: 'Go to Login'
        }).then(() => {
            const appBase = (typeof appBaseUrl === 'string' && appBaseUrl)
                ? appBaseUrl
                : ((typeof baseApiUrl === 'string' && baseApiUrl.endsWith('/api'))
                    ? baseApiUrl.slice(0, -4)
                    : `${window.location.origin}/FAS_music`);
            window.location.href = `${appBase}/index.html`;
        });
    }
}

// ========== STUDENT PAGE FUNCTIONS ==========

function checkStudentAuth() {
    const user = Auth.getUser();
    if (!user || getRoleCategory(user.role_name) !== 'student') {
        Swal.fire({
            icon: 'warning',
            title: 'Access Denied',
            text: 'You must be logged in as a Student to access this page.',
            confirmButtonColor: '#b8860b',
            confirmButtonText: 'Go to Login'
        }).then(() => {
            const appBase = (typeof appBaseUrl === 'string' && appBaseUrl)
                ? appBaseUrl
                : ((typeof baseApiUrl === 'string' && baseApiUrl.endsWith('/api'))
                    ? baseApiUrl.slice(0, -4)
                    : `${window.location.origin}/FAS_music`);
            window.location.href = `${appBase}/index.html`;
        });
        return false;
    }
    return true;
}

function checkGuardianAuth() {
    const user = Auth.getUser();
    if (!user || getRoleCategory(user.role_name) !== 'guardian') {
        Swal.fire({
            icon: 'warning',
            title: 'Access Denied',
            text: 'You must be logged in as a Guardian to access this page.',
            confirmButtonColor: '#b8860b',
            confirmButtonText: 'Go to Login'
        }).then(() => {
            const appBase = (typeof baseApiUrl === 'string' && baseApiUrl.endsWith('/api'))
                ? baseApiUrl.slice(0, -4)
                : `${window.location.origin}/FAS_music`;
            window.location.href = `${appBase}/index.html`;
        });
        return false;
    }
    return true;
}

function checkBranchScopedAuth() {
    const user = Auth.getUser();
    const roleCategory = getRoleCategory(user?.role_name);
    if (!user || (roleCategory !== 'manager' && roleCategory !== 'staff')) {
        Swal.fire({
            icon: 'warning',
            title: 'Access Denied',
            text: 'You must be logged in as branch staff or a branch manager to access this page.',
            confirmButtonColor: '#b8860b',
            confirmButtonText: 'Go to Login'
        }).then(() => {
            const appBase = (typeof appBaseUrl === 'string' && appBaseUrl)
                ? appBaseUrl
                : ((typeof baseApiUrl === 'string' && baseApiUrl.endsWith('/api'))
                    ? baseApiUrl.slice(0, -4)
                    : `${window.location.origin}/FAS_music`);
            window.location.href = `${appBase}/index.html`;
        });
        return false;
    }
    return true;
}

function checkInstructorAuth() {
    const user = Auth.getUser();
    if (!user || getRoleCategory(user.role_name) !== 'instructor') {
        Swal.fire({
            icon: 'warning',
            title: 'Access Denied',
            text: 'You must be logged in as an Instructor to access this page.',
            confirmButtonColor: '#b8860b',
            confirmButtonText: 'Go to Login'
        }).then(() => {
            const appBase = (typeof appBaseUrl === 'string' && appBaseUrl)
                ? appBaseUrl
                : ((typeof baseApiUrl === 'string' && baseApiUrl.endsWith('/api'))
                    ? baseApiUrl.slice(0, -4)
                    : `${window.location.origin}/FAS_music`);
            window.location.href = `${appBase}/index.html`;
        });
        return false;
    }
    return true;
}

async function fetchStudentPortalDataByEmail(email) {
    const url = `${baseApiUrl}/students.php?action=get-student-portal&email=${encodeURIComponent(email)}`;
    try {
        const res = await axios.get(url);
        const data = res.data;
        if (data?.success && data?.student) capturePortalDecisionState(data, 'student');
        return data;
    } catch (error) {
        const message = String(error?.response?.data?.error || '');
        if (error?.response?.status === 404 && message.toLowerCase().includes('student not found for this email')) {
            return {
                success: true,
                registration_required: true,
                message: 'Your previous registration is no longer active. Please register again to continue.',
                student: null,
                guardians: [],
                primary_guardian: null,
                instruments: [],
                current_enrollment: null,
                enrollment_history: [],
                current_session_grades: []
            };
        }
        throw error;
    }
}

async function handleStudentRegistrationReset(portal, fallbackMessage) {
    if (!portal?.registration_required) {
        return false;
    }

    const message = portal.message || fallbackMessage || 'Your registration is no longer active. Please register again.';

    if (typeof Swal !== 'undefined' && Swal.fire) {
        await Swal.fire({
            icon: 'info',
            title: 'Register Again',
            text: message,
            confirmButtonText: 'OK'
        });
    } else {
        alert(message);
    }

    Auth.logout();
    return true;
}

function buildStudentPerformanceMetrics(rows) {
    const rubricRows = Array.isArray(rows) ? rows.filter(row => Number(row?.progress_id || 0) > 0) : [];
    const dynamic = new Map();
    rubricRows.forEach(row => {
        (Array.isArray(row?.criteria_scores) ? row.criteria_scores : []).forEach(item => {
            const label = String(item?.name || '').trim();
            const score = Number(item?.score || 0);
            if (!label || score < 1 || score > 5) return;
            if (!dynamic.has(label)) dynamic.set(label, []);
            dynamic.get(label).push(score);
        });
    });
    if (dynamic.size) {
        return Array.from(dynamic.entries()).map(([label, values]) => {
            const average = values.reduce((sum, value) => sum + value, 0) / values.length;
            return { label, helper:'Instructor-defined lesson criterion', average, percent:Math.round((average / 5) * 100) };
        });
    }
    const rubricDefinitions = [
        { label: 'Rhythm', source: 'rhythm_score', helper: 'Timing and pulse' },
        { label: 'Technique', source: 'technique_score', helper: 'Hand control and accuracy' },
        { label: 'Sight Reading', source: 'assignment_score', helper: 'Reading and response' },
        { label: 'Performance Confidence', source: 'performance_score', helper: 'Stage presence and confidence' },
        { label: 'Theory Knowledge', source: 'focus_score', helper: 'Focus and musical understanding' }
    ];

    return rubricDefinitions.map(item => {
        const values = rubricRows
            .map(row => Number(row?.[item.source] || 0))
            .filter(value => Number.isFinite(value) && value > 0);
        const average = values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null;
        return {
            ...item,
            average,
            percent: average === null ? null : Math.max(0, Math.min(100, Math.round((average / 5) * 100)))
        };
    });
}

function renderStudentPerformanceProfile(metrics, rows) {
    const validMetrics = Array.isArray(metrics) ? metrics : [];
    const gradedRows = Array.isArray(rows)
        ? rows.filter(row => Number(row?.progress_id || 0) > 0)
        : [];
    const hasData = validMetrics.some(metric => Number(metric?.percent || 0) > 0);

    if (!validMetrics.length || !hasData) return '';

    const availableMetrics = validMetrics.filter(metric => Number.isFinite(Number(metric.percent)) && Number(metric.percent) > 0);
    const averagePercent = availableMetrics.length
        ? Math.round(availableMetrics.reduce((sum, metric) => sum + Number(metric.percent || 0), 0) / availableMetrics.length)
        : 0;
    const strongestMetric = availableMetrics.slice().sort((a, b) => Number(b.percent || 0) - Number(a.percent || 0))[0] || null;
    const radarId = 'studentPerformanceRadarChart';
    const radarEmptyId = 'studentPerformanceRadarEmpty';

    return `
        <div class="rounded-3xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 p-6 shadow-xl dark:shadow-black/40 mb-8">
            <div class="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <p class="text-xs font-bold uppercase tracking-[0.28em] text-gold-500">Performance Profile</p>
                    <h2 class="portal-section-title text-zinc-900 dark:text-white">Your Progress</h2>
                    <p class="text-sm text-zinc-500 dark:text-zinc-400 mt-1">
                        Based on ${gradedRows.length} graded session${gradedRows.length === 1 ? '' : 's'}.
                    </p>
                </div>
                <div class="flex flex-wrap gap-2">
                    <span class="inline-flex items-center rounded-full border border-gold-200 bg-gold-50 px-3 py-1.5 text-xs font-bold text-gold-700 dark:border-gold-500/20 dark:bg-gold-500/10 dark:text-gold-300">
                        Avg ${averagePercent}%
                    </span>
                    ${strongestMetric ? `<span class="inline-flex items-center rounded-full border border-zinc-200 bg-zinc-50 px-3 py-1.5 text-xs font-bold text-zinc-700 dark:border-white/10 dark:bg-white/5 dark:text-zinc-200">${escapeHtml(strongestMetric.label)} leading</span>` : ''}
                </div>
            </div>

            <div class="mt-6 grid grid-cols-1 xl:grid-cols-[minmax(0,1.1fr)_minmax(320px,0.95fr)] gap-8 items-center">
                <div class="relative rounded-3xl border border-zinc-100 dark:border-white/10 bg-gradient-to-br from-white to-zinc-50 dark:from-white/5 dark:to-white/3 p-5 min-h-[320px]">
                    <canvas id="${radarId}" aria-label="Student performance radar chart"></canvas>
                    <div id="${radarEmptyId}" class="hidden absolute inset-0 flex items-center justify-center text-center px-8 text-sm text-zinc-500 dark:text-zinc-400">
                        Grade a session to see the radar snapshot.
                    </div>
                </div>

                <div class="space-y-0 divide-y divide-zinc-100 dark:divide-white/10 rounded-3xl border border-zinc-100 dark:border-white/10 bg-white dark:bg-black/20 overflow-hidden">
                    ${validMetrics.map(metric => {
                        const percent = Number.isFinite(Number(metric.percent)) ? Number(metric.percent) : 0;
                        const helperText = metric.helper
                            ? `<div class="text-sm text-zinc-500 dark:text-zinc-400 mt-1">${escapeHtml(metric.helper)}</div>`
                            : '';
                        return `
                            <div class="px-5 py-4 flex items-start justify-between gap-4">
                                <div class="min-w-0">
                                    <div class="flex items-center gap-2">
                                        <span class="h-2.5 w-2.5 rounded-full bg-gold-500 shrink-0"></span>
                                        <div class="text-base font-semibold text-zinc-900 dark:text-white">${escapeHtml(metric.label)}</div>
                                    </div>
                                    ${helperText}
                                </div>
                                <div class="text-lg font-black text-zinc-900 dark:text-white shrink-0">${percent}%</div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        </div>
    `;
}

function renderStudentPerformanceRadar(metrics) {
    const validMetrics = Array.isArray(metrics) ? metrics : [];
    const radarCanvas = document.getElementById('studentPerformanceRadarChart');
    const radarEmpty = document.getElementById('studentPerformanceRadarEmpty');

    if (_studentPerformanceRadarChartInstance) {
        _studentPerformanceRadarChartInstance.destroy();
        _studentPerformanceRadarChartInstance = null;
    }

    const hasData = validMetrics.some(metric => Number(metric?.percent || 0) > 0);
    if (!radarCanvas) return;

    if (!hasData || typeof Chart === 'undefined') {
        radarCanvas.style.display = 'none';
        if (radarEmpty) radarEmpty.classList.remove('hidden');
        return;
    }

    if (radarEmpty) radarEmpty.classList.add('hidden');
    radarCanvas.style.display = '';

    _studentPerformanceRadarChartInstance = new Chart(radarCanvas, {
        type: 'radar',
        data: {
            labels: validMetrics.map(metric => metric.label),
            datasets: [{
                data: validMetrics.map(metric => Number(metric.percent || 0)),
                borderColor: '#b8860b',
                backgroundColor: 'rgba(184, 134, 11, 0.16)',
                pointBackgroundColor: '#b8860b',
                pointBorderColor: '#ffffff',
                pointHoverBackgroundColor: '#b8860b',
                pointHoverBorderColor: '#ffffff',
                pointRadius: 4,
                borderWidth: 2.5
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: {
                r: {
                    min: 0,
                    max: 100,
                    ticks: {
                        stepSize: 20,
                        backdropColor: 'transparent',
                        color: '#9ca3af',
                        font: { size: 10, weight: '600' }
                    },
                    grid: { color: 'rgba(212,175,55,0.12)' },
                    angleLines: { color: 'rgba(212,175,55,0.12)' },
                    pointLabels: {
                        color: '#374151',
                        font: { size: 11, weight: '700' }
                    }
                }
            }
        }
    });
}

function getStudentCertificateState(portal) {
    const enrollment = portal?.current_enrollment || null;
    const student = portal?.student || {};
    const certificate = portal?.certificate || {};
    const packageSessions = Number(enrollment?.package_sessions || student?.package_sessions || 0);
    const completedSessionsRaw = Number(enrollment?.completed_sessions || 0);
    const gradedSessions = Array.isArray(portal?.current_session_grades)
        ? portal.current_session_grades.filter((row) => Number(row?.progress_id || 0) > 0).length
        : 0;
    const completedSessions = Math.max(completedSessionsRaw, gradedSessions);
    const enrollmentStatus = String(enrollment?.status || '').trim().toLowerCase();
    const isAvailable = certificate?.available === true || Number(certificate?.certificate_id || 0) > 0;

    return {
        isAvailable,
        packageSessions,
        completedSessions,
        enrollmentStatus,
        studentName: `${student?.first_name || ''} ${student?.last_name || ''}`.trim() || 'Student',
        packageName: enrollment?.package_name || student?.package_name || 'Lesson Package',
        achievedLevel: certificate?.achieved_level || 'Achieved Level',
        instrumentName: certificate?.instrument_name || 'Music',
        certificateNumber: certificate?.certificate_number || '',
        teacherName: certificate?.teacher_name || `${enrollment?.teacher_first_name || ''} ${enrollment?.teacher_last_name || ''}`.trim() || 'Teacher',
        issueDate: certificate?.issue_date || '',
        examRating: certificate?.exam_rating || '',
        examinerNotes: certificate?.examiner_notes || '',
        strengths: Array.isArray(certificate?.strengths) ? certificate.strengths : [],
        branchName: student?.branch_name || enrollment?.branch_name || 'Father & Sons Music'
    };
}

function isStudentEnrollmentCompleted(portal) {
    const enrollment = portal?.current_enrollment || null;
    const purchased = Number(enrollment?.package_sessions || portal?.student?.package_sessions || 0);
    const used = Number(enrollment?.used_sessions || enrollment?.completed_sessions || 0);
    return String(enrollment?.status || '').trim().toLowerCase() === 'completed'
        || (purchased > 0 && used >= purchased);
}

function renderStudentCertificateCard(portal) {
    const state = getStudentCertificateState(portal);
    if (!state.isAvailable) {
        return '';
    }

    const issuedLabel = formatDateLong(state.issueDate) || state.issueDate;
    return `
        <section class="mb-5 rounded-2xl border border-gold-200/80 bg-gradient-to-br from-gold-50 via-white to-amber-50 px-4 py-4 dark:border-gold-500/20 dark:from-gold-500/10 dark:via-white/5 dark:to-white/3 sm:px-5">
            <div class="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
                <div class="flex items-start gap-3">
                    <div class="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-gold-500 text-black">
                        <i class="fas fa-certificate text-lg"></i>
                    </div>
                    <div class="min-w-0">
                        <p class="text-xs font-black uppercase tracking-[0.3em] text-gold-600 dark:text-gold-300">Certificate Issued</p>
                        <h2 class="mt-0.5 text-lg font-black text-zinc-900 dark:text-white">Achievement Certificate Ready</h2>
                        <p class="mt-1 text-xs text-zinc-600 dark:text-zinc-300 max-w-2xl">
                            The academy recognized your ${escapeHtml(state.achievedLevel)} achievement in ${escapeHtml(state.instrumentName)} after formal assessment.
                        </p>
                        <div class="mt-2 flex flex-wrap gap-1.5 text-[11px] font-bold text-zinc-600 dark:text-zinc-300">
                            <span class="inline-flex items-center rounded-full border border-gold-200 bg-white/80 px-2.5 py-1 dark:border-gold-500/20 dark:bg-white/5">
                                <i class="fas fa-user-graduate mr-2 text-gold-500"></i>${escapeHtml(state.studentName)}
                            </span>
                            <span class="inline-flex items-center rounded-full border border-gold-200 bg-white/80 px-2.5 py-1 dark:border-gold-500/20 dark:bg-white/5">
                                <i class="fas fa-chalkboard-teacher mr-2 text-gold-500"></i>${escapeHtml(state.teacherName)}
                            </span>
                            <span class="inline-flex items-center rounded-full border border-gold-200 bg-white/80 px-2.5 py-1 dark:border-gold-500/20 dark:bg-white/5">
                                <i class="fas fa-calendar-check mr-2 text-gold-500"></i>${escapeHtml(issuedLabel)}
                            </span>
                        </div>
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <button type="button" onclick="openStudentCertificatePreview()" class="rounded-xl bg-zinc-900 px-4 py-2.5 text-xs font-extrabold text-white transition hover:bg-zinc-800">
                        <i class="fas fa-eye mr-2"></i>View Certificate
                    </button>
                    <button type="button" onclick="printStudentCertificate()" class="rounded-xl bg-gold-500 px-4 py-2.5 text-xs font-extrabold text-black transition hover:bg-gold-400">
                        <i class="fas fa-print mr-2"></i>Print / Save PDF
                    </button>
                </div>
            </div>
        </section>
    `;
}

function renderStudentCompletedSessionsPanel(portal) {
    const state = getStudentCertificateState(portal);
    if (!isStudentEnrollmentCompleted(portal)) {
        return '';
    }

    const completionEntries = [];
    const enrollment = portal?.current_enrollment || null;

    if (enrollment) {
        completionEntries.push(enrollment);
    }

    (Array.isArray(portal?.enrollment_history) ? portal.enrollment_history : []).forEach((row) => {
        if (!row) return;
        const enrollmentId = Number(row.enrollment_id || 0);
        if (enrollmentId > 0 && completionEntries.some((item) => Number(item?.enrollment_id || 0) === enrollmentId)) {
            return;
        }
        completionEntries.push(row);
    });

    const rows = completionEntries
        .filter((row) => {
            const rowStatus = String(row?.status || '').trim().toLowerCase();
            const rowCompletedSessions = Number(row?.completed_sessions || 0);
            const rowPackageSessions = Number(row?.package_sessions || state.packageSessions || 0);
            return rowStatus === 'completed' || (rowPackageSessions > 0 && rowCompletedSessions >= rowPackageSessions);
        })
        .sort((a, b) => {
            const aTime = new Date(a?.end_date || a?.updated_at || a?.created_at || 0).getTime() || 0;
            const bTime = new Date(b?.end_date || b?.updated_at || b?.created_at || 0).getTime() || 0;
            if (aTime !== bTime) return bTime - aTime;
            return Number(b?.enrollment_id || 0) - Number(a?.enrollment_id || 0);
        });

    const historyMarkup = rows.length
        ? rows.map((row) => {
            const completedLabel = formatDateLong(row?.end_date || row?.updated_at || row?.created_at || '') || 'Not set';
            const paymentLabel = String(row?.payment_type || 'Partial Payment');
            const amountLabel = formatCurrencyPHP(Number(row?.total_amount || 0));
            const rowCompletedSessions = Number(row?.completed_sessions || 0);
            const rowRequiredSessions = Number(row?.package_sessions || row?.total_sessions || state.packageSessions || rowCompletedSessions || 0);
            const displayCompletedSessions = rowCompletedSessions > 0
                ? rowCompletedSessions
                : (String(row?.status || '').trim().toLowerCase() === 'completed' ? rowRequiredSessions : 0);
            const sessionLabel = `${displayCompletedSessions} of ${rowRequiredSessions || displayCompletedSessions} sessions`;

            return `
                <article class="rounded-[1.5rem] border border-zinc-200/80 dark:border-white/10 bg-zinc-50/80 dark:bg-white/5 px-5 py-4 sm:px-6 sm:py-5">
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                        <div class="flex items-start gap-4 min-w-0">
                            <div class="h-12 w-12 rounded-2xl border border-gold-100 dark:border-white/10 bg-gold-50 dark:bg-white/5 text-gold-600 grid place-items-center shrink-0">
                                <i class="fas fa-calendar-check text-lg"></i>
                            </div>
                            <div class="min-w-0">
                                <div class="text-lg font-extrabold text-zinc-900 dark:text-white truncate">${escapeHtml(row?.package_name || 'Session Package')}</div>
                                <div class="mt-1 text-sm text-zinc-600 dark:text-zinc-300">Completed on ${escapeHtml(completedLabel)}</div>
                            </div>
                        </div>
                        <span class="inline-flex items-center self-start rounded-full border border-gold-200 bg-gold-50 px-3 py-1.5 text-xs font-bold text-gold-700 dark:border-gold-500/20 dark:bg-gold-500/10 dark:text-gold-300">
                            Completed
                        </span>
                    </div>
                </article>
            `;
        }).join('')
        : `
            <div class="rounded-[1.75rem] border border-dashed border-zinc-300 dark:border-white/10 bg-zinc-50/70 dark:bg-white/5 px-6 py-10 text-center text-zinc-500 dark:text-zinc-400">
                Your completed lessons will appear here.
            </div>
        `;

    return `
        <section class="rounded-[1.75rem] border border-zinc-200/80 dark:border-white/10 bg-white dark:bg-white/5 px-5 py-5 sm:px-6 sm:py-6 mb-6">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                    <h2 class="portal-section-title text-zinc-900 dark:text-white">Session History</h2>
                    <p class="text-sm text-zinc-500 dark:text-zinc-400 mt-1">Purchased lessons that have been used. This does not indicate a passed level.</p>
                </div>
                <span class="inline-flex items-center rounded-full border border-gold-200 bg-gold-50 px-4 py-2 text-sm font-bold text-gold-700 dark:border-gold-500/20 dark:bg-gold-500/10 dark:text-gold-300 self-start sm:self-auto">
                    Completed
                </span>
            </div>
            <div class="mt-5 space-y-4">
                ${historyMarkup}
            </div>
        </section>
    `;
}

function ensureStudentCertificateModal() {
    let modal = document.getElementById('studentCertificateModal');
    if (modal) {
        return modal;
    }

    const wrapper = document.createElement('div');
    wrapper.innerHTML = `
        <div id="studentCertificateModal" class="fixed inset-0 z-[80] hidden bg-black/60 backdrop-blur-sm p-0 sm:p-4" aria-hidden="true">
            <div class="min-h-full flex items-stretch sm:items-center justify-center">
                <div class="w-full h-full sm:h-auto sm:max-h-[88vh] sm:max-w-3xl bg-white dark:bg-obsidian rounded-none sm:rounded-2xl border-0 sm:border sm:border-zinc-200 dark:sm:border-white/10 shadow-2xl overflow-hidden">
                    <div class="flex items-center justify-between gap-4 px-4 sm:px-5 py-3 border-b border-zinc-200 dark:border-white/10">
                        <div>
                            <div class="text-xs uppercase tracking-[0.25em] text-gold-600 dark:text-gold-300 font-bold">Certificate</div>
                            <div class="text-base font-extrabold text-zinc-900 dark:text-white mt-0.5">Achievement Certificate</div>
                        </div>
                        <button type="button" onclick="closeStudentCertificatePreview()" class="h-10 w-10 rounded-full border border-zinc-200 dark:border-white/10 text-zinc-600 dark:text-zinc-300 hover:bg-zinc-100 dark:hover:bg-white/10 transition" aria-label="Close certificate preview">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                    <div class="overflow-y-auto max-h-[calc(100vh-65px)] sm:max-h-[calc(88vh-65px)] px-3 sm:px-5 py-4 bg-zinc-50/80 dark:bg-black/20">
                        <div id="studentCertificatePreview" class="mx-auto max-w-2xl"></div>
                        <div class="mt-3 flex flex-wrap justify-end gap-2">
                            <button type="button" onclick="printStudentCertificate()" class="px-4 py-2.5 rounded-xl bg-gold-500 hover:bg-gold-400 text-black text-xs font-extrabold transition">
                                <i class="fas fa-print mr-2"></i>Print / Save PDF
                            </button>
                            <button type="button" onclick="closeStudentCertificatePreview()" class="px-4 py-2.5 rounded-xl bg-zinc-900 hover:bg-zinc-800 text-white text-xs font-extrabold transition">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(wrapper.firstElementChild);
    return document.getElementById('studentCertificateModal');
}

function buildStudentCertificateMarkup(portal) {
    const state = getStudentCertificateState(portal);
    const issuedLabel = formatDateLong(state.issueDate) || state.issueDate;
    const strengthsMarkup = state.strengths.length
        ? state.strengths.map(item => `<span class="inline-flex items-center rounded-full border border-gold-200 bg-gold-50 px-3 py-1.5 text-xs font-bold text-gold-700"><i class="fas fa-star mr-1.5 text-[9px]"></i>${escapeHtml(item.name)} · ${Math.round(Number(item.average))}/5</span>`).join('')
        : '';
    return `
        <div class="certificate-sheet relative overflow-hidden rounded-2xl border-2 border-gold-200 bg-white p-5 sm:p-7 shadow-xl shadow-black/10">
            <div class="absolute inset-0 bg-[radial-gradient(circle_at_top_left,_rgba(212,175,55,0.18),_transparent_35%),radial-gradient(circle_at_bottom_right,_rgba(184,134,11,0.12),_transparent_35%)]"></div>
            <div class="relative">
                <div class="flex items-start justify-between gap-4">
                    <div>
                        <p class="text-[9px] font-black uppercase tracking-[0.38em] text-gold-600">Father & Sons Music</p>
                        <h3 class="mt-1 text-2xl sm:text-3xl font-black text-zinc-900">Certificate of Achievement</h3>
                    </div>
                    <div class="h-11 w-11 rounded-xl bg-gold-500 text-black grid place-items-center shadow-lg shadow-gold-500/20 shrink-0">
                        <i class="fas fa-award text-xl"></i>
                    </div>
                </div>

                <div class="mt-6 text-center">
                    <p class="text-[10px] font-bold uppercase tracking-[0.28em] text-zinc-500">This certifies that</p>
                    <div class="mt-2 text-2xl sm:text-3xl font-black text-zinc-900">${escapeHtml(state.studentName)}</div>
                    <p class="mt-2 text-sm text-zinc-600">
                        has achieved <span class="font-bold text-zinc-900">${escapeHtml(state.achievedLevel)}</span>
                        in <span class="font-bold text-zinc-900">${escapeHtml(state.instrumentName)}</span>
                        at <span class="font-bold text-zinc-900">${escapeHtml(state.branchName)}</span>.
                    </p>
                </div>

                <div class="mt-6 grid grid-cols-3 gap-2">
                    <div class="rounded-xl border border-zinc-200 bg-white/80 px-3 py-3 text-center">
                        <div class="text-[9px] uppercase tracking-wider text-zinc-500 font-bold">Level</div>
                        <div class="mt-1 text-sm font-black text-zinc-900">${escapeHtml(state.achievedLevel)}</div>
                    </div>
                    <div class="rounded-xl border border-zinc-200 bg-white/80 px-3 py-3 text-center">
                        <div class="text-[9px] uppercase tracking-wider text-zinc-500 font-bold">Instrument</div>
                        <div class="mt-1 text-sm font-black text-zinc-900">${escapeHtml(state.instrumentName)}</div>
                    </div>
                    <div class="rounded-xl border border-zinc-200 bg-white/80 px-3 py-3 text-center">
                        <div class="text-[9px] uppercase tracking-wider text-zinc-500 font-bold">Issued</div>
                        <div class="mt-1 text-xs font-black text-zinc-900">${escapeHtml(issuedLabel)}</div>
                    </div>
                </div>

                ${(state.examRating || strengthsMarkup) ? `<div class="mt-4 rounded-xl border border-gold-200 bg-white/80 px-4 py-3"><div class="flex flex-wrap items-center justify-between gap-2"><div><div class="text-[9px] font-bold uppercase tracking-wider text-zinc-500">Achievement highlights</div><div class="mt-1 text-sm font-bold text-zinc-900">Passed promotional exam${state.examRating ? ` · ${escapeHtml(state.examRating)}` : ''}</div></div><i class="fas fa-chart-line text-gold-600"></i></div>${strengthsMarkup ? `<div class="mt-2 flex flex-wrap gap-2">${strengthsMarkup}</div>` : ''}${state.examinerNotes ? `<div class="mt-2 text-xs italic text-zinc-500">Examiner note: ${escapeHtml(state.examinerNotes)}</div>` : ''}</div>` : ''}

                <div class="mt-5 flex items-end justify-between gap-6">
                    <div class="text-left">
                        <div class="text-xs uppercase tracking-[0.3em] text-zinc-500 font-bold">Teacher</div>
                        <div class="mt-1 text-sm font-bold text-zinc-900">${escapeHtml(state.teacherName)}</div>
                    </div>
                    <div class="text-right">
                        <div class="text-xs uppercase tracking-[0.3em] text-zinc-500 font-bold">Status</div>
                        <div class="mt-1 text-sm font-black text-emerald-600">Achieved</div>
                    </div>
                </div>
            </div>
        </div>
    `;
}

function renderStudentCertificatePreview(portal) {
    const modal = ensureStudentCertificateModal();
    const preview = document.getElementById('studentCertificatePreview');
    if (!modal || !preview) return false;
    preview.innerHTML = buildStudentCertificateMarkup(portal);
    modal.classList.remove('hidden');
    modal.setAttribute('aria-hidden', 'false');
    return true;
}

function closeStudentCertificatePreview() {
    const modal = document.getElementById('studentCertificateModal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.setAttribute('aria-hidden', 'true');
}

function openStudentCertificatePreview() {
    const portal = studentDashboardPortalState || studentDashboardMetaState || null;
    if (!portal) {
        showMessage('Certificate details are not available yet.', 'error');
        return;
    }
    const state = getStudentCertificateState(portal);
    if (!state.isAvailable) {
        showMessage('A certificate becomes available only after the academy issues it for a level achievement.', 'error');
        return;
    }
    renderStudentCertificatePreview(portal);
}

function printStudentCertificate() {
    const portal = studentDashboardPortalState || studentDashboardMetaState || null;
    if (!portal) {
        showMessage('Certificate details are not available yet.', 'error');
        return;
    }
    const state = getStudentCertificateState(portal);
    if (!state.isAvailable) {
        showMessage('A certificate becomes available only after the academy issues it for a level achievement.', 'error');
        return;
    }

    const html = buildStudentCertificateMarkup(portal);
    const iframe = document.createElement('iframe');
    iframe.setAttribute('aria-hidden', 'true');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    iframe.style.opacity = '0';
    iframe.style.pointerEvents = 'none';

    const cleanup = () => {
        window.setTimeout(() => {
            try {
                iframe.remove();
            } catch (error) {
                console.warn('Unable to remove certificate print iframe.', error);
            }
        }, 1500);
    };

    iframe.onload = () => {
        try {
            const win = iframe.contentWindow;
            if (!win) {
                cleanup();
                return;
            }
            win.focus();
            win.print();
        } catch (error) {
            console.warn('Unable to print certificate iframe.', error);
        } finally {
            cleanup();
        }
    };

    const doc = `
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>Achievement Certificate</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        html, body { margin: 0; padding: 0; background: #f4f1e8; font-family: Inter, Arial, sans-serif; }
        .print-wrap { max-width: 1100px; margin: 0 auto; padding: 32px; }
        @media print {
            html, body { background: #fff; }
            .print-wrap { padding: 0; max-width: none; }
        }
    </style>
</head>
<body>
    <div class="print-wrap">${html}</div>
</body>
</html>`;

    document.body.appendChild(iframe);
    iframe.srcdoc = doc;
}

async function fetchGuardianPortalDataByEmail(email) {
    const url = `${baseApiUrl}/students.php?action=get-guardian-portal&email=${encodeURIComponent(email)}`;
    const res = await axios.get(url);
    const data = res.data;
    if (data?.success && Array.isArray(data.students)) {
        data.students.forEach(item => capturePortalDecisionState(item, 'guardian'));
    }
    return data;
}

async function fetchAttendanceSummary(studentId) {
    const url = `${baseApiUrl}/attendance.php?action=get-summary&student_id=${encodeURIComponent(studentId)}`;
    const res = await axios.get(url);
    return res.data;
}

async function fetchAttendanceList(studentId, limit = 50) {
    const url = `${baseApiUrl}/attendance.php?action=get-student-attendance&student_id=${encodeURIComponent(studentId)}&limit=${encodeURIComponent(limit)}`;
    const res = await axios.get(url);
    return res.data;
}

function formatCurrencyPHP(amount) {
    const n = Number(amount || 0);
    return `₱${n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function setText(id, value) {
    const el = document.getElementById(id);
    if (el) el.textContent = value ?? '';
}

function setHtml(id, html) {
    const el = document.getElementById(id);
    if (el) el.innerHTML = html;
}

function isRegistrationProfileComplete(student) {
    if (!student) return false;
    const required = ['first_name', 'last_name', 'email', 'phone', 'branch_id', 'date_of_birth', 'address'];
    return required.every((field) => {
        const val = student[field];
        return val !== null && val !== undefined && String(val).trim() !== '';
    });
}

function computeAgeFromDob(dob) {
    if (!dob) return null;
    const birth = new Date(dob);
    if (Number.isNaN(birth.getTime())) return null;
    const today = new Date();
    let age = today.getFullYear() - birth.getFullYear();
    const m = today.getMonth() - birth.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birth.getDate())) age--;
    return age >= 0 ? age : null;
}

async function fetchGuardianByEmail(email) {
    const url = `${baseApiUrl}/students.php?action=find-guardian&email=${encodeURIComponent(email)}`;
    const res = await axios.get(url);
    return res.data;
}

async function setGuardianMode(studentId, guardianMode, guardianEmail = '', guardianDetails = {}) {
    const res = await axios.post(`${baseApiUrl}/students.php?action=set-guardian-mode`, {
        student_id: Number(studentId),
        guardian_mode: guardianMode,
        guardian_email: guardianEmail,
        guardian_first_name: guardianDetails.first_name || '',
        guardian_last_name: guardianDetails.last_name || '',
        guardian_phone: guardianDetails.phone || '',
        guardian_relationship: guardianDetails.relationship || '',
        guardian_password_mode: guardianDetails.password_mode || 'default',
        guardian_password: guardianDetails.password || ''
    });
    return res.data;
}

function badgeClassForRegistrationStatus(status) {
    switch (String(status || '')) {
        case 'Approved': return 'bg-blue-500/15 text-blue-400 border border-blue-500/25';
        case 'Fee Paid': return 'bg-green-500/15 text-green-400 border border-green-500/25';
        case 'Pending': return 'bg-yellow-500/15 text-yellow-400 border border-yellow-500/25';
        case 'Rejected': return 'bg-red-500/15 text-red-400 border border-red-500/25';
        default: return 'bg-zinc-500/15 text-zinc-300 border border-zinc-500/25';
    }
}

function renderInstrumentChips(instruments) {
    if (!Array.isArray(instruments) || instruments.length === 0) {
        return `<div class="text-sm text-zinc-400 italic">No instruments assigned yet.</div>`;
    }
    return instruments.map(inst => {
        const name = escapeHtml(inst.instrument_name || 'Instrument');
        const type = escapeHtml(inst.type_name || '');
        const meta = type ? `<span class="text-[10px] text-zinc-400 ml-2">(${type})</span>` : '';
        return `<div class="inline-flex items-center px-3 py-2 rounded-xl bg-white/5 border border-white/10 text-sm text-white">
            <i class="fas fa-music mr-2 text-gold-400"></i>${name}${meta}
        </div>`;
    }).join('');
}

function buildStudentQrPayload(student) {
    // Payload format: FAS_ATTENDANCE|STUDENT|student_id|email|branch_id
    // branch_id ensures uptown=uptown, downtown=downtown validation at scan
    const sid = student?.student_id ?? '';
    const email = student?.email ?? '';
    const bid = student?.branch_id ?? '';
    return `FAS_ATTENDANCE|STUDENT|${sid}|${email}|${bid}`;
}

async function fetchStudentQrStatus(studentId, email = '') {
    const params = studentId > 0
        ? `student_id=${encodeURIComponent(studentId)}`
        : `email=${encodeURIComponent(email)}`;
    const url = `${baseApiUrl}/attendance.php?action=qr-status&${params}`;
    const res = await axios.get(url);
    return res.data;
}

function renderStudentQrStatus(status) {
    const code = String(status?.code || 'no_session');
    const titleMap = {
        valid_today: 'Ready to scan',
        early: 'Not yet',
        missed: 'Missed today',
        completed: 'Done for today',
        schedule_frozen: 'On hold',
        room_required: 'Ask the desk',
        no_session: 'No class today'
    };
    const banner = document.getElementById('qrStatusBanner');
    const titleEl = document.getElementById('studentQrStatusTitle');
    const messageEl = document.getElementById('studentQrStatusMessage');
    const styles = {
        valid_today: 'block border-emerald-300 bg-emerald-50 text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-200',
        early: 'block border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200',
        missed: 'block border-rose-300 bg-rose-50 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-200',
        completed: 'block border-sky-300 bg-sky-50 text-sky-700 dark:border-sky-500/30 dark:bg-sky-500/10 dark:text-sky-200',
        schedule_frozen: 'block border-rose-300 bg-rose-50 text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-200',
        room_required: 'block border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/30 dark:bg-amber-500/10 dark:text-amber-200',
        no_session: 'block border-zinc-300 bg-zinc-50 text-zinc-700 dark:border-zinc-500/30 dark:bg-zinc-500/10 dark:text-zinc-200'
    };

    if (titleEl) titleEl.textContent = titleMap[code] || 'Status';
    if (messageEl) messageEl.textContent = status?.message || '';
    if (banner) {
        banner.className = `w-full mb-4 rounded-2xl border px-4 py-3 text-sm font-medium ${styles[code] || styles.no_session}`;
        banner.textContent = status?.message || '';
        banner.classList.toggle('hidden', !status?.message);
    }
}

function renderQrCode(targetElId, payload) {
    const target = document.getElementById(targetElId);
    if (!target) return;
    target.innerHTML = '';
    if (!payload) {
        target.innerHTML = '<div class="text-sm text-zinc-400">QR data unavailable.</div>';
        return;
    }
    if (typeof QRCode === 'undefined') {
        target.innerHTML = '<div class="text-sm text-zinc-400">QR library not loaded.</div>';
        return;
    }
    // Ensure high-contrast QR for camera scanning
    target.style.background = '#ffffff';
    target.style.padding = '10px';
    target.style.borderRadius = '12px';
    target.style.boxShadow = '0 8px 20px rgba(0,0,0,0.08)';
    // QRCode.js expects a DOM element
    // eslint-disable-next-line no-new
    new QRCode(target, {
        text: payload,
        width: 220,
        height: 220,
        colorDark: '#000000',
        colorLight: '#ffffff',
        correctLevel: QRCode.CorrectLevel.H
    });
}

function renderAvailablePackagesAndInstruments(packages, instruments) {
    const pkgRows = Array.isArray(packages) && packages.length
        ? packages.map(p => {
            const sessions = Number(p.sessions || p.total_sessions || 0);
            const maxInst = Number(p.max_instruments || 0);
            const price = Number(p.price || 0);
            return `<div class="rounded-xl border border-white/10 bg-white/5 p-3">
                <div class="font-semibold text-white">${escapeHtml(p.package_name || 'Package')}</div>
                <div class="text-xs text-zinc-400 mt-1">${sessions} sessions • up to ${maxInst || 1} instrument(s)</div>
                <div class="text-xs text-gold-400 mt-1">${formatCurrencyPHP(price)}</div>
            </div>`;
        }).join('')
        : '<div class="text-zinc-500">No session packages available yet.</div>';

    const typeSet = new Set();
    (Array.isArray(instruments) ? instruments : []).forEach(i => {
        const t = (i.type_name || '').trim();
        if (t) typeSet.add(t);
    });
    const types = Array.from(typeSet);
    const instHtml = types.length
        ? `<div class="flex flex-wrap gap-2 mt-3">${types.map(t => `<span class="px-2 py-1 rounded-lg border border-gold-500/30 bg-gold-500/10 text-gold-300 text-xs font-semibold">${escapeHtml(t)}</span>`).join('')}</div>`
        : '<div class="text-zinc-500 mt-3">No instrument types available for your branch yet.</div>';

    return `${pkgRows}${instHtml}`;
}

function buildPublicFileUrl(filePath) {
    if (!filePath) return '';
    const raw = String(filePath || '').trim();
    if (!raw) return '';
    if (/^https?:\/\//i.test(raw)) return raw;
    const appBase = String(baseApiUrl || '').replace(/\/api\/?$/, '');
    const cleanPath = raw.replace(/^\/+/, '');
    return `${appBase}/${cleanPath}`;
}

const paymentDestinationControlIds = [
    'guardian-new-payment-method',
    'regPayMethod',
    'studentRequestPaymentMethod',
    'fpMethod',
    'guardianAdditionalPaymentMethod',
    'studentAdditionalSessionsPaymentMethod',
    'studentSessionExtensionPaymentMethod'
];
let paymentDestinationRequest = null;

function fetchPaymentDestination() {
    if (!paymentDestinationRequest) {
        paymentDestinationRequest = axios.get(`${baseApiUrl}/payment_destination.php`)
            .then(response => response.data?.success ? response.data.recipient : null)
            .catch(() => null);
    }
    return paymentDestinationRequest;
}

function renderPaymentDestination(container, method, recipient) {
    if (!container) return;
    const selectedMethod = String(method || '').trim().toLowerCase();
    if (!selectedMethod) {
        container.innerHTML = '';
        container.classList.add('hidden');
        return;
    }
    container.classList.remove('hidden');
    if (selectedMethod === 'cash') {
        container.innerHTML = '<span class="font-semibold"><i class="fas fa-store mr-1.5"></i>Pay at your selected branch</span>';
        return;
    }

    const contact = String(recipient?.contact_number || '').trim();
    const gcash = String(recipient?.gcash_number || contact).trim();
    const gcashQrPath = String(recipient?.gcash_qr_path || '').trim();
    const bankName = String(recipient?.bank_name || '').trim();
    const bankAccountName = String(recipient?.bank_account_name || '').trim();
    const bankAccountNumber = String(recipient?.bank_account_number || '').trim();

    let heading = 'Payment destination';
    let details = '';
    let copyValue = '';
    if (selectedMethod === 'gcash') {
        heading = 'GCash';
        copyValue = gcash;
        details = gcash
            ? `<span class="font-extrabold text-zinc-900 dark:text-white">${escapeHtml(gcash)}</span>`
            : 'Contact the branch desk for the current GCash number.';
    } else if (selectedMethod.includes('bank')) {
        heading = 'Bank transfer destination';
        if (bankAccountNumber) {
            copyValue = bankAccountNumber;
            details = `${bankName ? `<strong class="text-zinc-900 dark:text-white">${escapeHtml(bankName)}</strong><span class="mx-1">•</span>` : ''}${escapeHtml(bankAccountName)}<span class="mx-1">•</span><span class="font-bold text-gold-700 dark:text-gold-300">${escapeHtml(bankAccountNumber)}</span>`;
        } else {
            copyValue = contact;
            details = contact
                ? `<span class="font-extrabold text-zinc-900 dark:text-white">${escapeHtml(contact)}</span>`
                : 'Contact the branch desk for the current bank account details before sending.';
        }
    } else {
        details = contact
            ? `<span class="font-extrabold text-zinc-900 dark:text-white">${escapeHtml(contact)}</span>`
            : 'Contact the branch desk before sending your payment.';
        copyValue = contact;
    }

    container.innerHTML = `
        <div class="flex min-w-0 items-center justify-between gap-3">
            <div class="min-w-0 flex-1">
                <div class="text-[10px] font-black uppercase tracking-wider text-amber-700 dark:text-gold-300">${escapeHtml(heading)}</div>
                <div class="mt-1 break-all text-sm text-zinc-700 dark:text-zinc-200">${details}</div>
                ${copyValue ? `<button type="button" class="payment-destination-copy mt-1 inline-flex items-center gap-1 rounded-md px-1.5 py-1 text-[10px] font-bold text-amber-800 hover:bg-amber-100 dark:text-gold-200" data-copy-value="${escapeHtml(copyValue)}"><i class="fas fa-copy"></i>Copy</button>` : ''}
            </div>
            ${selectedMethod === 'gcash' && gcash ? (gcashQrPath
                ? `<img src="${escapeHtml(buildPublicFileUrl(gcashQrPath))}" alt="GCash payment QR" class="h-16 w-16 shrink-0 rounded-lg border border-amber-200 bg-white object-contain p-1">`
                : '<div class="payment-gcash-qr h-16 w-16 shrink-0 rounded-lg border border-amber-200 bg-white p-1" aria-label="GCash number QR code"></div>') : ''}
        </div>
    `;
    const qrTarget = container.querySelector('.payment-gcash-qr');
    if (qrTarget && typeof QRCode !== 'undefined') {
        new QRCode(qrTarget, { text: gcash, width: 54, height: 54, colorDark: '#111827', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
    }
    container.querySelector('.payment-destination-copy')?.addEventListener('click', async event => {
        const button = event.currentTarget;
        const value = String(button?.dataset?.copyValue || '');
        if (!value) return;
        try {
            await navigator.clipboard.writeText(value);
            const original = button.innerHTML;
            button.innerHTML = '<i class="fas fa-check mr-1"></i>Copied';
            window.setTimeout(() => { if (button.isConnected) button.innerHTML = original; }, 1500);
        } catch (_) {
            // The number remains visible for manual copying when clipboard access is unavailable.
        }
    });
}

function mountPaymentDestinationControl(select) {
    if (!(select instanceof HTMLSelectElement) || select.dataset.paymentDestinationMounted === '1') return;
    select.dataset.paymentDestinationMounted = '1';
    const container = document.createElement('div');
    const isEnrollmentPayment = select.id === 'studentRequestPaymentMethod';
    container.className = 'payment-destination-reference hidden rounded-xl border border-amber-200 bg-amber-50 px-3 py-2.5 text-xs text-amber-900 dark:border-gold-500/20 dark:bg-gold-500/10 dark:text-gold-100';
    container.dataset.paymentRecipientFor = select.id;
    if (isEnrollmentPayment && select.parentElement) {
        const paymentGrid = select.closest('.grid');
        if (paymentGrid) {
            [
                { control: document.getElementById('studentRequestPaymentMode'), label: 'Payment Type' },
                { control: select, label: 'Payment Method' }
            ].forEach(item => {
                if (!item.control || item.control.parentElement !== paymentGrid) return;
                const wrapper = document.createElement('div');
                const label = document.createElement('label');
                label.className = 'mb-2 block text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400';
                label.textContent = item.label;
                paymentGrid.insertBefore(wrapper, item.control);
                wrapper.appendChild(label);
                wrapper.appendChild(item.control);
            });
            // Keep the payment destination outside either field cell. Otherwise
            // the QR card stretches one grid row and leaves a large blank area
            // below Payment Type.
            paymentGrid.insertAdjacentElement('afterend', container);
        } else {
            select.insertAdjacentElement('afterend', container);
        }
    } else {
        select.insertAdjacentElement('afterend', container);
    }
    const refresh = async () => renderPaymentDestination(container, select.value, await fetchPaymentDestination());
    select.addEventListener('change', refresh);
    void refresh();
}

function initPaymentDestinationReferences() {
    const selector = paymentDestinationControlIds.map(id => `#${id}`).join(',');
    const scan = root => {
        if (root instanceof Element && root.matches(selector)) mountPaymentDestinationControl(root);
        root.querySelectorAll?.(selector).forEach(mountPaymentDestinationControl);
    };
    scan(document);
    if (!window.__paymentDestinationObserver) {
        window.__paymentDestinationObserver = new MutationObserver(mutations => {
            mutations.forEach(mutation => mutation.addedNodes.forEach(node => {
                if (node instanceof Element) scan(node);
            }));
        });
        window.__paymentDestinationObserver.observe(document.body, { childList: true, subtree: true });
    }
}

function formatTime12Hour(timeString) {
    if (!timeString) return '—';
    const parts = String(timeString).split(':');
    if (parts.length < 2) return timeString;
    const h = parseInt(parts[0], 10);
    const m = parseInt(parts[1], 10);
    if (Number.isNaN(h) || Number.isNaN(m)) return timeString;
    const suffix = h >= 12 ? 'PM' : 'AM';
    const hh = h % 12 === 0 ? 12 : h % 12;
    return `${hh}:${String(m).padStart(2, '0')} ${suffix}`;
}

function formatDateLong(dateString) {
    if (!dateString) return '';
    const raw = String(dateString).trim();
    if (!raw) return '';

    let dt;
    const ymd = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    if (ymd) {
        dt = new Date(`${raw}T12:00:00+08:00`);
    } else {
        dt = new Date(raw);
    }
    if (Number.isNaN(dt.getTime())) return raw;

    return dt.toLocaleDateString(undefined, {
        weekday: 'long',
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        timeZone: FAS_TIME_ZONE
    });
}

function formatDateShort(dateString) {
    if (!dateString) return '';
    const raw = String(dateString).trim();
    if (!raw) return '';
    const ymd = raw.match(/^(\d{4})-(\d{2})-(\d{2})/);
    const date = ymd
        ? new Date(`${ymd[1]}-${ymd[2]}-${ymd[3]}T12:00:00+08:00`)
        : new Date(raw);
    if (Number.isNaN(date.getTime())) return raw;
    return date.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric', timeZone: FAS_TIME_ZONE });
}

function getDayOfWeekFromDate(dateString) {
    if (!dateString) return '';
    const raw = String(dateString).trim();
    const ymd = raw.match(/^(\d{4})-(\d{2})-(\d{2})$/);
    let dt;
    if (ymd) {
        dt = new Date(`${raw}T12:00:00+08:00`);
    } else {
        dt = new Date(raw);
    }
    if (Number.isNaN(dt.getTime())) return '';
    return dt.toLocaleDateString('en-US', { weekday: 'long', timeZone: FAS_TIME_ZONE });
}

function getRegistrationFeeDueAmount(studentOrMeta = null) {
    const source = studentOrMeta && typeof studentOrMeta === 'object' ? studentOrMeta : {};
    const total = Number(source.registration_fee_amount || 1000);
    const paid = Number(source.registration_fee_paid || 0);
    const explicitDue = source.registration_fee_due !== undefined && source.registration_fee_due !== null
        ? Number(source.registration_fee_due)
        : null;
    if (Number.isFinite(explicitDue)) {
        return Math.max(0, explicitDue);
    }
    return Math.max(0, total - paid);
}

function computeStudentRequestPayableNow(basePrice, sessions, paymentRaw, registrationFeeDue = 0) {
    const price = Number(basePrice || 0);
    const s = Number(sessions || 0);
    const v = String(paymentRaw || '').toLowerCase();
    const regDue = Math.max(0, Number(registrationFeeDue || 0));
    if (price <= 0) return regDue;
    const ratio = s === 12 ? (3000 / 7450) : (s === 20 ? (5000 / 11800) : 0.42);
    const partial = Math.round(price * ratio);
    if (v === 'full' || v === 'full payment' || v === 'fullpayment') return price + regDue;
    if (v === 'partial payment' || v === 'partial' || v === 'downpayment') return partial + regDue;
    if (v === 'installment') {
        return Math.max(1, Math.round(price / Math.max(1, s || 1))) + regDue;
    }
    return partial + regDue;
}

function renderStudentRequestStatus(latestRequest) {
    if (!latestRequest) {
        return '<div class="text-sm text-zinc-500">No request submitted yet.</div>';
    }
    const status = String(latestRequest.status || 'Pending');
    const isRejected = status === 'Rejected' || status === 'Cancelled';
    const badgeClass = status === 'Approved'
        ? 'bg-green-500/15 text-green-300 border border-green-500/30'
        : isRejected
            ? 'bg-red-500/15 text-red-300 border border-red-500/30'
            : 'bg-yellow-500/15 text-yellow-300 border border-yellow-500/30';
    const displayStatus = status === 'Cancelled' ? 'Rejected' : status;
    const createdAt = latestRequest.created_at ? new Date(latestRequest.created_at).toLocaleString() : '—';
    const packageName = escapeHtml(latestRequest.package_name || 'Package');
    const amount = formatCurrencyPHP(latestRequest.requested_amount || 0);
    const paymentTypeRaw = String(latestRequest.payment_type || '').toLowerCase();
    const paymentModeLabel = paymentTypeRaw.includes('full')
        ? 'Full Payment'
        : (paymentTypeRaw.includes('install') ? 'Installment' : 'Partial Payment');
    const notes = latestRequest.admin_notes ? `<div class="text-xs text-zinc-400 mt-1">Admin note: ${escapeHtml(latestRequest.admin_notes)}</div>` : '';
    const preferredDate = latestRequest.preferred_date ? formatDateLong(latestRequest.preferred_date) : '';
    const preferredDay = String(latestRequest.preferred_day_of_week || '');
    const preferredStart = latestRequest.preferred_start_time ? formatTime12Hour(latestRequest.preferred_start_time) : '';
    const preferredEnd = latestRequest.preferred_end_time ? formatTime12Hour(latestRequest.preferred_end_time) : '';
    const preferenceInfo = preferredDate || preferredDay || preferredStart
        ? `<div class="mt-2 rounded-lg border border-amber-500/20 bg-amber-500/10 p-2 text-xs text-amber-200">
            <span class="font-semibold">Requested schedule:</span>
            ${escapeHtml([preferredDate || preferredDay, preferredStart && preferredEnd ? `${preferredStart} - ${preferredEnd}` : preferredStart].filter(Boolean).join(' • '))}
            ${status === 'Pending' ? '<div class="mt-1 text-zinc-400">Waiting for the desk to confirm or adjust this time.</div>' : ''}
        </div>`
        : '';
    const assignedTeacherName = `${latestRequest.assigned_teacher_first_name || ''} ${latestRequest.assigned_teacher_last_name || ''}`.trim();
    const assignedDate = latestRequest.assigned_date ? formatDateLong(latestRequest.assigned_date) : '';
    const assignedDay = latestRequest.assigned_day_of_week || '';
    const assignedStart = latestRequest.assigned_start_time ? formatTime12Hour(latestRequest.assigned_start_time) : '';
    const assignedEnd = latestRequest.assigned_end_time ? formatTime12Hour(latestRequest.assigned_end_time) : '';
    const assignedRoom = latestRequest.assigned_room || '';
    const whenText = assignedDate || [assignedDay].filter(Boolean).join(' • ');
    const assignmentInfo = status === 'Approved' && (assignedTeacherName || assignedDate || assignedDay || assignedStart || assignedEnd || assignedRoom)
        ? `<div class="mt-2 text-xs text-green-300 bg-green-500/10 border border-green-500/20 rounded-lg p-2">
            <div><span class="text-green-200 font-semibold">Assigned Teacher:</span> ${escapeHtml(assignedTeacherName || '—')}</div>
            <div><span class="text-green-200 font-semibold">Sessions start:</span> ${escapeHtml(whenText || 'Not set')}</div>
            <div><span class="text-green-200 font-semibold">Time:</span> ${escapeHtml((assignedStart && assignedEnd) ? `${assignedStart} - ${assignedEnd}` : 'Not set')}</div>
            <div><span class="text-green-200 font-semibold">Where:</span> ${escapeHtml(assignedRoom || 'Not set')}</div>
        </div>`
        : '';

    return `
        <div class="rounded-xl border border-white/10 bg-white/5 p-3">
            <div class="flex items-center gap-2">
                <span class="inline-flex items-center px-2 py-1 rounded-lg text-xs font-bold ${badgeClass}">${escapeHtml(displayStatus)}</span>
                <span class="text-xs text-zinc-400">${createdAt}</span>
            </div>
            <div class="mt-2 text-sm text-zinc-200">${packageName} • ${amount}</div>
            <div class="mt-1 text-xs text-zinc-400">Payment mode: <span class="text-zinc-200 font-semibold">${escapeHtml(paymentModeLabel)}</span></div>
            ${preferenceInfo}
            ${assignmentInfo}
            ${notes}
            ${isRejected ? '<div class="mt-2 text-xs text-amber-300 bg-amber-500/10 border border-amber-500/20 rounded-lg p-2">Your request was rejected. You can submit a new enrollment request below.</div>' : ''}
        </div>
    `;
}

function renderStudentAvailabilityCalendar(availabilities) {
    const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
    const grouped = {};
    days.forEach(d => { grouped[d] = []; });

    (Array.isArray(availabilities) ? availabilities : []).forEach(a => {
        const day = String(a.day_of_week || '');
        if (grouped[day]) grouped[day].push(a);
    });

    return days.map(day => {
        const slots = grouped[day];
        if (!slots.length) {
            return `<div class="rounded-xl border border-white/10 bg-black/20 p-3">
                <div class="text-xs font-bold uppercase tracking-wider text-zinc-400">${day}</div>
                <div class="text-xs text-zinc-500 mt-2">No active slots</div>
            </div>`;
        }
        return `<div class="rounded-xl border border-white/10 bg-black/20 p-3">
            <div class="text-xs font-bold uppercase tracking-wider text-zinc-300">${day}</div>
            <div class="mt-2 space-y-2">
                ${slots.map(s => {
                    const teacher = `${s.teacher_first_name || ''} ${s.teacher_last_name || ''}`.trim();
                    return `<div class="rounded-lg border border-gold-500/20 bg-gold-500/10 px-2 py-1">
                        ${teacher ? `<div class="text-xs font-semibold text-gold-200">${escapeHtml(teacher)}</div>` : ''}
                        <div class="text-[11px] text-zinc-300">${formatTime12Hour(s.start_time)} - ${formatTime12Hour(s.end_time)}</div>
                    </div>`;
                }).join('')}
            </div>
        </div>`;
    }).join('');
}

function enrollmentStatusBadgeClass(status) {
    const s = String(status || '');
    if (s === 'Ongoing') return 'bg-green-500/15 text-green-300 border border-green-500/30';
    if (s === 'Completed') return 'bg-blue-500/15 text-blue-300 border border-blue-500/30';
    if (s === 'Pending Payment') return 'bg-yellow-500/15 text-yellow-300 border border-yellow-500/30';
    if (s === 'Dropped' || s === 'Cancelled') return 'bg-red-500/15 text-red-300 border border-red-500/30';
    return 'bg-zinc-500/15 text-zinc-300 border border-zinc-500/30';
}

function renderCurrentEnrollmentSummary(enrollment) {
    if (!enrollment) {
        return '';
    }
    return renderPortalBalanceSection(enrollment, true);
}

function renderPortalBalanceSection(enrollment, showPackage = false) {
    if (!enrollment || String(enrollment.status) !== 'Active') return '';
    const balance = Number(enrollment.balance_amount ?? Math.max(0, Number(enrollment.total_amount || 0) - Number(enrollment.paid_amount || 0)));
    const status = String(enrollment.payment_status || (balance > 0 ? 'Partial' : 'Fully Paid'));
    const history = Array.isArray(enrollment.payment_history) ? enrollment.payment_history : [];
    const deadline = Number(enrollment.deadline_session || 0);
    const used = Number(enrollment.sessions_used || 0);
    const due = balance > 0;
    const pending = status === 'Pending Online Payment';
    const overdue = status === 'Payment Overdue';
    const soon = due && !overdue && deadline > 0 && used >= deadline - 1;
    const tone = !due ? 'border-emerald-200 bg-emerald-50 dark:border-emerald-500/30 dark:bg-emerald-500/10'
        : overdue ? 'border-rose-300 bg-rose-50 dark:border-rose-500/30 dark:bg-rose-500/10'
        : 'border-amber-300 bg-amber-50 dark:border-amber-500/30 dark:bg-amber-500/10';
    const accent = !due ? 'text-emerald-700 dark:text-emerald-300'
        : overdue ? 'text-rose-700 dark:text-rose-300' : 'text-amber-800 dark:text-amber-300';
    const label = !due ? 'Paid in full' : pending ? 'Payment under review' : overdue ? 'Payment overdue' : soon ? 'Balance due soon' : 'Balance to pay';
    const packageLabel = showPackage ? `<div class="mt-1 text-sm text-zinc-600 dark:text-zinc-300">${escapeHtml(enrollment.package_name || 'Session package')}</div>` : '';
    const historyHtml = history.length ? `<details class="mt-3 border-t border-zinc-200/80 pt-3 text-sm dark:border-white/10"><summary class="w-fit cursor-pointer font-semibold text-zinc-700 dark:text-zinc-200">Payment history</summary><div class="mt-2 space-y-2">${history.map(p => `<div class="flex flex-wrap justify-between gap-2 text-zinc-600 dark:text-zinc-300"><span>${escapeHtml(p.purpose || 'Payment')} · ${escapeHtml(p.payment_method || '')} · ${escapeHtml(p.payment_date || '')}</span><span class="font-semibold">${formatCurrencyPHP(p.amount)} · ${escapeHtml(p.status || '')}</span></div>`).join('')}</div></details>` : '';
    return `<div class="rounded-2xl border ${tone} p-4 sm:p-5">
        <div class="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div class="min-w-0">
                <div class="flex items-center gap-2 text-sm font-bold ${accent}"><i class="fas ${due ? 'fa-circle-exclamation' : 'fa-circle-check'}" aria-hidden="true"></i>${label}</div>
                <div class="mt-1 text-2xl font-black tracking-tight text-zinc-900 dark:text-white sm:text-3xl">${formatCurrencyPHP(balance)}</div>
                ${packageLabel}
            </div>
            ${due && !pending ? `<button type="button" onclick="openPortalBalancePayment(${Number(enrollment.enrollment_id)})" class="inline-flex min-h-11 shrink-0 items-center justify-center rounded-xl bg-amber-500 px-5 py-2.5 text-sm font-extrabold text-zinc-950 transition hover:bg-amber-400 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-amber-600">Pay balance</button>` : ''}
        </div>
        ${due ? `<div class="mt-4 flex flex-wrap gap-x-5 gap-y-1 text-xs font-medium text-zinc-700 dark:text-zinc-200"><span>Due before session <strong>${deadline}</strong></span><span><strong>${used}</strong> sessions used</span><span>Paid <strong>${formatCurrencyPHP(enrollment.paid_amount)}</strong></span></div>` : ''}
        ${pending ? '<div class="mt-3 text-xs font-medium text-amber-800 dark:text-amber-200">Your payment is awaiting approval.</div>' : ''}
        ${historyHtml}
    </div>`;
}

async function openPortalBalancePayment(enrollmentId) {
    try {
        const response = await axios.get(`${baseApiUrl}/students.php?action=get-enrollment-balance&enrollment_id=${encodeURIComponent(enrollmentId)}`);
        const enrollment = response.data?.enrollment;
        if (!enrollment || Number(enrollment.balance_amount) <= 0 || enrollment.payment_status === 'Pending Online Payment') {
            showMessage('This balance is no longer available for payment. Refresh the page.', 'info');
            return;
        }
        document.getElementById('portalBalancePaymentModal')?.remove();
        const modal = document.createElement('div');
        modal.id = 'portalBalancePaymentModal';
        modal.className = 'fixed inset-0 z-[1200] flex items-center justify-center bg-black/80 p-4';
        modal.innerHTML = `<form id="portalBalancePaymentForm" class="w-full max-w-md rounded-2xl bg-white p-5 text-slate-900 shadow-xl">
            <div class="flex items-center justify-between gap-3"><h2 class="text-lg font-bold">Pay balance</h2><button type="button" id="closePortalBalancePayment" class="grid h-9 w-9 place-items-center rounded-full text-xl text-slate-500 hover:bg-slate-100" aria-label="Close">×</button></div>
            <div class="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3"><div class="text-xs font-bold text-amber-800">Amount to pay</div><div class="mt-0.5 text-2xl font-black text-slate-900">${formatCurrencyPHP(enrollment.balance_amount)}</div><div class="mt-1 text-xs text-slate-600">Due before session ${Number(enrollment.deadline_session)}</div></div>
            <label class="mt-4 block text-sm font-semibold">Method<select name="payment_method" required class="mt-1 w-full rounded-lg border p-2"><option value="GCash">GCash</option><option value="Bank Transfer">Bank Transfer</option></select></label>
            <div id="portalBalanceDestination" class="mt-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm"></div>
            <label class="mt-3 block text-sm font-semibold">Reference number<input name="reference_number" required maxlength="100" class="mt-1 w-full rounded-lg border p-2"></label>
            <label class="mt-3 block text-sm font-semibold">Payment proof<input name="proof_file" type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required class="mt-1 w-full rounded-lg border p-2"></label>
            <p id="portalBalancePaymentError" class="mt-3 text-sm text-red-700" role="alert"></p>
            <button type="submit" class="mt-4 w-full rounded-lg bg-amber-500 px-4 py-2.5 font-bold text-black">Submit payment</button>
            <p class="mt-2 text-center text-xs text-slate-500">Balance updates after approval.</p>
        </form>`;
        document.body.appendChild(modal);
        const methodSelect = modal.querySelector('[name="payment_method"]');
        const destination = modal.querySelector('#portalBalanceDestination');
        fetchPaymentDestination().then(recipient => {
            if (!modal.isConnected) return;
            const updateDestination = () => renderPaymentDestination(destination, methodSelect.value, recipient);
            methodSelect.addEventListener('change', updateDestination);
            updateDestination();
        });
        modal.querySelector('#closePortalBalancePayment').onclick = () => modal.remove();
        modal.addEventListener('click', event => { if (event.target === modal) modal.remove(); });
        modal.querySelector('form').addEventListener('submit', async event => {
            event.preventDefault();
            const form = event.currentTarget;
            const button = form.querySelector('[type="submit"]');
            button.disabled = true;
            const data = new FormData(form);
            data.append('enrollment_id', String(enrollmentId));
            try {
                await axios.post(`${baseApiUrl}/students.php?action=submit-enrollment-balance-payment`, data);
                modal.remove();
                window.location.reload();
            } catch (error) {
                form.querySelector('#portalBalancePaymentError').textContent = error?.response?.data?.error || 'Payment could not be submitted.';
                button.disabled = false;
            }
        });
    } catch (error) {
        showMessage(error?.response?.data?.error || 'Could not load current balance.', 'error');
    }
}

function getScheduleFreezeReservationNotice(enrollment) {
    if (!enrollment) return null;
    const scheduleStatus = String(enrollment.schedule_status || '').trim().toLowerCase();
    const usedAbsences  = Number(enrollment.used_absences || 0);
    if (scheduleStatus === 'active') return null;
    const freezeRequired = Number(enrollment.schedule_freeze_required || 0) === 1
        || scheduleStatus === 'frozen'
        || (enrollment.schedule_freeze_required === undefined && !scheduleStatus && usedAbsences >= 3);
    if (!freezeRequired) return null;
    const amount = Number(enrollment.reservation_fee_amount || 100) || 100;
    const amountLabel = formatCurrencyPHP(amount).replace(/\.00$/, '');
    return {
        amount,
        usedAbsences,
        title: `PAY ${amountLabel} to reserve slot`,
        text: `You have ${usedAbsences} recorded absence${usedAbsences === 1 ? '' : 's'}. Please pay the reservation fee to hold your class slot.`
    };
}

function renderEnrollmentHistoryList(history) {
    const rows = (Array.isArray(history) ? history.slice() : []).sort((a, b) => {
        const aTime = new Date(a?.first_session_date || a?.start_date || a?.enrollment_date || a?.created_at || 0).getTime() || 0;
        const bTime = new Date(b?.first_session_date || b?.start_date || b?.enrollment_date || b?.created_at || 0).getTime() || 0;
        if (aTime !== bTime) return bTime - aTime;
        return Number(b?.enrollment_id || 0) - Number(a?.enrollment_id || 0);
    });

    if (!rows.length) {
        return '<div class="text-sm text-zinc-500">No previous enrollments yet.</div>';
    }
    return rows.map(row => {
        const startDate = formatDateLong(row.first_session_date || row.start_date || row.enrollment_date || '');
        return `<div class="rounded-xl border border-white/10 bg-black/20 p-3">
            <div class="flex items-center justify-between gap-2">
                <div class="text-sm font-semibold text-white">${escapeHtml(row.package_name || 'Package')}</div>
                <span class="inline-flex items-center px-2 py-1 rounded-lg text-[11px] font-bold ${enrollmentStatusBadgeClass(row.status)}">${escapeHtml(row.status || '—')}</span>
            </div>
            <div class="mt-1 text-xs text-zinc-400">Started: ${escapeHtml(startDate || 'Not set')} • ${escapeHtml(row.payment_type || 'Partial Payment')}</div>
        </div>`;
    }).join('');
}

function getStudentEnrollmentPaymentState(enrollment) {
    const totalAmount = Number(enrollment?.total_amount || 0);
    const paidAmount = Number(enrollment?.paid_amount || 0);
    if (totalAmount > 0 && paidAmount >= totalAmount) return 'Paid';
    if (paidAmount > 0) return 'Partial';
    return 'Unpaid';
}

function renderStudentProfileEnrollmentMeta(enrollment, instruments, branchName) {
    if (!enrollment) {
        return `
            <div class="text-zinc-500 dark:text-zinc-400">No approved or pending enrollment yet.</div>
            <div class="text-zinc-500 dark:text-zinc-400">Open Sessions if you need to request a package.</div>
        `;
    }

    const teacherName = `${enrollment.teacher_first_name || ''} ${enrollment.teacher_last_name || ''}`.trim() || 'Not assigned yet';
    const scheduleDate = formatDateLong(enrollment.first_session_date || enrollment.start_date || '');
    const scheduleStart = enrollment.first_start_time ? formatTime12Hour(enrollment.first_start_time) : '';
    const scheduleEnd = enrollment.first_end_time ? formatTime12Hour(enrollment.first_end_time) : '';
    const scheduleTime = scheduleStart && scheduleEnd ? `${scheduleStart} - ${scheduleEnd}` : 'Not scheduled yet';
    const roomName = enrollment.first_room || 'To be announced';
    const paymentState = getStudentEnrollmentPaymentState(enrollment);
    const balance = Math.max(0, Number(enrollment.total_amount || 0) - Number(enrollment.paid_amount || 0));
    const instrumentNames = (Array.isArray(instruments) ? instruments : [])
        .map(inst => String(inst.instrument_name || inst.type_name || '').trim())
        .filter(Boolean);
    const instrumentsLabel = instrumentNames.length ? instrumentNames.join(', ') : 'Not assigned yet';

    return `
        <div><span class="text-zinc-500 dark:text-zinc-400">Status:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(enrollment.status || 'Pending')}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">Teacher:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(teacherName)}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">First class:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(scheduleDate || 'Not scheduled yet')}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">Time:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(scheduleTime)}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">Room:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(roomName)}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">Instruments:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(instrumentsLabel)}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">Payment:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(`${paymentState} (${enrollment.payment_type || 'Partial Payment'})`)}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">Balance:</span> <span class="font-semibold text-zinc-900 dark:text-white">${formatCurrencyPHP(balance)}</span></div>
        <div><span class="text-zinc-500 dark:text-zinc-400">Branch:</span> <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(branchName || '—')}</span></div>
    `;
}

let guardianPortalStudents = [];
let guardianActiveStudentIndex = null;

function bindGuardianPortalNav() {
    const toggleBtn = document.getElementById('guardianMobileMenuToggle');
    const menu = document.getElementById('guardianMobileMenu');
    if (!toggleBtn || !menu || menu.dataset.bound === 'true') return;

    menu.dataset.bound = 'true';
    toggleBtn.addEventListener('click', () => {
        menu.classList.toggle('hidden');
    });
    menu.addEventListener('click', (event) => {
        if (event.target === menu) {
            menu.classList.add('hidden');
        }
    });
    menu.querySelectorAll('a').forEach((link) => {
        link.addEventListener('click', () => menu.classList.add('hidden'));
    });
}

function getGuardianPrimaryGuardian(portal, user = null) {
    const guardians = Array.isArray(portal?.guardians) ? portal.guardians : [];
    const email = String(user?.email || '').trim().toLowerCase();
    const matched = guardians.find((guardian) => String(guardian?.email || '').trim().toLowerCase() === email);
    return matched || guardians[0] || portal?.primary_guardian || null;
}

function getGuardianStudentBranchName(item) {
    const student = item?.student || item || {};
    return String(
        student?.branch_name
        || item?.branch_name
        || item?.current_enrollment?.branch_name
        || student?.current_enrollment?.branch_name
        || ''
    ).trim();
}

function getGuardianPortalBranchLabel(portal) {
    const directBranch = String(
        portal?.branch_name
        || portal?.branch
        || portal?.branchName
        || portal?.current_enrollment?.branch_name
        || ''
    ).trim();
    if (directBranch) return directBranch;

    const students = Array.isArray(portal?.students) ? portal.students : [];
    const uniqueBranches = Array.from(new Set(
        students
            .map((item) => getGuardianStudentBranchName(item))
            .filter(Boolean)
    ));
    if (uniqueBranches.length === 0) return '—';
    if (uniqueBranches.length === 1) return uniqueBranches[0];
    return uniqueBranches.join(', ');
}

function getStudentPortalBranchLabel(studentOrPortal) {
    const portal = studentOrPortal?.student ? studentOrPortal : null;
    const student = portal ? portal.student : (studentOrPortal || {});
    const branchName = student?.branch_name
        || student?.branch
        || student?.branchName
        || student?.current_branch_name
        || student?.enrollment_branch_name
        || portal?.current_enrollment?.branch_name
        || portal?.branch_name
        || window.__studentPortalBranchLabel
        || '—';
    return String(branchName).trim() || '—';
}

function applyStudentPortalIdentity(user, studentOrPortal = null) {
    const portal = studentOrPortal?.student ? studentOrPortal : null;
    const student = portal ? portal.student : (studentOrPortal || {});
    const displayName = `${student?.first_name || ''} ${student?.last_name || ''}`.trim()
        || String(student?.student_name || student?.full_name || student?.display_name || student?.name || '').trim()
        || user?.username
        || user?.email
        || 'Student';
    const email = student?.email || portal?.student?.email || user?.email || '—';
    const branchName = getStudentPortalBranchLabel(studentOrPortal);

    window.__studentPortalBranchLabel = branchName;

    setText('studentNavName', displayName);
    setText('studentMobileMenuName', displayName);
    ['studentSidebarName', 'studentSidebarMobileName', 'studentName', 'studentNameMobile'].forEach((id) => setText(id, displayName));
    ['studentSidebarEmail', 'studentSidebarMobileEmail', 'studentEmail', 'studentEmailMobile'].forEach((id) => setText(id, email));
    if (typeof window.setPortalBranchText === 'function') {
        window.setPortalBranchText('#studentSidebarBranch, #studentSidebarMobileBranch, #studentBranch, #studentBranchMobile', branchName);
    } else {
        ['studentSidebarBranch', 'studentSidebarMobileBranch', 'studentBranch', 'studentBranchMobile'].forEach((id) => setText(id, branchName));
    }
    if (typeof window.fitAllPortalBranchLabels === 'function') {
        window.fitAllPortalBranchLabels();
    }
}

function applyGuardianPortalIdentity(user, guardianOrPortal = null) {
    const portal = guardianOrPortal && Array.isArray(guardianOrPortal.guardians)
        ? guardianOrPortal
        : null;
    const guardian = portal
        ? (getGuardianPrimaryGuardian(portal, user) || {})
        : (guardianOrPortal || {});
    const portalGuardian = Array.isArray(portal?.guardians) ? portal.guardians[0] : null;
    const portalUserAccount = portal?.user_account || portal?.user || null;
    const displayName = `${guardian?.first_name || ''} ${guardian?.last_name || ''}`.trim()
        || user?.username
        || user?.email
        || portalGuardian?.first_name
        || portalGuardian?.last_name
        || 'Guardian';
    const email = guardian?.email
        || portalGuardian?.email
        || portalUserAccount?.email
        || user?.email
        || window.__guardianPortalEmail
        || '—';
    const branchName = (portal ? getGuardianPortalBranchLabel(portal) : null)
        || guardian?.branch_name
        || guardian?.branch
        || guardian?.branchName
        || portal?.branch_name
        || portal?.branch
        || portal?.branchName
        || window.__guardianPortalBranchLabel
        || '—';

    window.__guardianPortalEmail = email;
    window.__guardianPortalBranchLabel = branchName;

    setText('guardianNavName', displayName);
    setText('guardianMobileMenuName', displayName);
    setText('guardianSidebarName', displayName);
    setText('guardianSidebarEmail', email);
    if (typeof window.setPortalBranchText === 'function') {
        window.setPortalBranchText('#guardianSidebarBranch, #guardianMobileMenuProfileBranch', branchName);
    } else {
        setText('guardianSidebarBranch', branchName);
        setText('guardianMobileMenuProfileBranch', branchName);
    }
    setText('guardianMobileMenuProfileName', displayName);
    setText('guardianMobileMenuProfileEmail', email);
    if (typeof window.fitAllPortalBranchLabels === 'function') {
        window.fitAllPortalBranchLabels();
    }
}

async function fetchGuardianAbsenceRequests(email) {
    const url = `${baseApiUrl}/attendance.php?action=guardian-absence-list&guardian_email=${encodeURIComponent(email)}`;
    const res = await axios.get(url);
    const data = res.data;
    if (data?.success && Array.isArray(data.requests)) captureGuardianAbsenceDecisionState(data.requests);
    return data;
}

async function submitGuardianAbsenceRequest(payload) {
    const res = await axios.post(`${baseApiUrl}/attendance.php?action=guardian-absence-submit`, payload);
    return res.data;
}

async function updateGuardianProfileRequest(payload) {
    const res = await axios.post(`${baseApiUrl}/students.php?action=update-guardian-profile`, payload);
    return res.data;
}

function getGuardianSessionStatusMetrics(item) {
    const rows = getGuardianSessionRows(item);
    return rows.reduce((acc, row) => {
        const raw = String(row?.attendance_status || row?.status || 'Scheduled').trim().toLowerCase();
        if (['present', 'late', 'completed'].includes(raw)) acc.completed += 1;
        else if (raw === 'absent') acc.absent += 1;
        else if (raw === 'excused') acc.excused += 1;
        else acc.upcoming += 1;
        return acc;
    }, { completed: 0, absent: 0, excused: 0, upcoming: 0 });
}

function renderGuardianAbsenceStudentOptions(items) {
    const rows = Array.isArray(items) ? items : [];
    if (!rows.length) {
        return '<option value="">No linked students found</option>';
    }

    return rows.map((item, index) => {
        const student = item?.student || {};
        const studentId = Number(student.student_id || 0);
        const statusMetrics = getGuardianSessionStatusMetrics(item);
        const suffix = statusMetrics.upcoming > 0 ? ` (${statusMetrics.upcoming} upcoming)` : '';
        return `<option value="${studentId}">${escapeHtml(getGuardianStudentName(item, index))}${escapeHtml(suffix)}</option>`;
    }).join('');
}

function getGuardianAbsenceStudentSummary(item, index) {
    const student = item?.student || {};
    const studentId = Number(student.student_id || 0);
    const studentName = getGuardianStudentName(item, index);
    const nextSession = formatGuardianNextSessionLabel(item);
    const statusMetrics = getGuardianSessionStatusMetrics(item);
    const packageName = item?.current_enrollment?.package_name || student.package_name || 'No package';
    return {
        studentId,
        studentName,
        nextSession,
        packageName,
        upcoming: statusMetrics.upcoming
    };
}

function renderGuardianAbsenceStudentChoice(item, index, isSelected = false) {
    const summary = getGuardianAbsenceStudentSummary(item, index);
    return `
        <button
            type="button"
            class="guardian-absence-student-choice w-full rounded-2xl border px-4 py-3 text-left transition ${isSelected ? 'border-gold-300 bg-gold-50 dark:border-gold-500/30 dark:bg-gold-500/10' : 'border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 hover:border-gold-200'}"
            data-student-id="${summary.studentId}"
        >
            <div class="flex items-start justify-between gap-3">
                <div class="min-w-0">
                    <div class="text-sm font-bold text-zinc-900 dark:text-white">${escapeHtml(summary.studentName)}</div>
                    <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400 truncate">${escapeHtml(summary.packageName)}</div>
                </div>
                <span class="rounded-full border px-2.5 py-1 text-[10px] font-bold ${isSelected ? 'border-gold-300 bg-white text-gold-700 dark:border-gold-500/30 dark:bg-black/20 dark:text-gold-300' : 'border-zinc-200 bg-zinc-50 text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300'}">
                    ${summary.upcoming} upcoming
                </span>
            </div>
            <div class="mt-2 text-xs text-zinc-500 dark:text-zinc-400">${escapeHtml(summary.nextSession)}</div>
        </button>
    `;
}

function renderGuardianAbsenceStudentCards(items) {
    const rows = Array.isArray(items) ? items : [];
    if (!rows.length) {
        return `
            <div class="rounded-3xl border border-dashed border-zinc-200 dark:border-white/10 px-4 py-8 text-center text-sm text-zinc-500 dark:text-zinc-400">
                No linked students found.
            </div>
        `;
    }

    return rows.map((item, index) => {
        const summary = getGuardianAbsenceStudentSummary(item, index);
        const statusClass = summary.upcoming > 0
            ? 'border-emerald-200 bg-emerald-50 text-emerald-700 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-300'
            : 'border-zinc-200 bg-zinc-50 text-zinc-600 dark:border-white/10 dark:bg-black/20 dark:text-zinc-300';
        return `
            <button
                type="button"
                class="guardian-absence-card w-full rounded-2xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 px-4 py-4 text-left transition hover:border-gold-300 hover:shadow-sm"
                data-student-id="${summary.studentId}"
                data-student-name="${escapeHtml(summary.studentName)}"
            >
                <div class="flex items-start justify-between gap-3">
                    <div class="min-w-0">
                        <div class="text-sm font-bold text-zinc-900 dark:text-white">${escapeHtml(summary.studentName)}</div>
                        <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">${escapeHtml(summary.packageName)}</div>
                    </div>
                    <span class="rounded-full border px-2.5 py-1 text-[10px] font-bold ${statusClass}">
                        ${summary.upcoming} upcoming
                    </span>
                </div>
                <div class="mt-2 text-xs text-zinc-500 dark:text-zinc-400">${escapeHtml(summary.nextSession)}</div>
                <div class="mt-3 inline-flex items-center gap-1.5 text-xs font-semibold text-gold-600 dark:text-gold-300">
                    <i class="fas fa-paper-plane"></i> Request absence
                </div>
            </button>
        `;
    }).join('');
}

async function openGuardianAbsenceStudentPicker(items, currentStudentId = '') {
    const rows = Array.isArray(items) ? items : [];
    if (!rows.length) {
        showMessage('No linked students found.', 'error');
        return null;
    }

    let selectedStudentId = String(currentStudentId || rows[0]?.student?.student_id || '');

    const result = await Swal.fire({
        title: 'Choose student',
        width: 620,
        showCancelButton: true,
        confirmButtonText: 'Use student',
        cancelButtonText: 'Close',
        confirmButtonColor: '#b8860b',
        cancelButtonColor: '#6b7280',
        html: `
            <div class="text-left">
                <div class="mb-3 text-sm text-zinc-500 dark:text-zinc-400">Select the child you want to mark absent.</div>
                <div id="guardianAbsenceStudentPicker" class="space-y-2 max-h-[55vh] overflow-y-auto pr-1">
                    ${rows.map((item, index) => renderGuardianAbsenceStudentChoice(item, index, String(item?.student?.student_id || '') === selectedStudentId)).join('')}
                </div>
            </div>
        `,
        didOpen: () => {
            const popup = Swal.getPopup();
            const picker = popup?.querySelector('#guardianAbsenceStudentPicker');
            picker?.querySelectorAll('.guardian-absence-student-choice').forEach((button) => {
                button.addEventListener('click', () => {
                    selectedStudentId = String(button.dataset.studentId || '');
                    picker.querySelectorAll('.guardian-absence-student-choice').forEach((item) => {
                        const isActive = String(item.dataset.studentId || '') === selectedStudentId;
                        item.classList.toggle('border-gold-300', isActive);
                        item.classList.toggle('bg-gold-50', isActive);
                        item.classList.toggle('dark:border-gold-500/30', isActive);
                        item.classList.toggle('dark:bg-gold-500/10', isActive);
                        item.classList.toggle('border-zinc-200', !isActive);
                        item.classList.toggle('bg-white', !isActive);
                        item.classList.toggle('dark:border-white/10', !isActive);
                        item.classList.toggle('dark:bg-white/5', !isActive);
                    });
                });
            });
        },
        preConfirm: () => {
            if (!selectedStudentId) {
                Swal.showValidationMessage('Please choose a student.');
                return false;
            }
            return selectedStudentId;
        }
    });

    if (!result.isConfirmed || !result.value) {
        return null;
    }

    return String(result.value);
}

function openAbsenceModal(studentId, studentName = '') {
    const modal = document.getElementById('absenceRequestModal');
    const hiddenStudentId = document.getElementById('selectedStudentId');
    const modalStudentName = document.getElementById('modalStudentName');
    const dateInput = document.getElementById('guardianAbsenceSessionDate');
    const reasonInput = document.getElementById('guardianAbsenceReason');
    const notesInput = document.getElementById('guardianAbsenceNotes');
    if (!modal || !hiddenStudentId || !modalStudentName) return;

    hiddenStudentId.value = String(studentId || '');
    const matchIndex = Array.isArray(guardianPortalStudents)
        ? guardianPortalStudents.findIndex((item, index) => String(getGuardianAbsenceStudentSummary(item, index).studentId) === String(studentId))
        : -1;
    const student = matchIndex >= 0 ? guardianPortalStudents[matchIndex] : null;
    const resolvedName = studentName || (student ? getGuardianAbsenceStudentSummary(student, matchIndex).studentName : 'Student');
    modalStudentName.textContent = resolvedName;
    if (dateInput && !dateInput.value) {
        dateInput.value = getManilaYmd();
    }
    if (reasonInput) reasonInput.value = '';
    if (notesInput) notesInput.value = '';
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    document.body.classList.add('overflow-hidden');
}

function closeAbsenceModal() {
    const modal = document.getElementById('absenceRequestModal');
    const hiddenStudentId = document.getElementById('selectedStudentId');
    const modalStudentName = document.getElementById('modalStudentName');
    if (!modal) return;
    if (hiddenStudentId) hiddenStudentId.value = '';
    if (modalStudentName) modalStudentName.textContent = '';
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    document.body.classList.remove('overflow-hidden');
}

function renderGuardianAbsenceRequests(items) {
    const rows = Array.isArray(items) ? items : [];
    if (!rows.length) {
        return `
            <div class="rounded-3xl border border-dashed border-zinc-200 dark:border-white/10 px-4 py-10 text-center text-sm text-zinc-500 dark:text-zinc-400">
                No absence requests have been submitted yet.
            </div>
        `;
    }

    return rows.map((row) => {
        const status = String(row?.status || 'Pending');
        const badgeClass = status === 'Approved'
            ? 'border-emerald-200 bg-emerald-50 text-emerald-700'
            : status === 'Declined'
                ? 'border-rose-200 bg-rose-50 text-rose-700'
                : status === 'Reviewed'
                    ? 'border-blue-200 bg-blue-50 text-blue-700'
                    : 'border-amber-200 bg-amber-50 text-amber-700';

        return `
            <div class="rounded-3xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 p-5">
                <div class="flex flex-col gap-3 md:flex-row md:items-start md:justify-between">
                    <div>
                        <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold">Student</div>
                        <div class="mt-2 text-lg font-black text-zinc-900 dark:text-white">${escapeHtml(row.student_name || 'Student')}</div>
                        <div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(row.branch_name || 'Assigned branch')} • ${escapeHtml(formatDateLong(row.session_date || ''))}</div>
                    </div>
                    <span class="inline-flex items-center rounded-full border px-3 py-1 text-xs font-bold ${badgeClass}">
                        ${escapeHtml(status)}
                    </span>
                </div>
                <div class="mt-4 grid gap-3 sm:grid-cols-2 text-sm">
                    <div>
                        <div class="text-zinc-500 dark:text-zinc-400">Reason</div>
                        <div class="mt-1 font-semibold text-zinc-900 dark:text-white">${escapeHtml(row.reason || '—')}</div>
                    </div>
                    <div>
                        <div class="text-zinc-500 dark:text-zinc-400">Desk Review</div>
                        <div class="mt-1 font-semibold text-zinc-900 dark:text-white">${escapeHtml(row.reviewed_notes || 'Waiting for desk review.')}</div>
                    </div>
                </div>
                <div class="mt-3 rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 px-4 py-3 text-sm text-zinc-600 dark:text-zinc-300">
                    ${escapeHtml(row.notes || 'No additional notes submitted.')}
                </div>
            </div>
        `;
    }).join('');
}

function getGuardianInstrumentLabel(item) {
    const instruments = Array.isArray(item?.instruments) ? item.instruments : [];
    if (instruments.length > 0) {
        const names = instruments
            .map(inst => String(inst.instrument_name || '').trim())
            .filter(Boolean);
        if (names.length > 0) return names.join(', ');
    }

    const enrollmentNames = String(item?.current_enrollment?.instrument_names || '').trim();
    if (enrollmentNames) return enrollmentNames;

    const studentNames = String(item?.student?.instrument_names || '').trim();
    if (studentNames) return studentNames;

    return 'Not set';
}

function getGuardianStudentName(item, index) {
    const s = item?.student || {};
    return `${s.first_name || ''} ${s.last_name || ''}`.trim() || `Student ${index + 1}`;
}

function getSessionChronologicalSortValue(row) {
    const sessionDate = String(row?.session_date || '').trim();
    if (!sessionDate) return Number.MAX_SAFE_INTEGER;
    const timestamp = new Date(`${sessionDate}T${row?.start_time || '00:00:00'}`).getTime();
    return Number.isFinite(timestamp) ? timestamp : Number.MAX_SAFE_INTEGER;
}

function compareSessionRowsChronologically(a, b) {
    const timeDifference = getSessionChronologicalSortValue(a) - getSessionChronologicalSortValue(b);
    if (timeDifference !== 0) return timeDifference;
    const sessionDifference = Number(a?.session_number || 0) - Number(b?.session_number || 0);
    if (sessionDifference !== 0) return sessionDifference;
    return Number(a?.session_id || 0) - Number(b?.session_id || 0);
}

function getGuardianSessionRows(item) {
    const rows = Array.isArray(item?.current_session_grades) ? item.current_session_grades.slice() : [];
    return rows.sort(compareSessionRowsChronologically);
}

function isPackageSessionUsed(row) {
    const status = String(row?.status || '').trim().toLowerCase();
    const attendance = String(row?.attendance_status || '').trim().toLowerCase();
    return Number(row?.counted_in || 0) === 1
        || ['completed', 'late'].includes(status)
        || ['present', 'late'].includes(attendance);
}

function getUsedPackageSessionCount(item) {
    return getGuardianSessionRows(item).filter(isPackageSessionUsed).length;
}

function getGuardianLatestCompletedSessionRow(item) {
    const rows = getGuardianSessionRows(item).filter((row) => String(row?.instructor_completed_at || '').trim() !== '');
    return rows.length > 0 ? rows[rows.length - 1] : null;
}

function getGuardianSessionCompletionAlertKey(sessionId) {
    return `fas_guardian_session_alert_${Number(sessionId || 0)}`;
}

function isGuardianSessionCompletionAlertDismissed(sessionId) {
    try {
        return localStorage.getItem(getGuardianSessionCompletionAlertKey(sessionId)) === 'dismissed';
    } catch (e) {
        return false;
    }
}

function dismissGuardianSessionCompletionAlert(sessionId) {
    try {
        localStorage.setItem(getGuardianSessionCompletionAlertKey(sessionId), 'dismissed');
    } catch (e) {
        // Ignore storage failures.
    }
}

function isGuardianUpcomingSessionRow(row) {
    const raw = String(row?.attendance_status || row?.status || 'Scheduled').trim().toLowerCase();
    if (['present', 'late', 'completed', 'absent', 'cancelled', 'no show', 'cancelled_by_teacher', 'rescheduled'].includes(raw)) {
        return false;
    }
    if (!row?.session_date) return false;
    return String(row.session_date).slice(0, 10) >= getManilaYmd();
}

function getNextUpcomingSession(item) {
    const rows = getGuardianSessionRows(item).filter(isGuardianUpcomingSessionRow);
    return rows[0] || null;
}

function formatGuardianSessionLabel(row) {
    if (!row?.session_date) return 'Date and time pending';

    const dateLabel = formatDateLong(row.session_date);
    const timeLabel = row.start_time && row.end_time
        ? `${formatTime12Hour(row.start_time)} - ${formatTime12Hour(row.end_time)}`
        : (row.start_time ? formatTime12Hour(row.start_time) : '');

    return `${dateLabel}${timeLabel ? ` • ${timeLabel}` : ''}`;
}

function formatGuardianNextSessionLabel(item) {
    const enrollment = item?.current_enrollment || null;
    const nextRow = getNextUpcomingSession(item);
    if (nextRow) {
        return formatGuardianSessionLabel(nextRow);
    }
    const scheduleDate = enrollment?.first_session_date || enrollment?.start_date;
    if (scheduleDate) {
        return `First lesson: ${formatDateLong(scheduleDate)}`;
    }
    return 'No upcoming session scheduled yet';
}

function collectGuardianUpcomingSessions(items, limit = 6) {
    const rows = [];
    (Array.isArray(items) ? items : []).forEach((item, index) => {
        getGuardianSessionRows(item)
            .filter(isGuardianUpcomingSessionRow)
            .forEach((session) => {
                rows.push({
                    item,
                    index,
                    session,
                    sortTime: new Date(`${session.session_date}T${session.start_time || '00:00:00'}`).getTime() || 0
                });
            });
    });
    return rows.sort((a, b) => a.sortTime - b.sortTime).slice(0, limit);
}

function renderGuardianDashboardAlerts(students) {
    const rows = Array.isArray(students) ? students : [];
    const dueStudents = rows.filter((item) => getGuardianPaymentMetrics(item).totalBalance > 0);
    const alerts = [];

    const completionAlerts = rows.map((item) => {
        const row = getGuardianLatestCompletedSessionRow(item);
        if (!row) return null;
        const sessionId = Number(row.session_id || 0);
        if (sessionId < 1 || isGuardianSessionCompletionAlertDismissed(sessionId)) return null;
        const studentName = getGuardianStudentName(item, 0);
        const dateLabel = row?.session_date ? formatDateLong(row.session_date) : 'recently';
        const timeLabel = row?.start_time && row?.end_time
            ? `${formatTime12Hour(row.start_time)} - ${formatTime12Hour(row.end_time)}`
            : (row?.start_time ? formatTime12Hour(row.start_time) : '');
        return { item, row, sessionId, studentName, dateLabel, timeLabel };
    }).filter(Boolean).sort((a, b) => {
        const aTime = new Date(`${a.row?.session_date || ''}T${a.row?.start_time || '00:00:00'}`).getTime() || 0;
        const bTime = new Date(`${b.row?.session_date || ''}T${b.row?.start_time || '00:00:00'}`).getTime() || 0;
        return bTime - aTime;
    });

    if (completionAlerts.length > 0) {
        const previewItems = completionAlerts.slice(0, 3).map((entry) => `
            <div class="rounded-2xl border border-gold-200 bg-white/80 dark:bg-black/20 px-4 py-3 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                    <div class="text-sm font-bold text-zinc-900 dark:text-white">
                        ${escapeHtml(entry.studentName)} finished a session
                    </div>
                    <div class="mt-1 text-xs text-zinc-600 dark:text-zinc-300">
                        ${escapeHtml(entry.dateLabel)}${entry.timeLabel ? ` • ${escapeHtml(entry.timeLabel)}` : ''}
                    </div>
                </div>
                <div class="flex flex-wrap gap-2">
                    <a href="guardian_students.html" class="inline-flex items-center gap-2 rounded-xl bg-gold-500 px-3 py-2 text-xs font-bold text-black hover:bg-gold-400 transition">
                        <i class="fas fa-eye"></i> View
                    </a>
                    <button type="button" onclick="dismissGuardianSessionCompletionAlert(${entry.sessionId}); window.location.reload();" class="inline-flex items-center gap-2 rounded-xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-2 text-xs font-bold text-zinc-700 dark:text-zinc-200 hover:bg-zinc-50 dark:hover:bg-white/10 transition">
                        Dismiss
                    </button>
                </div>
            </div>
        `).join('');

        alerts.push(`
            <div class="rounded-3xl border border-gold-300 bg-gradient-to-br from-amber-50 via-white to-gold-50 dark:from-gold-500/15 dark:via-black/20 dark:to-black/10 px-4 py-4 shadow-xl dark:shadow-black/30">
                <div class="flex items-start justify-between gap-4 mb-3">
                    <div class="flex items-start gap-3">
                        <div class="h-11 w-11 rounded-2xl bg-gold-500/15 text-gold-600 dark:text-gold-300 grid place-items-center">
                            <i class="fas fa-bell text-lg"></i>
                        </div>
                        <div>
                            <div class="text-sm font-black uppercase tracking-[0.18em] text-gold-700 dark:text-gold-300">Session Completed</div>
                            <div class="text-lg font-extrabold text-zinc-900 dark:text-white">You have a new lesson update for your linked student(s).</div>
                            <div class="mt-1 text-sm text-zinc-600 dark:text-zinc-300">Check the details below. Real email guardians will also receive an email notification when available.</div>
                        </div>
                    </div>
                    <span class="inline-flex items-center rounded-full border border-gold-300 bg-white/90 dark:bg-white/5 px-3 py-1 text-xs font-bold text-gold-700 dark:text-gold-300">
                        New Alert
                    </span>
                </div>
                <div class="space-y-3">
                    ${previewItems}
                </div>
            </div>
        `);
    }

    // ── Frozen account notices ──
    const frozenStudents = rows.filter(item => {
        const enrollment = item?.current_enrollment || null;
        if (!enrollment) return false;
        const notice = getScheduleFreezeReservationNotice(enrollment);
        return !!notice;
    });
    if (frozenStudents.length > 0) {
        frozenStudents.forEach(item => {
            const s    = item?.student || {};
            const name = `${s.first_name || ''} ${s.last_name || ''}`.trim() || 'Student';
            const enrollment = item?.current_enrollment || {};
            const notice = getScheduleFreezeReservationNotice(enrollment);
            const studentIndex = rows.indexOf(item);
            const paymentPending = String(enrollment.__freeze_payment_status || '').toLowerCase() === 'pending';
            alerts.push(`
                <div class="rounded-2xl border border-rose-300 bg-rose-50 dark:border-rose-500/30 dark:bg-rose-500/10 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <div class="flex items-center gap-2 text-sm font-bold text-rose-800 dark:text-rose-200">
                            <i class="fas fa-snowflake"></i>
                            ${escapeHtml(name)}'s account is frozen
                        </div>
                        <div class="mt-1 text-xs text-rose-600 dark:text-rose-300">
                            ${escapeHtml(notice?.text || `${enrollment.used_absences || 0} absences recorded. ₱${notice?.amount || 100} slot reservation fee required.`)}
                        </div>
                    </div>
                    ${paymentPending
                        ? '<span class="inline-flex items-center gap-1.5 rounded-xl border border-amber-300 bg-amber-100 px-3 py-2 text-xs font-bold text-amber-800"><i class="fas fa-clock"></i> Awaiting desk approval</span>'
                        : `<button type="button" onclick="openGuardianFreezePayment(${studentIndex})" class="inline-flex items-center gap-1.5 rounded-xl bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500"><i class="fas fa-credit-card"></i> Pay online</button>`}
                </div>
            `);
        });
    }

    if (dueStudents.length > 0) {
        alerts.push(`
            <div class="rounded-2xl border border-amber-200 bg-amber-50 dark:border-amber-500/20 dark:bg-amber-500/10 px-4 py-3 flex flex-wrap items-center justify-between gap-3">
                <div class="text-sm text-amber-900 dark:text-amber-100">
                    <span class="font-bold">${dueStudents.length} student${dueStudents.length === 1 ? '' : 's'}</span> still have an outstanding balance.
                </div>
                <a href="guardian_payments.html" class="inline-flex items-center gap-2 rounded-xl bg-amber-600 px-3 py-2 text-xs font-bold text-white hover:bg-amber-500 transition">Review payments</a>
            </div>
        `);
    }

    const upcoming = collectGuardianUpcomingSessions(rows, 1);
    if (upcoming.length > 0) {
        const entry = upcoming[0];
        const name = getGuardianStudentName(entry.item, entry.index);
        const when = formatGuardianNextSessionLabel(entry.item);
        alerts.push(`
            <div class="rounded-2xl border border-blue-200 bg-blue-50 dark:border-blue-500/20 dark:bg-blue-500/10 px-4 py-3 text-sm text-blue-900 dark:text-blue-100">
                <span class="font-bold">Next lesson:</span> ${escapeHtml(name)} — ${escapeHtml(when)}
            </div>
        `);
    }

    if (!alerts.length) {
        return `
            <div class="rounded-2xl border border-emerald-200 bg-emerald-50 dark:border-emerald-500/20 dark:bg-emerald-500/10 px-4 py-3 text-sm text-emerald-800 dark:text-emerald-200">
                <i class="fas fa-circle-check mr-2"></i>All caught up for now.
            </div>
        `;
    }
    return alerts.join('');
}

function renderGuardianDashboardUpcomingList(items) {
    const upcoming = collectGuardianUpcomingSessions(items, 6);
    if (!upcoming.length) {
        return `<div class="rounded-2xl border border-dashed border-zinc-200 dark:border-white/10 px-4 py-8 text-center text-sm text-zinc-500">No upcoming sessions in the schedule yet.</div>`;
    }
    return upcoming.map((entry) => {
        const name = getGuardianStudentName(entry.item, entry.index);
        const session = entry.session;
        const when = formatGuardianSessionLabel(session);
        const teacher = session.teacher_name || 'Teacher pending';
        const room = session.room_name || 'Room pending';
        return `
            <button type="button" onclick="window.location.href='guardian_students.html'" class="w-full rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 text-left hover:border-gold-300 transition">
                <div class="font-bold text-zinc-900 dark:text-white">${escapeHtml(name)}</div>
                <div class="mt-1 text-sm text-zinc-600 dark:text-zinc-300">${escapeHtml(when)}</div>
                <div class="mt-1 text-xs text-zinc-500">${escapeHtml(teacher)} • ${escapeHtml(room)}</div>
            </button>
        `;
    }).join('');
}

function renderGuardianDashboardBalanceList(items) {
    const rows = (Array.isArray(items) ? items : [])
        .map((item, index) => ({ item, index, metrics: getGuardianPaymentMetrics(item) }))
        .filter((row) => row.metrics.totalBalance > 0)
        .sort((a, b) => b.metrics.totalBalance - a.metrics.totalBalance);

    if (!rows.length) {
        return `<div class="rounded-2xl border border-dashed border-zinc-200 dark:border-white/10 px-4 py-8 text-center text-sm text-emerald-600 dark:text-emerald-300">All linked students are fully paid for now.</div>`;
    }

    return rows.map(({ item, index, metrics }) => {
        const name = getGuardianStudentName(item, index);
        return `
            <a href="guardian_payments.html" class="block rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 hover:border-gold-300 transition">
                <div class="flex items-center justify-between gap-3">
                    <div class="font-bold text-zinc-900 dark:text-white">${escapeHtml(name)}</div>
                    <div class="text-lg font-black text-gold-600 dark:text-gold-400">${formatCurrencyPHP(metrics.totalBalance)}</div>
                </div>
            </a>
        `;
    }).join('');
}

function buildGuardianSessionDetailMarkup(row) {
    const dateLabel = row.session_date ? formatDateLong(row.session_date) : 'Date pending';
    const timeLabel = row.start_time && row.end_time
        ? `${formatTime12Hour(row.start_time)} - ${formatTime12Hour(row.end_time)}`
        : (row.start_time ? formatTime12Hour(row.start_time) : 'Time pending');
    const attendanceLabel = row.attendance_status && row.attendance_status !== 'Pending'
        ? row.attendance_status
        : (row.status || 'Scheduled');
    const remarksText = cleanSessionNoteText(row.teacher_remarks || row.remarks, 'No teacher remarks recorded yet.');
    const remarks = escapeHtml(remarksText);

    return `
        <div class="text-left">
            <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 font-bold">Session ${escapeHtml(String(row.session_number || ''))}</div>
            <h3 class="mt-2 text-xl font-black text-zinc-900">${escapeHtml(row.instrument_name || 'Student Session')}</h3>
            <div class="mt-2 text-sm text-zinc-500">${escapeHtml(dateLabel)} • ${escapeHtml(timeLabel)}</div>
            <div class="mt-1 text-sm text-zinc-500">${escapeHtml(row.teacher_name || 'Teacher not assigned')} • ${escapeHtml(row.room_name || 'Room pending')}</div>
            <div class="mt-4 flex flex-wrap items-center gap-2">
                ${renderAttendanceStatusBadge(attendanceLabel)}
                ${renderStudentGradeBadge(row.average_score, row.progress_id)}
            </div>
            <div class="mt-5 rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-4">
                <div class="text-[11px] uppercase tracking-[0.18em] text-zinc-500 font-bold">Teacher Remarks</div>
                <div class="mt-2 text-sm leading-6 text-zinc-700">${remarks}</div>
            </div>
        </div>
    `;
}

function openGuardianSessionDetails(studentIndex, sessionIndex) {
    const item = guardianPortalStudents[Number(studentIndex)];
    if (!item) return;
    const rows = getGuardianSessionRows(item);
    const row = rows[Number(sessionIndex)];
    if (!row) return;
    Swal.fire({
        width: 920,
        confirmButtonText: 'Close',
        confirmButtonColor: '#b8860b',
        html: buildGuardianSessionDetailMarkup(row)
    });
}

function renderGuardianStudentCard(item, index) {
    const s = item?.student || {};
    const enrollment = item?.current_enrollment || null;
    const studentId = s.student_id ?? `g-${index}`;
    const studentName = getGuardianStudentName(item, index);
    const branch = s.branch_name || '—';
    const regStatus = s.registration_status || 'Pending';
    const pkgName = enrollment?.package_name || s.package_name || 'Not assigned yet';
    const attendanceTotal = Number(enrollment?.package_sessions || s.package_sessions || 0);
    const paymentMetrics = getGuardianPaymentMetrics(item);
    const statusMetrics = getGuardianSessionStatusMetrics(item);

    return `
        <button type="button" onclick="openGuardianStudentModal(${index})" class="w-full rounded-3xl border ${getScheduleFreezeReservationNotice(enrollment) ? 'border-rose-300 dark:border-rose-500/30' : 'border-zinc-200 dark:border-white/10'} bg-white dark:bg-white/5 p-5 text-left shadow-lg transition hover:border-gold-300">
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <div class="text-xl font-extrabold text-zinc-900 dark:text-white">${escapeHtml(studentName)}</div>
                    <div class="text-sm text-zinc-500 dark:text-zinc-400 mt-1">${escapeHtml(branch)} • ${escapeHtml(pkgName)}</div>
                </div>
                <div class="flex flex-wrap items-center gap-2">
                    <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${badgeClassForRegistrationStatus(regStatus)}">${escapeHtml(regStatus)}</span>
                    ${getScheduleFreezeReservationNotice(enrollment) ? `<span class="inline-flex items-center gap-1 rounded-full border border-rose-300 bg-rose-50 px-3 py-1 text-xs font-bold text-rose-700 dark:border-rose-500/20 dark:bg-rose-500/10 dark:text-rose-300"><i class="fas fa-snowflake text-[9px]"></i> Frozen</span>` : ''}
                    ${paymentMetrics.totalBalance > 0 ? `<span class="inline-flex items-center rounded-full border border-gold-200 bg-gold-50 px-3 py-1 text-xs font-bold text-gold-700 dark:border-gold-500/20 dark:bg-gold-500/10 dark:text-gold-400">${formatCurrencyPHP(paymentMetrics.totalBalance)} due</span>` : ''}
                </div>
            </div>

            <div class="mt-4 flex flex-wrap items-center gap-3 text-sm text-zinc-600 dark:text-zinc-300">
                <span>Attended <strong id="guardianProgressAttended-${studentId}" class="text-zinc-900 dark:text-white">—</strong> / ${attendanceTotal || '—'}</span>
                <span>•</span>
                <span>Next: ${escapeHtml(formatGuardianNextSessionLabel(item))}</span>
                <span class="ml-auto text-gold-600 dark:text-gold-400 font-bold">View <i class="fas fa-arrow-right"></i></span>
            </div>
            <div id="guardianProgressRemaining-${studentId}" class="portal-hide-tech" aria-hidden="true">—</div>
            <div id="guardianProgressLast-${studentId}" class="portal-hide-tech" aria-hidden="true">—</div>
        </button>
    `;
}

function renderGuardianStudentModal(item, index) {
    const s = item?.student || {};
    const enrollment = item?.current_enrollment || null;
    const history = item?.enrollment_history || item?.history || [];
    const studentId = s.student_id ?? `g-${index}`;
    const studentName = `${s.first_name || ''} ${s.last_name || ''}`.trim() || 'Student';
    const branch = s.branch_name || '—';
    const regStatus = s.registration_status || 'Pending';
    const regPaid = Number(s.registration_fee_paid || 0);
    const regTotal = Number(s.registration_fee_amount || 0);
    const regRemaining = Math.max(0, regTotal - regPaid);
    const pkgName = enrollment?.package_name || s.package_name || 'Not assigned yet';
    const pkgSessions = enrollment?.package_sessions || s.package_sessions || 0;
    const pkgTotal = Number(enrollment?.total_amount || s.package_price || 0);
    const pkgPaid = Number(enrollment?.paid_amount || 0);
    const pkgBalance = Math.max(0, pkgTotal - pkgPaid);
    const teacherName = `${enrollment?.teacher_first_name || ''} ${enrollment?.teacher_last_name || ''}`.trim() || 'Not set';
    const scheduleDate = formatDateLong(enrollment?.first_session_date || enrollment?.start_date || '');
    const scheduleStart = enrollment?.first_start_time ? formatTime12Hour(enrollment.first_start_time) : '';
    const scheduleEnd = enrollment?.first_end_time ? formatTime12Hour(enrollment.first_end_time) : '';
    const scheduleTime = scheduleStart && scheduleEnd ? `${scheduleStart} - ${scheduleEnd}` : 'Not set';
    const scheduleRoom = enrollment?.first_room || 'Not set';
    const paymentState = enrollment?.payment_status || s.registration_status || 'Pending';
    const instrumentsLabel = getGuardianInstrumentLabel(item);
    const sessionRows = getGuardianSessionRows(item);
    const usedPackageSessions = Math.max(Number(enrollment?.used_sessions || enrollment?.completed_sessions || 0), getUsedPackageSessionCount(item));
    const canRequestAdditionalSessions = Number(pkgSessions || 0) > 0 && usedPackageSessions >= Number(pkgSessions || 0);
    const packageSessionsRemaining = Math.max(0, Number(pkgSessions || 0) - usedPackageSessions);
    const additionalRequest = item?.latest_session_extension_request || null;
    const hasPendingAdditionalRequest = String(additionalRequest?.status || '') === 'Pending';
    const learningProgress = Array.isArray(item?.learning_progress) ? item.learning_progress : [];
    const learningHistory = Array.isArray(item?.learning_history) ? item.learning_history : [];
    const registrationReady = String(s.status || '') === 'Active' && ['Approved', 'Fee Paid'].includes(String(regStatus));
    const enrollmentStatus = String(enrollment?.status || '');
    const canRequestEnrollment = registrationReady && !['Pending', 'Active', 'Completed'].includes(enrollmentStatus);
    const freezeNotice = getScheduleFreezeReservationNotice(enrollment);
    const freezePaymentPending = String(enrollment?.__freeze_payment_status || '').toLowerCase() === 'pending';

    const recentSessions = sessionRows.slice(0, 5);
    const hasMoreDetails = learningProgress.length > 0 || learningHistory.length > 0 || sessionRows.length > 0 || history.length > 0;
    return `<div class="space-y-4">
        ${freezeNotice ? `<div class="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-rose-300 bg-rose-50 px-4 py-3 dark:border-rose-500/30 dark:bg-rose-500/10"><div class="flex items-start gap-3"><i class="fas fa-snowflake mt-0.5 text-rose-500"></i><div><div class="text-sm font-bold text-rose-800 dark:text-rose-200">Account frozen</div><div class="mt-0.5 text-xs text-rose-600 dark:text-rose-300">A ₱${freezeNotice.amount || 100} online reservation payment is needed to restore attendance access.</div></div></div>${freezePaymentPending ? '<span class="rounded-lg bg-amber-100 px-3 py-2 text-xs font-bold text-amber-800">Awaiting desk approval</span>' : `<button type="button" onclick="openGuardianFreezePayment(${index})" class="rounded-lg bg-rose-600 px-4 py-2 text-xs font-bold text-white hover:bg-rose-500"><i class="fas fa-credit-card mr-1"></i>Pay online</button>`}</div>` : ''}
        <div class="flex flex-wrap items-center justify-between gap-2"><div class="text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(branch)} <span class="mx-1">·</span> ID ${escapeHtml(String(studentId))}</div><span class="rounded-full px-3 py-1 text-xs font-bold ${badgeClassForRegistrationStatus(regStatus)}">${escapeHtml(regStatus)}</span></div>
        ${canRequestEnrollment ? `<div class="flex flex-col gap-3 rounded-xl border border-gold-200 bg-gold-50 p-4 dark:border-gold-500/20 dark:bg-gold-500/10 sm:flex-row sm:items-center sm:justify-between"><div><div class="font-bold text-zinc-900 dark:text-white">No enrollment yet</div><div class="mt-0.5 text-xs text-zinc-600 dark:text-zinc-300">Start with 12 sessions and one instrument.</div></div><button type="button" onclick="openGuardianEnrollmentRequest(${index})" class="rounded-xl bg-gold-500 px-5 py-2.5 text-sm font-extrabold text-black hover:bg-gold-400"><i class="fas fa-paper-plane mr-2"></i>Enroll Student</button></div>` : ''}
        ${enrollmentStatus === 'Pending' ? `<div class="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200"><span><i class="fas fa-clock mr-2"></i>Enrollment and preferred schedule are awaiting desk confirmation.</span><button type="button" onclick="openGuardianEnrollmentRequest(${index})" class="rounded-lg border border-amber-300 bg-white px-3 py-2 text-xs font-bold text-amber-800 hover:bg-amber-100 dark:border-amber-500/30 dark:bg-white/10 dark:text-amber-200">View Request</button></div>` : ''}
        ${enrollment ? `<div class="grid gap-3 sm:grid-cols-2"><section class="rounded-xl border border-zinc-200 bg-zinc-50 p-4 dark:border-white/10 dark:bg-black/20"><div class="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Enrollment</div><div class="mt-1 font-bold text-zinc-900 dark:text-white">${escapeHtml(pkgName)}</div><div class="mt-1 text-xs text-zinc-500">${pkgSessions || '—'} sessions · ${escapeHtml(instrumentsLabel)}</div>${pkgBalance > 0 ? `<div class="mt-2 text-xs font-bold text-gold-600">${formatCurrencyPHP(pkgBalance)} balance</div>` : '<div class="mt-2 text-xs font-bold text-emerald-600">Paid</div>'}${canRequestAdditionalSessions ? `<button type="button" onclick="openGuardianAdditionalSessions(${index})" ${hasPendingAdditionalRequest ? 'disabled' : ''} class="mt-3 rounded-lg bg-gold-500 px-3 py-2 text-xs font-bold text-black hover:bg-gold-400 disabled:opacity-50">${hasPendingAdditionalRequest ? 'Additional Sessions Pending' : 'Request Additional Sessions'}</button>` : ''}</section><section class="rounded-xl border border-zinc-200 bg-zinc-50 p-4 dark:border-white/10 dark:bg-black/20"><div class="text-[10px] font-bold uppercase tracking-wider text-zinc-500">Sessions</div><div class="mt-2 flex gap-6"><div><div id="guardianModalProgressAttended-${studentId}" class="text-2xl font-black text-zinc-900 dark:text-white">—</div><div class="text-[10px] text-zinc-500">Attended</div></div><div><div id="guardianModalProgressRemaining-${studentId}" class="text-2xl font-black text-zinc-900 dark:text-white">—</div><div class="text-[10px] text-zinc-500">Remaining</div></div></div><div id="guardianModalProgressLast-${studentId}" class="mt-2 text-xs text-zinc-500">—</div></section></div><section class="rounded-xl border border-zinc-200 px-4 py-3 dark:border-white/10"><div class="flex gap-3"><i class="fas fa-calendar-day mt-1 text-gold-600"></i><div><div class="text-sm font-bold text-zinc-900 dark:text-white">${scheduleDate ? escapeHtml(scheduleDate) : 'Schedule pending'}${scheduleTime !== 'Not set' ? ` · ${escapeHtml(scheduleTime)}` : ''}</div><div class="mt-0.5 text-xs text-zinc-500">${escapeHtml(teacherName)}</div></div></div></section>` : ''}
        ${hasMoreDetails ? `<details class="group rounded-xl border border-zinc-200 dark:border-white/10"><summary class="flex cursor-pointer list-none items-center justify-between px-4 py-3 text-sm font-bold text-zinc-800 dark:text-white"><span><i class="fas fa-folder-open mr-2 text-gold-600"></i>View sessions and progress</span><i class="fas fa-chevron-down text-xs text-zinc-400 transition group-open:rotate-180"></i></summary><div class="space-y-4 border-t border-zinc-200 p-4 dark:border-white/10">
            ${learningProgress.length ? `<section><div class="mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">Learning progress</div><div class="space-y-2">${learningProgress.map(row => `<div class="rounded-lg bg-zinc-50 px-3 py-3 dark:bg-white/5"><div class="flex items-center justify-between gap-2"><div class="text-sm font-bold text-zinc-900 dark:text-white">${escapeHtml(row.instrument_name || 'Instrument')} · ${escapeHtml(row.level_name || 'Level not set')}</div><span class="text-xs text-zinc-500">${escapeHtml(row.assessment_readiness || 'Not Ready')}</span></div>${row.current_topic ? `<div class="mt-1 text-xs text-zinc-500">${escapeHtml(row.current_topic)}</div>` : ''}</div>`).join('')}</div></section>` : ''}
            ${recentSessions.length ? `<section><div class="mb-2 flex justify-between"><div class="text-xs font-bold uppercase tracking-wider text-zinc-500">Recent sessions</div><span class="text-xs text-zinc-400">${sessionRows.length} total</span></div><div class="space-y-2">${recentSessions.map((row, sessionIndex) => `<button type="button" onclick="openGuardianSessionDetails(${index}, ${sessionIndex})" class="flex w-full items-center justify-between rounded-lg bg-zinc-50 px-3 py-3 text-left dark:bg-white/5"><div><div class="text-sm font-bold text-zinc-900 dark:text-white">Session ${escapeHtml(String(row.session_number || ''))}</div><div class="text-xs text-zinc-500">${escapeHtml(row.session_date ? formatDateShort(row.session_date) : 'Date pending')}</div></div><span class="text-xs font-bold text-gold-600">View</span></button>`).join('')}</div></section>` : ''}
            ${learningHistory.length ? `<section><div class="mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">Achievements</div><div class="space-y-2">${learningHistory.map(row => `<div class="rounded-lg bg-zinc-50 px-3 py-3 text-sm dark:bg-white/5"><span class="font-bold">${escapeHtml(row.instrument_name || 'Instrument')} · ${escapeHtml(row.level_name || 'Level')}</span>${row.certificate_id ? '<span class="ml-2 text-xs font-bold text-emerald-600">Certificate issued</span>' : ''}</div>`).join('')}</div></section>` : ''}
            ${history.length ? `<section><div class="mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">Enrollment history</div><div class="space-y-2">${renderEnrollmentHistoryList(history)}</div></section>` : ''}
        </div></details>` : ''}
    </div>`;

    return `
        <div class="space-y-6">
            ${getScheduleFreezeReservationNotice(enrollment) ? `
            <div class="rounded-2xl border border-rose-300 bg-rose-50 dark:border-rose-500/30 dark:bg-rose-500/10 px-4 py-3 flex items-start gap-3">
                <i class="fas fa-snowflake text-rose-500 mt-0.5 shrink-0"></i>
                <div>
                    <p class="text-sm font-bold text-rose-800 dark:text-rose-200">Account Frozen</p>
                    <p class="text-xs text-rose-600 dark:text-rose-300 mt-0.5">
                        ${enrollment.used_absences || 0} absence${Number(enrollment.used_absences || 0) === 1 ? '' : 's'} recorded.
                        A ₱${getScheduleFreezeReservationNotice(enrollment)?.amount || 100} slot reservation fee must be paid at the branch to restore access.
                    </p>
                </div>
            </div>
            ` : ''}
            <div class="flex flex-wrap items-center justify-between gap-3">
                <div>
                    <div class="text-sm text-zinc-500 dark:text-zinc-400">Branch: <span class="font-semibold text-zinc-700 dark:text-zinc-200">${escapeHtml(branch)}</span></div>
                    <div class="text-sm text-zinc-500 dark:text-zinc-400 mt-1">Student ID: <span class="font-semibold text-zinc-700 dark:text-zinc-200">${escapeHtml(String(studentId))}</span></div>
                </div>
                <span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${badgeClassForRegistrationStatus(regStatus)}">${escapeHtml(regStatus)}</span>
            </div>

            ${canRequestEnrollment ? `<div class="rounded-2xl border border-gold-200 bg-gold-50 p-4 dark:border-gold-500/20 dark:bg-gold-500/10 sm:flex sm:items-center sm:justify-between sm:gap-4"><div><div class="font-extrabold text-zinc-900 dark:text-white">Ready to enroll this student?</div><p class="mt-1 text-sm text-zinc-600 dark:text-zinc-300">Request the standard 12-session package and choose one instrument.</p></div><button type="button" onclick="openGuardianEnrollmentRequest(${index})" class="mt-3 inline-flex items-center justify-center rounded-xl bg-gold-500 px-5 py-3 text-sm font-extrabold text-black transition hover:bg-gold-400 sm:mt-0"><i class="fas fa-paper-plane mr-2"></i>Enroll Student</button></div>` : ''}
            ${enrollmentStatus === 'Pending' ? `<div class="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-800 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200"><i class="fas fa-clock mr-2"></i>The enrollment request is waiting for academy review.</div>` : ''}

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4">
                    <div class="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Registration</div>
                    <div class="mt-3 text-sm text-zinc-600 dark:text-zinc-300">Paid: <span class="text-zinc-900 dark:text-white font-semibold">${formatCurrencyPHP(regPaid)}</span></div>
                    <div class="text-sm text-zinc-600 dark:text-zinc-300">Total: <span class="text-zinc-900 dark:text-white font-semibold">${formatCurrencyPHP(regTotal)}</span></div>
                    <div class="text-sm text-zinc-600 dark:text-zinc-300">Remaining: <span class="text-gold-500 font-semibold">${formatCurrencyPHP(regRemaining)}</span></div>
                </div>
                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4">
                    <div class="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Package & Payments</div>
                    <div class="mt-3 text-sm text-zinc-600 dark:text-zinc-300">Package: <span class="text-zinc-900 dark:text-white font-semibold">${escapeHtml(pkgName)}</span></div>
                    <div class="text-sm text-zinc-600 dark:text-zinc-300">Sessions: <span class="text-zinc-900 dark:text-white font-semibold">${pkgSessions ? `${pkgSessions} sessions` : '—'}</span></div>
                    <div class="text-sm text-zinc-600 dark:text-zinc-300">Paid: <span class="text-zinc-900 dark:text-white font-semibold">${formatCurrencyPHP(pkgPaid)}</span></div>
                    <div class="text-sm text-zinc-600 dark:text-zinc-300">Balance: <span class="text-gold-500 font-semibold">${formatCurrencyPHP(pkgBalance)}</span></div>
                    ${enrollment && canRequestAdditionalSessions ? `
                        <button type="button" onclick="openGuardianAdditionalSessions(${index})" ${hasPendingAdditionalRequest ? 'disabled' : ''} class="mt-4 w-full rounded-xl bg-gold-500 px-3 py-2.5 text-xs font-extrabold text-black transition hover:bg-gold-400 disabled:cursor-not-allowed disabled:opacity-50">
                            ${hasPendingAdditionalRequest ? 'Additional Sessions Pending' : 'Request Additional Sessions'}
                        </button>
                        <div class="mt-2 text-[11px] text-zinc-500 dark:text-zinc-400">₱650 each · purchased lessons do not reset learning progress</div>
                    ` : ''}
                </div>
                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4">
                    <div class="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Attendance</div>
                    <div class="mt-3 grid grid-cols-3 gap-2 text-center">
                        <div class="rounded-xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 p-2">
                            <div class="text-[10px] text-zinc-500 dark:text-zinc-400 uppercase tracking-widest">Attended</div>
                            <div id="guardianModalProgressAttended-${studentId}" class="text-lg font-black text-zinc-900 dark:text-white mt-1">—</div>
                        </div>
                        <div class="rounded-xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 p-2">
                            <div class="text-[10px] text-zinc-500 dark:text-zinc-400 uppercase tracking-widest">Remaining</div>
                            <div id="guardianModalProgressRemaining-${studentId}" class="text-lg font-black text-zinc-900 dark:text-white mt-1">—</div>
                        </div>
                        <div class="rounded-xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 p-2">
                            <div class="text-[10px] text-zinc-500 dark:text-zinc-400 uppercase tracking-widest">Last</div>
                            <div id="guardianModalProgressLast-${studentId}" class="text-xs font-semibold text-zinc-700 dark:text-zinc-200 mt-2">—</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-5">
                <div class="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Current Schedule</div>
                <div class="mt-3 grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                    <div><span class="text-zinc-500 dark:text-zinc-400">Teacher:</span> <span class="text-zinc-900 dark:text-white font-semibold">${escapeHtml(teacherName)}</span></div>
                    <div><span class="text-zinc-500 dark:text-zinc-400">Payment:</span> <span class="text-zinc-900 dark:text-white font-semibold">${escapeHtml(paymentState)}</span></div>
                    <div><span class="text-zinc-500 dark:text-zinc-400">Date:</span> <span class="text-zinc-900 dark:text-white font-semibold">${escapeHtml(scheduleDate || 'Not set')}</span></div>
                    <div><span class="text-zinc-500 dark:text-zinc-400">Time:</span> <span class="text-zinc-900 dark:text-white font-semibold">${escapeHtml(scheduleTime)}</span></div>
                    <div><span class="text-zinc-500 dark:text-zinc-400">Room:</span> <span class="text-zinc-900 dark:text-white font-semibold">${escapeHtml(scheduleRoom)}</span></div>
                    <div><span class="text-zinc-500 dark:text-zinc-400">Instruments:</span> <span class="text-zinc-900 dark:text-white font-semibold">${escapeHtml(instrumentsLabel)}</span></div>
                </div>
            </div>

            <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-5">
                <div class="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Formal Learning Progress</div>
                <div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">Instructor-managed by instrument; independent from purchased sessions and optional songs.</div>
                <div class="mt-4 grid grid-cols-1 lg:grid-cols-2 gap-3">
                    ${learningProgress.length ? learningProgress.map((row) => `
                        <div class="rounded-xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 p-4">
                            <div class="flex items-start justify-between gap-3">
                                <div>
                                    <div class="text-xs font-bold uppercase tracking-widest text-gold-600">${escapeHtml(row.instrument_name || 'Instrument')}</div>
                                    <div class="mt-1 text-lg font-black text-zinc-900 dark:text-white">${escapeHtml(row.level_name || 'Level not set')}</div>
                                    <div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(row.book_material || 'No book/material recorded')}</div>
                                </div>
                                <span class="rounded-full border border-zinc-200 dark:border-white/10 px-2.5 py-1 text-[10px] font-bold text-zinc-600 dark:text-zinc-300">${escapeHtml(row.assessment_readiness || 'Not Ready')}</span>
                            </div>
                            ${row.current_topic ? `<div class="mt-3 text-sm text-zinc-600 dark:text-zinc-300"><span class="font-bold">Current topic:</span> ${escapeHtml(row.current_topic)}</div>` : ''}
                        </div>
                    `).join('') : '<div class="lg:col-span-2 rounded-xl border border-dashed border-zinc-200 dark:border-white/10 px-4 py-6 text-center text-sm text-zinc-500 dark:text-zinc-400">The instructor has not created a formal learning record yet.</div>'}
                </div>
                ${learningHistory.length ? `
                    <div class="mt-5 border-t border-zinc-200 dark:border-white/10 pt-4">
                        <div class="text-xs font-bold uppercase tracking-widest text-zinc-500">Level / Book History</div>
                        <div class="mt-3 space-y-2">
                            ${learningHistory.map((row) => `
                                <div class="flex flex-wrap items-center justify-between gap-2 rounded-xl bg-white dark:bg-white/5 px-4 py-3 text-sm">
                                    <div><span class="font-bold text-zinc-900 dark:text-white">${escapeHtml(row.instrument_name || 'Instrument')} · ${escapeHtml(row.level_name || 'Level')}</span><span class="text-zinc-500 dark:text-zinc-400"> · ${escapeHtml(row.book_material || 'No book recorded')}</span></div>
                                    <div class="text-xs font-bold text-emerald-600">Achieved${row.achieved_at ? ` · ${escapeHtml(formatDateShort(row.achieved_at))}` : ''}${row.certificate_id ? ' · Certificate Issued' : ''}</div>
                                </div>
                            `).join('')}
                        </div>
                    </div>
                ` : ''}
            </div>

            <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-5">
                <div class="flex flex-wrap items-center justify-between gap-3">
                    <div>
                        <div class="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Session Tracker</div>
                        <div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">Track completed, upcoming, and graded sessions for this student.</div>
                    </div>
                    <div class="rounded-full border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 px-3 py-1 text-xs font-bold text-zinc-600 dark:text-zinc-300">
                        ${sessionRows.length} session record${sessionRows.length === 1 ? '' : 's'}
                    </div>
                </div>
                <div class="mt-4 space-y-3">
                    ${sessionRows.length ? sessionRows.map((row, sessionIndex) => {
                        const dateLabel = row.session_date ? formatDateShort(row.session_date) : 'Date pending';
                        const timeLabel = row.start_time && row.end_time
                            ? `${formatTime12Hour(row.start_time)} - ${formatTime12Hour(row.end_time)}`
                            : (row.start_time ? formatTime12Hour(row.start_time) : 'Time pending');
                        const attendanceLabel = row.attendance_status && row.attendance_status !== 'Pending'
                            ? row.attendance_status
                            : (row.status || 'Scheduled');
                        return `
                            <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 px-4 py-4">
                                <div class="flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                                    <div>
                                        <div class="text-sm font-bold text-zinc-900 dark:text-white">Session ${escapeHtml(String(row.session_number || ''))}</div>
                                        <div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(dateLabel)} • ${escapeHtml(timeLabel)}</div>
                                        <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">${escapeHtml(row.instrument_name || 'Instrument Session')} • ${escapeHtml(row.room_name || 'Room pending')}</div>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-2">
                                        ${renderAttendanceStatusBadge(attendanceLabel)}
                                        ${renderStudentGradeBadge(row.average_score, row.progress_id)}
                                        <button type="button" onclick="openGuardianSessionDetails(${index}, ${sessionIndex})" class="inline-flex items-center rounded-xl bg-zinc-900 px-3 py-2 text-xs font-bold text-white transition hover:bg-zinc-800 dark:bg-white/10 dark:hover:bg-white/20">
                                            View Session
                                        </button>
                                    </div>
                                </div>
                            </div>
                        `;
                    }).join('') : '<div class="rounded-2xl border border-dashed border-zinc-200 dark:border-white/10 px-4 py-8 text-center text-sm text-zinc-500 dark:text-zinc-400">No session records yet for this student.</div>'}
                </div>
            </div>

            <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-5">
                <div class="text-xs uppercase tracking-[0.2em] text-zinc-500 font-bold">Enrollment History</div>
                <div class="mt-3 space-y-3">
                    ${renderEnrollmentHistoryList(history)}
                </div>
            </div>
        </div>
    `;
}

function renderGuardianStudentsList(items) {
    if (!Array.isArray(items) || items.length === 0) {
        return `
            <div class="rounded-3xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 p-10 text-center text-zinc-500 dark:text-zinc-400">
                <i class="fas fa-user-slash text-3xl mb-3"></i>
                <div class="font-semibold">No linked students found.</div>
                <div class="text-xs text-zinc-500 mt-2">Ask the admin to link your guardian account to a student profile.</div>
            </div>
        `;
    }
    return items.map((item, index) => renderGuardianStudentCard(item, index)).join('');
}

function updateGuardianTotals(items) {
    const rows = Array.isArray(items) ? items : [];
    let totalBalance = 0;
    let totalPaid = 0;

    rows.forEach(item => {
        const s = item?.student || {};
        const enrollment = item?.current_enrollment || null;
        const regPaid = Number(s.registration_fee_paid || 0);
        const regTotal = Number(s.registration_fee_amount || 0);
        const regRemaining = Math.max(0, regTotal - regPaid);
        const pkgTotal = Number(enrollment?.total_amount || s.package_price || 0);
        const pkgPaid = Number(enrollment?.paid_amount || 0);
        const pkgRemaining = Math.max(0, pkgTotal - pkgPaid);

        totalBalance += regRemaining + pkgRemaining;
        totalPaid += regPaid + pkgPaid;
    });

    setText('guardianStudentCount', String(rows.length));
    setText('guardianTotalBalance', formatCurrencyPHP(totalBalance));
    setText('guardianTotalPaid', formatCurrencyPHP(totalPaid));
}

function getGuardianPaymentMetrics(item) {
    const student = item?.student || {};
    const enrollment = item?.current_enrollment || null;
    const registrationPaid = Number(student.registration_fee_paid || 0);
    const registrationTotal = Number(student.registration_fee_amount || 0);
    const registrationBalance = Math.max(0, registrationTotal - registrationPaid);
    const packagePaid = Number(enrollment?.paid_amount || 0);
    const packageTotal = Number(enrollment?.total_amount || student.package_price || 0);
    const packageBalance = Math.max(0, packageTotal - packagePaid);

    return {
        registrationPaid,
        registrationTotal,
        registrationBalance,
        packagePaid,
        packageTotal,
        packageBalance,
        totalPaid: registrationPaid + packagePaid,
        totalBalance: registrationBalance + packageBalance
    };
}

function renderGuardianPaymentCard(item, index) {
    const student = item?.student || {};
    const enrollment = item?.current_enrollment || null;
    const studentName = getGuardianStudentName(item, index);
    const branchName = student.branch_name || '—';
    const packageName = enrollment?.package_name || student.package_name || 'No package yet';

    return `
        <div class="w-full rounded-3xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-5 text-left">
            <div class="text-base font-bold text-zinc-900 dark:text-white">${escapeHtml(studentName)}</div>
            <div class="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">${escapeHtml(branchName)} · ${escapeHtml(packageName)}</div>
            <div class="mt-3">
                ${enrollment?.status === 'Active' ? renderPortalBalanceSection(enrollment) : '<div class="text-sm text-zinc-500">No active enrollment</div>'}
            </div>
            <button type="button" onclick="openGuardianStudentModal(${index})" class="mt-3 text-xs font-semibold text-zinc-600 underline underline-offset-2 dark:text-zinc-300">Student details</button>
        </div>
    `;
}

function renderGuardianPaymentsList(items) {
    if (!Array.isArray(items) || items.length === 0) {
        return `
            <div class="col-span-full rounded-3xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 p-10 text-center text-zinc-500 dark:text-zinc-400">
                <i class="fas fa-wallet text-3xl mb-3"></i>
                <div class="font-semibold">No linked student payments found.</div>
                <div class="mt-2 text-xs">Ask the admin to link your guardian account to a student profile first.</div>
            </div>
        `;
    }
    return items.map((item, index) => renderGuardianPaymentCard(item, index)).join('');
}

function updateGuardianPaymentTotals(items) {
    const rows = Array.isArray(items) ? items : [];
    let totalPaid = 0;
    let totalBalance = 0;
    rows.forEach((item) => {
        const metrics = getGuardianPaymentMetrics(item);
        totalPaid += metrics.totalPaid;
        totalBalance += metrics.totalBalance;
    });
    setText('guardianPaymentStudentCount', String(rows.length));
    setText('guardianPaymentTotalPaid', formatCurrencyPHP(totalPaid));
    setText('guardianPaymentTotalBalance', formatCurrencyPHP(totalBalance));
}

async function hydrateGuardianAttendance(items) {
    const rows = Array.isArray(items) ? items : [];
    await Promise.all(rows.map(async (item) => {
        const student = item?.student || {};
        const studentId = student.student_id;
        if (!studentId) return;

        try {
            const summaryRes = await fetchAttendanceSummary(studentId);
            const attended = summaryRes?.success
                ? Number(summaryRes.summary?.present_count ?? 0) + Number(summaryRes.summary?.late_count ?? 0)
                : 0;
            const total = Number(item?.current_enrollment?.package_sessions || student.package_sessions || 0);
            const remaining = total > 0 ? Math.max(0, total - attended) : 0;
            const lastAttended = summaryRes?.success && summaryRes.summary?.last_attended_at
                ? new Date(summaryRes.summary.last_attended_at).toLocaleString()
                : '—';

            setText(`guardianProgressAttended-${studentId}`, String(attended));
            setText(`guardianProgressRemaining-${studentId}`, total > 0 ? String(remaining) : '—');
            setText(`guardianProgressLast-${studentId}`, `Last attendance: ${lastAttended}`);
            setText(`guardianModalProgressAttended-${studentId}`, String(attended));
            setText(`guardianModalProgressRemaining-${studentId}`, total > 0 ? String(remaining) : '—');
            setText(`guardianModalProgressLast-${studentId}`, lastAttended);
        } catch (e) {
            setText(`guardianProgressAttended-${studentId}`, '—');
            setText(`guardianProgressRemaining-${studentId}`, '—');
            setText(`guardianProgressLast-${studentId}`, 'Last attendance: —');
            setText(`guardianModalProgressAttended-${studentId}`, '—');
            setText(`guardianModalProgressRemaining-${studentId}`, '—');
            setText(`guardianModalProgressLast-${studentId}`, '—');
        }
    }));
}

function openGuardianStudentModal(index) {
    const item = guardianPortalStudents[index];
    const modal = document.getElementById('guardianStudentModal');
    const body = document.getElementById('guardianStudentModalBody');
    const title = document.getElementById('guardianStudentModalTitle');
    if (!item || !modal || !body || !title) return;

    guardianActiveStudentIndex = index;
    const student = item?.student || {};
    const studentName = `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student';
    title.textContent = studentName;
    body.innerHTML = renderGuardianStudentModal(item, index);
    const studentId = student.student_id;
    if (studentId) {
        const attendedText = document.getElementById(`guardianProgressAttended-${studentId}`)?.textContent || '—';
        const remainingText = document.getElementById(`guardianProgressRemaining-${studentId}`)?.textContent || '—';
        const lastText = (document.getElementById(`guardianProgressLast-${studentId}`)?.textContent || 'Last attendance: —').replace(/^Last attendance:\s*/, '');
        setText(`guardianModalProgressAttended-${studentId}`, attendedText);
        setText(`guardianModalProgressRemaining-${studentId}`, remainingText);
        setText(`guardianModalProgressLast-${studentId}`, lastText);
    }
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    document.body.classList.add('overflow-hidden');
}

function closeGuardianStudentModal() {
    const modal = document.getElementById('guardianStudentModal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    document.body.classList.remove('overflow-hidden');
    guardianActiveStudentIndex = null;
}

function getGuardianPortalDefaultBranchId() {
    const portalBranchId = Number(window.__guardianPortalBranchId || 0);
    if (portalBranchId > 0) return portalBranchId;
    const firstStudent = Array.isArray(guardianPortalStudents) ? guardianPortalStudents[0] : null;
    return Number(firstStudent?.student?.branch_id || firstStudent?.branch_id || 0);
}

function setGuardianPortalBranchContext(portal, students = []) {
    const portalBranchId = Number(portal?.branch_id || portal?.current_enrollment?.branch_id || 0);
    if (portalBranchId > 0) {
        window.__guardianPortalBranchId = portalBranchId;
        return;
    }

    if (Number(window.__guardianPortalBranchId || 0) > 0) {
        return;
    }

    const firstStudent = Array.isArray(students) ? students[0] : null;
    const studentBranchId = Number(firstStudent?.student?.branch_id || firstStudent?.branch_id || 0);
    if (studentBranchId > 0) {
        window.__guardianPortalBranchId = studentBranchId;
    }
}

async function fetchGuardianBranchOptionsHtml(selectedBranchId = '') {
    try {
        const response = await axios.get(`${baseApiUrl}/branch.php?action=get-branches`);
        const data = response.data || {};
        const branches = Array.isArray(data.branches) ? data.branches : [];
        const selectedValue = String(selectedBranchId || '');

        if (!branches.length) {
            return '<option value="">No branches available</option>';
        }

        return branches.map((branch) => {
            const value = String(branch.branch_id || '');
            const selected = selectedValue && value === selectedValue ? ' selected' : '';
            return `<option value="${escapeHtml(value)}"${selected}>${escapeHtml(branch.branch_name || 'Branch')}</option>`;
        }).join('');
    } catch (error) {
        return '<option value="">Unable to load branches</option>';
    }
}

function getGuardianPortalCurrentEmail() {
    return Auth.getUser()?.email || '';
}

function getGuardianPortalCurrentName() {
    const user = Auth.getUser() || {};
    return `${user.first_name || ''} ${user.last_name || ''}`.trim() || user.username || 'Guardian';
}

async function guardianAddChildMenu() {
    return guardianRegisterNewStudent();
}

async function guardianRegisterNewStudent() {
    const branchId = getGuardianPortalDefaultBranchId();
    const guardianEmail = getGuardianPortalCurrentEmail();
    const branchOptionsHtml = await fetchGuardianBranchOptionsHtml(branchId);
    const result = await Swal.fire({
        width: 920,
        padding: '0',
        showCancelButton: true,
        confirmButtonText: 'Request Register',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#b8860b',
        cancelButtonColor: '#6b7280',
        allowOutsideClick: false,
        background: '#ffffff',
        customClass: {
            popup: 'guardian-register-popup'
        },
        html: `
            <div class="guardian-register-shell text-left">
                <div class="space-y-4">
                    <div class="rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-4 py-3 text-sm text-zinc-600 dark:text-zinc-300">
                        Fill in only the details that are not already saved in your guardian portal. The request stays pending until the academy reviews it and assigns the Student ID.
                    </div>

                    <div class="grid grid-cols-1 xl:grid-cols-[1fr_320px] gap-4">
                        <div class="space-y-4">
                            <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 overflow-hidden">
                                <div class="flex items-center gap-2.5 px-4 py-3 bg-zinc-50 dark:bg-zinc-800 border-b border-zinc-100 dark:border-white/10">
                                    <div class="h-5 w-5 rounded-full bg-gold-500 flex items-center justify-center shrink-0"><span class="text-black text-[9px] font-black">1</span></div>
                                    <p class="text-sm font-semibold text-zinc-900 dark:text-white">Student Details</p>
                                </div>
                                <div class="px-4 py-4 space-y-3">
                                    <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                                        <input id="guardian-new-first" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" placeholder="First name">
                                        <input id="guardian-new-last" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" placeholder="Last name">
                                        <input id="guardian-new-dob" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" type="date" placeholder="Date of birth">
                                        <input id="guardian-new-age" class="w-full px-3 py-2 bg-zinc-100 dark:bg-white/5 border border-zinc-200 dark:border-white/10 rounded-xl text-sm text-zinc-500 dark:text-zinc-300 cursor-not-allowed" type="text" readonly placeholder="Age will appear here">
                                        <div class="relative">
                                            <input id="guardian-new-password" class="w-full px-3 py-2 pr-11 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" type="password" placeholder="Password">
                                            <button type="button" onclick="togglePassword('guardian-new-password', 'guardian-new-password-eye')" class="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-200" aria-label="Toggle password visibility">
                                                <i id="guardian-new-password-eye" class="fas fa-eye"></i>
                                            </button>
                                        </div>
                                        <div class="relative">
                                            <input id="guardian-new-password-confirm" class="w-full px-3 py-2 pr-11 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" type="password" placeholder="Confirm password">
                                            <button type="button" onclick="togglePassword('guardian-new-password-confirm', 'guardian-new-password-confirm-eye')" class="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-700 dark:text-zinc-400 dark:hover:text-zinc-200" aria-label="Toggle confirm password visibility">
                                                <i id="guardian-new-password-confirm-eye" class="fas fa-eye"></i>
                                            </button>
                                        </div>
                                        <div class="md:col-span-2 rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-4 py-3">
                                            <div class="flex gap-1">
                                                <div id="guardian-pass-bar-1" class="h-1 flex-1 rounded bg-zinc-200"></div>
                                                <div id="guardian-pass-bar-2" class="h-1 flex-1 rounded bg-zinc-200"></div>
                                                <div id="guardian-pass-bar-3" class="h-1 flex-1 rounded bg-zinc-200"></div>
                                                <div id="guardian-pass-bar-4" class="h-1 flex-1 rounded bg-zinc-200"></div>
                                            </div>
                                            <p id="guardian-pass-strength" class="mt-1 text-xs text-zinc-500">Password strength</p>
                                            <p id="guardian-pass-match" class="mt-1 text-xs"></p>
                                        </div>
                                        <div class="md:col-span-2">
                                            <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1">Branch</label>
                                            <select id="guardian-new-branch" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500">
                                                <option value="">Select branch</option>
                                                ${branchOptionsHtml}
                                            </select>
                                            <div class="mt-1 text-[11px] text-zinc-400">Choose the branch where the student should register.</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 overflow-hidden xl:self-start">
                            <div class="flex items-center gap-2.5 px-4 py-3 bg-zinc-50 dark:bg-zinc-800 border-b border-zinc-100 dark:border-white/10">
                                <div class="h-5 w-5 rounded-full bg-gold-500 flex items-center justify-center shrink-0"><span class="text-black text-[9px] font-black">2</span></div>
                                <p class="text-sm font-semibold text-zinc-900 dark:text-white">Registration Payment</p>
                            </div>
                            <div class="px-4 py-4 space-y-3">
                                <div class="rounded-xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200/70 dark:border-amber-500/30 px-3 py-2.5 text-xs text-amber-800 dark:text-amber-200">
                                    A <strong>₱1,000 lifetime registration fee</strong> is required before approval.
                                </div>
                                <div>
                                    <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1">Payment Method *</label>
                                    <select id="guardian-new-payment-method" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500">
                                        <option value="">Select payment method</option>
                                        <option value="GCash">GCash</option>
                                        <option value="Bank Transfer">Bank Transfer</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1">Reference Number *</label>
                                    <input id="guardian-new-reference-number" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" type="text" placeholder="Transaction / reference no.">
                                    <p class="mt-1 text-[11px] text-zinc-400">Enter the payment reference or transaction number.</p>
                                </div>
                                <div>
                                    <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1">Registration Proof *</label>
                                    <input id="guardian-new-registration-proof" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs text-zinc-700 dark:text-zinc-200 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-gold-500/20 file:text-gold-600 file:text-xs file:font-semibold" type="file" accept=".jpg,.jpeg,.png,.pdf,image/*">
                                    <p class="mt-1 text-[11px] text-zinc-400">Upload proof of payment for the ₱1,000 registration.</p>
                                </div>
                                <div>
                                    <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1">ID Proof *</label>
                                    <input id="guardian-new-id-proof" class="w-full px-3 py-2 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-xl text-xs text-zinc-700 dark:text-zinc-200 file:mr-2 file:py-1.5 file:px-3 file:rounded-lg file:border-0 file:bg-gold-500/20 file:text-gold-600 file:text-xs file:font-semibold" type="file" accept=".jpg,.jpeg,.png,.pdf,image/*">
                                    <p class="mt-1 text-[11px] text-zinc-400">Upload a valid ID or school ID proof.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `,
        focusConfirm: false,
        didOpen: () => {
            const firstInput = document.getElementById('guardian-new-first');
            if (firstInput) firstInput.focus();

            const dobInput = document.getElementById('guardian-new-dob');
            const ageInput = document.getElementById('guardian-new-age');
            const passwordInput = document.getElementById('guardian-new-password');
            const confirmInput = document.getElementById('guardian-new-password-confirm');
            const strengthText = document.getElementById('guardian-pass-strength');
            const matchText = document.getElementById('guardian-pass-match');
            const bars = [
                document.getElementById('guardian-pass-bar-1'),
                document.getElementById('guardian-pass-bar-2'),
                document.getElementById('guardian-pass-bar-3'),
                document.getElementById('guardian-pass-bar-4')
            ];
            const updateGuardianAge = () => {
                if (!dobInput || !ageInput) return;
                const age = calculateAgeFromBirthdate(dobInput.value);
                ageInput.value = age === null || age < 0 ? '' : `${age} years old`;
            };
            const resetBars = () => {
                bars.forEach((bar) => {
                    if (bar) bar.className = 'h-1 flex-1 rounded bg-zinc-200';
                });
            };
            const updateGuardianPasswordChecker = () => {
                const password = String(passwordInput?.value || '');
                const confirm = String(confirmInput?.value || '');
                let score = 0;
                if (password.length >= 8) score++;
                if (/[A-Z]/.test(password)) score++;
                if (/[a-z]/.test(password)) score++;
                if (/[0-9]/.test(password)) score++;
                if (/[!@#$%^&*]/.test(password)) score++;

                resetBars();

                if (!password) {
                    if (strengthText) {
                        strengthText.textContent = 'Password strength';
                        strengthText.className = 'mt-1 text-xs text-zinc-500';
                    }
                } else if (score <= 2) {
                    if (strengthText) {
                        strengthText.textContent = 'Weak password';
                        strengthText.className = 'mt-1 text-xs text-red-500';
                    }
                    if (bars[0]) bars[0].classList.replace('bg-zinc-200', 'bg-red-500');
                } else if (score <= 4) {
                    if (strengthText) {
                        strengthText.textContent = 'Medium password';
                        strengthText.className = 'mt-1 text-xs text-yellow-600';
                    }
                    bars.slice(0, 3).forEach((bar) => {
                        if (bar) bar.classList.replace('bg-zinc-200', 'bg-yellow-500');
                    });
                } else {
                    if (strengthText) {
                        strengthText.textContent = 'Strong password';
                        strengthText.className = 'mt-1 text-xs text-green-600';
                    }
                    bars.forEach((bar) => {
                        if (bar) bar.classList.replace('bg-zinc-200', 'bg-green-500');
                    });
                }

                if (matchText) {
                    if (!password && !confirm) {
                        matchText.textContent = '';
                        matchText.className = 'mt-1 text-xs';
                    } else if (password === confirm) {
                        matchText.textContent = 'Passwords match';
                        matchText.className = 'mt-1 text-xs text-green-600';
                    } else {
                        matchText.textContent = 'Passwords do not match';
                        matchText.className = 'mt-1 text-xs text-red-500';
                    }
                }
            };

            updateGuardianAge();
            dobInput?.addEventListener('input', updateGuardianAge);
            dobInput?.addEventListener('change', updateGuardianAge);
            updateGuardianPasswordChecker();
            passwordInput?.addEventListener('input', updateGuardianPasswordChecker);
            confirmInput?.addEventListener('input', updateGuardianPasswordChecker);
        },
        preConfirm: () => {
            const paymentProofFile = document.getElementById('guardian-new-registration-proof')?.files?.[0] || null;
            const idProofFile = document.getElementById('guardian-new-id-proof')?.files?.[0] || null;
            const paymentMethod = String(document.getElementById('guardian-new-payment-method')?.value || '').trim();
            const referenceNumber = String(document.getElementById('guardian-new-reference-number')?.value || '').trim();
            const password1 = String(document.getElementById('guardian-new-password')?.value || '');
            const password2 = String(document.getElementById('guardian-new-password-confirm')?.value || '');
            const data = {
                student_first_name: String(document.getElementById('guardian-new-first')?.value || '').trim(),
                student_last_name: String(document.getElementById('guardian-new-last')?.value || '').trim(),
                student_date_of_birth: String(document.getElementById('guardian-new-dob')?.value || '').trim(),
                password1,
                password2,
                branch_id: Number(String(document.getElementById('guardian-new-branch')?.value || branchId || 0).trim() || branchId || 0),
                payment_method: paymentMethod,
                reference_number: referenceNumber,
                registration_proof_file: paymentProofFile,
                age_verification_proof_file: idProofFile
            };

            if (!data.student_first_name || !data.student_last_name || !data.student_date_of_birth) {
                Swal.showValidationMessage('Please fill in all required student fields.');
                return false;
            }
            if (!data.branch_id) {
                Swal.showValidationMessage('Please choose a branch.');
                return false;
            }
            if (!data.payment_method) {
                Swal.showValidationMessage('Please select a payment method.');
                return false;
            }
            if (!data.reference_number) {
                Swal.showValidationMessage('Please enter the payment reference number.');
                return false;
            }
            if (!data.registration_proof_file) {
                Swal.showValidationMessage('Please upload proof of payment.');
                return false;
            }
            if (!data.age_verification_proof_file) {
                Swal.showValidationMessage('Please upload an ID proof.');
                return false;
            }
            if (!password1 || !password2) {
                Swal.showValidationMessage('Please fill in both password fields.');
                return false;
            }
            if (password1 !== password2) {
                Swal.showValidationMessage('Passwords do not match.');
                return false;
            }
            if (
                password1.length < 8 ||
                !/[A-Z]/.test(password1) ||
                !/[a-z]/.test(password1) ||
                !/[0-9]/.test(password1) ||
                !/[!@#$%^&*]/.test(password1)
            ) {
                Swal.showValidationMessage('Password does not meet the requirements.');
                return false;
            }
            return data;
        }
        });

    if (!result.isConfirmed) return;

    try {
        const formData = new FormData();
        formData.append('action', 'guardian-register-child');
        formData.append('guardian_email', guardianEmail);
        formData.append('student_first_name', result.value.student_first_name);
        formData.append('student_last_name', result.value.student_last_name);
        formData.append('student_date_of_birth', result.value.student_date_of_birth);
        formData.append('branch_id', String(result.value.branch_id || branchId || 0));
        formData.append('password', result.value.password1);
        formData.append('payment_method', result.value.payment_method);
        formData.append('reference_number', result.value.reference_number);
        if (result.value.registration_proof_file) {
            formData.append('registration_proof_file', result.value.registration_proof_file);
        }
        if (result.value.age_verification_proof_file) {
            formData.append('age_verification_proof_file', result.value.age_verification_proof_file);
        }

        const data = await postStudentPackageRequest(formData);
        if (!data.success) {
            throw new Error(data.error || 'Failed to register student.');
        }

        await Swal.fire({
            icon: 'success',
            title: 'Registration Submitted',
            html: `
                <div class="text-left text-sm leading-6">
                    <p>The student registration is now pending review.</p>
                    <p class="mt-2">The guardian will be notified once the academy accepts the registration.</p>
                    <p class="mt-2">After approval, the school will email you the Student ID / login for <strong>${escapeHtml(`${result.value.student_first_name || ''} ${result.value.student_last_name || ''}`.trim())}</strong>.</p>
                    <p class="mt-2 text-xs text-zinc-500">That email will include the student name as a reference so it is easier to distinguish if you manage more than one child.</p>
                </div>
            `,
            confirmButtonColor: '#b8860b'
        });

        if (document.getElementById('guardianStudentsList')) {
            await initGuardianStudentsPage();
        }
    } catch (error) {
        await Swal.fire({
            icon: 'error',
            title: 'Registration Failed',
            text: error?.response?.data?.error || error?.message || 'Unable to create the student.',
            confirmButtonColor: '#b8860b'
        });
    }
}

window.guardianAddChildMenu = guardianAddChildMenu;
window.guardianRegisterNewStudent = guardianRegisterNewStudent;

function bindGuardianStudentModalEvents() {
    const modal = document.getElementById('guardianStudentModal');
    if (modal && !modal.dataset.bound) {
        modal.dataset.bound = 'true';
        modal.addEventListener('click', (event) => {
            if (event.target === modal) closeGuardianStudentModal();
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') closeGuardianStudentModal();
        });
    }
}

async function initGuardianDashboardPage() {
    if (!checkGuardianAuth()) return;

    const user = Auth.getUser();
    bindGuardianPortalNav();
    applyGuardianPortalIdentity(user);

    const portal = await fetchGuardianPortalDataByEmail(user?.email || '');
    if (!portal?.success) {
        showMessage(portal?.error || 'Failed to load guardian dashboard.', 'error');
        return;
    }

    const guardian = getGuardianPrimaryGuardian(portal, user) || {};
    window.__guardianPortalBranchLabel = getGuardianPortalBranchLabel(portal);
    setGuardianPortalBranchContext(portal, []);
    applyGuardianPortalIdentity(user, portal);

    const students = Array.isArray(portal.students) ? portal.students : [];
    guardianPortalStudents = students;
    notifyFreezeRestoredForGuardianPortal(students);
    startGuardianFreezeRefreshWatcher();
    startGuardianSessionRefreshWatcher();

    const greetingName = `${guardian.first_name || ''}`.trim() || 'Guardian';
    setText('guardianDashboardGreeting', greetingName ? `Hello, ${greetingName}.` : '');

    let totalBalance = 0;
    let totalPaid = 0;
    let upcomingCount = 0;
    students.forEach((item) => {
        const metrics = getGuardianPaymentMetrics(item);
        totalBalance += metrics.totalBalance;
        totalPaid += metrics.totalPaid;
        upcomingCount += getGuardianSessionStatusMetrics(item).upcoming;
    });

    setText('guardianDashboardStudentCount', String(students.length));
    setText('guardianDashboardTotalBalance', formatCurrencyPHP(totalBalance));
    setText('guardianDashboardTotalPaid', formatCurrencyPHP(totalPaid));
    setText('guardianDashboardUpcomingCount', String(upcomingCount));

    setHtml('guardianDashboardAlerts', renderGuardianDashboardAlerts(students));
    setHtml('guardianDashboardUpcomingList', renderGuardianDashboardUpcomingList(students));
    setHtml('guardianDashboardBalanceList', renderGuardianDashboardBalanceList(students));

    await hydrateGuardianAttendance(students);
    bindGuardianStudentModalEvents();
}

async function initGuardianStudentsPage() {
    if (!checkGuardianAuth()) return;

    const user = Auth.getUser();
    bindGuardianPortalNav();
    applyGuardianPortalIdentity(user);

    const portal = await fetchGuardianPortalDataByEmail(user?.email || '');
    if (!portal?.success) {
        showMessage(portal?.error || 'Failed to load guardian portal.', 'error');
        return;
    }

    const primaryGuardian = getGuardianPrimaryGuardian(portal, user) || {};
    window.__guardianPortalBranchLabel = getGuardianPortalBranchLabel(portal);
    setGuardianPortalBranchContext(portal, portal.students || []);
    applyGuardianPortalIdentity(user, portal);
    setText('guardianName', `${primaryGuardian.first_name || ''} ${primaryGuardian.last_name || ''}`.trim() || (user?.username || 'Guardian'));
    setText('guardianEmail', primaryGuardian.email || user?.email || '—');
    setText('guardianPhone', primaryGuardian.phone || '—');

    const students = Array.isArray(portal.students) ? portal.students : [];
    guardianPortalStudents = students;
    notifyFreezeRestoredForGuardianPortal(students);
    startGuardianFreezeRefreshWatcher();
    startGuardianSessionRefreshWatcher();
    updateGuardianTotals(students);
    setHtml('guardianStudentsList', renderGuardianStudentsList(students));
    await hydrateGuardianAttendance(students);
    bindGuardianStudentModalEvents();
}

async function initGuardianPaymentsPage() {
    if (!checkGuardianAuth()) return;

    const user = Auth.getUser();
    bindGuardianPortalNav();
    applyGuardianPortalIdentity(user);

    const portal = await fetchGuardianPortalDataByEmail(user?.email || '');
    if (!portal?.success) {
        showMessage(portal?.error || 'Failed to load guardian payments.', 'error');
        return;
    }

    const primaryGuardian = getGuardianPrimaryGuardian(portal, user) || {};
    window.__guardianPortalBranchLabel = getGuardianPortalBranchLabel(portal);
    setGuardianPortalBranchContext(portal, portal.students || []);
    applyGuardianPortalIdentity(user, portal);
    const guardianName = `${primaryGuardian.first_name || ''} ${primaryGuardian.last_name || ''}`.trim() || (user?.username || 'Guardian');
    setText('guardianNameInline', guardianName);

    const students = Array.isArray(portal.students) ? portal.students : [];
    guardianPortalStudents = students;
    notifyFreezeRestoredForGuardianPortal(students);
    startGuardianFreezeRefreshWatcher();
    startGuardianSessionRefreshWatcher();
    updateGuardianPaymentTotals(students);
    setHtml('guardianPaymentsList', renderGuardianPaymentsList(students));
    await hydrateGuardianAttendance(students);
    bindGuardianStudentModalEvents();
}

async function initGuardianProfilePage() {
    if (!checkGuardianAuth()) return;

    const user = Auth.getUser();
    bindGuardianPortalNav();
    applyGuardianPortalIdentity(user);

    const portal = await fetchGuardianPortalDataByEmail(user?.email || '');
    if (!portal?.success) {
        showMessage(portal?.error || 'Failed to load guardian profile.', 'error');
        return;
    }

    const guardian = getGuardianPrimaryGuardian(portal, user) || {};
    const students = Array.isArray(portal.students) ? portal.students : [];
    const metrics = students.reduce((acc, item) => {
        const payment = getGuardianPaymentMetrics(item);
        acc.balance += payment.totalBalance;
        return acc;
    }, { balance: 0 });

    window.__guardianPortalBranchLabel = getGuardianPortalBranchLabel(portal);
    applyGuardianPortalIdentity(user, portal);
    notifyFreezeRestoredForGuardianPortal(students);
    startGuardianFreezeRefreshWatcher();
    startGuardianSessionRefreshWatcher();
    setText('guardianProfileHeading', `${guardian.first_name || ''} ${guardian.last_name || ''}`.trim() || 'Guardian Profile');
    setText('guardianProfileLinkedStudents', String(students.length));
    setText('guardianProfileBalance', formatCurrencyPHP(metrics.balance));

    const fieldMap = {
        guardianProfileGuardianId: guardian.guardian_id || '',
        guardianProfileUserId: user?.user_id || '',
        guardianProfileFirstName: guardian.first_name || '',
        guardianProfileLastName: guardian.last_name || '',
        guardianProfileEmail: guardian.email || user?.email || '',
        guardianProfilePhone: guardian.phone || '',
        guardianProfileRelationship: guardian.relationship_type || 'Legal Guardian',
        guardianProfileOccupation: guardian.occupation || '',
        guardianProfileAddress: guardian.address || ''
    };

    Object.entries(fieldMap).forEach(([id, value]) => {
        const el = document.getElementById(id);
        if (el) el.value = value;
    });

    const form = document.getElementById('guardianProfileForm');
    if (!form || form.dataset.bound === 'true') return;
    form.dataset.bound = 'true';

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const submitBtn = document.getElementById('guardianProfileSaveBtn');
        if (submitBtn) submitBtn.disabled = true;

        const payload = {
            guardian_id: document.getElementById('guardianProfileGuardianId')?.value || '',
            user_id: document.getElementById('guardianProfileUserId')?.value || '',
            first_name: document.getElementById('guardianProfileFirstName')?.value.trim() || '',
            last_name: document.getElementById('guardianProfileLastName')?.value.trim() || '',
            email: document.getElementById('guardianProfileEmail')?.value.trim() || '',
            phone: document.getElementById('guardianProfilePhone')?.value.trim() || '',
            relationship_type: document.getElementById('guardianProfileRelationship')?.value || '',
            occupation: document.getElementById('guardianProfileOccupation')?.value.trim() || '',
            address: document.getElementById('guardianProfileAddress')?.value.trim() || ''
        };

        try {
            const data = await updateGuardianProfileRequest(payload);
            if (data?.success) {
                const nextUser = {
                    ...(Auth.getUser() || {}),
                    username: `${payload.first_name} ${payload.last_name}`.trim() || payload.email,
                    first_name: payload.first_name,
                    last_name: payload.last_name,
                    email: payload.email,
                    phone: payload.phone
                };
                Auth.setUser(nextUser);
                window.__guardianPortalBranchLabel = getGuardianPortalBranchLabel(portal);
                setGuardianPortalBranchContext(portal, portal.students || []);
                applyGuardianPortalIdentity(nextUser, portal);
                setText('guardianProfileHeading', `${payload.first_name} ${payload.last_name}`.trim() || 'Guardian Profile');
                showMessage(data.message || 'Guardian profile updated.', 'success');
            } else {
                showMessage(data?.error || 'Failed to update guardian profile.', 'error');
            }
        } catch (error) {
            showMessage(error?.response?.data?.error || 'Network error while updating profile.', 'error');
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    });
}

async function initGuardianAbsencePage() {
    if (!checkGuardianAuth()) return;

    const user = Auth.getUser();
    bindGuardianPortalNav();
    applyGuardianPortalIdentity(user);

    const [portal, absenceData] = await Promise.all([
        fetchGuardianPortalDataByEmail(user?.email || ''),
        fetchGuardianAbsenceRequests(user?.email || '')
    ]);

    if (!portal?.success) {
        showMessage(portal?.error || 'Failed to load guardian absence page.', 'error');
        return;
    }

    const guardian = getGuardianPrimaryGuardian(portal, user) || {};
    const students = Array.isArray(portal.students) ? portal.students : [];
    guardianPortalStudents = students;
    window.__guardianPortalBranchLabel = getGuardianPortalBranchLabel(portal);
    setGuardianPortalBranchContext(portal, students);
    notifyFreezeRestoredForGuardianPortal(students);
    startGuardianFreezeRefreshWatcher();
    startGuardianSessionRefreshWatcher();
    applyGuardianPortalIdentity(user, portal);

    setText('guardianAbsenceName', `${guardian.first_name || ''} ${guardian.last_name || ''}`.trim() || 'Guardian');
    setText('guardianAbsenceStudentCount', String(students.length));

    const totalUpcoming = students.reduce((sum, item) => sum + getGuardianSessionStatusMetrics(item).upcoming, 0);
    setText('guardianAbsenceUpcomingCount', String(totalUpcoming));

    const requestRows = Array.isArray(absenceData?.requests) ? absenceData.requests : [];
    setText('guardianAbsencePendingCount', String(requestRows.filter((row) => String(row.status || '').toLowerCase() === 'pending').length));
    setHtml('guardianAbsenceRequestsList', renderGuardianAbsenceRequests(requestRows));

        const studentsList = document.getElementById('guardianStudentsList');
        if (studentsList) {
            studentsList.innerHTML = renderGuardianAbsenceStudentCards(students);
            studentsList.addEventListener('click', (event) => {
                const card = event.target.closest('.guardian-absence-card');
                if (!card) return;
                openAbsenceModal(card.dataset.studentId || '', card.dataset.studentName || '');
            });
        }

        const absenceModal = document.getElementById('absenceRequestModal');
        absenceModal?.addEventListener('click', (event) => {
            if (event.target === absenceModal) {
                closeAbsenceModal();
            }
        });
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                closeAbsenceModal();
            }
        });

        const dateInput = document.getElementById('guardianAbsenceSessionDate');
        if (dateInput && !dateInput.value) {
            dateInput.value = getManilaYmd();
        }

    const form = document.getElementById('guardianAbsenceForm');
    if (!form || form.dataset.bound === 'true') return;
    form.dataset.bound = 'true';

    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const submitBtn = document.getElementById('guardianAbsenceSubmitBtn');
        if (submitBtn) submitBtn.disabled = true;

        const payload = {
            guardian_email: Auth.getUser()?.email || '',
            guardian_user_id: Auth.getUser()?.user_id || '',
            student_id: document.getElementById('selectedStudentId')?.value || '',
            session_date: document.getElementById('guardianAbsenceSessionDate')?.value || '',
            reason: document.getElementById('guardianAbsenceReason')?.value || '',
            notes: document.getElementById('guardianAbsenceNotes')?.value.trim() || ''
        };

        try {
            const data = await submitGuardianAbsenceRequest(payload);
            if (data?.success) {
                showMessage(data.message || 'Absence request submitted.', 'success');
                form.reset();
                if (dateInput) dateInput.value = getManilaYmd();
                closeAbsenceModal();

                const refreshed = await fetchGuardianAbsenceRequests(Auth.getUser()?.email || '');
                const rows = Array.isArray(refreshed?.requests) ? refreshed.requests : [];
                setText('guardianAbsencePendingCount', String(rows.filter((row) => String(row.status || '').toLowerCase() === 'pending').length));
                setHtml('guardianAbsenceRequestsList', renderGuardianAbsenceRequests(rows));
            } else {
                showMessage(data?.error || 'Failed to submit absence request.', 'error');
            }
        } catch (error) {
            showMessage(error?.response?.data?.error || 'Network error while submitting absence request.', 'error');
        } finally {
            if (submitBtn) submitBtn.disabled = false;
        }
    });
}

let studentRequestAvailableInstruments = [];
const studentInstructorAvailabilityState = {
    student: null,
    candidates: [],
    availabilityRows: [],
    eligibleCandidates: [],
    selectedTeacherId: 0,
    selectedTeacherName: '',
    slots: [],
    reservedSlots: [],
    occupiedSlots: [],
    bookedSessions: [],
    month: '',
    selectedDate: '',
    selectedSlot: null,
    selectedSlots: [],
    sessionCount: 12,
    activeSlotIndex: -1,
    requestToken: 0,
    applySlot: null,
    requestController: null,
    slotCache: new Map()
};

function getStudentRequestSelectedTypeIds() {
    return Array.from(document.querySelectorAll('#studentRequestInstrumentContainer select.student-request-instrument-type'))
        .map(select => Number(select.value || 0))
        .filter(typeId => typeId > 0);
}

function isGeneralInstructorSpecialization(value) {
    const text = String(value || '').toLowerCase();
    return text.includes('general')
        || text.includes('all around')
        || text.includes('all-around')
        || text.includes('all instruments');
}

function getInstructorSpecializationTypeIds(candidate) {
    const raw = candidate?.specialization_type_ids;
    const values = Array.isArray(raw) ? raw : String(raw || '').split(',');
    return values.map(value => Number(value || 0)).filter(value => value > 0);
}

function getEligibleStudentRequestInstructors(candidates, availabilityRows, selectedTypeIds) {
    const requestedTypes = new Set((Array.isArray(selectedTypeIds) ? selectedTypeIds : []).map(Number));
    if (!requestedTypes.size) return [];
    const availableTeacherIds = new Set((Array.isArray(availabilityRows) ? availabilityRows : [])
        .map(row => Number(row.teacher_id || 0))
        .filter(id => id > 0));

    return (Array.isArray(candidates) ? candidates : []).filter(candidate => {
        const teacherId = Number(candidate.teacher_id || 0);
        if (!teacherId || !availableTeacherIds.has(teacherId)) return false;
        if (isGeneralInstructorSpecialization(candidate.specialization)) return true;
        return getInstructorSpecializationTypeIds(candidate).some(typeId => requestedTypes.has(typeId));
    });
}

function ensureStudentInstructorAvailabilityModal() {
    if (document.getElementById('studentInstructorAvailabilityModal')) return;
    document.body.insertAdjacentHTML('beforeend', `
        <div id="studentInstructorAvailabilityModal" class="fixed inset-0 z-[100] hidden bg-black/65 p-3 backdrop-blur-sm sm:p-5" aria-hidden="true">
            <div class="mx-auto flex h-full max-h-[900px] w-full max-w-5xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-zinc-950">
                <div class="flex items-center justify-between gap-4 border-b border-zinc-200 px-4 py-4 dark:border-white/10 sm:px-6">
                    <div>
                        <div class="text-[10px] font-bold uppercase tracking-[.2em] text-emerald-600">Instructor availability</div>
                        <h3 class="mt-1 text-lg font-black text-zinc-900 dark:text-white sm:text-xl">Choose an available instructor</h3>
                        <p id="studentInstructorAvailabilityContext" class="mt-1 text-xs text-zinc-500 dark:text-zinc-400"></p>
                    </div>
                    <button type="button" id="closeStudentInstructorAvailabilityBtn" class="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-zinc-200 text-zinc-500 hover:bg-zinc-100 dark:border-white/10 dark:hover:bg-white/10" aria-label="Close instructor availability">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div class="grid min-h-0 flex-1 grid-cols-1 md:grid-cols-[260px_minmax(0,1fr)]">
                    <aside class="min-h-0 overflow-y-auto border-b border-zinc-200 bg-zinc-50 p-4 dark:border-white/10 dark:bg-white/5 md:border-b-0 md:border-r">
                        <label for="studentAvailableInstructorSelect" class="mb-2 block text-xs font-bold uppercase tracking-wider text-zinc-500">Available instructor</label>
                        <select id="studentAvailableInstructorSelect" class="w-full rounded-xl border border-zinc-200 bg-white px-3 py-3 text-sm font-bold text-zinc-900 focus:border-emerald-500 focus:outline-none dark:border-white/10 dark:bg-zinc-900 dark:text-white"><option value="">Select instructor...</option></select>
                        <div class="mt-5 mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">Preferred class days</div>
                        <div id="studentSelectedAvailabilitySlots" class="space-y-2"></div>
                        <button type="button" id="studentAddAvailabilityDayBtn" class="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-emerald-300 bg-emerald-50 px-3 py-2.5 text-xs font-bold text-emerald-700 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-50 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300"><i class="fas fa-plus"></i>Add another day</button>
                    </aside>
                    <section class="min-h-0 overflow-y-auto p-4 sm:p-6">
                        <div class="mb-4 flex items-center justify-between gap-3">
                            <button type="button" id="studentInstructorCalendarPrev" class="rounded-lg border border-zinc-200 px-3 py-2 text-xs font-bold text-zinc-600 hover:bg-zinc-50 dark:border-white/10 dark:text-zinc-300"><i class="fas fa-chevron-left mr-1"></i>Prev</button>
                            <div id="studentInstructorCalendarMonth" class="text-sm font-black text-zinc-900 dark:text-white"></div>
                            <button type="button" id="studentInstructorCalendarNext" class="rounded-lg border border-zinc-200 px-3 py-2 text-xs font-bold text-zinc-600 hover:bg-zinc-50 dark:border-white/10 dark:text-zinc-300">Next<i class="fas fa-chevron-right ml-1"></i></button>
                        </div>
                        <div class="grid grid-cols-7 gap-1.5 text-center text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                            <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
                        </div>
                        <div id="studentInstructorCalendarGrid" class="mt-2 grid grid-cols-7 gap-1.5"></div>
                        <div id="studentInstructorCalendarStatus" class="mt-4 rounded-xl border border-zinc-200 bg-zinc-50 px-4 py-3 text-sm text-zinc-500 dark:border-white/10 dark:bg-white/5 dark:text-zinc-400" aria-live="polite">Select an instructor to display available dates.</div>
                        <div id="studentInstructorTimeSlots" class="mt-4"></div>
                    </section>
                </div>
                <div class="flex flex-col gap-3 border-t border-zinc-200 px-4 py-3 dark:border-white/10 sm:flex-row sm:items-center sm:justify-between sm:px-6">
                    <div class="text-xs text-zinc-500 dark:text-zinc-400">The desk will make the final instructor and room confirmation.</div>
                    <div class="flex gap-2"><button type="button" id="cancelStudentInstructorScheduleBtn" class="rounded-xl border border-zinc-200 px-4 py-2 text-sm font-bold text-zinc-600 dark:border-white/10 dark:text-zinc-300">Cancel</button><button type="button" id="confirmStudentInstructorScheduleBtn" class="rounded-xl bg-emerald-600 px-5 py-2 text-sm font-bold text-white hover:bg-emerald-700">Use Selected Schedule</button></div>
                </div>
            </div>
        </div>
    `);

    const modal = document.getElementById('studentInstructorAvailabilityModal');
    document.getElementById('closeStudentInstructorAvailabilityBtn')?.addEventListener('click', closeStudentInstructorAvailabilityModal);
    modal?.addEventListener('click', event => {
        if (event.target === modal) closeStudentInstructorAvailabilityModal();
    });
    document.getElementById('studentAvailableInstructorSelect')?.addEventListener('change', event => {
        void selectStudentAvailableInstructor(Number(event.target.value || 0));
    });
    document.getElementById('studentAddAvailabilityDayBtn')?.addEventListener('click', addAnotherStudentAvailabilityDay);
    document.getElementById('studentSelectedAvailabilitySlots')?.addEventListener('click', event => {
        const removeButton = event.target.closest('[data-remove-student-slot]');
        if (removeButton) {
            removeStudentAvailabilitySlot(Number(removeButton.dataset.removeStudentSlot));
            return;
        }
        const datesButton = event.target.closest('[data-view-student-slot-dates]');
        if (datesButton) {
            openStudentRecurringDatesModal(Number(datesButton.dataset.viewStudentSlotDates));
            return;
        }
        const editButton = event.target.closest('[data-edit-student-slot]');
        if (editButton) editStudentAvailabilitySlot(Number(editButton.dataset.editStudentSlot));
    });
    document.getElementById('cancelStudentInstructorScheduleBtn')?.addEventListener('click', closeStudentInstructorAvailabilityModal);
    document.getElementById('confirmStudentInstructorScheduleBtn')?.addEventListener('click', confirmStudentInstructorSchedule);
    document.getElementById('studentInstructorCalendarGrid')?.addEventListener('click', event => {
        const button = event.target.closest('[data-student-availability-date]');
        if (button && !button.disabled) selectStudentInstructorAvailabilityDate(button.dataset.studentAvailabilityDate || '');
    });
    document.getElementById('studentInstructorTimeSlots')?.addEventListener('click', event => {
        const button = event.target.closest('[data-student-availability-slot]');
        if (!button) return;
        const slot = studentInstructorAvailabilityState.slots[Number(button.dataset.studentAvailabilitySlot)] || null;
        if (slot && typeof studentInstructorAvailabilityState.applySlot === 'function') {
            studentInstructorAvailabilityState.applySlot(slot, studentInstructorAvailabilityState.selectedTeacherName);
        }
    });
    document.getElementById('studentInstructorCalendarPrev')?.addEventListener('click', () => shiftStudentInstructorCalendar(-1));
    document.getElementById('studentInstructorCalendarNext')?.addEventListener('click', () => shiftStudentInstructorCalendar(1));
}

function setStudentInstructorAvailabilityModalOpen(open) {
    const modal = document.getElementById('studentInstructorAvailabilityModal');
    if (!modal) return;
    modal.classList.toggle('hidden', !open);
    modal.setAttribute('aria-hidden', open ? 'false' : 'true');
}

function closeStudentInstructorAvailabilityModal() {
    studentInstructorAvailabilityState.requestToken += 1;
    if (studentInstructorAvailabilityState.requestController) {
        studentInstructorAvailabilityState.requestController.abort();
        studentInstructorAvailabilityState.requestController = null;
    }
    setStudentInstructorAvailabilityModalOpen(false);
}

function getStudentInstructorMonthLabel(monthKey) {
    const [year, month] = String(monthKey || '').split('-').map(Number);
    const date = new Date(Date.UTC(year, month - 1, 15, 12));
    return Number.isNaN(date.getTime()) ? '' : date.toLocaleDateString(undefined, { month: 'long', year: 'numeric', timeZone: FAS_TIME_ZONE });
}

function shiftStudentInstructorCalendar(delta) {
    const [year, month] = String(studentInstructorAvailabilityState.month || '').split('-').map(Number);
    const manilaNow = getManilaDateParts();
    const date = new Date(year || manilaNow.year, (month || manilaNow.month) - 1, 1);
    date.setMonth(date.getMonth() + delta);
    const nextMonth = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
    const currentMonth = getManilaMonthKey();
    if (nextMonth < currentMonth) return;
    studentInstructorAvailabilityState.month = nextMonth;
    renderStudentInstructorAvailabilityCalendar();
    if (studentInstructorAvailabilityState.selectedTeacherId) {
        void loadStudentInstructorAvailabilityMonth();
    }
}

function renderStudentAvailableInstructorList() {
    const select = document.getElementById('studentAvailableInstructorSelect');
    if (!select) return;
    const rows = studentInstructorAvailabilityState.eligibleCandidates;
    select.innerHTML = `<option value="">${rows.length ? 'Select instructor...' : 'No matching instructors available'}</option>` + rows.map(candidate => `<option value="${Number(candidate.teacher_id || 0)}">${escapeHtml(candidate.teacher_name || 'Instructor')}</option>`).join('');
    select.value = studentInstructorAvailabilityState.selectedTeacherId ? String(studentInstructorAvailabilityState.selectedTeacherId) : '';
    renderStudentSelectedAvailabilitySlots();
}

function renderStudentSelectedAvailabilitySlots() {
    const container = document.getElementById('studentSelectedAvailabilitySlots');
    const addButton = document.getElementById('studentAddAvailabilityDayBtn');
    if (!container) return;
    const state = studentInstructorAvailabilityState;
    if (!state.selectedSlots.length) {
        container.innerHTML = '<div class="rounded-xl border border-dashed border-zinc-300 px-3 py-4 text-center text-xs text-zinc-500 dark:border-white/10">Choose a green date and time.</div>';
    } else {
        const projections = buildProjectedRecurringDates(state.selectedSlots, state.sessionCount);
        const recurringDays = state.selectedSlots.map(slot => `Every ${slot.day_of_week || getDayOfWeekFromDate(slot.session_date)}`);
        container.innerHTML = `<div class="rounded-lg bg-emerald-50 px-3 py-2 text-[11px] font-bold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">Repeats weekly: ${escapeHtml(recurringDays.join(', '))}</div>${state.selectedSlots.map((slot, index) => `<div class="rounded-xl border ${index === state.activeSlotIndex ? 'border-emerald-400 bg-emerald-50 dark:bg-emerald-500/10' : 'border-zinc-200 bg-white dark:border-white/10 dark:bg-zinc-900'} p-3"><div class="flex items-start justify-between gap-2"><button type="button" data-view-student-slot-dates="${index}" class="min-w-0 flex-1 text-left"><span class="block text-xs font-black text-zinc-900 dark:text-white">${escapeHtml(slot.day_of_week || getDayOfWeekFromDate(slot.session_date))}</span><span class="mt-1 block text-[11px] text-zinc-500">${escapeHtml(`${formatTime12Hour(slot.start_time)} - ${formatTime12Hour(slot.end_time)}`)}</span><span class="mt-1 block text-[10px] font-bold text-emerald-700 dark:text-emerald-400"><i class="fas fa-calendar-days mr-1"></i>View ${projections[index]?.length || 0} lesson dates</span></button><div class="flex gap-2"><button type="button" data-edit-student-slot="${index}" class="text-zinc-400 hover:text-blue-600" aria-label="Edit preferred day"><i class="fas fa-pen"></i></button><button type="button" data-remove-student-slot="${index}" class="text-zinc-400 hover:text-red-500" aria-label="Remove preferred day"><i class="fas fa-times"></i></button></div></div></div>`).join('')}`;
    }
    if (addButton) addButton.disabled = !state.selectedTeacherId || !state.selectedSlots.length || state.selectedSlots.length >= 7 || state.activeSlotIndex === -1;
}

function buildProjectedRecurringDates(slots, sessionCount = 12) {
    const rows = Array.isArray(slots) ? slots : [];
    const projections = rows.map(() => []);
    const queue = rows.map((slot, index) => ({
        index,
        nextDate: String(slot.session_date || '').slice(0, 10),
        startTime: String(slot.start_time || '').slice(0, 5)
    })).filter(item => /^\d{4}-\d{2}-\d{2}$/.test(item.nextDate));
    const total = Math.max(1, Math.min(100, Number(sessionCount || 12)));
    for (let session = 0; session < total && queue.length; session += 1) {
        queue.sort((a, b) => a.nextDate.localeCompare(b.nextDate) || a.startTime.localeCompare(b.startTime) || a.index - b.index);
        const current = queue[0];
        projections[current.index].push(current.nextDate);
        const next = new Date(`${current.nextDate}T00:00:00`);
        next.setDate(next.getDate() + 7);
        current.nextDate = `${next.getFullYear()}-${String(next.getMonth() + 1).padStart(2, '0')}-${String(next.getDate()).padStart(2, '0')}`;
    }
    return projections;
}

function openStudentRecurringDatesModal(index) {
    const state = studentInstructorAvailabilityState;
    const slot = state.selectedSlots[index];
    if (!slot || typeof Swal === 'undefined') return;
    const dates = buildProjectedRecurringDates(state.selectedSlots, state.sessionCount)[index] || [];
    const day = slot.day_of_week || getDayOfWeekFromDate(slot.session_date);
    Swal.fire({
        title: `Every ${day}`,
        html: `<div class="text-left"><div class="mb-3 rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm text-emerald-800"><strong>${escapeHtml(`${formatTime12Hour(slot.start_time)} - ${formatTime12Hour(slot.end_time)}`)}</strong><div class="mt-1 text-xs">Projected dates within the selected package schedule.</div></div><div class="max-h-72 space-y-2 overflow-y-auto">${dates.map((date, dateIndex) => `<div class="flex items-center gap-3 rounded-lg border border-zinc-200 px-3 py-2"><span class="grid h-7 w-7 place-items-center rounded-full bg-emerald-100 text-xs font-black text-emerald-700">${dateIndex + 1}</span><span class="text-sm font-semibold text-zinc-800">${escapeHtml(formatDateLong(date) || date)}</span></div>`).join('') || '<div class="text-sm text-zinc-500">No projected dates yet.</div>'}</div></div>`,
        confirmButtonText: 'Close',
        confirmButtonColor: '#059669',
        width: '32rem'
    });
}

window.openStudentRecurringDatesModal = openStudentRecurringDatesModal;

function addAnotherStudentAvailabilityDay() {
    const state = studentInstructorAvailabilityState;
    if (!state.selectedTeacherId || !state.selectedSlots.length || state.selectedSlots.length >= 7) return;
    state.activeSlotIndex = -1;
    state.selectedDate = '';
    renderStudentSelectedAvailabilitySlots();
    renderStudentInstructorAvailabilityCalendar();
}

function editStudentAvailabilitySlot(index) {
    const state = studentInstructorAvailabilityState;
    const slot = state.selectedSlots[index];
    if (!slot) return;
    state.activeSlotIndex = index;
    state.selectedDate = slot.session_date;
    state.month = String(slot.session_date || '').slice(0, 7) || state.month;
    renderStudentSelectedAvailabilitySlots();
    renderStudentInstructorAvailabilityCalendar();
    void loadStudentInstructorAvailabilityMonth();
}

function removeStudentAvailabilitySlot(index) {
    const state = studentInstructorAvailabilityState;
    state.selectedSlots.splice(index, 1);
    state.activeSlotIndex = state.selectedSlots.length ? Math.min(index, state.selectedSlots.length - 1) : -1;
    state.selectedDate = state.activeSlotIndex >= 0 ? state.selectedSlots[state.activeSlotIndex].session_date : '';
    renderStudentSelectedAvailabilitySlots();
    renderStudentInstructorAvailabilityCalendar();
}

function confirmStudentInstructorSchedule() {
    const state = studentInstructorAvailabilityState;
    if (!state.selectedTeacherId || !state.selectedSlots.length) {
        showMessage('Select an instructor and at least one available class day.', 'error');
        return;
    }
    if (typeof state.confirmSlots === 'function') state.confirmSlots(state.selectedSlots.slice(), state.selectedTeacherName);
    closeStudentInstructorAvailabilityModal();
}

function renderStudentInstructorAvailabilityCalendar(statusMessage = '') {
    const grid = document.getElementById('studentInstructorCalendarGrid');
    const label = document.getElementById('studentInstructorCalendarMonth');
    const status = document.getElementById('studentInstructorCalendarStatus');
    if (!grid || !label || !status) return;
    const monthKey = studentInstructorAvailabilityState.month || getManilaMonthKey();
    studentInstructorAvailabilityState.month = monthKey;
    label.textContent = getStudentInstructorMonthLabel(monthKey);
    const prevButton = document.getElementById('studentInstructorCalendarPrev');
    if (prevButton) {
        const manilaMonth = getManilaMonthKey();
        prevButton.disabled = monthKey <= manilaMonth;
        prevButton.classList.toggle('opacity-40', prevButton.disabled);
        prevButton.classList.toggle('cursor-not-allowed', prevButton.disabled);
    }
    const [year, month] = monthKey.split('-').map(Number);
    const first = new Date(year, month - 1, 1);
    const daysInMonth = new Date(year, month, 0).getDate();
    const grouped = studentInstructorAvailabilityState.slots.reduce((result, slot, index) => {
        const key = String(slot.session_date || '');
        if (!result[key]) result[key] = [];
        result[key].push({ slot, index });
        return result;
    }, {});
    const state = studentInstructorAvailabilityState;
    const studentId = Number(state.student?.student_id || 0);
    const ownProjectedDates = new Set(buildProjectedRecurringDates(state.selectedSlots, state.sessionCount).flat());
    const ownReservedSlots = state.reservedSlots.filter(slot => studentId > 0 && Number(slot.student_id || 0) === studentId);
    const otherReservedDates = new Set(state.reservedSlots
        .filter(slot => !studentId || Number(slot.student_id || 0) !== studentId)
        .map(slot => String(slot.session_date || '')));
    const ownBookedKeys = new Set(state.bookedSessions.map(slot => `${String(slot.session_date || '')}|${String(slot.start_time || '')}|${String(slot.end_time || '')}`));
    const ownBookedDates = new Set(state.bookedSessions.map(slot => String(slot.session_date || '')));
    const ownReservedDates = new Set(ownReservedSlots.map(slot => String(slot.session_date || '')));
    const occupiedDates = new Set(state.occupiedSlots
        .filter(slot => !ownBookedKeys.has(`${String(slot.session_date || '')}|${String(slot.start_time || '')}|${String(slot.end_time || '')}`))
        .map(slot => String(slot.session_date || '')));
    const todayKey = getManilaYmd();
    let html = Array.from({ length: first.getDay() }, () => '<div class="h-14"></div>').join('');
    for (let day = 1; day <= daysInMonth; day += 1) {
        const dateKey = `${year}-${String(month).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const available = (grouped[dateKey] || []).length;
        const ownRequest = ownProjectedDates.has(dateKey) || ownReservedDates.has(dateKey) || ownBookedDates.has(dateKey);
        const reservedByOthers = otherReservedDates.has(dateKey);
        const occupied = occupiedDates.has(dateKey);
        const selected = dateKey === studentInstructorAvailabilityState.selectedDate;
        const dateDay = getDayOfWeekFromDate(dateKey);
        const usedByAnotherSlot = studentInstructorAvailabilityState.selectedSlots.some((slot, index) => {
            if (index === studentInstructorAvailabilityState.activeSlotIndex) return false;
            return (slot.day_of_week || getDayOfWeekFromDate(slot.session_date)) === dateDay;
        });
        const disabled = !studentInstructorAvailabilityState.selectedTeacherId || !available || dateKey < todayKey || usedByAnotherSlot;
        const colorClass = ownRequest
            ? `border-amber-400 bg-amber-100 text-amber-900 dark:border-amber-500/40 dark:bg-amber-500/15 ${available && !disabled ? 'hover:bg-amber-200' : 'cursor-not-allowed'}`
            : available && !disabled
            ? (selected ? 'border-gold-500 bg-amber-50 ring-1 ring-gold-500/30 dark:bg-gold-500/10' : 'border-emerald-300 bg-emerald-50 hover:bg-emerald-100 dark:border-emerald-500/30 dark:bg-emerald-500/10')
            : occupied || reservedByOthers ? 'cursor-not-allowed border-red-300 bg-red-100 text-red-700 dark:border-red-500/30 dark:bg-red-500/10' : 'cursor-not-allowed border-zinc-200 bg-zinc-100 text-zinc-400 dark:border-white/5 dark:bg-white/[.02] dark:text-zinc-700';
        html += `<button type="button" data-student-availability-date="${dateKey}" ${disabled ? 'disabled' : ''} class="h-14 rounded-lg border p-1.5 text-left transition ${colorClass}">
            <div class="flex items-start justify-between gap-1"><span class="text-sm font-bold ${available && !disabled ? 'text-zinc-900 dark:text-white' : ''}">${day}</span>${available && !disabled ? `<span class="rounded-full bg-emerald-600 px-1.5 py-0.5 text-[9px] font-bold text-white">${available}</span>` : ''}</div>
            ${ownRequest ? `<div class="mt-1 text-[9px] font-bold text-amber-800">${ownBookedDates.has(dateKey) ? 'Your session' : 'Your request'}</div>` : available && !disabled ? '<div class="mt-1 text-[9px] font-bold text-emerald-700 dark:text-emerald-400">Available</div>' : reservedByOthers ? '<div class="mt-1 text-[9px] font-bold text-red-700">Reserved by others</div>' : occupied ? '<div class="mt-1 text-[9px] font-bold text-red-700">Occupied by others</div>' : '<div class="mt-1 text-[9px] font-bold text-zinc-500">Unavailable</div>'}
        </button>`;
    }
    grid.innerHTML = html;
    if (statusMessage) status.innerHTML = statusMessage;
    else if (!studentInstructorAvailabilityState.selectedTeacherId) status.textContent = 'Select an instructor to display available dates.';
    else if (!studentInstructorAvailabilityState.slots.length && !ownProjectedDates.size && !ownReservedDates.size && !ownBookedDates.size) status.textContent = 'This instructor has no open one-hour slots in the current scheduling window.';
    else status.textContent = 'Green: available · Yellow: your 12-session request/schedule · Red: occupied or reserved by others · Gray: unavailable.';
    const inlineTimes = document.getElementById('studentInstructorTimeSlots');
    if (inlineTimes) inlineTimes.innerHTML = '';
}

function renderStudentInstructorTimeSlots(grouped = null) {
    const container = document.getElementById('studentInstructorTimeSlots');
    if (!container) return;
    const dateKey = studentInstructorAvailabilityState.selectedDate;
    const rows = grouped?.[dateKey] || studentInstructorAvailabilityState.slots
        .map((slot, index) => ({ slot, index }))
        .filter(item => String(item.slot.session_date || '') === dateKey);
    if (!dateKey || !rows.length) {
        container.innerHTML = '';
        return;
    }
    container.innerHTML = `<div class="mb-2 text-xs font-bold uppercase tracking-wider text-zinc-500">Available times for ${escapeHtml(formatDateLong(dateKey) || dateKey)}</div><div class="grid grid-cols-1 gap-2 sm:grid-cols-2">${rows.map(item => `<button type="button" data-student-availability-slot="${item.index}" class="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-left transition hover:border-emerald-400 hover:bg-emerald-100 dark:border-emerald-500/30 dark:bg-emerald-500/10"><span class="block font-bold text-emerald-800 dark:text-emerald-300">${escapeHtml(`${formatTime12Hour(item.slot.start_time)} - ${formatTime12Hour(item.slot.end_time)}`)}</span><span class="mt-1 block text-xs text-zinc-500 dark:text-zinc-400">Use this preferred time</span></button>`).join('')}</div>`;
}

function selectStudentInstructorAvailabilityDate(dateKey) {
    studentInstructorAvailabilityState.selectedDate = String(dateKey || '');
    renderStudentInstructorAvailabilityCalendar();
    openStudentInstructorTimePickerModal(dateKey);
}

function openStudentInstructorTimePickerModal(dateKey) {
    const normalizedDate = String(dateKey || '').trim();
    if (!normalizedDate || typeof Swal === 'undefined') return;
    const rows = studentInstructorAvailabilityState.slots
        .filter(slot => String(slot.session_date || '') === normalizedDate)
        .sort((a, b) => String(a.start_time || '').localeCompare(String(b.start_time || '')));
    const studentId = Number(studentInstructorAvailabilityState.student?.student_id || 0);
    const ownReservedRows = studentInstructorAvailabilityState.reservedSlots.filter(slot => String(slot.session_date || '') === normalizedDate && studentId > 0 && Number(slot.student_id || 0) === studentId);
    const reservedByOthersRows = studentInstructorAvailabilityState.reservedSlots.filter(slot => String(slot.session_date || '') === normalizedDate && (!studentId || Number(slot.student_id || 0) !== studentId));
    const ownBookedRows = studentInstructorAvailabilityState.bookedSessions.filter(slot => String(slot.session_date || '') === normalizedDate);
    const ownBookedKeys = new Set(ownBookedRows.map(slot => `${String(slot.start_time || '')}|${String(slot.end_time || '')}`));
    const occupiedRows = studentInstructorAvailabilityState.occupiedSlots.filter(slot => String(slot.session_date || '') === normalizedDate && !ownBookedKeys.has(`${String(slot.start_time || '')}|${String(slot.end_time || '')}`));
    if (!rows.length) return;
    Swal.fire({
        title: formatDateLong(normalizedDate) || normalizedDate,
        html: `<div class="mb-4 text-sm text-zinc-500">Green: available · Yellow: yours · Red: occupied/reserved by others</div><div class="grid grid-cols-1 gap-2 text-left sm:grid-cols-2">${rows.map((slot, index) => `<button type="button" class="student-time-picker-option rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-left transition hover:border-emerald-400 hover:bg-emerald-100" data-slot-index="${index}"><div class="font-black text-emerald-800">${escapeHtml(`${formatTime12Hour(slot.start_time)} - ${formatTime12Hour(slot.end_time)}`)}</div><div class="mt-1 text-xs text-zinc-500">Select this preferred time</div></button>`).join('')}${ownReservedRows.map(slot => `<div class="rounded-xl border border-amber-300 bg-amber-100 px-4 py-3"><div class="font-black text-amber-900">${escapeHtml(`${formatTime12Hour(slot.start_time)} - ${formatTime12Hour(slot.end_time)}`)}</div><div class="mt-1 text-xs font-bold text-amber-700">Your pending request</div></div>`).join('')}${ownBookedRows.map(slot => `<div class="rounded-xl border border-amber-300 bg-amber-100 px-4 py-3"><div class="font-black text-amber-900">${escapeHtml(`${formatTime12Hour(slot.start_time)} - ${formatTime12Hour(slot.end_time)}`)}</div><div class="mt-1 text-xs font-bold text-amber-700">Your scheduled session</div></div>`).join('')}${reservedByOthersRows.map(slot => `<div class="rounded-xl border border-red-300 bg-red-100 px-4 py-3"><div class="font-black text-red-900">${escapeHtml(`${formatTime12Hour(slot.start_time)} - ${formatTime12Hour(slot.end_time)}`)}</div><div class="mt-1 text-xs font-bold text-red-700">Reserved by another student</div></div>`).join('')}${occupiedRows.map(slot => `<div class="rounded-xl border border-red-300 bg-red-100 px-4 py-3"><div class="font-black text-red-900">${escapeHtml(`${formatTime12Hour(slot.start_time)} - ${formatTime12Hour(slot.end_time)}`)}</div><div class="mt-1 text-xs font-bold text-red-700">Occupied by another student</div></div>`).join('')}</div>`,
        showConfirmButton: false,
        showCloseButton: true,
        width: '42rem',
        customClass: { popup: 'rounded-3xl', htmlContainer: 'm-0', title: 'text-lg font-bold' },
        didOpen: () => {
            Swal.getPopup()?.querySelectorAll('.student-time-picker-option').forEach(button => {
                button.addEventListener('click', () => {
                    const slot = rows[Number(button.dataset.slotIndex)];
                    if (slot && typeof studentInstructorAvailabilityState.applySlot === 'function') {
                        studentInstructorAvailabilityState.applySlot(slot, studentInstructorAvailabilityState.selectedTeacherName);
                    }
                    Swal.close();
                });
            });
        }
    });
}

async function selectStudentAvailableInstructor(teacherId) {
    const candidate = studentInstructorAvailabilityState.eligibleCandidates.find(row => Number(row.teacher_id) === Number(teacherId));
    if (!candidate) return;
    const previousTeacherId = Number(studentInstructorAvailabilityState.selectedTeacherId || 0);
    studentInstructorAvailabilityState.selectedTeacherId = Number(teacherId);
    studentInstructorAvailabilityState.selectedTeacherName = String(candidate.teacher_name || 'Instructor');
    if (previousTeacherId !== Number(teacherId)) {
        studentInstructorAvailabilityState.selectedSlots = [];
        studentInstructorAvailabilityState.activeSlotIndex = -1;
    }
    studentInstructorAvailabilityState.slots = [];
    studentInstructorAvailabilityState.reservedSlots = [];
    studentInstructorAvailabilityState.occupiedSlots = [];
    studentInstructorAvailabilityState.bookedSessions = [];
    studentInstructorAvailabilityState.selectedDate = '';
    renderStudentAvailableInstructorList();
    await loadStudentInstructorAvailabilityMonth();
}

async function loadStudentInstructorAvailabilityMonth() {
    const state = studentInstructorAvailabilityState;
    const teacherId = Number(state.selectedTeacherId || 0);
    if (!teacherId || !state.month) return;
    const [year, month] = state.month.split('-').map(Number);
    const monthStart = `${year}-${String(month).padStart(2, '0')}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const monthEnd = `${year}-${String(month).padStart(2, '0')}-${String(lastDay).padStart(2, '0')}`;
    const branchId = Number(state.student?.branch_id || 0);
    const studentId = Number(state.student?.student_id || 0);
    const cacheKey = `${teacherId}|${branchId}|${studentId}|${state.month}`;
    const cached = state.slotCache.get(cacheKey);
    if (cached && (Date.now() - Number(cached.savedAt || 0)) < 60000) {
        state.slots = Array.isArray(cached.slots) ? cached.slots : [];
        state.reservedSlots = Array.isArray(cached.reservedSlots) ? cached.reservedSlots : [];
        state.occupiedSlots = Array.isArray(cached.occupiedSlots) ? cached.occupiedSlots : [];
        state.bookedSessions = Array.isArray(cached.bookedSessions) ? cached.bookedSessions : [];
        renderStudentInstructorAvailabilityCalendar();
        return;
    }

    if (state.requestController) state.requestController.abort();
    state.requestController = typeof AbortController !== 'undefined' ? new AbortController() : null;
    state.slots = [];
    state.reservedSlots = [];
    state.occupiedSlots = [];
    state.bookedSessions = [];
    renderStudentInstructorAvailabilityCalendar(`<i class="fas fa-spinner fa-spin mr-2 text-emerald-600"></i>Loading ${escapeHtml(state.selectedTeacherName)}'s available dates...`);
    const token = ++state.requestToken;
    try {
        const params = new URLSearchParams({
            action: 'get-teacher-available-slots',
            teacher_id: String(teacherId),
            branch_id: String(branchId),
            student_id: String(studentId),
            start_date: monthStart,
            end_date: monthEnd
        });
        const response = await axios.get(`${baseApiUrl}/students.php?${params.toString()}`, {
            timeout: 15000,
            signal: state.requestController?.signal
        });
        if (token !== state.requestToken || teacherId !== Number(state.selectedTeacherId) || state.month !== `${year}-${String(month).padStart(2, '0')}`) return;
        state.slots = response.data?.success && Array.isArray(response.data.slots) ? response.data.slots : [];
        state.reservedSlots = response.data?.success && Array.isArray(response.data.reserved_slots) ? response.data.reserved_slots : [];
        state.occupiedSlots = response.data?.success && Array.isArray(response.data.occupied_slots) ? response.data.occupied_slots : [];
        state.bookedSessions = response.data?.success && Array.isArray(response.data.booked_sessions) ? response.data.booked_sessions : [];
        state.slotCache.set(cacheKey, { savedAt: Date.now(), slots: state.slots.slice(), reservedSlots: state.reservedSlots.slice(), occupiedSlots: state.occupiedSlots.slice(), bookedSessions: state.bookedSessions.slice() });
        renderStudentInstructorAvailabilityCalendar();
    } catch (error) {
        if (token !== state.requestToken || error?.code === 'ERR_CANCELED' || error?.name === 'CanceledError') return;
        state.slots = [];
        state.reservedSlots = [];
        state.occupiedSlots = [];
        state.bookedSessions = [];
        renderStudentInstructorAvailabilityCalendar('<i class="fas fa-triangle-exclamation mr-2 text-red-500"></i>Unable to load this instructor’s availability. Please try again.');
    } finally {
        if (token === state.requestToken) state.requestController = null;
    }
}

function openStudentAvailableInstructors() {
    const selectedTypeIds = getStudentRequestSelectedTypeIds();
    if (!selectedTypeIds.length) {
        showMessage('Choose an instrument type first.', 'error');
        return;
    }
    ensureStudentInstructorAvailabilityModal();
    const state = studentInstructorAvailabilityState;
    state.eligibleCandidates = getEligibleStudentRequestInstructors(state.candidates, state.availabilityRows, selectedTypeIds);
    const savedTeacherId = Number(state.selectedSlots[0]?.teacher_id || state.selectedTeacherId || 0);
    const savedTeacher = state.eligibleCandidates.find(candidate => Number(candidate.teacher_id) === savedTeacherId);
    state.selectedTeacherId = savedTeacher ? savedTeacherId : 0;
    state.selectedTeacherName = savedTeacher ? String(savedTeacher.teacher_name || 'Instructor') : '';
    if (!savedTeacher) {
        state.selectedSlots = [];
        state.activeSlotIndex = -1;
    }
    state.slots = [];
    state.reservedSlots = [];
    state.occupiedSlots = [];
    state.bookedSessions = [];
    state.selectedDate = '';
    const preferredDate = String(document.getElementById('studentRequestPreferredDate')?.value || '');
    state.month = (preferredDate || getManilaYmd()).slice(0, 7);
    const typeNames = Array.from(document.querySelectorAll('#studentRequestInstrumentContainer select.student-request-instrument-type'))
        .filter(select => select.value)
        .map(select => select.selectedOptions?.[0]?.textContent || '')
        .filter(Boolean);
    const context = document.getElementById('studentInstructorAvailabilityContext');
    if (context) context.textContent = `${state.student?.branch_name || 'Student branch'} • ${typeNames.join(', ')}`;
    renderStudentAvailableInstructorList();
    renderStudentInstructorAvailabilityCalendar();
    setStudentInstructorAvailabilityModalOpen(true);
    if (state.selectedTeacherId) void loadStudentInstructorAvailabilityMonth();
}

function getStudentRequestAvailableTypes() {
    const seen = new Set();
    const types = [];
    studentRequestAvailableInstruments.forEach(inst => {
        const id = inst.type_id;
        const name = inst.type_name || 'Other';
        if (id != null && !seen.has(id)) {
            seen.add(id);
            types.push({ type_id: id, type_name: name });
        }
    });
    return types.sort((a, b) => (a.type_name || '').localeCompare(b.type_name || ''));
}

function getStudentRequestInstrumentsByType(typeId) {
    if (!typeId) return [];
    return studentRequestAvailableInstruments.filter(inst => String(inst.type_id) === String(typeId));
}

function renderStudentRequestInstrumentSelectors(maxInstruments, instruments) {
    const maxCount = Math.max(1, Number(maxInstruments || 1));
    studentRequestAvailableInstruments = Array.isArray(instruments) ? instruments : [];
    const types = getStudentRequestAvailableTypes();
    const typeOptionsHtml = types.map(t =>
        `<option value="${t.type_id}">${escapeHtml(t.type_name)}</option>`
    ).join('');

    let html = '';
    for (let i = 1; i <= maxCount; i++) {
        const slotLabel = maxCount === 1 ? 'Instrument Type' : `Instrument Type ${i}`;
        html += `
            <div class="p-4 rounded-xl border border-slate-200 bg-slate-50 space-y-3 shadow-sm">
                <label class="block text-sm font-semibold text-slate-700">${slotLabel} *</label>
                <div>
                    <label class="block text-xs font-semibold uppercase tracking-wide text-slate-500 mb-1">Type</label>
                    <select class="student-request-instrument-type w-full px-4 py-2.5 bg-white border border-slate-200 rounded-xl text-slate-900 focus:outline-none focus:border-gold-400" data-slot="${i}" onchange="onStudentRequestInstrumentTypeChange(${i})">
                        <option value="">Select...</option>
                        ${typeOptionsHtml}
                    </select>
                </div>
            </div>
        `;
    }
    return html;
}

function onStudentRequestInstrumentTypeChange(slot) {
    const typeSelect = document.querySelector(`select.student-request-instrument-type[data-slot="${slot}"]`);
    if (!typeSelect) return;

    const typeId = typeSelect.value;

    // Check for duplicate type selection across other slots
    if (typeId) {
        const allTypeSelects = document.querySelectorAll('select.student-request-instrument-type');
        const duplicateType = Array.from(allTypeSelects).some(sel =>
            sel !== typeSelect && String(sel.value || '') === String(typeId)
        );
        if (duplicateType) {
            typeSelect.value = '';
            if (typeof showMessage === 'function') {
                showMessage('That instrument type has already been selected in another slot. Please choose a different type.', 'error');
            }
            // Refresh disabled states without recursing into the type-change handler
            _syncStudentRequestTypeDisabledStates();
            return;
        }
    }
    onStudentRequestInstrumentDropdownChange(slot);
    if (typeof window.refreshStudentInstructorAvailabilityControl === 'function') {
        window.refreshStudentInstructorAvailabilityControl();
    }
}

// Sync disabled state of type dropdowns so already-used types are greyed out
function _syncStudentRequestTypeDisabledStates() {
    const allTypeSelects = document.querySelectorAll('select.student-request-instrument-type');
    const usedTypes = new Set();
    allTypeSelects.forEach(sel => { if (sel.value) usedTypes.add(String(sel.value)); });
    allTypeSelects.forEach(sel => {
        const currentVal = String(sel.value || '');
        Array.from(sel.options).forEach(opt => {
            if (opt.value === '') return;
            opt.disabled = usedTypes.has(String(opt.value)) && String(opt.value) !== currentVal;
        });
    });
}

function getResolvedInstrumentIdsFromSelectors(rootSelector, typeSelector, instrumentSelector, availableInstruments) {
    const root = rootSelector ? document.querySelector(rootSelector) : document;
    if (!root) return [];

    const instrumentList = Array.isArray(availableInstruments) ? availableInstruments : [];
    const resolvedIds = [];
    const usedIds = new Set();
    const typeSelects = Array.from(root.querySelectorAll(typeSelector));

    typeSelects.forEach(typeSelect => {
        const slot = typeSelect.dataset.slot;
        const instrumentSelect = instrumentSelector && slot != null
            ? root.querySelector(`${instrumentSelector}[data-slot="${slot}"]`)
            : null;

        let instrumentId = Number.parseInt(instrumentSelect?.value || '', 10) || 0;
        if (instrumentId < 1) {
            const typeId = String(typeSelect.value || '').trim();
            if (typeId) {
                const fallback = instrumentList.find(inst =>
                    String(inst.type_id) === String(typeId) &&
                    !usedIds.has(String(inst.instrument_id))
                );
                instrumentId = Number.parseInt(fallback?.instrument_id || '', 10) || 0;
            }
        }

        if (instrumentId > 0 && !usedIds.has(String(instrumentId))) {
            usedIds.add(String(instrumentId));
            resolvedIds.push(instrumentId);
        }
    });

    return resolvedIds;
}

function getStudentRequestSelectedInstrumentIds() {
    return getResolvedInstrumentIdsFromSelectors(
        '#studentRequestInstrumentContainer',
        'select.student-request-instrument-type',
        'select.student-request-instrument',
        studentRequestAvailableInstruments
    );
}

function getWalkinSelectedInstrumentIds() {
    return getResolvedInstrumentIdsFromSelectors(
        '#walkinInstrumentsContainer',
        'select.student-request-instrument-type',
        'select.student-request-instrument',
        studentRequestAvailableInstruments
    );
}

function onStudentRequestInstrumentDropdownChange(changedSlot = null) {
    const selects = document.querySelectorAll('select.student-request-instrument');
    if (!selects.length) return;
    const changedSelect = changedSlot != null
        ? document.querySelector(`select.student-request-instrument[data-slot="${changedSlot}"]`)
        : null;

    if (changedSelect && changedSelect.value) {
        const selectedValue = String(changedSelect.value);
        const duplicateExists = Array.from(selects).some(select =>
            select !== changedSelect && String(select.value || '') === selectedValue
        );
        if (duplicateExists) {
            changedSelect.value = '';
            if (typeof showMessage === 'function') {
                showMessage('That instrument has already been selected in another slot. Please choose a different instrument.', 'error');
            }
        }
    }

    const used = new Set();
    selects.forEach(select => {
        const val = select.value;
        if (val) used.add(val);
    });
    selects.forEach(select => {
        const currentVal = select.value;
        Array.from(select.options).forEach(opt => {
            if (opt.value === '') return;
            opt.disabled = used.has(opt.value) && opt.value !== currentVal;
        });
    });

    // Also keep type dropdowns in sync
    _syncStudentRequestTypeDisabledStates();
}

async function fetchStudentRequestMetaByEmail(email, options = {}) {
    const staffContext = options?.staffContext ? '&staff_context=1' : '';
    const url = `${baseApiUrl}/students.php?action=get-student-request-meta&email=${encodeURIComponent(email)}${staffContext}`;
    const res = await axios.get(url);
    return res.data;
}

function ensureGuardianEnrollmentModal() {
    if (document.getElementById('studentRequestModal')) return;
    document.body.insertAdjacentHTML('beforeend', `<div id="studentRequestModal" class="fixed inset-0 z-[80] hidden overflow-y-auto bg-black/60 p-0 backdrop-blur-sm sm:p-4" aria-hidden="true"><div class="flex min-h-full items-stretch justify-center sm:items-center"><div class="flex h-[100dvh] w-full flex-col overflow-hidden bg-white shadow-2xl dark:bg-obsidian sm:h-auto sm:max-h-[92vh] sm:max-w-4xl sm:rounded-3xl sm:border sm:border-zinc-200 dark:sm:border-white/10"><div class="flex items-center justify-between border-b border-zinc-200 px-5 py-4 dark:border-white/10"><div><div class="text-[10px] font-bold uppercase tracking-[.22em] text-gold-600">Enrollment Request</div><h2 id="guardianEnrollmentStudentName" class="mt-1 text-lg font-black text-zinc-900 dark:text-white">Enroll Student</h2></div><button type="button" onclick="closeStudentRequestModal()" class="grid h-10 w-10 place-items-center rounded-full border border-zinc-200 text-zinc-500 hover:bg-zinc-100 dark:border-white/10 dark:hover:bg-white/10"><i class="fas fa-times"></i></button></div><div class="min-h-0 flex-1 overflow-y-auto p-4 sm:p-6"><div id="studentRequestStatus"></div><form id="studentPackageRequestForm" class="mt-4 space-y-4"><div class="grid gap-4 lg:grid-cols-[minmax(0,1.25fr)_300px]"><div class="space-y-4"><section class="rounded-2xl border border-zinc-200 p-4 dark:border-white/10"><div class="mb-3 text-sm font-extrabold text-zinc-900 dark:text-white"><span class="mr-2 text-gold-600">1.</span>Choose the 12-session package</div><select id="studentRequestPackage" class="hidden"><option value="">Select package</option></select><div id="studentRequestPackageCards" class="space-y-2"></div></section><section class="rounded-2xl border border-zinc-200 p-4 dark:border-white/10"><div class="mb-3 text-sm font-extrabold text-zinc-900 dark:text-white"><span class="mr-2 text-gold-600">2.</span>Choose payment</div><div class="grid gap-3 sm:grid-cols-2"><select id="studentRequestPaymentMode" class="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm dark:border-zinc-700 dark:bg-zinc-900"><option value="Partial Payment">Partial Payment</option><option value="Full Payment">Full Payment</option></select><select id="studentRequestPaymentMethod" class="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm dark:border-zinc-700 dark:bg-zinc-900"><option value="">Select payment method</option><option value="GCash">GCash</option><option value="Bank Transfer">Bank Transfer</option></select></div></section><section class="rounded-2xl border border-zinc-200 p-4 dark:border-white/10"><div class="mb-3 text-sm font-extrabold text-zinc-900 dark:text-white"><span class="mr-2 text-gold-600">3.</span>Choose one instrument</div><div id="studentRequestInstrumentContainer"></div><label class="mt-4 block text-xs font-bold uppercase tracking-wider text-zinc-500">Payment proof</label><input id="studentRequestPaymentProof" name="package_payment_proof_file" type="file" accept=".jpg,.jpeg,.png,.webp,.pdf" class="mt-2 w-full rounded-xl border border-dashed border-zinc-300 p-3 text-sm dark:border-zinc-700"><p id="guardianEnrollmentProofName" class="mt-1 hidden text-xs text-gold-600"></p></section><section class="rounded-2xl border border-zinc-200 p-4 dark:border-white/10"><div class="mb-1 text-sm font-extrabold text-zinc-900 dark:text-white"><span class="mr-2 text-gold-600">4.</span>Request a class schedule</div><p class="mb-3 text-xs text-zinc-500 dark:text-zinc-400">Select a preferred date and an available one-hour window.</p><div class="grid gap-3 sm:grid-cols-2"><div><label for="studentRequestPreferredDate" class="mb-1 block text-xs font-bold text-zinc-500">Preferred date</label><input id="studentRequestPreferredDate" type="date" required class="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm dark:border-zinc-700 dark:bg-zinc-900"></div><div><label for="studentRequestPreferredTime" class="mb-1 block text-xs font-bold text-zinc-500">Preferred time</label><select id="studentRequestPreferredTime" required class="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm dark:border-zinc-700 dark:bg-zinc-900"><option value="">Choose a date first</option></select></div></div><div id="studentRequestScheduleHint" class="mt-3 rounded-xl border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-gold-500/20 dark:bg-gold-500/10 dark:text-gold-200">The desk will confirm this request or adjust it if an instructor or room is unavailable.</div></section></div><aside class="self-start rounded-2xl border border-zinc-200 bg-zinc-50 p-4 dark:border-white/10 dark:bg-white/5"><div class="text-sm font-extrabold text-zinc-900 dark:text-white">Payment Summary</div><div id="studentRequestAmount" class="mt-3 text-sm"></div></aside></div><div id="studentAvailabilityCalendar" class="hidden"></div><div id="studentRequestAutoDay" class="mt-3 text-xs text-zinc-500"></div><div class="mt-5 flex flex-col-reverse gap-2 border-t border-zinc-200 pt-4 dark:border-white/10 sm:flex-row sm:justify-end"><button type="button" onclick="closeStudentRequestModal()" class="rounded-xl border border-zinc-300 px-5 py-3 text-sm font-bold dark:border-white/10">Cancel</button><button id="studentSubmitRequestBtn" type="submit" class="rounded-xl bg-gold-500 px-6 py-3 text-sm font-extrabold text-black hover:bg-gold-400"><i class="fas fa-paper-plane mr-2"></i>Submit Request</button></div></form></div></div></div></div>`);
    const scheduleHint = document.getElementById('studentRequestScheduleHint');
    const guardianModalPanel = document.getElementById('studentRequestModal')?.querySelector(':scope > div > div');
    if (guardianModalPanel) {
        guardianModalPanel.classList.remove('sm:max-w-4xl', 'sm:max-h-[92vh]');
        guardianModalPanel.classList.add('sm:max-w-5xl', 'sm:max-h-[94vh]');
    }
    const guardianModalBody = guardianModalPanel?.lastElementChild;
    const guardianRequestForm = document.getElementById('studentPackageRequestForm');
    const guardianRequestGrid = guardianRequestForm?.querySelector(':scope > div');
    const guardianRequestSteps = guardianRequestGrid?.firstElementChild;
    const guardianPaymentSummary = guardianRequestGrid?.querySelector('aside');
    guardianModalBody?.classList.add('lg:overflow-hidden', 'lg:flex', 'lg:flex-col');
    guardianRequestForm?.classList.add('lg:flex', 'lg:min-h-0', 'lg:flex-1', 'lg:flex-col');
    guardianRequestGrid?.classList.add('grid', 'grid-cols-1', 'gap-4', 'lg:min-h-0', 'lg:flex-1', 'lg:grid-cols-[minmax(0,1fr)_300px]');
    guardianRequestSteps?.classList.add('lg:overflow-y-auto', 'lg:overscroll-contain', 'lg:pr-2');
    if (guardianPaymentSummary) {
        guardianPaymentSummary.id = 'studentRequestPaymentSummaryPanel';
        guardianPaymentSummary.classList.add('lg:sticky', 'lg:top-0', 'lg:max-h-full', 'lg:overflow-y-auto');
    }
    const guardianPaymentMethod = document.getElementById('studentRequestPaymentMethod');
    const guardianPaymentGrid = guardianPaymentMethod?.parentElement;
    if (guardianPaymentGrid && !document.getElementById('studentRequestReferenceNumber')) {
        const evidenceGrid = document.createElement('div');
        evidenceGrid.className = 'mt-3 grid grid-cols-1 gap-3 sm:grid-cols-2';
        evidenceGrid.innerHTML = `<div><label for="studentRequestReferenceNumber" class="mb-2 block text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400">Reference Number</label><input id="studentRequestReferenceNumber" type="text" autocomplete="off" placeholder="Transaction / reference no." class="w-full rounded-xl border border-zinc-200 bg-white px-3 py-2.5 text-sm text-zinc-900 placeholder-zinc-400 focus:border-gold-500 focus:outline-none dark:border-zinc-700 dark:bg-zinc-900 dark:text-white"></div>`;
        const guardianProofInput = document.getElementById('studentRequestPaymentProof');
        const guardianProofLabel = guardianProofInput?.previousElementSibling;
        const guardianProofName = document.getElementById('guardianEnrollmentProofName');
        if (guardianProofInput) {
            const proofWrap = document.createElement('div');
            if (guardianProofLabel) {
                guardianProofLabel.className = 'mb-2 block text-xs font-bold uppercase tracking-wider text-zinc-500 dark:text-zinc-400';
                guardianProofLabel.textContent = 'Payment Proof';
                proofWrap.appendChild(guardianProofLabel);
            }
            guardianProofInput.className = 'w-full rounded-xl border border-dashed border-zinc-300 bg-zinc-50 px-3 py-2 text-xs dark:border-zinc-700 dark:bg-zinc-900';
            proofWrap.appendChild(guardianProofInput);
            if (guardianProofName) proofWrap.appendChild(guardianProofName);
            evidenceGrid.appendChild(proofWrap);
        }
        guardianPaymentGrid.insertAdjacentElement('afterend', evidenceGrid);
    }
    const guardianPreferredDate = document.getElementById('studentRequestPreferredDate');
    const guardianScheduleSection = guardianPreferredDate?.closest('section');
    const guardianScheduleGrid = guardianPreferredDate?.closest('.grid');
    if (guardianScheduleGrid) {
        guardianScheduleGrid.outerHTML = '<input id="studentRequestPreferredDate" type="hidden"><select id="studentRequestPreferredTime" class="hidden" aria-hidden="true"><option value=""></option></select><div id="studentRequestSelectedScheduleSummary" class="mb-3 rounded-xl border border-dashed border-zinc-300 bg-zinc-50 px-4 py-3 text-sm text-zinc-500 dark:border-white/10 dark:bg-white/5 dark:text-zinc-400">No preferred schedule selected yet.</div>';
    }
    guardianScheduleSection?.querySelector('p')?.remove();
    if (scheduleHint && !document.getElementById('studentViewAvailableInstructorsBtn')) {
        scheduleHint.insertAdjacentHTML('afterend', `<button type="button" id="studentViewAvailableInstructorsBtn" class="mt-3 inline-flex w-full items-center justify-center gap-2 rounded-xl border border-emerald-300 bg-emerald-50 px-4 py-3 text-sm font-bold text-emerald-700 transition hover:border-emerald-400 hover:bg-emerald-100 disabled:cursor-not-allowed disabled:opacity-50 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300 dark:hover:bg-emerald-500/15"><i class="fas fa-chalkboard-user"></i>View Available Instructors</button>`);
    }
    scheduleHint?.remove();
}

async function openGuardianEnrollmentRequest(index) {
    const item = guardianPortalStudents[Number(index)];
    const student = item?.student || {};
    const studentId = Number(student.student_id || 0);
    if (!studentId) return;
    try {
        ensureGuardianEnrollmentModal();
        const requestMeta = await fetchStudentRequestMetaByStudentId(studentId);
        if (!requestMeta?.success) throw new Error(requestMeta?.error || 'Unable to load enrollment choices.');
        closeGuardianStudentModal();
        setText('guardianEnrollmentStudentName', `Enroll ${`${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student'}`);
        initStudentRequestSection(student, requestMeta, { studentId, onSuccess: initGuardianStudentsPage });
        openStudentRequestModal();
    } catch (error) {
        showMessage(error?.response?.data?.error || error?.message || 'Unable to open enrollment request.', 'error');
    }
}

window.openGuardianEnrollmentRequest = openGuardianEnrollmentRequest;

async function fetchStudentRequestMetaByStudentId(studentId) {
    const res = await axios.get(`${baseApiUrl}/students.php?action=get-student-request-meta&student_id=${encodeURIComponent(studentId)}`);
    return res.data;
}

async function postStudentPackageRequest(payload) {
    const isFormData = (typeof FormData !== 'undefined') && (payload instanceof FormData);
    const res = await axios.post(
        `${baseApiUrl}/students.php`,
        isFormData ? payload : payload,
        isFormData ? { headers: { 'Content-Type': 'multipart/form-data' } } : undefined
    );
    return res.data;
}

function initStudentAdditionalSessionAction(student, portal, requestMeta, attendanceSummary) {
    const statusEl = document.getElementById('studentAdditionalSessionStatus');
    const addBtn = document.getElementById('studentAddAnotherSessionBtn');
    if (!statusEl || !addBtn) return;

    const latest = requestMeta?.latest_session_extension_request || null;
    const hasPendingRequest = latest && String(latest.status || '') === 'Pending';
    const currentEnrollment = portal?.current_enrollment || null;
    const totalSessions = Number(currentEnrollment?.package_sessions || student?.package_sessions || 0);
    const attendedSessions = Math.max(
        Number(currentEnrollment?.used_sessions || currentEnrollment?.completed_sessions || 0),
        Number(attendanceSummary?.summary?.present_count || 0) + Number(attendanceSummary?.summary?.late_count || 0)
    );
    const remainingSessions = totalSessions > 0 ? Math.max(0, totalSessions - attendedSessions) : 0;
    const canRequestAdditionalSessions = totalSessions > 0 && remainingSessions === 0;

    if (hasPendingRequest) {
        statusEl.textContent = 'You already have a pending request. Please wait for approval.';
    } else if (canRequestAdditionalSessions) {
        statusEl.textContent = `${attendedSessions} of ${totalSessions} sessions used. You can now request additional sessions.`;
    } else if (totalSessions > 0) {
        statusEl.textContent = `${attendedSessions} of ${totalSessions} sessions used. Additional sessions become available after the remaining ${remainingSessions} session${remainingSessions === 1 ? '' : 's'} are used.`;
    } else {
        statusEl.textContent = 'Finish your current package before adding more sessions.';
    }

    addBtn.classList.toggle('hidden', !canRequestAdditionalSessions && !hasPendingRequest);
    addBtn.disabled = hasPendingRequest || !canRequestAdditionalSessions;

    addBtn.onclick = () => {
        if (hasPendingRequest) {
            showMessage('Please wait for your pending request to be approved.', 'error');
            return;
        }
        if (!canRequestAdditionalSessions) {
            showMessage(`Finish the remaining ${remainingSessions} session${remainingSessions === 1 ? '' : 's'} before requesting more.`, 'error');
            return;
        }

        window.location.href = 'student_profile.html#studentAdditionalSessionsCard';
    };
}

function initStudentRequestSection(student, requestMeta, options = {}) {
    const statusEl = document.getElementById('studentRequestStatus');
    const packageSelect = document.getElementById('studentRequestPackage');
    const packageCardsContainer = document.getElementById('studentRequestPackageCards');
    const amountEl = document.getElementById('studentRequestAmount');
    const instrumentsContainer = document.getElementById('studentRequestInstrumentContainer');
    const paymentModeEl = document.getElementById('studentRequestPaymentMode');
    const paymentMethodEl = document.getElementById('studentRequestPaymentMethod');
    const referenceNumberEl = document.getElementById('studentRequestReferenceNumber');
    const availabilityCalendar = document.getElementById('studentAvailabilityCalendar');
    const form = document.getElementById('studentPackageRequestForm');
    const submitBtn = document.getElementById('studentSubmitRequestBtn');
    const paymentProofEl = document.getElementById('studentRequestPaymentProof');
    const paymentProofNameEl = document.getElementById('studentRequestProofFileName') || document.getElementById('guardianEnrollmentProofName');
    const autoDayEl = document.getElementById('studentRequestAutoDay');
    const preferredDateEl = document.getElementById('studentRequestPreferredDate');
    const preferredTimeEl = document.getElementById('studentRequestPreferredTime');
    const scheduleHintEl = document.getElementById('studentRequestScheduleHint');
    const viewInstructorsBtn = document.getElementById('studentViewAvailableInstructorsBtn');
    const selectedScheduleSummaryEl = document.getElementById('studentRequestSelectedScheduleSummary');

    if (!statusEl || !packageSelect || !packageCardsContainer || !amountEl || !instrumentsContainer || !paymentModeEl || !paymentMethodEl || !availabilityCalendar || !form || !submitBtn || !preferredDateEl || !preferredTimeEl) {
        return;
    }
    if (paymentProofEl) {
        paymentProofEl.onchange = event => {
            const file = event.target.files?.[0];
            if (paymentProofNameEl) {
                paymentProofNameEl.textContent = file ? `Selected: ${file.name}` : '';
                paymentProofNameEl.classList.toggle('hidden', !file);
            }
        };
    }

    const packages = Array.isArray(requestMeta?.packages) ? requestMeta.packages : [];
    const instruments = Array.isArray(requestMeta?.instruments) ? requestMeta.instruments : [];
    const availabilities = Array.isArray(requestMeta?.availabilities) ? requestMeta.availabilities : [];
    const teacherCandidates = Array.isArray(requestMeta?.teacher_candidates) ? requestMeta.teacher_candidates : [];
    const latest = requestMeta?.latest_request || null;
    // Only consider it "pending" if status is actually 'Pending' - not 'Cancelled' or 'Rejected'
    const hasPendingRequest = latest && String(latest.status || '') === 'Pending';
    // Check if form should be disabled (Pending or Approved status means no editing allowed)
    const requestStatus = String(latest?.status || '');
    const isFormDisabled = requestStatus === 'Pending' || requestStatus === 'Approved';
    const packageScope = String(requestMeta?.package_scope || '').toLowerCase();

    // Promotions are selected only by desk/admin/manager. Student and guardian
    // online enrollment always starts with the basic 12-session package.
    const filteredPackages = packages.filter(pkg => Number(pkg.sessions || 0) === 12);

    const defaultPackageId = String(requestMeta?.default_package_id || '');
    let selectedPackageId = defaultPackageId;

    statusEl.innerHTML = renderStudentRequestStatus(latest);
    availabilityCalendar.innerHTML = '';

    const todayYmd = getManilaYmd();
    preferredDateEl.min = todayYmd;

    const getRequestedTimeOptions = (dateValue) => {
        const dayName = getDayOfWeekFromDate(dateValue);
        const slots = [];
        const seen = new Set();
        const selectedTypeIds = getStudentRequestSelectedTypeIds();
        const eligibleTeacherIds = new Set(
            getEligibleStudentRequestInstructors(teacherCandidates, availabilities, selectedTypeIds)
                .map(candidate => Number(candidate.teacher_id || 0))
        );
        availabilities
            .filter(row => String(row.day_of_week || '') === dayName && eligibleTeacherIds.has(Number(row.teacher_id || 0)))
            .forEach(row => {
                const startParts = String(row.start_time || '').split(':').map(Number);
                const endParts = String(row.end_time || '').split(':').map(Number);
                let cursor = (startParts[0] * 60) + startParts[1];
                const end = (endParts[0] * 60) + endParts[1];
                while (Number.isFinite(cursor) && Number.isFinite(end) && cursor + 60 <= end) {
                    const startValue = `${String(Math.floor(cursor / 60)).padStart(2, '0')}:${String(cursor % 60).padStart(2, '0')}`;
                    const endMinutes = cursor + 60;
                    const endValue = `${String(Math.floor(endMinutes / 60)).padStart(2, '0')}:${String(endMinutes % 60).padStart(2, '0')}`;
                    const key = `${startValue}|${endValue}`;
                    if (!seen.has(key)) {
                        seen.add(key);
                        slots.push({ start: startValue, end: endValue });
                    }
                    cursor += 60;
                }
            });
        return slots
            .filter(slot => {
                if (dateValue !== todayYmd) return true;
                const manilaNow = getManilaDateParts();
                const currentMinutes = (manilaNow.hour * 60) + manilaNow.minute;
                const [hours, minutes] = slot.start.split(':').map(Number);
                return ((hours * 60) + minutes) > currentMinutes;
            })
            .sort((a, b) => a.start.localeCompare(b.start));
    };

    const refreshRequestedTimes = (preserveValue = '') => {
        const dayName = getDayOfWeekFromDate(preferredDateEl.value);
        const hasInstrument = getStudentRequestSelectedTypeIds().length > 0;
        const slots = getRequestedTimeOptions(preferredDateEl.value);
        preferredTimeEl.innerHTML = slots.length
            ? '<option value="">Select preferred time</option>' + slots.map(slot => `<option value="${slot.start}|${slot.end}">${escapeHtml(formatTime12Hour(slot.start))} - ${escapeHtml(formatTime12Hour(slot.end))}</option>`).join('')
            : `<option value="">${hasInstrument ? 'No instructor time windows for this date' : 'Choose an instrument first'}</option>`;
        if (preserveValue && slots.some(slot => `${slot.start}|${slot.end}` === preserveValue)) {
            preferredTimeEl.value = preserveValue;
        }
        if (autoDayEl) {
            autoDayEl.textContent = dayName ? `${dayName} request — subject to desk confirmation.` : 'Choose a preferred class date.';
        }
        if (scheduleHintEl) {
            scheduleHintEl.innerHTML = !hasInstrument
                ? '<i class="fas fa-circle-info mr-1"></i>Choose an instrument first to see matching instructor availability.'
                : slots.length
                ? '<i class="fas fa-circle-info mr-1"></i>This is a request. The desk will confirm it or adjust the instructor, room, or time if there is a conflict.'
                : '<i class="fas fa-triangle-exclamation mr-1"></i>No instructor availability is listed for this day. Please choose another date.';
        }
        if (viewInstructorsBtn) {
            const eligibleCount = getEligibleStudentRequestInstructors(teacherCandidates, availabilities, getStudentRequestSelectedTypeIds()).length;
            viewInstructorsBtn.disabled = !hasInstrument;
            viewInstructorsBtn.innerHTML = `<i class="fas fa-chalkboard-user"></i>${hasInstrument ? `View Available Instructors${eligibleCount ? ` (${eligibleCount})` : ''}` : 'Choose an Instrument First'}`;
        }
    };

    if (Number(studentInstructorAvailabilityState.student?.student_id || 0) !== Number(student?.student_id || 0)) {
        studentInstructorAvailabilityState.slotCache.clear();
        if (studentInstructorAvailabilityState.requestController) {
            studentInstructorAvailabilityState.requestController.abort();
            studentInstructorAvailabilityState.requestController = null;
        }
    }
    studentInstructorAvailabilityState.selectedSlot = null;
    studentInstructorAvailabilityState.selectedSlots = [];
    studentInstructorAvailabilityState.activeSlotIndex = -1;
    studentInstructorAvailabilityState.selectedTeacherId = 0;
    studentInstructorAvailabilityState.selectedTeacherName = '';
    studentInstructorAvailabilityState.student = student;
    studentInstructorAvailabilityState.candidates = teacherCandidates;
    studentInstructorAvailabilityState.availabilityRows = availabilities;
    studentInstructorAvailabilityState.applySlot = (slot, teacherName) => {
        const state = studentInstructorAvailabilityState;
        const dateValue = String(slot.session_date || '');
        const timeValue = `${String(slot.start_time || '').slice(0, 5)}|${String(slot.end_time || '').slice(0, 5)}`;
        const candidateSlot = {
            teacher_id: Number(state.selectedTeacherId || 0),
            teacher_name: String(teacherName || state.selectedTeacherName || 'Instructor'),
            session_date: dateValue,
            day_of_week: String(slot.day_of_week || getDayOfWeekFromDate(dateValue)),
            start_time: String(slot.start_time || '').slice(0, 5),
            end_time: String(slot.end_time || '').slice(0, 5)
        };
        const duplicateIndex = state.selectedSlots.findIndex((saved, index) => index !== state.activeSlotIndex && (saved.day_of_week || getDayOfWeekFromDate(saved.session_date)) === candidateSlot.day_of_week);
        if (duplicateIndex >= 0) {
            showPortalToast(
                `${candidateSlot.day_of_week} is already in your weekly schedule. Choose another weekday.`,
                'warning',
                'Day already selected'
            );
            return;
        }
        if (state.activeSlotIndex >= 0 && state.selectedSlots[state.activeSlotIndex]) {
            state.selectedSlots[state.activeSlotIndex] = candidateSlot;
        } else {
            state.selectedSlots.push(candidateSlot);
            state.activeSlotIndex = state.selectedSlots.length - 1;
        }
        preferredDateEl.value = dateValue;
        refreshRequestedTimes(timeValue);
        if (!Array.from(preferredTimeEl.options).some(option => option.value === timeValue)) {
            preferredTimeEl.insertAdjacentHTML('beforeend', `<option value="${escapeHtml(timeValue)}">${escapeHtml(formatTime12Hour(slot.start_time))} - ${escapeHtml(formatTime12Hour(slot.end_time))}</option>`);
        }
        preferredTimeEl.value = timeValue;
        studentInstructorAvailabilityState.selectedSlot = {
            teacherId: Number(studentInstructorAvailabilityState.selectedTeacherId || 0),
            date: dateValue,
            start: String(slot.start_time || '').slice(0, 5),
            end: String(slot.end_time || '').slice(0, 5)
        };
        renderStudentSelectedAvailabilitySlots();
        renderStudentInstructorAvailabilityCalendar();
        if (scheduleHintEl) {
            scheduleHintEl.innerHTML = `<i class="fas fa-circle-check mr-1 text-emerald-600"></i>${state.selectedSlots.length} preferred class day${state.selectedSlots.length === 1 ? '' : 's'} selected with ${escapeHtml(teacherName || 'the instructor')}.`;
        }
    };
    studentInstructorAvailabilityState.confirmSlots = (slots, teacherName) => {
        const first = slots[0];
        if (!first) return;
        preferredDateEl.value = first.session_date;
        const firstTime = `${first.start_time}|${first.end_time}`;
        preferredTimeEl.innerHTML = `<option value="${escapeHtml(firstTime)}">${escapeHtml(formatTime12Hour(first.start_time))} - ${escapeHtml(formatTime12Hour(first.end_time))}</option>`;
        preferredTimeEl.value = firstTime;
        if (selectedScheduleSummaryEl) {
            const projections = buildProjectedRecurringDates(slots, studentInstructorAvailabilityState.sessionCount);
            const recurringLabel = slots.map(item => `Every ${item.day_of_week || getDayOfWeekFromDate(item.session_date)}`).join(', ');
            selectedScheduleSummaryEl.innerHTML = `<div class="font-bold text-zinc-900 dark:text-white">${slots.length} preferred weekly class day${slots.length === 1 ? '' : 's'}</div><div class="mt-1 text-xs font-semibold text-emerald-700 dark:text-emerald-400">Repeats weekly: ${escapeHtml(recurringLabel)}</div><div class="mt-2 flex flex-wrap gap-2">${slots.map((item, index) => `<button type="button" onclick="openStudentRecurringDatesModal(${index})" class="rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-left text-xs text-emerald-800 hover:bg-emerald-100"><strong class="block">${escapeHtml(item.day_of_week || getDayOfWeekFromDate(item.session_date))}</strong><span>${escapeHtml(`${formatTime12Hour(item.start_time)} - ${formatTime12Hour(item.end_time)}`)} · ${projections[index]?.length || 0} dates</span></button>`).join('')}</div><div class="mt-2 text-xs text-emerald-700 dark:text-emerald-400">Preferred instructor: ${escapeHtml(teacherName || first.teacher_name || 'Instructor')}</div>`;
        }
    };
    if (viewInstructorsBtn) viewInstructorsBtn.onclick = openStudentAvailableInstructors;
    window.refreshStudentInstructorAvailabilityControl = () => {
        const state = studentInstructorAvailabilityState;
        state.selectedSlots = [];
        state.activeSlotIndex = -1;
        state.selectedTeacherId = 0;
        state.selectedTeacherName = '';
        state.selectedSlot = null;
        preferredDateEl.value = '';
        preferredTimeEl.innerHTML = '<option value=""></option>';
        if (selectedScheduleSummaryEl) {
            selectedScheduleSummaryEl.textContent = 'No preferred schedule selected yet.';
        }
        if (scheduleHintEl) {
            scheduleHintEl.innerHTML = '<i class="fas fa-circle-info mr-1"></i>Open instructor availability to choose your preferred class day or add multiple days.';
        }
        refreshRequestedTimes('');
    };

    let initialPreferredDate = String(latest?.preferred_date || '');
    if (!initialPreferredDate || initialPreferredDate < todayYmd) {
        initialPreferredDate = todayYmd;
        for (let offset = 0; offset < 14; offset += 1) {
            const candidateValue = addDaysToYmd(todayYmd, offset);
            if (getRequestedTimeOptions(candidateValue).length) {
                initialPreferredDate = candidateValue;
                break;
            }
        }
    }
    preferredDateEl.value = initialPreferredDate;
    const latestTimeValue = latest?.preferred_start_time && latest?.preferred_end_time
        ? `${String(latest.preferred_start_time).slice(0, 5)}|${String(latest.preferred_end_time).slice(0, 5)}`
        : '';
    refreshRequestedTimes(latestTimeValue);

    packageSelect.innerHTML = '<option value="">Select package...</option>' + filteredPackages.map(pkg => {
        const sessions = Number(pkg.sessions || 0);
        const maxInst = Number(pkg.max_instruments || 1);
        const price = formatCurrencyPHP(pkg.price || 0);
        const instLabel = maxInst > 1 ? `up to ${maxInst} instruments` : '1 instrument';
        return `<option value="${pkg.package_id}" data-max-instruments="${maxInst}" data-sessions="${sessions}" data-price="${pkg.price || 0}">${escapeHtml(pkg.package_name || 'Package')} — ${sessions} sessions, ${instLabel} · ${price}</option>`;
    }).join('');

    const packageExists = selectedPackageId && filteredPackages.some(pkg => String(pkg.package_id) === String(selectedPackageId));
    if (!packageExists && (packageScope === 'initial' || filteredPackages.length === 1)) {
        selectedPackageId = String(filteredPackages[0]?.package_id || '');
    }
    if (selectedPackageId) {
        packageSelect.value = selectedPackageId;
    }

    const getSelectedPackageData = () => {
        const selected = packageSelect.options[packageSelect.selectedIndex];
        return {
            maxInst: Number(selected?.getAttribute('data-max-instruments') || 0),
            price: Number(selected?.getAttribute('data-price') || 0),
            sessions: Number(selected?.getAttribute('data-sessions') || 0),
            label: String(selected?.textContent || '').trim()
        };
    };

    const renderPackageCards = () => {
        if (!filteredPackages.length) {
            packageCardsContainer.innerHTML = `
                <div class="rounded-2xl border border-dashed border-zinc-300 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-4 py-5 text-center text-sm text-zinc-500 dark:text-zinc-400">
                    No session packages are available right now.
                </div>
            `;
            return;
        }

        packageCardsContainer.innerHTML = filteredPackages.map((pkg) => {
            const packageId = String(pkg.package_id || '');
            const sessions = Number(pkg.sessions || 0);
            const maxInst = Number(pkg.max_instruments || 1);
            const price = formatCurrencyPHP(pkg.price || 0);
            const active = packageId === selectedPackageId;
            const instLabel = maxInst > 1 ? `up to ${maxInst} instruments` : '1 instrument';

            return `
                <button type="button"
                    class="student-request-package-card w-full text-left rounded-[1.25rem] border px-4 py-3 transition ${active ? 'border-gold-500 bg-gold-50/70 dark:bg-gold-500/10 ring-1 ring-gold-500/25' : 'border-zinc-200 dark:border-white/10 bg-white dark:bg-zinc-900/40 hover:border-gold-300 dark:hover:border-gold-500/30'} ${isFormDisabled ? 'opacity-50 cursor-not-allowed pointer-events-none' : ''}"
                    data-package-id="${escapeHtml(packageId)}"
                    data-max-instruments="${maxInst}"
                    data-sessions="${sessions}"
                    data-price="${pkg.price || 0}"
                    ${isFormDisabled ? 'disabled' : ''}>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4">
                        <div class="flex items-center gap-4 min-w-0">
                            <span class="h-6 w-6 rounded-full border flex items-center justify-center shrink-0 ${active ? 'border-gold-500 bg-gold-500 text-white' : 'border-zinc-300 dark:border-white/20 bg-white dark:bg-zinc-950 text-transparent'}">
                                <i class="fas fa-check text-[10px]"></i>
                            </span>
                            <div class="min-w-0">
                                <div class="text-base font-semibold text-zinc-900 dark:text-white">${escapeHtml(pkg.package_name || 'Package')}</div>
                                <div class="mt-1 text-xs text-zinc-500 dark:text-zinc-400">${sessions} sessions · ${escapeHtml(instLabel)}</div>
                            </div>
                        </div>
                        <div class="text-base font-bold text-zinc-700 dark:text-zinc-200 whitespace-nowrap sm:text-right">${escapeHtml(price)}</div>
                    </div>
                </button>
            `;
        }).join('');

        if (!isFormDisabled) {
            packageCardsContainer.querySelectorAll('.student-request-package-card').forEach((card) => {
                card.addEventListener('click', () => {
                    selectedPackageId = String(card.dataset.packageId || '');
                    packageSelect.value = selectedPackageId;
                    renderPackageCards();
                    updateRequestPackageUI();
                });
            });
        }
    };

    if (filteredPackages.length === 0) {
        statusEl.innerHTML += '<div class="text-xs text-yellow-300 mt-2">No session package is available for enrollment request right now. Please contact desk/admin.</div>';
    }

    const updateRequestPackageUI = () => {
        const { maxInst, price, sessions, label } = getSelectedPackageData();
        studentInstructorAvailabilityState.sessionCount = Math.max(1, Number(sessions || 12));
        const paymentType = String(paymentModeEl.value || 'Partial Payment');
        const registrationFeeDue = getRegistrationFeeDueAmount(student);
        const payableNow = computeStudentRequestPayableNow(price, sessions, paymentType, registrationFeeDue);
        const partialNow = computeStudentRequestPayableNow(price, sessions, 'Partial Payment', 0);

        if (!price) {
            amountEl.innerHTML = `<p class="text-sm text-zinc-400 dark:text-zinc-500">Select a package to see your payment breakdown.</p>`;
        } else {
            const regFeeRow = registrationFeeDue > 0 ? `
                <div class="flex items-center justify-between py-2 border-b border-zinc-100 dark:border-white/10">
                    <div>
                        <p class="text-sm font-semibold text-zinc-700 dark:text-zinc-200">Registration Fee</p>
                        <p class="text-xs text-zinc-400">One-time lifetime fee</p>
                    </div>
                    <span class="text-sm font-bold text-zinc-900 dark:text-white">${formatCurrencyPHP(registrationFeeDue)}</span>
                </div>` : `
                <div class="flex items-center gap-2 py-2 border-b border-zinc-100 dark:border-white/10">
                    <i class="fas fa-circle-check text-emerald-500 text-sm"></i>
                    <p class="text-sm text-emerald-700 dark:text-emerald-400 font-semibold">Registration fee already paid ✓</p>
                </div>`;

            amountEl.innerHTML = `
                <div class="space-y-3">
                    <div>
                        <h3 class="text-base font-extrabold text-zinc-900 dark:text-white">${escapeHtml(String(label || 'Selected package').split('—')[0].trim())}</h3>
                        <p class="mt-0.5 text-xs text-zinc-500 dark:text-zinc-400">${sessions} sessions</p>
                    </div>
                    <div class="rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 px-3 py-3 space-y-2">
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-zinc-500 dark:text-zinc-400">Package price</span>
                            <span class="font-semibold text-zinc-900 dark:text-white">${formatCurrencyPHP(price)}</span>
                        </div>
                        <div class="flex items-center justify-between text-sm">
                            <span class="text-zinc-500 dark:text-zinc-400">Payment mode</span>
                            <span class="font-semibold text-zinc-900 dark:text-white">${escapeHtml(paymentType)}</span>
                        </div>
                        <div class="flex items-center justify-between border-t border-zinc-200 pt-2 text-sm dark:border-white/10">
                            <span class="font-black text-zinc-900 dark:text-white">Due now</span>
                            <span class="text-lg font-black text-gold-600 dark:text-gold-400">${formatCurrencyPHP(payableNow)}</span>
                        </div>
                    </div>
                    ${regFeeRow}
                    ${paymentType === 'Full Payment' ? '' : `<div class="text-xs text-zinc-500 dark:text-zinc-400">Package balance after payment: ${formatCurrencyPHP(Math.max(0, price - partialNow))}</div>`}
                </div>`;
        }

        instrumentsContainer.innerHTML = maxInst > 0
            ? renderStudentRequestInstrumentSelectors(maxInst, instruments)
            : '<div class="text-sm text-zinc-400 dark:text-zinc-500 text-center py-3">Choose a package first.</div>';

        renderPackageCards();
        refreshRequestedTimes('');
    };

    packageSelect.onchange = () => {
        selectedPackageId = String(packageSelect.value || '');
        updateRequestPackageUI();
    };
    paymentModeEl.onchange = updateRequestPackageUI;
    renderPackageCards();
    updateRequestPackageUI();

    const regStatus = String(student.registration_status || 'Pending');
    const profileComplete = isRegistrationProfileComplete(student);
    const registrationApproved = ['Approved', 'Fee Paid'].includes(regStatus);

    // The same modal is reused for different linked students. Clear any disabled
    // state left by a previously viewed ineligible or pending student.
    submitBtn.disabled = false;
    submitBtn.classList.remove('opacity-60', 'cursor-not-allowed');

    if (registrationApproved && !profileComplete) {
        // Admin approval is authoritative. Older approved records may not have
        // every optional profile field populated, but can still enroll.
        statusEl.innerHTML += '<div class="mt-2 text-xs text-slate-500">Registration approved. You may continue with enrollment.</div>';
    }

    if (String(student.status || '') !== 'Active') {
        submitBtn.disabled = true;
        submitBtn.classList.add('opacity-60', 'cursor-not-allowed');
        statusEl.innerHTML += '<div class="text-xs text-yellow-300 mt-2">Your student account is not active yet. Please contact desk/admin.</div>';
    } else if (!registrationApproved) {
        submitBtn.disabled = true;
        submitBtn.classList.add('opacity-60', 'cursor-not-allowed');
        statusEl.innerHTML += '<div class="text-xs text-yellow-300 mt-2">Registration payment must be completed before enrollment.</div>';
    } else if (filteredPackages.length === 0) {
        submitBtn.disabled = true;
        submitBtn.classList.add('opacity-60', 'cursor-not-allowed');
    } else if (hasPendingRequest) {
        submitBtn.disabled = true;
        submitBtn.classList.add('opacity-60', 'cursor-not-allowed');
        statusEl.innerHTML += '<div class="text-xs text-yellow-300 mt-2">You already have a pending request. Wait for desk/admin decision.</div>';
    }

    form.onsubmit = async (e) => {
        e.preventDefault();
        if (submitBtn.disabled) return;

        const packageId = parseInt(packageSelect.value, 10);
        const paymentType = String(paymentModeEl.value || '').trim();
        const paymentMethod = String(paymentMethodEl.value || '').trim();
        const referenceNumber = String(referenceNumberEl?.value || '').trim();
        const instrumentIds = getStudentRequestSelectedInstrumentIds();
        const uniqueInstrumentIds = Array.from(new Set(instrumentIds));
        const preferredDate = String(preferredDateEl.value || '').trim();
        const [preferredStartTime = '', preferredEndTime = ''] = String(preferredTimeEl.value || '').split('|');
        const preferredDay = getDayOfWeekFromDate(preferredDate);
        const preferredSlots = studentInstructorAvailabilityState.selectedSlots.slice();
        const preferredTeacherId = Number(preferredSlots[0]?.teacher_id || 0);

        if (!packageId || !paymentType || !paymentMethod || uniqueInstrumentIds.length < 1 || !preferredSlots.length || !preferredDate || !preferredStartTime || !preferredEndTime) {
            showMessage('Please complete the package, instrument, payment, and preferred schedule.', 'error');
            return;
        }
        if (!['Full Payment', 'Partial Payment', 'Installment'].includes(paymentType)) {
            showMessage('Invalid payment mode selected.', 'error');
            return;
        }
        if (paymentMethod !== 'Cash' && !referenceNumber) {
            showMessage('Enter the transaction or reference number.', 'warning');
            referenceNumberEl?.focus();
            return;
        }
        const paymentProofFile = paymentProofEl && paymentProofEl.files && paymentProofEl.files[0] ? paymentProofEl.files[0] : null;
        if (paymentMethod !== 'Cash' && !paymentProofFile) {
            showMessage('Upload proof of payment for non-cash enrollment payments.', 'error');
            return;
        }

        const selectedOption = packageSelect.options[packageSelect.selectedIndex];
        const maxInst = Number(selectedOption?.getAttribute('data-max-instruments') || 1);
        if (uniqueInstrumentIds.length > maxInst) {
            showMessage(`You can select up to ${maxInst} instrument(s) for this package.`, 'error');
            return;
        }

        submitBtn.disabled = true;
        submitBtn.textContent = 'Submitting...';
        let keepDisabled = false;

            try {
                const requestFormData = new FormData();
            requestFormData.append('action', 'submit-package-request');
            requestFormData.append('student_id', String(Number(student.student_id)));
            requestFormData.append('package_id', String(packageId));
            requestFormData.append('payment_type', paymentType);
            requestFormData.append('payment_method', paymentMethod);
            requestFormData.append('reference_number', referenceNumber);
            requestFormData.append('instrument_ids_json', JSON.stringify(uniqueInstrumentIds));
            requestFormData.append('preferred_date', preferredDate);
            requestFormData.append('preferred_day_of_week', preferredDay);
            requestFormData.append('preferred_start_time', preferredStartTime);
            requestFormData.append('preferred_end_time', preferredEndTime);
            if (preferredTeacherId > 0) {
                requestFormData.append('preferred_teacher_id', String(preferredTeacherId));
            }
            requestFormData.append('preferred_slots_json', JSON.stringify(preferredSlots));
            if (paymentProofFile) {
                requestFormData.append('package_payment_proof_file', paymentProofFile);
            }

            const response = await postStudentPackageRequest(requestFormData);
            if (response.success) {
                closeStudentRequestModal();
                showMessage(response.message || 'Request submitted successfully.', 'success');
                const user = Auth.getUser();
                if (options.studentId || user?.email) {
                    const refreshedMeta = options.studentId
                        ? await fetchStudentRequestMetaByStudentId(options.studentId)
                        : await fetchStudentRequestMetaByEmail(user.email);
                    if (refreshedMeta?.success) {
                        keepDisabled = true;
                        initStudentRequestSection(student, refreshedMeta, options);
                    }
                }
                if (typeof options.onSuccess === 'function') await options.onSuccess();
            } else {
                showMessage(response.error || 'Failed to submit request.', 'error');
            }
        } catch (error) {
            showMessage('Network error. Please try again.', 'error');
        } finally {
            if (!keepDisabled) {
                submitBtn.disabled = false;
                submitBtn.textContent = 'Submit Request';
            }
        }
    };
}

function renderOnboardingStatusBadge(label, tone = 'zinc') {
    const tones = {
        green: 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25',
        blue: 'bg-blue-500/15 text-blue-400 border border-blue-500/25',
        amber: 'bg-amber-500/15 text-amber-400 border border-amber-500/25',
        red: 'bg-red-500/15 text-red-400 border border-red-500/25',
        zinc: 'bg-zinc-500/15 text-zinc-300 border border-zinc-500/25'
    };
    const cls = tones[tone] || tones.zinc;
    return `<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${cls}">${escapeHtml(label)}</span>`;
}

function setStudentModalState(modalId, shouldOpen) {
    const modal = document.getElementById(modalId);
    if (!modal) return;

    if (shouldOpen) {
        const active = document.activeElement;
        if (active instanceof HTMLElement && !modal.contains(active)) {
            modal.__returnFocusEl = active;
        }
        modal.removeAttribute('inert');
        modal.classList.remove('hidden');
        modal.setAttribute('aria-hidden', 'false');

        window.requestAnimationFrame(() => {
            const firstFocusable = modal.querySelector('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
            if (firstFocusable instanceof HTMLElement) {
                firstFocusable.focus();
            }
        });
    } else {
        const active = document.activeElement;
        if (active instanceof HTMLElement && modal.contains(active)) {
            active.blur();
        }

        modal.setAttribute('inert', '');
        modal.setAttribute('aria-hidden', 'true');
        modal.classList.add('hidden');

        const returnFocusEl = modal.__returnFocusEl;
        if (returnFocusEl instanceof HTMLElement && document.contains(returnFocusEl)) {
            window.requestAnimationFrame(() => returnFocusEl.focus());
        }
    }

    const anyOpen = ['studentRegistrationModal', 'studentRequestModal'].some((id) => {
        const item = document.getElementById(id);
        return item && !item.classList.contains('hidden');
    });
    document.body.classList.toggle('overflow-hidden', anyOpen);
}

function openStudentRegistrationModal() {
    const student = studentDashboardPortalState?.student || null;
    const regStatus = String(student?.registration_status || 'Pending');
    const latestPaymentStatus = String(student?.registration_payment_status || '');
    const registrationApproved = ['Approved', 'Fee Paid'].includes(regStatus) || ['Approved', 'Fee Paid'].includes(latestPaymentStatus);

    if (regStatus === 'Rejected') {
        void handleRejectedStudentRegistrationOpen();
        return;
    }

    if (registrationApproved) {
        renderStudentRegistrationModal(student, studentDashboardPortalState || null);
    }

    setStudentModalState('studentRegistrationModal', true);
}

function closeStudentRegistrationModal() {
    setStudentModalState('studentRegistrationModal', false);
}

function openStudentRequestModal() {
    setStudentModalState('studentRequestModal', true);
}

function closeStudentRequestModal() {
    closeStudentInstructorAvailabilityModal();
    setStudentModalState('studentRequestModal', false);
}

// ── Freeze Payment Modal (Student Side) ───────────────────────────
function openFreezePaymentModal(options = null) {
    const context      = options && typeof options === 'object' ? options : {};
    const enrollmentId = Number(context.enrollmentId || window.__freezeEnrollmentId || 0);
    const studentId    = Number(context.studentId || window.__freezeStudentId || 0);
    const amount       = Number(context.amount || window.__freezeAmount || 100);
    const studentName  = String(context.studentName || '').trim();
    if (!enrollmentId || !studentId) {
        Swal.fire({ icon:'error', title:'Error', text:'Account information not loaded. Please refresh the page.', confirmButtonColor:'#b8860b' });
        return;
    }

    Swal.fire({
        title: '<i class="fas fa-snowflake text-rose-500 mr-2"></i>Pay Slot Reservation Fee',
        width: 480,
        showCancelButton: true,
        confirmButtonText: 'Submit Payment',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#b8860b',
        allowOutsideClick: false,
        html: `
            <div class="text-left space-y-4 py-2">
                <div class="rounded-xl bg-rose-50 border border-rose-200 px-4 py-3 flex items-center justify-between">
                    <span class="text-sm font-semibold text-rose-800">Amount Due</span>
                    <span class="text-xl font-black text-rose-700">₱${Number(amount).toFixed(2)}</span>
                </div>
                <p class="text-sm text-zinc-500">${studentName ? `Submit an online reservation payment for <strong class="text-zinc-800">${escapeHtml(studentName)}</strong>.` : 'Submit your reservation payment online.'} The desk will verify it before restoring attendance access.</p>

                <div id="fpOnlineFields" class="space-y-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-600 uppercase tracking-wide mb-1">Payment Method</label>
                        <select id="fpMethod" class="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:border-blue-400">
                            <option value="GCash">GCash</option>
                            <option value="Bank Transfer">Bank Transfer</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-600 uppercase tracking-wide mb-1">Reference Number *</label>
                        <input type="text" id="fpReference" placeholder="Reference number"
                            class="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-800 focus:outline-none focus:border-blue-400"
                            maxlength="100">
                    </div>
                </div>

                <p id="fpMsg" class="hidden text-xs font-medium text-red-600"></p>
            </div>
        `,
        preConfirm: async () => {
            const method = document.getElementById('fpMethod')?.value || 'GCash';
            const ref    = (document.getElementById('fpReference')?.value || '').trim();
            const msgEl  = document.getElementById('fpMsg');

            if (!ref) {
                if (msgEl) { msgEl.textContent = 'Reference number is required for online payments.'; msgEl.classList.remove('hidden'); }
                return false;
            }
            if (msgEl) msgEl.classList.add('hidden');

            try {
                const payload = new FormData();
                payload.append('action',           'submit-freeze-payment');
                payload.append('enrollment_id',    String(enrollmentId));
                payload.append('student_id',       String(studentId));
                payload.append('payment_method',   method);
                payload.append('reference_number', ref);
                payload.append('source',           'online');
                const res  = await axios.post(`${baseApiUrl}/students.php?action=submit-freeze-payment`, payload);
                const data = res.data || {};
                if (!data.success) { Swal.showValidationMessage(data.error || 'Submission failed.'); return false; }
                return data;
            } catch (e) {
                Swal.showValidationMessage('Network error. Please try again.');
                return false;
            }
        }
    }).then(result => {
        if (!result.isConfirmed || !result.value) return;
        Swal.fire({
            icon: 'success',
            title: 'Payment Submitted',
            text: result.value.message || 'Your payment is pending desk approval.',
            confirmButtonColor: '#b8860b'
        }).then(() => window.location.reload());
    });
}

function openGuardianFreezePayment(studentIndex) {
    const item = guardianPortalStudents[Number(studentIndex)];
    const student = item?.student || {};
    const enrollment = item?.current_enrollment || {};
    const notice = getScheduleFreezeReservationNotice(enrollment);
    if (!item || !notice) {
        Swal.fire({ icon: 'info', title: 'Payment not needed', text: 'This student account is not currently waiting for a reservation payment.', confirmButtonColor: '#b8860b' });
        return;
    }

    openFreezePaymentModal({
        enrollmentId: Number(enrollment.enrollment_id || 0),
        studentId: Number(student.student_id || 0),
        amount: Number(notice.amount || enrollment.reservation_fee_amount || 100),
        studentName: `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student'
    });
}

window.openFreezePaymentModal = openFreezePaymentModal;
window.openGuardianFreezePayment = openGuardianFreezePayment;

window.openStudentRegistrationModal = openStudentRegistrationModal;
window.closeStudentRegistrationModal = closeStudentRegistrationModal;
window.openStudentRequestModal = openStudentRequestModal;
window.closeStudentRequestModal = closeStudentRequestModal;

async function resetRejectedStudentRegistration(studentId) {
    const res = await axios.post(`${baseApiUrl}/users.php?action=reset-rejected-registration`, {
        student_id: Number(studentId)
    });
    return res.data;
}

async function handleRejectedStudentRegistrationOpen() {
    const studentId = Number(studentDashboardPortalState?.student?.student_id || 0);
    if (studentId < 1) {
        showMessage('Unable to reset this rejected registration right now.', 'error');
        return;
    }

    const result = await Swal.fire({
        icon: 'warning',
        title: 'Registration Rejected By Admin',
        text: 'Registration rejected. Please try again or contact admin.',
        confirmButtonText: 'OK',
        confirmButtonColor: '#b8860b'
    });

    if (!result.isConfirmed) {
        return;
    }

    try {
        const reset = await resetRejectedStudentRegistration(studentId);
        if (!reset?.success) {
            throw new Error(reset?.error || 'Failed to reset rejected registration.');
        }

        try {
            sessionStorage.setItem('student_reopen_registration_modal', '1');
            sessionStorage.setItem('student_registration_rejected_notice', '1');
        } catch (e) {
            // Ignore storage issues and just reload.
        }
        window.location.reload();
    } catch (error) {
        showMessage(error?.message || 'Failed to reset rejected registration.', 'error');
    }
}

function bindStudentModalFrame(modalId, closeFn) {
    const modal = document.getElementById(modalId);
    if (!modal || modal.dataset.bound === 'true') return;
    modal.dataset.bound = 'true';
    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            closeFn();
        }
    });
}

function openPendingRequestPaymentModal(requestId) {
    const req = pendingRequestsById[String(requestId)];
    if (!req) {
        showMessage('Payment details not found.', 'error');
        return;
    }

    const paymentType = escapeHtml(req.payment_type || 'Partial Payment');
    const paymentMethod = escapeHtml(req.payment_method || '—');
    const payableNow = Number(req.payable_now || 0);
    const packageAmount = Number(req.requested_amount || req.package_price || 0);
    const proofHtml = req.payment_proof_path
        ? `<a href="${escapeHtml(buildPublicFileUrl(req.payment_proof_path))}" target="_blank" rel="noopener" class="text-sm text-blue-600 underline">View payment proof</a>`
        : '<span class="text-sm text-slate-500">No payment proof uploaded</span>';

    Swal.fire({
        title: 'Payment Details',
        width: 620,
        confirmButtonText: 'Close',
        html: `
            <div class="text-left space-y-4 text-sm text-slate-700">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div><span class="font-semibold text-slate-900">Payment Type:</span> ${paymentType}</div>
                    <div><span class="font-semibold text-slate-900">Payment Method:</span> ${paymentMethod}</div>
                    <div><span class="font-semibold text-slate-900">Pay Now:</span> ${formatCurrencyPHP(payableNow)}</div>
                    <div><span class="font-semibold text-slate-900">Package Amount:</span> ${formatCurrencyPHP(packageAmount)}</div>
                </div>
                <div><span class="font-semibold text-slate-900">Proof of Payment:</span> ${proofHtml}</div>
            </div>
        `
    });
}

function renderStudentRegistrationModal(student, portal) {
    const body = document.getElementById('studentRegistrationModalBody');
    if (!body) return;
    const regStatus = String(student?.registration_status || 'Pending');
    const latestPaymentStatus = String(student?.registration_payment_status || '');
    const profileComplete = isRegistrationProfileComplete(student);
    const guardian = Array.isArray(portal?.guardians) && portal.guardians.length > 0
        ? (portal?.primary_guardian || portal.guardians[0])
        : null;
    const registrationSettled = profileComplete && (
        ['Approved', 'Fee Paid'].includes(regStatus) || ['Approved', 'Fee Paid'].includes(latestPaymentStatus)
    );
    const hasSubmittedPendingRegistration = regStatus === 'Pending'
        && latestPaymentStatus === 'Pending'
        && profileComplete
        && Boolean(
            student?.registration_proof_path
            || student?.registration_payment_method
            || student?.registration_reference_number
            || student?.registration_receipt_number
        );

    if (registrationSettled) {
        body.innerHTML = `
            <div class="space-y-5">
                <div class="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-4 sm:px-5">
                    <div class="text-sm font-bold text-emerald-800">Registration approved</div>
                    <div class="text-sm text-emerald-700 mt-1">Your membership registration is complete. You can now continue to the enrollment module and request your class package.</div>
                </div>

                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 sm:p-5">
                    <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold mb-4">Student Details</div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Name:</span> ${escapeHtml(`${student?.first_name || ''} ${student?.last_name || ''}`.trim() || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Email:</span> ${escapeHtml(student?.email || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Phone:</span> ${escapeHtml(student?.phone || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Branch:</span> ${escapeHtml(student?.branch_name || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Birthday:</span> ${escapeHtml(student?.date_of_birth || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Address:</span> ${escapeHtml(student?.address || '—')}</div>
                    </div>
                </div>

                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 sm:p-5">
                    <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold mb-4">Registration Payment</div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Registration Fee:</span> ₱1,000.00</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Status:</span> ${escapeHtml(regStatus || latestPaymentStatus || 'Approved')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Payment Method:</span> ${escapeHtml(student?.registration_payment_method || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Reference Number:</span> ${escapeHtml(student?.registration_reference_number || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Receipt Number:</span> ${escapeHtml(student?.registration_receipt_number || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Payment Proof:</span> ${student?.registration_proof_path ? `<a href="${buildPublicFileUrl(student.registration_proof_path)}" target="_blank" rel="noopener" class="text-blue-700 underline">View file</a>` : '—'}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Proof ID:</span> ${student?.age_verification_proof_path ? `<a href="${buildPublicFileUrl(student.age_verification_proof_path)}" target="_blank" rel="noopener" class="text-emerald-700 underline">View file</a>` : '—'}</div>
                    </div>
                </div>

                ${guardian ? `
                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 sm:p-5">
                    <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold mb-4">Guardian</div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Name:</span> ${escapeHtml(`${guardian.first_name || ''} ${guardian.last_name || ''}`.trim() || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Relationship:</span> ${escapeHtml(guardian.relationship_type || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Email:</span> ${escapeHtml(guardian.email || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Phone:</span> ${escapeHtml(guardian.phone || '—')}</div>
                    </div>
                </div>
                ` : ''}

                <div class="rounded-2xl border border-gold-500/20 bg-amber-50 dark:bg-gold-500/10 p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
                    <div>
                        <div class="text-sm font-bold text-zinc-900 dark:text-white">Enrollment is now available</div>
                        <div class="text-sm text-zinc-600 dark:text-zinc-300 mt-1">Open the enrollment module to choose a package, instruments, and class schedule.</div>
                    </div>
                    <button type="button" onclick="openStudentRequestModal()" class="px-5 py-3 rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition whitespace-nowrap">
                        Open Enrollment Module
                    </button>
                </div>
            </div>
        `;
        return;
    }

    if (hasSubmittedPendingRegistration) {
        body.innerHTML = `
            <div class="space-y-5">
                <div class="rounded-2xl border border-amber-200 bg-amber-50 px-4 py-4 sm:px-5">
                    <div class="text-sm font-bold text-amber-800">Registration pending admin review</div>
                    <div class="text-sm text-amber-700 mt-1">Your registration has already been submitted. These details stay locked while admin reviews your request.</div>
                </div>

                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 sm:p-5">
                    <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold mb-4">Student Details</div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Name:</span> ${escapeHtml(`${student?.first_name || ''} ${student?.last_name || ''}`.trim() || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Email:</span> ${escapeHtml(student?.email || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Phone:</span> ${escapeHtml(student?.phone || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Branch:</span> ${escapeHtml(student?.branch_name || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Birthday:</span> ${escapeHtml(student?.date_of_birth || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Address:</span> ${escapeHtml(student?.address || '—')}</div>
                    </div>
                </div>

                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 sm:p-5">
                    <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold mb-4">Registration Payment</div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Registration Fee:</span> ₱1,000.00</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Payment Method:</span> ${escapeHtml(student?.registration_payment_method || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Reference Number:</span> ${escapeHtml(student?.registration_reference_number || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Receipt Number:</span> ${escapeHtml(student?.registration_receipt_number || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Payment Proof:</span> ${student?.registration_proof_path ? `<a href="${buildPublicFileUrl(student.registration_proof_path)}" target="_blank" rel="noopener" class="text-blue-700 underline">View file</a>` : '—'}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Proof ID:</span> ${student?.age_verification_proof_path ? `<a href="${buildPublicFileUrl(student.age_verification_proof_path)}" target="_blank" rel="noopener" class="text-emerald-700 underline">View file</a>` : '—'}</div>
                    </div>
                </div>

                ${guardian ? `
                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-4 sm:p-5">
                    <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold mb-4">Guardian</div>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Name:</span> ${escapeHtml(`${guardian.first_name || ''} ${guardian.last_name || ''}`.trim() || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Relationship:</span> ${escapeHtml(guardian.relationship_type || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Email:</span> ${escapeHtml(guardian.email || '—')}</div>
                        <div><span class="font-semibold text-zinc-700 dark:text-zinc-200">Phone:</span> ${escapeHtml(guardian.phone || '—')}</div>
                    </div>
                </div>
                ` : ''}
            </div>
        `;
        return;
    }

    body.innerHTML = `
        <div class="space-y-3 sm:space-y-4 min-w-0 pb-[calc(9rem+env(safe-area-inset-bottom))] sm:pb-4">
            ${studentRegistrationRestartNotice ? `
                <div class="rounded-xl sm:rounded-2xl border border-red-200 bg-red-50 px-3 py-2.5 sm:px-5 sm:py-3">
                    <div class="text-xs sm:text-sm font-bold text-red-700">Registration rejected</div>
                    <div class="text-xs sm:text-sm text-red-600 mt-0.5">Please fill in the form again and resubmit.</div>
                </div>
            ` : ''}

            <!-- Intro hint -->
            <div class="rounded-lg sm:rounded-xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-3 py-2.5 sm:px-4 sm:py-3 text-xs sm:text-sm text-zinc-600 dark:text-zinc-300">
                Fill in the student details below. Guardian info is required for students 18 and under. Then upload your registration payment to submit.
            </div>

            <!-- Two-column: left = student + guardian, right = payment -->
            <div class="grid grid-cols-1 lg:grid-cols-[minmax(0,1fr)_minmax(0,280px)] gap-3 sm:gap-4 min-w-0">

                <!-- LEFT -->
                <div class="space-y-3 sm:space-y-4 min-w-0">

                    <!-- 1. Student Details -->
                    <div class="rounded-xl sm:rounded-2xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 overflow-hidden min-w-0">
                        <div class="flex items-center gap-2 sm:gap-2.5 px-3 py-2.5 sm:px-4 sm:py-3 bg-zinc-50 dark:bg-zinc-800 border-b border-zinc-100 dark:border-white/10">
                            <div class="h-5 w-5 rounded-full bg-gold-500 flex items-center justify-center shrink-0"><span class="text-black text-[9px] font-black">1</span></div>
                            <p class="text-xs sm:text-sm font-semibold text-zinc-900 dark:text-white">Student Details</p>
                        </div>
                        <form id="registrationDetailsForm" class="px-3 py-3 sm:px-4 sm:py-4 grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3 min-w-0">
                            <div class="min-w-0">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">First Name *</label>
                                <input id="regFirstName" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" />
                            </div>
                            <div class="min-w-0">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Last Name *</label>
                                <input id="regLastName" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" />
                            </div>
                            <div class="min-w-0">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Middle Name</label>
                                <input id="regMiddleName" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" />
                            </div>
                            <div class="w-full min-w-0">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5 uppercase tracking-wide">Phone *</label>
                                <input id="regPhone" type="tel" name="student_phone" required autocomplete="off"
                                    class="intl-phone-input w-full max-w-full box-border px-3 py-2.5 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-gold-500"
                                    placeholder="Phone number" />
                            </div>
                            <div class="min-w-0 md:col-span-2">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Date of Birth *</label>
                                <div class="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
                                    <input id="regDob" type="date" class="flex-1 min-w-0 w-full px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" />
                                    <div class="flex-shrink-0 flex flex-row sm:flex-col items-center justify-center gap-2 sm:gap-0 min-w-[72px] px-3 py-2 bg-zinc-100 dark:bg-white/5 border border-zinc-200 dark:border-white/10 rounded-lg sm:rounded-xl text-center self-start sm:self-auto">
                                        <span class="text-[9px] font-bold uppercase tracking-wide text-zinc-400 leading-none">Age</span>
                                        <input id="regAge" readonly class="w-full bg-transparent text-center text-sm font-bold text-zinc-700 dark:text-zinc-200 cursor-not-allowed focus:outline-none leading-tight sm:mt-0.5 p-0" style="min-width:32px;max-width:44px;" />
                                    </div>
                                </div>
                            </div>
                            <div class="min-w-0">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Email</label>
                                <input id="regEmail" type="email" readonly class="w-full min-w-0 px-3 py-2.5 bg-zinc-100 dark:bg-white/5 border border-zinc-200 dark:border-white/10 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-500 cursor-not-allowed" />
                            </div>
                            <div class="min-w-0">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Branch</label>
                                <div id="regBranchDisplay" class="w-full min-w-0 px-3 py-2.5 bg-zinc-100 dark:bg-white/5 border border-zinc-200 dark:border-white/10 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-600 dark:text-zinc-300 font-medium break-words">
                                    ${escapeHtml(student?.branch_name || 'Assigned branch')}
                                </div>
                            </div>
                            <div class="col-span-1 md:col-span-2 min-w-0">
                                <input type="hidden" id="regAddress">
                                <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Address</label>
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3 min-w-0">
                                    <div class="min-w-0">
                                        <label class="block text-[10px] font-medium text-zinc-400 dark:text-zinc-500 mb-1">Street</label>
                                        <input type="text" id="regStreet" placeholder="House no., street, subdivision" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:border-gold-500">
                                    </div>
                                    <div class="min-w-0">
                                        <label class="block text-[10px] font-medium text-zinc-400 dark:text-zinc-500 mb-1">Barangay</label>
                                        <input type="text" id="regBarangay" placeholder="Barangay" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:border-gold-500">
                                    </div>
                                    <div class="min-w-0">
                                        <label class="block text-[10px] font-medium text-zinc-400 dark:text-zinc-500 mb-1">Province</label>
                                        <select id="regProvince" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500">
                                            <option value="">Loading provinces...</option>
                                        </select>
                                    </div>
                                    <div class="min-w-0">
                                        <label class="block text-[10px] font-medium text-zinc-400 dark:text-zinc-500 mb-1">City / Municipality</label>
                                        <select id="regCity" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" disabled>
                                            <option value="">Select province first</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>

                    <!-- 2. Guardian -->
                    <div class="rounded-xl sm:rounded-2xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 overflow-hidden min-w-0">
                        <div class="flex items-center gap-2 sm:gap-2.5 px-3 py-2.5 sm:px-4 sm:py-3 bg-zinc-50 dark:bg-zinc-800 border-b border-zinc-100 dark:border-white/10">
                            <div class="h-5 w-5 rounded-full bg-gold-500 flex items-center justify-center shrink-0"><span class="text-black text-[9px] font-black">2</span></div>
                            <p class="text-xs sm:text-sm font-semibold text-zinc-900 dark:text-white flex-1 min-w-0">Guardian</p>
                            <span id="guardianRequiredBadge" class="hidden text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-700 border border-amber-200 shrink-0">Required</span>
                        </div>
                        <div class="px-3 py-3 sm:px-4">
                            <div id="guardianAutoStatus" class="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400">
                                Enter the student's date of birth above — guardian fields appear automatically for students 18 and under.
                            </div>
                            <div id="guardianInputs" class="space-y-2.5 sm:space-y-3 hidden min-w-0">
                                <div class="grid grid-cols-1 md:grid-cols-2 gap-2.5 sm:gap-3 min-w-0">
                                    <div class="min-w-0 md:col-span-2">
                                        <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Guardian Email *</label>
                                        <div class="flex flex-col gap-2 sm:flex-row">
                                            <div class="relative min-w-0 flex-1">
                                                <input id="guardianEmailInput" type="email" autocomplete="email" placeholder="guardian@example.com" class="w-full min-w-0 px-3 py-2.5 pr-11 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:border-gold-500" />
                                                <button type="button" id="guardianCopyEmailBtn" aria-label="Copy guardian email" title="Copy email" class="absolute right-1.5 top-1/2 grid h-8 w-8 -translate-y-1/2 place-items-center rounded-lg text-zinc-400 hover:bg-zinc-100 hover:text-zinc-700 dark:hover:bg-white/10 dark:hover:text-white">
                                                    <i class="far fa-copy"></i>
                                                </button>
                                            </div>
                                            <button type="button" id="guardianFindBtn" class="shrink-0 rounded-lg border border-zinc-300 bg-zinc-50 px-3 py-2.5 text-xs font-bold text-zinc-700 hover:border-gold-400 hover:bg-gold-50 dark:border-zinc-700 dark:bg-zinc-800 dark:text-zinc-200">
                                                Find existing
                                            </button>
                                        </div>
                                        <p id="guardianInfoBox" class="mt-1.5 text-xs text-zinc-500 dark:text-zinc-400"></p>
                                    </div>
                                    <div class="min-w-0">
                                        <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">First Name *</label>
                                        <input id="guardianFirstNameInput" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" />
                                    </div>
                                    <div class="min-w-0">
                                        <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Last Name *</label>
                                        <input id="guardianLastNameInput" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" />
                                    </div>
                                    <div class="w-full min-w-0 md:col-span-2">
                                        <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 mb-1.5 uppercase tracking-wide">Phone *</label>
                                        <input id="guardianPhoneInput" type="tel" name="guardian_phone" required autocomplete="off"
                                            class="intl-phone-input w-full max-w-full box-border px-3 py-2.5 bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white placeholder-zinc-400 focus:outline-none focus:ring-1 focus:ring-gold-500"
                                            placeholder="Phone number" />
                                    </div>
                                    <div class="min-w-0 md:col-span-2">
                                        <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Relationship *</label>
                                        <select id="guardianRelationshipInput" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500">
                                            <option value="">Select…</option>
                                            <option value="Mother">Mother</option>
                                            <option value="Father">Father</option>
                                            <option value="Legal Guardian">Legal Guardian</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div><!-- end left col -->

                <!-- RIGHT: Registration Payment -->
                <div class="rounded-xl sm:rounded-2xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 overflow-hidden min-w-0 lg:self-start">
                    <div class="flex items-center gap-2 sm:gap-2.5 px-3 py-2.5 sm:px-4 sm:py-3 bg-zinc-50 dark:bg-zinc-800 border-b border-zinc-100 dark:border-white/10">
                        <div class="h-5 w-5 rounded-full bg-gold-500 flex items-center justify-center shrink-0"><span class="text-black text-[9px] font-black">3</span></div>
                        <p class="text-xs sm:text-sm font-semibold text-zinc-900 dark:text-white">Registration Payment</p>
                    </div>
                    <form id="registrationPaymentForm" class="px-3 py-3 sm:px-4 sm:py-4 space-y-2.5 sm:space-y-3 min-w-0">
                        <div class="rounded-lg sm:rounded-xl bg-amber-50 dark:bg-amber-500/10 border border-amber-200/70 dark:border-amber-500/30 px-3 py-2.5 text-xs text-amber-800 dark:text-amber-200">
                            A <strong>₱1,000 lifetime registration fee</strong> is required before enrollment.
                        </div>
                        <div class="flex items-center justify-between px-3 py-2.5 bg-zinc-100 dark:bg-white/5 border border-zinc-200 dark:border-white/10 rounded-lg sm:rounded-xl">
                            <span class="text-xs text-zinc-500 font-medium">Registration Fee</span>
                            <span class="text-sm font-bold text-zinc-900 dark:text-white">₱1,000.00</span>
                        </div>
                        <div class="min-w-0">
                            <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Payment Method *</label>
                            <select id="regPayMethod" class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500">
                                <option value="GCash">GCash</option>
                                <option value="Bank Transfer">Bank Transfer</option>


                            </select>
                        </div>
                        <div class="min-w-0">
                            <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Reference Number *</label>
                            <input type="text" id="regPayReference" placeholder="Transaction / reference no." class="w-full min-w-0 px-3 py-2.5 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-base sm:text-sm text-zinc-900 dark:text-white focus:outline-none focus:border-gold-500" />
                            <div id="regPayReferenceHint" class="mt-1.5 text-[11px] text-zinc-400 break-words">Enter the reference or transaction number.</div>
                        </div>
                        <div class="min-w-0">
                            <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Proof of Payment *</label>
                            <input type="file" id="regPayProof" accept=".jpg,.jpeg,.png,.webp,.pdf" class="w-full min-w-0 max-w-full px-2 py-2.5 sm:px-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-xs text-zinc-700 dark:text-zinc-200 file:mr-2 file:py-1.5 file:px-2.5 file:rounded-lg file:border-0 file:bg-gold-500/20 file:text-gold-600 file:text-xs file:font-semibold" />
                            <p class="mt-1.5 text-[11px] text-zinc-400">Screenshot or receipt · JPG, PNG, PDF</p>
                            <button type="button" id="regPayProofViewBtn" class="hidden mt-1.5 text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium inline-flex items-center gap-1">
                                <i class="fas fa-eye text-[10px]"></i> Click to view uploaded file
                            </button>
                        </div>
                        <div class="min-w-0">
                            <label class="block text-[10px] font-semibold text-zinc-500 dark:text-zinc-400 uppercase tracking-wide mb-1.5">Valid ID / Proof of Age *</label>
                            <input type="file" id="regAgeProof" accept=".jpg,.jpeg,.png,.webp,.pdf" class="w-full min-w-0 max-w-full px-2 py-2.5 sm:px-3 bg-white dark:bg-zinc-900 border border-zinc-200 dark:border-zinc-700 rounded-lg sm:rounded-xl text-xs text-zinc-700 dark:text-zinc-200 file:mr-2 file:py-1.5 file:px-2.5 file:rounded-lg file:border-0 file:bg-gold-500/20 file:text-gold-600 file:text-xs file:font-semibold" />
                            <p class="mt-1.5 text-[11px] text-zinc-400">Birth certificate, valid ID, etc. · JPG, PNG, PDF</p>
                            <button type="button" id="regAgeProofViewBtn" class="hidden mt-1.5 text-xs text-blue-600 dark:text-blue-400 hover:underline font-medium inline-flex items-center gap-1">
                                <i class="fas fa-eye text-[10px]"></i> Click to view uploaded file
                            </button>
                        </div>
                        <div id="regPayStatus" class="text-xs text-zinc-500 dark:text-zinc-300 break-words"></div>
                    </form>
                </div>

            </div><!-- end grid -->

            <!-- Submit row -->
            <div class="sticky bottom-0 z-20 -mx-3 sm:-mx-5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2.5 sm:gap-3 border-t border-zinc-100 dark:border-white/10 bg-gradient-to-t from-white via-white/98 to-white/90 dark:from-obsidian dark:via-obsidian/98 dark:to-obsidian/90 backdrop-blur-sm px-3 py-3 sm:px-5 sm:pt-4 pb-[calc(0.75rem+env(safe-area-inset-bottom))] sm:pb-[calc(1rem+env(safe-area-inset-bottom))]">
                <div id="submitRegistrationStatus" class="text-xs sm:text-sm text-zinc-500 dark:text-zinc-400 min-w-0"></div>
                <button type="button" id="submitRegistrationRequestBtn"
                    class="w-full sm:w-auto px-5 py-3 rounded-xl sm:rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition whitespace-nowrap shadow-lg">
                    Submit Registration
                </button>
            </div>
        </div>
    `;
    initStudentRegistrationPhonePickers();
}

function initStudentRegistrationPhonePickers() {
    if (window.FasIntlPhone) {
        window.FasIntlPhone.init(document.getElementById('studentRegistrationModalBody') || document);
    }
}

// PH Address data for student registration modal
let studentRegPhProvinces = [];
let studentRegPhCities = [];
let studentRegAddressLoaded = false;

async function loadStudentRegAddressData() {
    if (studentRegAddressLoaded) return;
    try {
        const [provRes, cityRes] = await Promise.all([
            fetch('https://raw.githubusercontent.com/darklight721/philippines/master/provinces.json'),
            fetch('https://raw.githubusercontent.com/darklight721/philippines/master/cities.json')
        ]);
        studentRegPhProvinces = provRes.ok ? await provRes.json() : [];
        studentRegPhCities = cityRes.ok ? await cityRes.json() : [];
        studentRegPhProvinces = (Array.isArray(studentRegPhProvinces) ? studentRegPhProvinces : [])
            .filter(r => r && r.key && r.name)
            .sort((a, b) => String(a.name).localeCompare(String(b.name)));
        studentRegPhCities = Array.isArray(studentRegPhCities) ? studentRegPhCities : [];
        studentRegAddressLoaded = true;
    } catch (err) {
        console.error('Failed to load PH address data:', err);
    }
}

function studentRegPopulateSelect(selectEl, items, placeholder) {
    if (!selectEl) return;
    const options = [`<option value="">${placeholder}</option>`];
    items.forEach(item => {
        const val = String(item.value || '').replace(/"/g, '&quot;');
        const lbl = String(item.label || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        options.push(`<option value="${val}">${lbl}</option>`);
    });
    selectEl.innerHTML = options.join('');
}

function studentRegGetSelectText(selectEl) {
    if (!selectEl) return '';
    const option = selectEl.options?.[selectEl.selectedIndex];
    return option && option.value ? option.textContent.trim() : '';
}

function studentRegSyncCityOptions() {
    const provinceSelect = document.getElementById('regProvince');
    const citySelect = document.getElementById('regCity');
    if (!provinceSelect || !citySelect) return;

    const provinceKey = provinceSelect.value;
    const provinceName = studentRegGetSelectText(provinceSelect);
    const cities = provinceKey
        ? studentRegPhCities
            .filter(row => String(row.province || '') === String(provinceKey))
            .map(row => ({ value: row.name, label: row.name }))
            .sort((a, b) => a.label.localeCompare(b.label))
        : [];

    studentRegPopulateSelect(
        citySelect,
        cities,
        provinceKey ? `Select city/municipality in ${provinceName}` : 'Select province first'
    );
    citySelect.disabled = !provinceKey;
}

function studentRegSyncHiddenAddress() {
    const street = document.getElementById('regStreet')?.value.trim() || '';
    const barangay = document.getElementById('regBarangay')?.value.trim() || '';
    const city = studentRegGetSelectText(document.getElementById('regCity'));
    const province = studentRegGetSelectText(document.getElementById('regProvince'));
    const hidden = document.getElementById('regAddress');
    if (hidden) {
        hidden.value = [street, barangay, city, province].filter(Boolean).join(', ');
    }
}

async function initStudentRegistrationAddressCascade() {
    await loadStudentRegAddressData();

    const provinceSelect = document.getElementById('regProvince');
    const citySelect = document.getElementById('regCity');

    if (!provinceSelect || !citySelect) return;

    // Populate provinces
    studentRegPopulateSelect(
        provinceSelect,
        studentRegPhProvinces.map(r => ({ value: r.key, label: r.name })),
        'Select province'
    );

    // Add event listeners
    ['regStreet', 'regBarangay', 'regCity', 'regProvince'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', studentRegSyncHiddenAddress);
            el.addEventListener('change', studentRegSyncHiddenAddress);
        }
    });

    provinceSelect.addEventListener('change', () => {
        studentRegSyncCityOptions();
        studentRegSyncHiddenAddress();
    });

    citySelect.addEventListener('change', studentRegSyncHiddenAddress);

    // Initial sync
    studentRegSyncCityOptions();
    studentRegSyncHiddenAddress();
}

// Global function to show image preview modal
function showImageModal(imageUrl, fileName) {
    // Create modal if it doesn't exist
    let modal = document.getElementById('imagePreviewModal');
    if (!modal) {
        modal = document.createElement('div');
        modal.id = 'imagePreviewModal';
        modal.className = 'fixed inset-0 z-[80] hidden items-center justify-center overflow-hidden bg-black/80 p-3 backdrop-blur-sm sm:p-6';
        modal.setAttribute('role', 'dialog');
        modal.setAttribute('aria-modal', 'true');
        modal.setAttribute('aria-labelledby', 'imagePreviewFileName');
        modal.innerHTML = `
            <div class="flex w-full max-w-4xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-zinc-900" style="max-height: min(90vh, 90dvh);">
                <div class="flex shrink-0 items-center justify-between gap-3 border-b border-zinc-200 px-4 py-3 dark:border-zinc-700">
                    <p id="imagePreviewFileName" class="min-w-0 truncate text-sm font-semibold text-zinc-900 dark:text-white"></p>
                    <button type="button" data-image-preview-close aria-label="Close image preview" class="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-zinc-200 bg-white text-zinc-600 transition hover:bg-zinc-100 focus:outline-none focus:ring-2 focus:ring-gold-500 dark:border-zinc-700 dark:bg-zinc-800 dark:text-white dark:hover:bg-zinc-700">
                        <i class="fas fa-times text-base" aria-hidden="true"></i>
                    </button>
                </div>
                <div class="flex min-h-0 flex-1 items-center justify-center overflow-hidden bg-zinc-100 p-3 dark:bg-zinc-800 sm:p-5">
                    <img id="imagePreviewImg" src="" alt="Preview" class="block h-auto w-auto max-w-full object-contain" style="max-height: calc(min(90vh, 90dvh) - 5.5rem);" />
                </div>
            </div>
        `;
        document.body.appendChild(modal);

        // Close on backdrop click
        modal.addEventListener('click', (e) => {
            if (e.target === modal || e.target.closest('[data-image-preview-close]')) closeImagePreviewModal();
        });
    }

    // Update modal content
    const img = document.getElementById('imagePreviewImg');
    const fileNameEl = document.getElementById('imagePreviewFileName');
    if (img) img.src = imageUrl;
    if (fileNameEl) fileNameEl.textContent = fileName;

    // Show modal
    modal.classList.remove('hidden');
    modal.classList.add('flex');
    modal.dataset.previousBodyOverflow = document.body.style.overflow || '';
    document.body.style.overflow = 'hidden';
    modal.querySelector('[data-image-preview-close]')?.focus({ preventScroll: true });
}

function closeImagePreviewModal() {
    const modal = document.getElementById('imagePreviewModal');
    if (!modal || modal.classList.contains('hidden')) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    document.body.style.overflow = modal.dataset.previousBodyOverflow || '';
    delete modal.dataset.previousBodyOverflow;
}

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !document.getElementById('imagePreviewModal')?.classList.contains('hidden')) {
        closeImagePreviewModal();
    }
});

function renderStudentActionBanner(student, meta, portal) {
    const banner = document.getElementById('studentActionBanner');
    const titleEl = document.getElementById('studentActionBannerTitle');
    const textEl = document.getElementById('studentActionBannerText');
    const buttonsEl = document.getElementById('studentActionBannerButtons');
    if (!banner || !titleEl || !textEl || !buttonsEl) return;

    const profileComplete = isRegistrationProfileComplete(student);
    const regStatus = String(student?.registration_status || 'Pending');
    const isRejected = regStatus === 'Rejected';
    const regPaid = ['Approved', 'Fee Paid'].includes(regStatus);
    const latestReq = meta?.latest_request || null;
    const hasPendingReq = latestReq && String(latestReq.status || '') === 'Pending';
    const enrollmentApproved = portal?.current_enrollment && String(portal.current_enrollment.status || '') === 'Active';
    const enrollmentCompleted = isStudentEnrollmentCompleted(portal);
    const reservationNotice = getScheduleFreezeReservationNotice(portal?.current_enrollment || null);

    if (enrollmentApproved && !reservationNotice && !enrollmentCompleted) {
        banner.classList.add('hidden');
        return;
    }

    let title = 'Complete your registration';
    let text = '';
    let actions = `
        <button type="button" onclick="openStudentRegistrationModal()" class="px-5 py-3 rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition">Register</button>
        <a href="student_profile.html" class="px-5 py-3 rounded-2xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-800 dark:text-zinc-100 text-sm font-semibold transition">Profile</a>
    `;

    if (enrollmentCompleted) {
        title = 'Your purchased lessons have been used';
        text = 'Your level and learning progress stay unchanged. Request additional sessions from Enrollment Details when you are ready to continue.';
        actions = `
            <a href="student_profile.html#studentAdditionalSessionsCard" class="px-5 py-3 rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition flex items-center gap-2">
                <i class="fas fa-calendar-plus"></i>Request Additional Sessions
            </a>
            <a href="student_sessions.html" class="px-5 py-3 rounded-2xl bg-white/90 dark:bg-white/5 border border-gold-200 dark:border-white/10 text-zinc-800 dark:text-zinc-100 text-sm font-semibold transition">View Used Lessons</a>
        `;
    } else if (reservationNotice) {
        title = 'Your account is frozen';
        text = `You have ${reservationNotice.usedAbsences} recorded absence${reservationNotice.usedAbsences === 1 ? '' : 's'}. Pay the ₱${reservationNotice.amount} slot reservation fee to restore access.`;

        // Store enrollment info on window for the pay modal
        window.__freezeEnrollmentId = Number(portal?.current_enrollment?.enrollment_id || 0);
        window.__freezeStudentId    = Number(student?.student_id || 0);
        window.__freezeAmount       = reservationNotice.amount;

        // Check if there's already a pending payment submission
        const pendingPayment = portal?.current_enrollment?.__freeze_payment_status;
        if (pendingPayment === 'Pending') {
            actions = `
                <span class="inline-flex items-center gap-2 px-5 py-3 rounded-2xl bg-amber-100 border border-amber-300 text-amber-800 text-sm font-bold">
                    <i class="fas fa-clock"></i> Payment Pending Approval
                </span>
                <a href="student_attendance.html" class="px-5 py-3 rounded-2xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-800 dark:text-zinc-100 text-sm font-semibold transition">Attendance</a>
            `;
        } else if (pendingPayment === 'Rejected') {
            actions = `
                <button type="button" onclick="openFreezePaymentModal()" class="px-5 py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-sm font-extrabold transition flex items-center gap-2">
                    <i class="fas fa-snowflake"></i> Pay Again — ₱${reservationNotice.amount}
                </button>
                <span class="text-xs text-rose-500 font-semibold self-center">Previous payment was rejected.</span>
            `;
        } else {
            actions = `
                <button type="button" onclick="openFreezePaymentModal()" class="px-5 py-3 rounded-2xl bg-rose-600 hover:bg-rose-500 text-white text-sm font-extrabold transition flex items-center gap-2">
                    <i class="fas fa-snowflake"></i> Pay Now — ₱${reservationNotice.amount}
                </button>
                <a href="student_attendance.html" class="px-5 py-3 rounded-2xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-800 dark:text-zinc-100 text-sm font-semibold transition">View Attendance</a>
            `;
        }
        // Make the banner visually distinct for frozen state
        banner.className = banner.className.replace('bg-amber-50', 'bg-rose-50').replace('dark:bg-gold-500/10', 'dark:bg-rose-500/10').replace('border-gold-500/25', 'border-rose-400/40');
    } else if (isRejected) {
        title = 'Registration was rejected';
        text = 'Open the form to try again.';
        actions = `<button type="button" onclick="openStudentRegistrationModal()" class="px-5 py-3 rounded-2xl bg-red-500 hover:bg-red-400 text-white text-sm font-extrabold transition">Register Again</button>`;
    } else if (profileComplete && !regPaid) {
        title = 'Waiting for approval';
        text = 'Your registration is being reviewed.';
        actions = `<button type="button" onclick="openStudentRegistrationModal()" class="px-5 py-3 rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition">Check Status</button>`;
    } else if (profileComplete && regPaid && hasPendingReq) {
        title = 'Class request sent';
        const requestDate = latestReq.preferred_date ? formatDateLong(latestReq.preferred_date) : (latestReq.preferred_day_of_week || 'your preferred date');
        const requestStart = latestReq.preferred_start_time ? formatTime12Hour(latestReq.preferred_start_time) : '';
        const requestEnd = latestReq.preferred_end_time ? formatTime12Hour(latestReq.preferred_end_time) : '';
        const requestTime = requestStart && requestEnd ? `, ${requestStart} - ${requestEnd}` : '';
        text = `Requested: ${requestDate}${requestTime}. The desk will confirm it or adjust it if there is a conflict.`;
        actions = `
            <button type="button" onclick="openStudentRequestModal()" class="px-5 py-3 rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition">View Request</button>
            <a href="student_sessions.html" class="px-5 py-3 rounded-2xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-800 dark:text-zinc-100 text-sm font-semibold transition">Sessions</a>
        `;
    } else if (profileComplete && regPaid) {
        title = 'Request your classes';
        text = 'Choose your package and instrument.';
        actions = `
            <button type="button" onclick="openStudentRequestModal()" class="px-5 py-3 rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition">Request Classes</button>
            <a href="student_sessions.html" class="px-5 py-3 rounded-2xl bg-white dark:bg-white/5 border border-zinc-200 dark:border-white/10 text-zinc-800 dark:text-zinc-100 text-sm font-semibold transition">Sessions</a>
        `;
    }

    titleEl.textContent = title;
    if (text) {
        textEl.textContent = text;
        textEl.classList.remove('hidden');
    } else {
        textEl.textContent = '';
        textEl.classList.add('hidden');
    }
    buttonsEl.innerHTML = actions;
    banner.classList.remove('hidden');
}

function renderStudentOnboardingSteps(student, meta, portal) {
    const container = document.getElementById('studentOnboardingSteps');
    if (!container) return;

    const profileComplete = isRegistrationProfileComplete(student);
    const regStatus = String(student?.registration_status || 'Pending');
    const isRejected = regStatus === 'Rejected';
    const regPaid = ['Approved', 'Fee Paid'].includes(regStatus);
    const latestReq = meta?.latest_request || null;
    const hasPendingReq = latestReq && String(latestReq.status || '') === 'Pending';
    const enrollmentApproved = portal?.current_enrollment && String(portal.current_enrollment.status || '') === 'Active';
    const registrationLocked = !profileComplete || !regPaid;

    // Determine which step is active (1 = details, 2 = pay, 3 = request classes)
    const currentStep = isRejected ? 1 : !profileComplete ? 1 : !regPaid ? 2 : !enrollmentApproved ? 3 : 0;

    // Step progress dots
    const stepDots = [1, 2, 3].map(n => {
        const done = n < currentStep;
        const active = n === currentStep;
        return `<div class="flex items-center gap-1.5">
            <div class="w-2.5 h-2.5 rounded-full transition-all ${done ? 'bg-emerald-500' : active ? 'bg-gold-500 ring-4 ring-gold-500/20' : 'bg-zinc-300 dark:bg-zinc-600'}"></div>
            ${n < 3 ? '<div class="w-6 h-px ' + (done ? 'bg-emerald-400' : 'bg-zinc-300 dark:bg-zinc-600') + '"></div>' : ''}
        </div>`;
    }).join('');

    // Build the active step card content
    let cardIcon = '', cardTitle = '', cardDesc = '', cardCta = '', cardNote = '';

    if (currentStep === 1 && isRejected) {
        cardIcon = '<i class="fas fa-exclamation-circle text-2xl text-red-500"></i>';
        cardTitle = 'Registration Rejected';
        cardDesc = 'Your registration was rejected. Please review your details and resubmit.';
        cardCta = `<button type="button" onclick="openStudentRegistrationModal()" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-red-500 hover:bg-red-400 text-white font-bold transition">Restart Registration</button>`;
        cardNote = '';
    } else if (currentStep === 1) {
        cardIcon = '<i class="fas fa-user-edit text-2xl text-gold-500"></i>';
        cardTitle = 'Complete your details';
        cardDesc = 'Fill in your personal information to begin the enrollment process.';
        cardCta = `<button type="button" onclick="openStudentRegistrationModal()" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-gold-500 hover:bg-gold-400 text-black font-bold transition">Open Registration</button>`;
        cardNote = '<span class="text-zinc-400 dark:text-zinc-500 text-xs">Next: Pay the registration fee</span>';
    } else if (currentStep === 2) {
        cardIcon = '<i class="fas fa-credit-card text-2xl text-gold-500"></i>';
        cardTitle = 'Pay the registration fee';
        cardDesc = 'Upload your proof of payment so the school can approve your registration.';
        cardCta = `<button type="button" onclick="openStudentRegistrationModal()" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-gold-500 hover:bg-gold-400 text-black font-bold transition">Open Payment Step</button>`;
        cardNote = '<span class="text-zinc-400 dark:text-zinc-500 text-xs">Next: Request your classes</span>';
    } else if (currentStep === 3) {
        cardIcon = '<i class="fas fa-calendar-check text-2xl text-gold-500"></i>';
        cardTitle = hasPendingReq ? 'Request submitted — waiting for approval' : 'Request your classes';
        cardDesc = hasPendingReq
            ? 'Your class request is under review. The school will contact you soon.'
            : 'Choose your lesson package and preferred instrument to start classes.';
        cardCta = hasPendingReq
            ? `<button type="button" onclick="openStudentRequestModal()" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-zinc-100 dark:bg-white/10 text-zinc-700 dark:text-white font-bold transition">View Request</button>`
            : `<button type="button" onclick="openStudentRequestModal()" class="w-full sm:w-auto px-6 py-3 rounded-xl bg-gold-500 hover:bg-gold-400 text-black font-bold transition">Request Classes</button>`;
        cardNote = latestReq ? `<div class="mt-3 w-full">${renderStudentRequestStatus(latestReq)}</div>` : '';
    } else {
        // All complete - show compact summary
        container.innerHTML = `
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400">
                <i class="fas fa-check-circle text-lg"></i>
                <span class="text-sm font-semibold">All steps complete — you're enrolled!</span>
                <a href="student_sessions.html" class="ml-auto text-xs font-bold underline underline-offset-2 whitespace-nowrap">View Sessions</a>
            </div>
        `;
        return;
    }

    // All steps list (collapsed by default, toggled via button)
    const allStepsList = `
        <div id="allOnboardingSteps" class="hidden mt-4 space-y-2 border-t border-zinc-200 dark:border-white/10 pt-4">
            <!-- Step 1 -->
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl ${currentStep > 1 ? 'bg-emerald-500/8 border border-emerald-500/15' : currentStep === 1 ? 'bg-gold-500/10 border border-gold-500/25' : 'bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-white/10 opacity-50'}">
                <div class="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${currentStep > 1 ? 'bg-emerald-500' : currentStep === 1 ? 'bg-gold-500' : 'bg-zinc-300 dark:bg-zinc-600'}">
                    ${currentStep > 1 ? '<i class="fas fa-check text-white text-[10px]"></i>' : '<span class="text-white text-[10px] font-black">1</span>'}
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-bold text-zinc-900 dark:text-white">Complete your details</div>
                </div>
                ${currentStep > 1 ? renderOnboardingStatusBadge('Done', 'green') : currentStep === 1 ? renderOnboardingStatusBadge('Do This First', 'amber') : ''}
            </div>
            <!-- Step 2 -->
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl ${currentStep > 2 ? 'bg-emerald-500/8 border border-emerald-500/15' : currentStep === 2 ? 'bg-gold-500/10 border border-gold-500/25' : 'bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-white/10 opacity-50'}">
                <div class="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${currentStep > 2 ? 'bg-emerald-500' : currentStep === 2 ? 'bg-gold-500' : 'bg-zinc-300 dark:bg-zinc-600'}">
                    ${currentStep > 2 ? '<i class="fas fa-check text-white text-[10px]"></i>' : '<span class="text-white text-[10px] font-black">2</span>'}
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-bold text-zinc-900 dark:text-white">Pay registration fee</div>
                </div>
                ${currentStep > 2 ? renderOnboardingStatusBadge('Approved', 'green') : currentStep === 2 ? renderOnboardingStatusBadge('Waiting', 'amber') : ''}
            </div>
            <!-- Step 3 -->
            <div class="flex items-center gap-3 px-4 py-3 rounded-xl ${currentStep > 3 ? 'bg-emerald-500/8 border border-emerald-500/15' : currentStep === 3 ? 'bg-gold-500/10 border border-gold-500/25' : 'bg-zinc-50 dark:bg-zinc-800 border border-zinc-200 dark:border-white/10 opacity-50'}">
                <div class="flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center ${currentStep > 3 ? 'bg-emerald-500' : currentStep === 3 ? 'bg-gold-500' : 'bg-zinc-300 dark:bg-zinc-600'}">
                    ${currentStep > 3 ? '<i class="fas fa-check text-white text-[10px]"></i>' : '<span class="text-white text-[10px] font-black">3</span>'}
                </div>
                <div class="flex-1 min-w-0">
                    <div class="text-sm font-bold text-zinc-900 dark:text-white">Request classes</div>
                </div>
                ${enrollmentApproved ? renderOnboardingStatusBadge('Approved', 'green') : hasPendingReq ? renderOnboardingStatusBadge('Sent', 'blue') : currentStep === 3 ? renderOnboardingStatusBadge('Unlock Now', 'amber') : renderOnboardingStatusBadge('Locked', 'zinc')}
            </div>
        </div>
    `;

    container.innerHTML = `
        <div>
            <!-- Progress indicator -->
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center gap-1">${stepDots}</div>
                <span class="text-xs font-semibold text-zinc-400 dark:text-zinc-500">Step ${currentStep} of 3</span>
            </div>

            <!-- Active step card -->
            <div class="rounded-2xl border-2 ${isRejected ? 'border-red-400 bg-red-50/40 dark:bg-red-500/5' : 'border-gold-400/60 bg-gradient-to-br from-white to-gold-50/30 dark:from-white/5 dark:to-gold-500/5'} p-5 sm:p-6">
                <div class="flex flex-col sm:flex-row sm:items-start gap-4">
                    <div class="flex-shrink-0 w-12 h-12 rounded-2xl ${isRejected ? 'bg-red-100 dark:bg-red-500/10' : 'bg-gold-100 dark:bg-gold-500/10'} flex items-center justify-center">
                        ${cardIcon}
                    </div>
                    <div class="flex-1 min-w-0">
                        <h3 class="text-lg font-extrabold text-zinc-900 dark:text-white leading-snug">${cardTitle}</h3>
                        <p class="text-sm text-zinc-500 dark:text-zinc-400 mt-1">${cardDesc}</p>
                        <div class="mt-4 flex flex-wrap items-center gap-3">
                            ${cardCta}
                            ${cardNote}
                        </div>
                    </div>
                </div>
            </div>

            <!-- Toggle all steps -->
            <div class="mt-3 text-center">
                <button
                    type="button"
                    onclick="
                        const el = document.getElementById('allOnboardingSteps');
                        const btn = this;
                        if (el.classList.contains('hidden')) {
                            el.classList.remove('hidden');
                            btn.textContent = 'Hide steps';
                        } else {
                            el.classList.add('hidden');
                            btn.textContent = 'View all steps';
                        }
                    "
                    class="text-xs font-semibold text-zinc-400 dark:text-zinc-500 hover:text-zinc-600 dark:hover:text-zinc-300 transition underline underline-offset-2"
                >View all steps</button>
            </div>

            ${allStepsList}
        </div>
    `;
}

function wireStudentOnboardingActions(student, meta, portal) {
    const guardianAutoStatus = document.getElementById('guardianAutoStatus');
    const guardianInputs = document.getElementById('guardianInputs');
    const guardianFirstNameInput = document.getElementById('guardianFirstNameInput');
    const guardianLastNameInput = document.getElementById('guardianLastNameInput');
    const guardianPhoneInput = document.getElementById('guardianPhoneInput');
    const guardianRelationshipInput = document.getElementById('guardianRelationshipInput');
    const guardianEmailInput = document.getElementById('guardianEmailInput');
    const guardianCopyEmailBtn = document.getElementById('guardianCopyEmailBtn');
    const guardianFindBtn = document.getElementById('guardianFindBtn');
    const guardianInfoBox = document.getElementById('guardianInfoBox');
    const regForm = document.getElementById('registrationDetailsForm');
    const regBranchDisplay = document.getElementById('regBranchDisplay');
    const paymentForm = document.getElementById('registrationPaymentForm');
    const regPayStatus = document.getElementById('regPayStatus');
    const regPayReference = document.getElementById('regPayReference');
    const regPayReferenceHint = document.getElementById('regPayReferenceHint');
    const regPayProof = document.getElementById('regPayProof');
    const regAgeProof = document.getElementById('regAgeProof');
    const submitAllBtn = document.getElementById('submitRegistrationRequestBtn');
    const submitAllStatus = document.getElementById('submitRegistrationStatus');

    const hasGuardian = Array.isArray(portal?.guardians) && portal.guardians.length > 0;
    const getCurrentAge = () => computeAgeFromDob(document.getElementById('regDob')?.value || '');
    const isGuardianRequired = () => {
        const age = getCurrentAge();
        return age !== null && age <= 18;
    };
    const syncGuardianState = () => {
        const mustHaveGuardian = isGuardianRequired();
        if (guardianInputs) guardianInputs.classList.toggle('hidden', !mustHaveGuardian);
        if (guardianInfoBox) guardianInfoBox.classList.toggle('hidden', !mustHaveGuardian);
        const badge = document.getElementById('guardianRequiredBadge');
        if (badge) badge.classList.toggle('hidden', !mustHaveGuardian);
        if (guardianAutoStatus) {
            guardianAutoStatus.classList.toggle('hidden', mustHaveGuardian);
            if (!mustHaveGuardian) {
                if (getCurrentAge() === null) {
                    guardianAutoStatus.textContent = "Enter the student's date of birth above — guardian fields appear automatically for students 18 and under.";
                } else {
                    guardianAutoStatus.textContent = 'Guardian details are not required because the student is above 18 years old.';
                }
            }
        }
        if (!mustHaveGuardian) {
            if (guardianEmailInput) guardianEmailInput.value = '';
            if (guardianFirstNameInput) guardianFirstNameInput.value = '';
            if (guardianLastNameInput) guardianLastNameInput.value = '';
            if (guardianPhoneInput) window.FasIntlPhone?.reset(guardianPhoneInput);
            if (guardianRelationshipInput) guardianRelationshipInput.value = '';
            if (guardianInfoBox) guardianInfoBox.textContent = '';
        }
    };

    if (guardianEmailInput && portal?.guardians?.[0]?.email) {
        const g = portal.guardians[0];
        guardianEmailInput.value = g.email || '';
        if (guardianFirstNameInput) guardianFirstNameInput.value = g.first_name || '';
        if (guardianLastNameInput) guardianLastNameInput.value = g.last_name || '';
        if (guardianPhoneInput) window.FasIntlPhone?.setValue(guardianPhoneInput, g.phone || '');
        if (guardianRelationshipInput) guardianRelationshipInput.value = g.relationship_type || '';
    }

    if (guardianFindBtn && guardianEmailInput && guardianInfoBox) {
        guardianFindBtn.onclick = async () => {
            const email = guardianEmailInput.value.trim();
            if (!email) {
                guardianInfoBox.textContent = 'Enter a guardian email to search.';
                return;
            }
            guardianInfoBox.textContent = 'Searching guardian...';
            const res = await fetchGuardianByEmail(email);
            if (res.success && res.guardian) {
                const g = res.guardian;
                guardianInfoBox.innerHTML = `Found: <span class="font-semibold">${escapeHtml(g.first_name || '')} ${escapeHtml(g.last_name || '')}</span> • ${escapeHtml(g.relationship_type || '')} • ${escapeHtml(g.phone || '')}`;
                if (guardianFirstNameInput) guardianFirstNameInput.value = g.first_name || '';
                if (guardianLastNameInput) guardianLastNameInput.value = g.last_name || '';
                if (guardianPhoneInput) window.FasIntlPhone?.setValue(guardianPhoneInput, g.phone || '');
                if (guardianRelationshipInput) guardianRelationshipInput.value = g.relationship_type || '';
            } else {
                guardianInfoBox.textContent = res.error || 'Guardian not found.';
            }
        };
    }

    if (guardianCopyEmailBtn && guardianEmailInput) {
        guardianCopyEmailBtn.onclick = async () => {
            const email = guardianEmailInput.value.trim();
            if (!email) {
                showMessage('Enter the guardian email first.', 'error');
                guardianEmailInput.focus();
                return;
            }
            try {
                await navigator.clipboard.writeText(email);
                showMessage('Guardian email copied.', 'success');
            } catch (error) {
                guardianEmailInput.select();
                document.execCommand('copy');
                showMessage('Guardian email copied.', 'success');
            }
        };
    }

    if (regBranchDisplay) {
        regBranchDisplay.textContent = student?.branch_name || 'Assigned branch';
    }

    // Prefill registration fields from current student record
    const regFirstName = document.getElementById('regFirstName');
    const regLastName = document.getElementById('regLastName');
    const regMiddleName = document.getElementById('regMiddleName');
    const regEmail = document.getElementById('regEmail');
    const regPhone = document.getElementById('regPhone');
    const regDob = document.getElementById('regDob');
    const regAddress = document.getElementById('regAddress');
    if (regFirstName && !regFirstName.value) regFirstName.value = student?.first_name || '';
    if (regLastName && !regLastName.value) regLastName.value = student?.last_name || '';
    if (regMiddleName && !regMiddleName.value) regMiddleName.value = student?.middle_name || '';
    if (regEmail && !regEmail.value) regEmail.value = student?.email || '';
    if (regPhone && !regPhone.value) window.FasIntlPhone?.setValue(regPhone, student?.phone || '');
    if (regDob && !regDob.value) regDob.value = student?.date_of_birth || '';
    if (regAddress && !regAddress.value) regAddress.value = student?.address || '';

    // Initialize PH address cascade for student registration
    initStudentRegistrationAddressCascade();

    if (regForm) {
        regForm.onsubmit = (e) => e.preventDefault();
    }

    const regAge = document.getElementById('regAge');
    if (regDob && regAge) {
        const updateAge = () => {
            const age = computeAgeFromDob(regDob.value || '');
            regAge.value = age === null ? '' : String(age);

            // Date validation with red indicator
            const dobValue = regDob.value;
            if (dobValue) {
                const dobDate = new Date(dobValue);
                const today = new Date();
                const minDate = new Date(1900, 0, 1);

                // Check if date is valid and within reasonable range
                if (isNaN(dobDate.getTime()) || dobDate > today || dobDate < minDate) {
                    regDob.classList.add('!border-red-500', 'dark:!border-red-500');
                    regAge.classList.add('!border-red-500', 'dark:!border-red-500');
                } else if (age !== null && age < 3) {
                    // Minimum age 3 years old
                    regDob.classList.add('!border-red-500', 'dark:!border-red-500');
                    regAge.classList.add('!border-red-500', 'dark:!border-red-500');
                } else {
                    regDob.classList.remove('!border-red-500', 'dark:!border-red-500');
                    regAge.classList.remove('!border-red-500', 'dark:!border-red-500');
                }
            } else {
                regDob.classList.remove('!border-red-500', 'dark:!border-red-500');
                regAge.classList.remove('!border-red-500', 'dark:!border-red-500');
            }

            syncGuardianState();
        };
        regDob.addEventListener('change', updateAge);
        regDob.addEventListener('input', updateAge);
        updateAge();
    } else {
        syncGuardianState();
    }

    if (paymentForm) {
        paymentForm.onsubmit = (e) => e.preventDefault();
    }

    const updateRegistrationReferenceUI = () => {
        const method = String(document.getElementById('regPayMethod')?.value || 'Other').trim();
        if (!regPayReference || !regPayReferenceHint) return;
        const isCash = method === 'Cash';
        regPayReference.placeholder = isCash
            ? 'Enter official receipt or transaction number'
            : `Enter ${method || 'payment'} reference number`;
        regPayReferenceHint.textContent = isCash
            ? 'For cash payments, enter the official receipt or transaction number.'
            : 'Required together with the uploaded proof of payment.';
    };
    document.getElementById('regPayMethod')?.addEventListener('change', updateRegistrationReferenceUI);
    updateRegistrationReferenceUI();

    if (submitAllBtn) {
        submitAllBtn.onclick = async () => {
            const guardianRequired = isGuardianRequired();
            if (guardianRequired) {
                if (!guardianEmailInput?.value?.trim()) {
                    showMessage('Guardian email is required.', 'error');
                    return;
                }
                if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(guardianEmailInput.value.trim())) {
                    showMessage('Enter a valid guardian email address.', 'error');
                    guardianEmailInput.focus();
                    return;
                }
                if (!guardianFirstNameInput?.value?.trim() || !guardianLastNameInput?.value?.trim() || !(window.FasIntlPhone?.getValue(guardianPhoneInput) || guardianPhoneInput?.value?.trim()) || !guardianRelationshipInput?.value?.trim()) {
                    showMessage('Guardian name, phone, and relationship are required.', 'error');
                    return;
                }
            }

            const payload = {
                action: 'update-student',
                student_id: Number(student.student_id),
                first_name: document.getElementById('regFirstName')?.value?.trim() || '',
                last_name: document.getElementById('regLastName')?.value?.trim() || '',
                middle_name: document.getElementById('regMiddleName')?.value?.trim() || '',
                email: document.getElementById('regEmail')?.value?.trim() || '',
                phone: window.FasIntlPhone?.getValue(document.getElementById('regPhone')) || document.getElementById('regPhone')?.value?.trim() || '',
                address: document.getElementById('regAddress')?.value?.trim() || '',
                date_of_birth: document.getElementById('regDob')?.value || null,
                branch_id: Number(student?.branch_id || 0)
            };
            payload.age = computeAgeFromDob(payload.date_of_birth);

            const amount = 1000;
            const method = document.getElementById('regPayMethod')?.value || 'Other';
            const referenceNumber = regPayReference?.value?.trim() || '';
            const proofFile = regPayProof?.files && regPayProof.files[0] ? regPayProof.files[0] : null;
            const ageProofFile = regAgeProof?.files && regAgeProof.files[0] ? regAgeProof.files[0] : null;

            if (!isRegistrationProfileComplete(payload)) {
                showMessage('Please complete all required registration details.', 'error');
                return;
            }
            if (!proofFile) {
                showMessage('Upload proof of payment for admin approval.', 'error');
                return;
            }
            if (!referenceNumber) {
                showMessage('Enter the payment reference number for admin approval.', 'error');
                return;
            }
            if (!ageProofFile) {
                showMessage('Upload proof ID for age verification.', 'error');
                return;
            }

            submitAllBtn.disabled = true;
            submitAllBtn.textContent = 'Submitting...';
            if (submitAllStatus) submitAllStatus.textContent = 'Submitting registration request...';
            if (regPayStatus) regPayStatus.textContent = '';

            try {
                if (guardianRequired) {
                    const details = {
                        first_name: guardianFirstNameInput?.value?.trim() || '',
                        last_name: guardianLastNameInput?.value?.trim() || '',
                        phone: window.FasIntlPhone?.getValue(guardianPhoneInput) || guardianPhoneInput?.value?.trim() || '',
                        relationship: guardianRelationshipInput?.value?.trim() || ''
                    };

                    const guardianEmail = guardianEmailInput?.value?.trim() || '';
                    const guardianConfirm = await Swal.fire({
                        icon: 'question',
                        title: 'Create guardian account',
                        html: `
                            <div class="text-left text-sm leading-6">
                                <p>You are creating a new guardian account for this student.</p>
                                <p class="mt-2">Guardian contact email: <strong>${escapeHtml(guardianEmail)}</strong></p>
                                <p class="mt-2">After you continue, we will save the guardian details and show the login information on the next screen.</p>
                                <p class="mt-2">The student and guardian will each have their own login details. Please write them down or keep them safe.</p>
                                <p class="mt-2">The guardian will set their own password before continuing.</p>
                            </div>
                        `,
                        showCancelButton: true,
                        confirmButtonText: 'Yes, create it',
                        cancelButtonText: 'Cancel',
                        confirmButtonColor: '#b8860b',
                        cancelButtonColor: '#6b7280'
                    });

                    if (!guardianConfirm.isConfirmed) {
                        return;
                    }

             const customPasswordResult = await Swal.fire({
    icon: 'question',
    title: 'Create guardian password',
    html: `
        <div class="text-left text-sm leading-6">
            <p>Enter a new password for the guardian account.</p>
            <p class="mt-2 text-xs text-zinc-500">
                Use at least 8 characters with uppercase, lowercase, a number, and a special character.
            </p>
        </div>

        <!-- New Password -->
        <div class="relative mt-4">
            <input
                id="guardian-custom-password"
                class="swal2-input !m-0 !w-full !pr-12"
                type="password"
                placeholder="New password"
            >

            <button
                type="button"
                id="toggle-guardian-password"
                class="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-700"
            >
                <i class="fas fa-eye"></i>
            </button>
        </div>

        <!-- Password Strength -->
        <div class="mt-2 text-left">
            <div class="flex gap-1">
                <div id="strength-bar-1" class="h-1 flex-1 rounded bg-zinc-200"></div>
                <div id="strength-bar-2" class="h-1 flex-1 rounded bg-zinc-200"></div>
                <div id="strength-bar-3" class="h-1 flex-1 rounded bg-zinc-200"></div>
                <div id="strength-bar-4" class="h-1 flex-1 rounded bg-zinc-200"></div>
            </div>

            <p
                id="password-strength-text"
                class="mt-1 text-xs text-zinc-500"
            >
                Password strength
            </p>
        </div>

        <!-- Confirm Password -->
        <div class="relative mt-3">
            <input
                id="guardian-custom-password-confirm"
                class="swal2-input !m-0 !w-full !pr-12"
                type="password"
                placeholder="Confirm password"
            >

            <button
                type="button"
                id="toggle-guardian-password-confirm"
                class="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-700"
            >
                <i class="fas fa-eye"></i>
            </button>
        </div>

        <!-- Password Match Status -->
        <p
            id="password-match-text"
            class="mt-2 text-left text-xs"
        ></p>
    `,

    focusConfirm: false,
    showCancelButton: true,
    confirmButtonText: 'Create Password',
    cancelButtonText: 'Go Back',
    confirmButtonColor: '#b8860b',
    cancelButtonColor: '#6b7280',

    didOpen: () => {
        const passwordInput = document.getElementById(
            'guardian-custom-password'
        );

        const confirmInput = document.getElementById(
            'guardian-custom-password-confirm'
        );

        const strengthText = document.getElementById(
            'password-strength-text'
        );

        const matchText = document.getElementById(
            'password-match-text'
        );

        const bars = [
            document.getElementById('strength-bar-1'),
            document.getElementById('strength-bar-2'),
            document.getElementById('strength-bar-3'),
            document.getElementById('strength-bar-4')
        ];

        // Password visibility toggle
        const setupPasswordToggle = (inputId, buttonId) => {
            const input = document.getElementById(inputId);
            const button = document.getElementById(buttonId);
            const icon = button.querySelector('i');

            button.addEventListener('click', () => {
                const isPassword = input.type === 'password';

                input.type = isPassword ? 'text' : 'password';

                icon.classList.toggle('fa-eye', !isPassword);
                icon.classList.toggle('fa-eye-slash', isPassword);
            });
        };

        setupPasswordToggle(
            'guardian-custom-password',
            'toggle-guardian-password'
        );

        setupPasswordToggle(
            'guardian-custom-password-confirm',
            'toggle-guardian-password-confirm'
        );

        // Password strength checker
        const checkStrength = () => {
            const password = passwordInput.value;

            let score = 0;

            if (password.length >= 8) score++;
            if (/[A-Z]/.test(password)) score++;
            if (/[a-z]/.test(password)) score++;
            if (/[0-9]/.test(password)) score++;
            if (/[!@#$%^&*]/.test(password)) score++;

            // Reset bars
            bars.forEach(bar => {
                bar.className =
                    'h-1 flex-1 rounded bg-zinc-200';
            });

            if (!password) {
                strengthText.textContent = 'Password strength';
                strengthText.className =
                    'mt-1 text-xs text-zinc-500';
                return;
            }

            if (score <= 2) {
                strengthText.textContent = 'Weak password';
                strengthText.className =
                    'mt-1 text-xs text-red-500';

                bars[0].classList.replace(
                    'bg-zinc-200',
                    'bg-red-500'
                );

            } else if (score <= 4) {
                strengthText.textContent = 'Medium password';
                strengthText.className =
                    'mt-1 text-xs text-yellow-600';

                bars.slice(0, 3).forEach(bar => {
                    bar.classList.replace(
                        'bg-zinc-200',
                        'bg-yellow-500'
                    );
                });

            } else {
                strengthText.textContent = 'Strong password';
                strengthText.className =
                    'mt-1 text-xs text-green-600';

                bars.forEach(bar => {
                    bar.classList.replace(
                        'bg-zinc-200',
                        'bg-green-500'
                    );
                });
            }
        };

        // Password match checker
        const checkMatch = () => {
            const password = passwordInput.value;
            const confirmPassword = confirmInput.value;

            if (!confirmPassword) {
                matchText.textContent = '';
                return;
            }

            if (password === confirmPassword) {
                matchText.innerHTML = `
                    <i class="fas fa-check-circle"></i>
                    Passwords match
                `;

                matchText.className =
                    'mt-2 text-left text-xs text-green-600';

            } else {
                matchText.innerHTML = `
                    <i class="fas fa-times-circle"></i>
                    Passwords do not match
                `;

                matchText.className =
                    'mt-2 text-left text-xs text-red-500';
            }
        };

        passwordInput.addEventListener('input', () => {
            checkStrength();
            checkMatch();
        });

        confirmInput.addEventListener('input', checkMatch);
    },

    preConfirm: () => {
        const pass1 =
            document.getElementById('guardian-custom-password')?.value || '';

        const pass2 =
            document.getElementById(
                'guardian-custom-password-confirm'
            )?.value || '';

        if (!pass1 || !pass2) {
            Swal.showValidationMessage(
                'Please fill in both password fields.'
            );
            return false;
        }

        if (pass1 !== pass2) {
            Swal.showValidationMessage(
                'Passwords do not match.'
            );
            return false;
        }

        if (
            pass1.length < 8 ||
            !/[A-Z]/.test(pass1) ||
            !/[a-z]/.test(pass1) ||
            !/[0-9]/.test(pass1) ||
            !/[!@#$%^&*]/.test(pass1)
        ) {
            Swal.showValidationMessage(
                'Password does not meet the requirements.'
            );
            return false;
        }

        return pass1;
    }
});

                    if (!customPasswordResult.isConfirmed) {
                        return;
                    }

                    const guardianPasswordMode = 'custom';
                    const guardianPassword = String(customPasswordResult.value || '');

                    const resGuardian = await setGuardianMode(student.student_id, 'With Guardian', guardianEmail, {
                        ...details,
                        password_mode: guardianPasswordMode,
                        password: guardianPassword
                    });
                    if (!resGuardian?.success) {
                        throw new Error(resGuardian?.error || 'Failed to save guardian details.');
                    }
                    if (resGuardian?.message) {
                        const combinedMessage = resGuardian.mail_error
                            ? `${resGuardian.message} Mail notice: ${resGuardian.mail_error}`
                            : resGuardian.message;
                        showMessage(combinedMessage, resGuardian.mail_error || resGuardian.guardian_login_generated ? 'info' : 'success');
                    }
                    if (resGuardian?.student_login_identifier || resGuardian?.guardian_username) {
                        const studentLoginId = resGuardian.student_login_identifier || 'Not available';
                        const guardianLogin = resGuardian.guardian_username || guardianEmail;
                        const guardianPasswordText = resGuardian.guardian_temporary_password || 'Not available';
                        await Swal.fire({
                            icon: 'info',
                            title: 'Login Credentials',
                            width: 500,
                            confirmButtonText: 'Got it',
                            confirmButtonColor: '#b8860b',
                            html: `
                                <div class="text-left text-sm" style="color:#1f2937;">
                                    <p style="color:#64748b;margin-bottom:12px;font-size:13px;">Save these details to sign in later.</p>

                                    <div style="background:#f0f9ff;border:1px solid #bae6fd;border-radius:8px;padding:10px 12px;margin-bottom:8px;">
                                        <div style="font-size:10px;letter-spacing:0.08em;text-transform:uppercase;color:#0369a1;font-weight:700;">Student ID</div>
                                        <div style="font-size:18px;font-weight:800;color:#0c4a6e;margin-top:2px;">${escapeHtml(studentLoginId)}</div>
                                    </div>

                                    <div style="background:#fef3c7;border:1px solid #fde047;border-radius:8px;padding:10px 12px;margin-bottom:8px;">
                                        <div style="font-size:10px;letter-spacing:0.08em;text-transform:uppercase;color:#a16207;font-weight:700;">Guardian Login</div>
                                        <div style="font-size:14px;font-weight:700;color:#713f12;margin-top:2px;word-break:break-all;">${escapeHtml(guardianLogin)}</div>
                                    </div>

                                    <div style="background:#fef3c7;border:1px solid #fde047;border-radius:8px;padding:10px 12px;">
                                        <div style="font-size:10px;letter-spacing:0.08em;text-transform:uppercase;color:#a16207;font-weight:700;">Guardian Password</div>
                                        <div style="font-size:14px;font-weight:700;color:#713f12;margin-top:2px;word-break:break-all;">${escapeHtml(guardianPasswordText)}</div>
                                    </div>
                                </div>
                            `,
                        });
                    }
                } else if (hasGuardian) {
                    // Preserve existing guardian links for adult students unless staff changes them manually.
                }

                const resReg = await axios.post(`${baseApiUrl}/students.php`, payload);
                if (!(resReg.data && resReg.data.success)) {
                    throw new Error(resReg.data?.error || 'Failed to save registration details.');
                }

                const formData = new FormData();
                formData.append('student_id', String(Number(student.student_id)));
                formData.append('amount', String(amount));
                formData.append('payment_method', String(method));
                formData.append('reference_number', String(referenceNumber));
                formData.append('registration_proof_file', proofFile);
                formData.append('age_verification_proof_file', ageProofFile);

                const resPay = await axios.post(`${baseApiUrl}/users.php?action=pay-registration-fee`, formData, {
                    headers: { 'Content-Type': 'multipart/form-data' }
                });
                if (!(resPay.data && resPay.data.success)) {
                    throw new Error(resPay.data?.error || 'Payment submission failed.');
                }

                try {
                    sessionStorage.removeItem('student_registration_rejected_notice');
                } catch (e) {
                    // Ignore storage issues.
                }
                studentRegistrationRestartNotice = false;

                const msg = resPay.data?.message || 'Registration request submitted.';
                closeStudentRegistrationModal();
                if (submitAllStatus) submitAllStatus.textContent = msg;
                showMessage(msg, 'success');
                initStudentDashboardPage();
            } catch (err) {
                const msg = err?.response?.data?.error || err?.message || 'Failed to submit registration request.';
                if (submitAllStatus) submitAllStatus.textContent = msg;
                showMessage(msg, 'error');
            } finally {
                submitAllBtn.disabled = false;
                submitAllBtn.textContent = 'Submit Registration Request';
            }
        };
    }
}

async function initStudentDashboardPage() {
    if (!checkStudentAuth()) return;
    const user = Auth.getUser();
    if (!user?.email) {
        showMessage('Your account email is missing. Please contact admin.', 'error');
        return;
    }

    const portal = await fetchStudentPortalDataByEmail(user.email);
    if (await handleStudentRegistrationReset(portal, 'This registration was rejected or removed. Please register again.')) return;
    if (!portal.success) {
        showMessage(portal.error || 'Failed to load your profile.', 'error');
        return;
    }

    const s = portal.student;
    applyStudentPortalIdentity(user, portal);
    setHtml('studentStatusBadge', `<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${badgeClassForRegistrationStatus(s.registration_status)}">${escapeHtml(s.registration_status || '—')}</span>`);

    const profileComplete = isRegistrationProfileComplete(s);
    const regPaid = ['Approved', 'Fee Paid'].includes(String(s.registration_status || 'Pending'));
    const isNewStudent = !profileComplete || !regPaid;
    const enrollmentApproved = portal.current_enrollment && String(portal.current_enrollment.status || '') === 'Active';
    const enrollmentCompleted = isStudentEnrollmentCompleted(portal);
    const isEnrolledStudent = Boolean(enrollmentApproved);
    const overviewCard = document.getElementById('studentEnrollmentOverviewCard');
    const performanceCard = document.getElementById('studentPerformanceCard');
    const requestShortcutCard = document.getElementById('studentRequestShortcutCard');
    const upcomingCard = document.getElementById('studentUpcomingScheduleCard');
    const upcomingDetails = document.getElementById('studentUpcomingDetails');
    const qrCard = document.getElementById('studentQrCard');
    const completedState = document.getElementById('studentCompletedState');
    const enrollmentPaymentCard = document.getElementById('studentEnrollmentPaymentCard');
    bindStudentModalFrame('studentRegistrationModal', closeStudentRegistrationModal);
    bindStudentModalFrame('studentRequestModal', closeStudentRequestModal);
    if (!window.__studentModalEscBound) {
        window.__studentModalEscBound = true;
        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                closeStudentRegistrationModal();
                closeStudentRequestModal();
            }
        });
    }
    const welcomeNote = document.getElementById('studentWelcomeNote');
    if (welcomeNote) {
        if (enrollmentCompleted) {
            welcomeNote.textContent = 'Your purchased sessions have been used. Request additional sessions from Enrollment Details if you want to continue.';
        } else if (isEnrolledStudent) {
            welcomeNote.textContent = 'View your upcoming class, open your QR code, and keep your profile updated.';
        } else if (isNewStudent) {
            welcomeNote.textContent = 'Check your registration status here, then continue to enrollment once admin approval is complete.';
        } else {
            welcomeNote.textContent = 'Quick view of your account and QR. For full details, open Sessions or Profile.';
        }
    }
    if (overviewCard) overviewCard.classList.toggle('hidden', isEnrolledStudent || enrollmentCompleted);
    if (requestShortcutCard) requestShortcutCard.classList.toggle('hidden', isEnrolledStudent || !regPaid);
    if (upcomingCard) upcomingCard.classList.toggle('hidden', !isEnrolledStudent || enrollmentCompleted);
    if (qrCard) qrCard.classList.toggle('hidden', true);
    if (enrollmentPaymentCard) enrollmentPaymentCard.classList.toggle('hidden', !isEnrolledStudent);
    if (completedState) {
        if (enrollmentCompleted) {
            completedState.innerHTML = renderStudentCompletedSessionsPanel(portal);
            completedState.classList.remove('hidden');
        } else {
            completedState.innerHTML = '';
            completedState.classList.add('hidden');
        }
    }

    // Package
    setText('packageName', s.package_name || 'Not assigned yet');
    setText('packageSessions', s.package_sessions ? `${s.package_sessions} sessions` : '—');
    setText('packageMaxInstruments', s.package_max_instruments ? `${s.package_max_instruments} instrument(s)` : '—');

    const upcomingDate = formatDateLong(portal.current_enrollment?.first_session_date || '');
    if (upcomingDetails) upcomingDetails.classList.toggle('hidden', !upcomingDate);
    const upcomingStart = portal.current_enrollment?.first_start_time ? formatTime12Hour(portal.current_enrollment.first_start_time) : '';
    const upcomingEnd = portal.current_enrollment?.first_end_time ? formatTime12Hour(portal.current_enrollment.first_end_time) : '';
    const upcomingTime = upcomingStart && upcomingEnd ? `${upcomingStart} - ${upcomingEnd}` : 'To be announced';
    const upcomingRoom = portal.current_enrollment?.first_room || 'To be announced';
    const upcomingTeacher = `${portal.current_enrollment?.teacher_first_name || ''} ${portal.current_enrollment?.teacher_last_name || ''}`.trim() || 'Not assigned yet';
    setText('studentUpcomingDate', upcomingDate || (isEnrolledStudent ? 'No upcoming class scheduled' : 'Waiting for schedule'));
    setText('studentUpcomingTime', upcomingTime);
    setText('studentUpcomingRoom', upcomingRoom);
    setText('studentUpcomingTeacher', upcomingTeacher);

    // Enrollment focus cards
    setHtml('currentEnrollmentSummary', renderCurrentEnrollmentSummary(portal.current_enrollment || null));
    setHtml('enrollmentHistoryList', renderEnrollmentHistoryList(portal.enrollment_history || []));

    // Attendance summary (optional)
    const summaryRes = await fetchAttendanceSummary(s.student_id);
    if (summaryRes.success) {
        const attended = Number(summaryRes.summary?.present_count ?? 0) + Number(summaryRes.summary?.late_count ?? 0);
        setText('sessionsAttended', String(attended));
        const total = Number(s.package_sessions || 0);
        const remaining = total > 0 ? Math.max(0, total - attended) : 0;
        setText('sessionsRemaining', total > 0 ? String(remaining) : '—');
        setText('lastAttended', summaryRes.summary?.last_attended_at ? new Date(summaryRes.summary.last_attended_at).toLocaleString() : '—');
    } else {
        setText('sessionsAttended', '0');
        setText('sessionsRemaining', '—');
        setText('lastAttended', '—');
    }

    if (isEnrolledStudent) {
        const performanceRows = Array.isArray(portal.current_session_grades) ? portal.current_session_grades : [];
        const performanceMetrics = buildStudentPerformanceMetrics(performanceRows);
        const hasGrades = performanceRows.some(row => Number(row?.progress_id || 0) > 0)
            && performanceMetrics.some(metric => Number(metric?.percent || 0) > 0);
        if (performanceCard) {
            performanceCard.innerHTML = hasGrades ? renderStudentPerformanceProfile(performanceMetrics, performanceRows) : '';
            performanceCard.classList.toggle('hidden', !hasGrades);
        }
        renderStudentPerformanceRadar(hasGrades ? performanceMetrics : []);
    } else {
        setHtml('studentPerformanceCard', '');
        performanceCard?.classList.add('hidden');
        renderStudentPerformanceRadar([]);
    }

    const dashboardCertificateCard = document.getElementById('studentCertificateCard');
    if (dashboardCertificateCard) {
        const certificateMarkup = renderStudentCertificateCard(portal);
        dashboardCertificateCard.innerHTML = certificateMarkup;
        dashboardCertificateCard.classList.toggle('hidden', certificateMarkup === '');
    }

    let meta = null;
    try {
        const resMeta = await fetchStudentRequestMetaByEmail(user.email);
        if (resMeta?.success) {
            meta = resMeta;
            if (!isEnrolledStudent && regPaid) {
                initStudentRequestSection(s, meta);
            }
        }
    } catch (e) {
        setHtml('studentAvailabilityCalendar', '<div class="text-zinc-500">Unable to load teacher availability right now.</div>');
    }

    const dashboardParams = new URLSearchParams(window.location.search);
    if (dashboardParams.get('open_request') === '1' && document.getElementById('studentRequestModal')) {
        openStudentRequestModal();
        dashboardParams.delete('open_request');
        const nextUrl = new URL(window.location.href);
        nextUrl.search = dashboardParams.toString();
        window.history.replaceState({}, '', nextUrl.toString());
    }

    // Fetch current freeze payment status so the banner shows the right state
    const freezeNotice = getScheduleFreezeReservationNotice(portal?.current_enrollment || null);
    if (freezeNotice && portal?.current_enrollment?.enrollment_id) {
        try {
            const fpRes  = await axios.get(`${baseApiUrl}/students.php?action=get-student-freeze-payment-status&enrollment_id=${encodeURIComponent(portal.current_enrollment.enrollment_id)}`);
            const fpData = fpRes.data || {};
            if (fpData.success && fpData.payment) {
                portal.current_enrollment.__freeze_payment_status = fpData.payment.status;
            }
        } catch (_) { /* non-critical */ }
    }
    studentDashboardPortalState = portal;
    notifyStudentSessionCompletions(portal);
    startStudentSessionRefreshWatcher();
    notifyFreezeRestoredForStudentPortal(portal, s);
    startStudentFreezeRefreshWatcher();

    if (!isEnrolledStudent && !enrollmentCompleted) {
        studentDashboardMetaState = meta;
        renderStudentActionBanner(s, meta, portal);
        renderStudentOnboardingSteps(s, meta, portal);
        renderStudentRegistrationModal(s, portal);
        wireStudentOnboardingActions(s, meta, portal);

        let reopenRegistrationModal = false;
        try {
            reopenRegistrationModal = sessionStorage.getItem('student_reopen_registration_modal') === '1';
            studentRegistrationRestartNotice = sessionStorage.getItem('student_registration_rejected_notice') === '1';
            if (reopenRegistrationModal) {
                sessionStorage.removeItem('student_reopen_registration_modal');
            }
        } catch (e) {
            reopenRegistrationModal = false;
            studentRegistrationRestartNotice = false;
        }
        if (reopenRegistrationModal) {
            renderStudentRegistrationModal(s, portal);
            setStudentModalState('studentRegistrationModal', true);
        }
    } else {
        renderStudentActionBanner(s, meta, portal);
        setHtml('studentOnboardingSteps', '');
        closeStudentRegistrationModal();
        closeStudentRequestModal();
    }

    if (!enrollmentApproved) {
        if (qrCard) {
            qrCard.classList.add('hidden');
            qrCard.classList.add('opacity-70');
        }
        setHtml('qrCodeBox', '<div class="text-sm text-zinc-500 text-center">QR locked until admin approves your enrollment.</div>');
        setText('qrPayloadText', 'Locked — approval required');
    } else {
        try {
            const qrStatusRes = await fetchStudentQrStatus(Number(s.student_id || 0), s.email || '');
            const qrStatus = qrStatusRes?.qr_status || { code: 'no_session', message: 'You do not have a session today.' };

            if (qrStatus.code === 'valid_today') {
                if (qrCard) {
                    qrCard.classList.remove('hidden');
                    qrCard.classList.remove('opacity-70');
                }
                const payload = buildStudentQrPayload(s);
                setText('qrPayloadText', payload);
                renderQrCode('qrCodeBox', payload);
            } else {
                if (qrCard) qrCard.classList.add('hidden');
                setText('qrPayloadText', qrStatus.message || 'QR unavailable');
                setHtml('qrCodeBox', `<div class="text-sm text-zinc-500 text-center">${escapeHtml(qrStatus.message || 'QR unavailable for today.')}</div>`);
            }
        } catch (_) {
            if (qrCard) qrCard.classList.add('hidden');
            setText('qrPayloadText', 'QR status unavailable');
            setHtml('qrCodeBox', '<div class="text-sm text-zinc-500 text-center">Unable to verify your QR status right now.</div>');
        }
    }
}

async function initStudentQrPage() {
    if (!checkStudentAuth()) return;
    const user = Auth.getUser();

    const portal = await fetchStudentPortalDataByEmail(user.email);
    if (await handleStudentRegistrationReset(portal, 'This registration was rejected or removed. Please register again.')) return;
    if (!portal.success) {
        showMessage(portal.error || 'Failed to load your QR code.', 'error');
        return;
    }
    const s = portal.student;
    applyStudentPortalIdentity(user, portal);

    const enrollmentApproved = portal.current_enrollment && String(portal.current_enrollment.status || '') === 'Active';
    if (!enrollmentApproved) {
        renderStudentQrStatus({ code: 'no_session', message: 'QR locked until admin approves your enrollment.' });
        setHtml('qrCodeBox', '<div class="text-sm text-zinc-500 dark:text-zinc-400 text-center">QR locked until admin approves your enrollment.</div>');
        setText('qrPayloadText', 'Locked — approval required');
        return;
    }

    try {
        const qrStatusRes = await fetchStudentQrStatus(Number(s.student_id || 0), s.email || '');
        const qrStatus = qrStatusRes?.qr_status || { code: 'no_session', message: 'You do not have a session today.' };
        renderStudentQrStatus(qrStatus);

        if (qrStatus.code === 'valid_today') {
            const payload = buildStudentQrPayload(s);
            setText('qrPayloadText', payload);
            renderQrCode('qrCodeBox', payload);
        } else {
            setText('qrPayloadText', qrStatus.message || 'QR unavailable');
            setHtml('qrCodeBox', `<div class="text-sm text-zinc-600 dark:text-zinc-300 text-center">${escapeHtml(qrStatus.message || 'QR unavailable for today.')}</div>`);
        }
    } catch (error) {
        renderStudentQrStatus({ code: 'no_session', message: 'Unable to verify your QR status right now.' });
        setText('qrPayloadText', 'QR status unavailable');
        setHtml('qrCodeBox', '<div class="text-sm text-zinc-600 dark:text-zinc-300 text-center">Unable to verify your QR status right now.</div>');
    }

    if (!window.__studentQrRefreshTimer) {
        window.__studentQrRefreshTimer = window.setInterval(() => {
            if (document.visibilityState === 'visible') initStudentQrPage();
        }, 60000);
    }
}

async function initStudentSessionsPage() {
    if (!checkStudentAuth()) return;
    const user = Auth.getUser();

    const portal = await fetchStudentPortalDataByEmail(user.email);
    if (await handleStudentRegistrationReset(portal, 'This registration was rejected or removed. Please register again.')) return;
    if (!portal.success) {
        showMessage(portal.error || 'Failed to load sessions.', 'error');
        return;
    }
    const s = portal.student;
    applyStudentPortalIdentity(user, portal);
    setText('packageName', s.package_name || 'Not assigned yet');
    setText('packageSessions', s.package_sessions ? `${s.package_sessions} sessions included` : '—');
    setText('gradedSessionCount', '—');
    setText('currentGradeAverage', '—');

    const enrollmentApproved = portal.current_enrollment && String(portal.current_enrollment.status || '') === 'Active';
    if (!enrollmentApproved) {
        setHtml('attendanceTableBody', `
            <tr>
                <td colspan="5" class="px-6 py-10 text-center text-zinc-400">
                    <i class="fas fa-lock text-2xl mb-2"></i>
                    <div class="font-semibold">Session tracking is locked</div>
                    <div class="text-xs text-zinc-500 mt-1">Your session grades will appear here after admin approves your enrollment.</div>
                </td>
            </tr>
        `);
    } else {
        const rows = Array.isArray(portal.current_session_grades) ? portal.current_session_grades : [];
        const gradedRows = rows.filter(r => Number(r.progress_id || 0) > 0 && Number(r.average_score || 0) > 0);
        const averageGrade = gradedRows.length
            ? String(Math.round(gradedRows.reduce((sum, row) => sum + Number(row.average_score || 0), 0) / gradedRows.length))
            : null;

        setText('gradedSessionCount', String(gradedRows.length));
        setText('currentGradeAverage', averageGrade ? `${averageGrade}/5` : 'Pending');

        const sortedRows = [...rows].sort(compareSessionRowsChronologically);

        window.__studentGradesRows = sortedRows;
        window.__studentSessionsRows = sortedRows;

        if (sortedRows.length === 0) {
            setHtml('attendanceTableBody', `
                <div class="rounded-3xl border border-dashed border-zinc-300 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-6 py-10 text-center text-zinc-400">
                    <i class="fas fa-calendar-minus text-2xl mb-2"></i>
                    <div class="font-semibold">No session records yet</div>
                    <div class="text-xs text-zinc-500 mt-1">Your session tracker will fill in once your class schedule is generated.</div>
                </div>
            `);
        } else {
            setHtml('attendanceTableBody', sortedRows.map((r, index) => {
                const dateValue = r.session_date ? new Date(r.session_date) : null;
                const monthLabel = dateValue ? dateValue.toLocaleDateString('en-PH', { month: 'short' }).toUpperCase() : '—';
                const dayLabel = dateValue ? dateValue.toLocaleDateString('en-PH', { day: '2-digit' }) : '—';
                const weekdayLabel = dateValue ? dateValue.toLocaleDateString('en-PH', { weekday: 'short' }).toUpperCase() : '—';
                const dateLabel = r.session_date ? formatDateLong(r.session_date) : 'Date pending';
                const start = r.start_time ? formatTime12Hour(r.start_time) : '';
                const end = r.end_time ? formatTime12Hour(r.end_time) : '';
                const timeLabel = start && end ? `${start} - ${end}` : (start || 'Time pending');
                const sessionNumber = r.session_number ? `Session ${escapeHtml(String(r.session_number))}` : 'Session';
                const attendanceLabel = r.attendance_status && r.attendance_status !== 'Pending'
                    ? r.attendance_status
                    : (r.status || 'Scheduled');
                const roomLabel = r.room_name || 'Room to be confirmed';
                const teacherLabel = r.teacher_name || 'Teacher pending';
                const sessionState = Number(r.progress_id || 0) > 0
                    ? 'Graded'
                    : ((String(r.status || '').toLowerCase() === 'completed' || String(r.attendance_status || '').toLowerCase() === 'present') ? 'Upcoming' : 'Upcoming');
                const noteLabel = Number(r.progress_id || 0) > 0
                    ? 'This session has already been graded. Open the details to review the score and remarks.'
                    : 'Not scored yet - your coach will grade this after the session.';

                return `
                    <article class="rounded-2xl border ${Number(r.progress_id || 0) > 0 ? 'border-zinc-200 dark:border-white/10' : 'border-gold-500/30 dark:border-gold-500/20'} bg-white dark:bg-white/5 p-3 sm:p-4 shadow-sm hover:shadow-md transition">
                        <div class="flex flex-col gap-3 md:flex-row md:items-center">
                            <div class="flex items-start gap-3 min-w-0 flex-1">
                                <div class="shrink-0 rounded-xl bg-amber-50 dark:bg-white/5 border border-amber-100 dark:border-white/10 px-2 py-2 text-center leading-none w-16">
                                    <div class="text-[9px] font-black tracking-[0.18em] text-amber-700 dark:text-amber-300">${escapeHtml(monthLabel)}</div>
                                    <div class="mt-1 text-2xl font-black text-zinc-900 dark:text-white">${escapeHtml(dayLabel)}</div>
                                    <div class="mt-1 text-[9px] font-black tracking-[0.16em] text-amber-700/80 dark:text-amber-200">${escapeHtml(weekdayLabel)}</div>
                                </div>
                                <div class="min-w-0 flex-1">
                                    <div class="flex flex-wrap items-center gap-2">
                                        <div class="text-[11px] uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold">${escapeHtml(sessionNumber)}</div>
                                        <span class="inline-flex items-center rounded-full border border-gold-500/30 bg-gold-500/10 px-2.5 py-1 text-[10px] font-bold text-gold-700 dark:text-gold-300">
                                            <i class="fas fa-calendar-day mr-1 text-[9px]"></i>${escapeHtml(sessionState)}
                                        </span>
                                    </div>
                                    <div class="mt-1.5 text-lg sm:text-xl font-black text-zinc-900 dark:text-white">${escapeHtml(dateLabel)}</div>
                                    <div class="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1.5 text-[13px] text-zinc-500 dark:text-zinc-300">
                                        <span class="inline-flex items-center gap-1.5"><i class="far fa-clock text-zinc-400"></i>${escapeHtml(timeLabel)}</span>
                                        <span class="inline-flex items-center gap-1.5"><i class="far fa-circle-dot text-zinc-400"></i>${escapeHtml(roomLabel)}</span>
                                        <span class="inline-flex items-center gap-1.5"><i class="far fa-user text-zinc-400"></i>${escapeHtml(teacherLabel)}</span>
                                    </div>
                                    <div class="mt-2 text-xs text-zinc-500 dark:text-zinc-400">${escapeHtml(noteLabel)}</div>
                                </div>
                            </div>
                            <div class="flex flex-col items-start md:items-end gap-2">
                                <button type="button" onclick="openStudentGradeDetails(${index})" class="inline-flex items-center gap-2 px-4 py-2.5 rounded-full bg-gold-500 hover:bg-gold-400 text-black text-xs font-extrabold transition shadow-sm whitespace-nowrap">
                                    View details <i class="fas fa-chevron-right text-[9px]"></i>
                                </button>
                                <div class="flex flex-wrap items-center justify-start md:justify-end gap-2">
                                    ${renderAttendanceStatusBadge(attendanceLabel)}
                                    ${renderStudentGradeBadge(r.average_score, r.progress_id)}
                                </div>
                            </div>
                        </div>
                        <div class="mt-2 text-[11px] text-zinc-500 dark:text-zinc-400">
                            Skill level: <span class="font-semibold text-zinc-700 dark:text-zinc-200">${escapeHtml(r.skill_level || 'Not graded yet')}</span>
                        </div>
                    </article>
                `;
            }).join(''));
        }
    }

    // Purchased-session requests live under Enrollment Details. This page only
    // displays actual scheduled/attended lesson sessions.
}

function renderAttendanceStatusBadge(status) {
    const value = String(status || '—');
    const cls = value === 'Present'
        ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/25'
        : value === 'Late'
            ? 'bg-amber-500/15 text-amber-400 border border-amber-500/25'
            : value === 'Absent'
                ? 'bg-red-500/15 text-red-400 border border-red-500/25'
                : 'bg-zinc-500/15 text-zinc-300 border border-zinc-500/25';
    return `<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${cls}">${escapeHtml(value)}</span>`;
}

function renderStudentGradeBadge(averageScore, progressId) {
    const hasGrade = Number(progressId || 0) > 0 && Number(averageScore || 0) > 0;
    const label = hasGrade ? `${Math.round(Number(averageScore))}/5` : 'Pending';
    const cls = hasGrade
        ? 'bg-gold-500/15 text-gold-300 border border-gold-500/30'
        : 'bg-zinc-500/15 text-zinc-300 border border-zinc-500/25';
    return `<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${cls}">${escapeHtml(label)}</span>`;
}

function renderStudentSkillLevel(skillLevel) {
    if (!skillLevel) {
        return '<span class="text-zinc-500">Not graded yet</span>';
    }
    return `<span class="font-semibold text-white">${escapeHtml(skillLevel)}</span>`;
}

function buildStudentGradeDetailsMarkup(row) {
    const dateLabel = row.session_date ? formatDateLong(row.session_date) : 'Date pending';
    const timeLabel = row.start_time && row.end_time
        ? `${formatTime12Hour(row.start_time)} - ${formatTime12Hour(row.end_time)}`
        : (row.start_time ? formatTime12Hour(row.start_time) : 'Time pending');
    const hasGrade = Number(row.progress_id || 0) > 0;
    const averageScore = hasGrade ? String(Math.round(Number(row.average_score))) : null;
    const sessionEndValue = row.session_date
        ? `${row.session_date}T${row.end_time || row.start_time || '23:59:59'}`
        : '';
    const sessionEnd = sessionEndValue ? new Date(sessionEndValue) : null;
    const isFutureSession = sessionEnd && !Number.isNaN(sessionEnd.getTime()) && sessionEnd.getTime() > Date.now();
    const remarksText = cleanSessionNoteText(row.teacher_remarks || row.remarks, '');
    const savedCriteria = hasGrade && Array.isArray(row.criteria_scores) && row.criteria_scores.length
        ? row.criteria_scores.map(item => [item.name || 'Criterion', Number(item.score || 0)])
        : (hasGrade ? [
            ['Performance', row.performance_score],
            ['Technique', row.technique_score],
            ['Rhythm', row.rhythm_score],
            ['Focus', row.focus_score],
            ['Assignment', row.assignment_score]
        ] : []);
    const ratedCriteria = savedCriteria.filter(([, value]) => Number(value) >= 1 && Number(value) <= 5);
    const gradedDate = formatDateLong(row.assessment_date || row.updated_at || row.session_date || '') || 'Date not recorded';
    const scoreMeaning = (value) => ({ 1:'Needs attention', 2:'Developing', 3:'Good', 4:'Very good', 5:'Excellent' }[Number(value)] || 'Rated');
    const overallMeaning = scoreMeaning(Math.max(1, Math.min(5, Math.round(Number(averageScore || 0)))));
    const scorePills = ratedCriteria.map(([label, value]) => `
        <div class="rounded-2xl border border-zinc-200 bg-zinc-50 px-4 py-3.5">
            <div class="min-h-[2.5rem] text-sm font-bold leading-5 text-zinc-800">${escapeHtml(label)}</div>
            <div class="mt-2 flex items-end justify-between gap-3">
                <div class="text-2xl font-black leading-none text-zinc-900">${escapeHtml(String(value))}<span class="text-sm font-semibold text-zinc-400">/5</span></div>
                <span class="text-[11px] font-bold text-zinc-500">${escapeHtml(scoreMeaning(value))}</span>
            </div>
            <div class="mt-3 h-2 w-full overflow-hidden rounded-full bg-zinc-200"><div class="h-full rounded-full bg-[#bd9525]" style="width:${Math.max(0, Math.min(100, Number(value) * 20))}%"></div></div>
        </div>
    `).join('');
    const resultSection = hasGrade ? `
        <section class="mt-5 overflow-hidden rounded-2xl border border-emerald-200 bg-emerald-50">
            <div class="flex flex-col gap-4 px-5 py-4 sm:flex-row sm:items-center sm:justify-between">
                <div class="flex items-start gap-3">
                    <div class="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-white text-emerald-600 shadow-sm"><i class="fas fa-check"></i></div>
                    <div>
                        <div class="text-xs font-black uppercase tracking-[0.18em] text-emerald-700">Evaluation complete</div>
                        <div class="mt-1 font-bold text-zinc-900">${escapeHtml(overallMeaning)}</div>
                        <div class="mt-0.5 text-xs text-emerald-800">Recorded ${escapeHtml(gradedDate)}</div>
                    </div>
                </div>
                <div class="rounded-xl bg-white px-5 py-2.5 text-center shadow-sm">
                    <div class="text-[10px] font-bold uppercase tracking-wider text-zinc-400">Overall</div>
                    <div class="text-2xl font-black text-zinc-900">${escapeHtml(averageScore)}<span class="text-sm text-zinc-400">/5</span></div>
                </div>
            </div>
        </section>
        ${remarksText ? `<section class="mt-5"><h4 class="text-sm font-bold text-zinc-900">Instructor’s note</h4><div class="mt-2 flex gap-3 rounded-2xl border border-gold-200 bg-gold-50/70 px-4 py-3.5"><i class="fas fa-quote-left mt-1 text-gold-500"></i><p class="text-sm leading-6 text-zinc-700">${escapeHtml(remarksText)}</p></div></section>` : ''}
        ${ratedCriteria.length ? `<section class="mt-6"><div class="flex flex-wrap items-end justify-between gap-2"><div><h4 class="text-base font-black text-zinc-900">Lesson evaluation</h4><p class="mt-1 text-xs leading-5 text-zinc-500">Only the areas used by the instructor for this session are shown.</p></div><span class="rounded-full bg-zinc-100 px-3 py-1 text-xs font-bold text-zinc-600">${ratedCriteria.length} ${ratedCriteria.length === 1 ? 'area' : 'areas'} evaluated</span></div><div class="mt-3 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">${scorePills}</div></section>` : ''}
    ` : `
        <section class="mt-5 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-4">
            <div class="flex items-start gap-3">
                <div class="mt-0.5 grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-white text-amber-600"><i class="far ${isFutureSession ? 'fa-calendar' : 'fa-clock'}"></i></div>
                <div><div class="font-bold text-zinc-900">${isFutureSession ? 'This lesson is scheduled' : 'Waiting for instructor evaluation'}</div><p class="mt-1 text-sm leading-6 text-zinc-600">${isFutureSession ? `This session is on ${escapeHtml(dateLabel)}. Scores will appear here only after the lesson is completed and graded.` : 'No grade has been submitted for this session yet. There is no score breakdown to show.'}</p></div>
            </div>
        </section>
    `;

    return `
        <div class="text-left overflow-hidden rounded-[1.5rem] bg-[#f8f4ea] max-w-[96vw] sm:max-w-none max-h-[100dvh] sm:max-h-[calc(100dvh-2rem)] flex flex-col shadow-2xl">
            <div class="flex items-start justify-between gap-3 bg-[#bd9525] px-5 py-4 text-white">
                <div>
                    <div class="text-[10px] font-black uppercase tracking-[0.22em] text-white/90">Session ${escapeHtml(String(row.session_number || ''))}</div>
                    <h3 class="mt-1 text-base sm:text-lg font-black leading-tight">${escapeHtml(row.instrument_name || 'Instrument Session')}</h3>
                </div>
                <button type="button" onclick="Swal.close()" class="h-8 w-8 shrink-0 rounded-full bg-white/20 hover:bg-white/30 text-white flex items-center justify-center transition" aria-label="Close modal">
                    <i class="fas fa-times text-xs"></i>
                </button>
            </div>
            <div class="px-5 py-5 bg-white overflow-y-auto">
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2">
                    <div class="rounded-xl border border-zinc-100 bg-zinc-50 px-3 py-2.5 flex items-center gap-2.5">
                        <div class="h-9 w-9 rounded-xl bg-white border border-zinc-200 grid place-items-center text-gold-500 shrink-0">
                            <i class="far fa-calendar text-sm"></i>
                        </div>
                        <div class="min-w-0">
                            <div class="text-[11px] text-zinc-400 font-medium">Date</div>
                            <div class="text-sm font-extrabold text-zinc-900">${escapeHtml(dateLabel)}</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-zinc-100 bg-zinc-50 px-3 py-2.5 flex items-center gap-2.5">
                        <div class="h-9 w-9 rounded-xl bg-white border border-zinc-200 grid place-items-center text-gold-500 shrink-0">
                            <i class="far fa-clock text-sm"></i>
                        </div>
                        <div>
                            <div class="text-[11px] text-zinc-400 font-medium">Time</div>
                            <div class="text-sm font-extrabold text-zinc-900">${escapeHtml(timeLabel)}</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-zinc-100 bg-zinc-50 px-3 py-2.5 flex items-center gap-2.5">
                        <div class="h-9 w-9 rounded-xl bg-white border border-zinc-200 grid place-items-center text-gold-500 shrink-0">
                            <i class="far fa-circle-dot text-sm"></i>
                        </div>
                        <div>
                            <div class="text-[11px] text-zinc-400 font-medium">Location</div>
                            <div class="text-sm font-extrabold text-zinc-900 break-words">${escapeHtml(row.room_name || 'To be confirmed')}</div>
                        </div>
                    </div>
                    <div class="rounded-xl border border-zinc-100 bg-zinc-50 px-3 py-2.5 flex items-center gap-2.5">
                        <div class="h-9 w-9 rounded-xl bg-white border border-zinc-200 grid place-items-center text-gold-500 shrink-0">
                            <i class="far fa-user text-sm"></i>
                        </div>
                        <div>
                            <div class="text-[11px] text-zinc-400 font-medium">Instructor</div>
                            <div class="text-sm font-extrabold text-zinc-900 break-words">${escapeHtml(row.teacher_name || 'Not assigned')}</div>
                        </div>
                    </div>
                </div>

                ${resultSection}

                <div class="sticky bottom-0 mt-6 border-t border-zinc-100 bg-white/95 pt-4 backdrop-blur">
                    <button type="button" onclick="Swal.close()" class="w-full inline-flex items-center justify-center gap-2 rounded-full bg-[#12192a] px-5 py-2.5 text-sm text-white font-extrabold shadow-lg shadow-[#12192a]/20 hover:bg-[#0d1322] transition">
                        Close
                    </button>
                </div>
            </div>
        </div>
    `;
}

function openStudentGradeDetails(index) {
    const rows = Array.isArray(window.__studentSessionsRows) && window.__studentSessionsRows.length
        ? window.__studentSessionsRows
        : (Array.isArray(window.__studentGradesRows) ? window.__studentGradesRows : []);
    const row = rows[Number(index)];
    if (!row) return;
    Swal.fire({
        width: 720,
        showConfirmButton: false,
        showCloseButton: false,
        background: 'transparent',
        padding: 0,
        customClass: {
            popup: 'session-detail-swal'
        },
        html: buildStudentGradeDetailsMarkup(row)
    });
}

window.openStudentGradeDetails = openStudentGradeDetails;

async function initStudentGradesPage() {
    const listEl = document.getElementById('studentGradesList');
    if (!checkStudentAuth()) return;
    const user = Auth.getUser();

    if (!listEl) return;

    try {
        const portal = await fetchStudentPortalDataByEmail(user.email);
        if (await handleStudentRegistrationReset(portal, 'This registration was rejected or removed. Please register again.')) return;
        if (!portal.success) {
            listEl.innerHTML = `
                <div class="rounded-3xl border border-dashed border-red-200 bg-red-50 px-6 py-12 text-center text-red-600">
                    <div class="font-semibold">Failed to load grades</div>
                    <div class="text-sm mt-2">${escapeHtml(portal.error || 'The portal did not return grade data.')}</div>
                </div>
            `;
            return;
        }

        applyStudentPortalIdentity(user, portal);
        studentDashboardPortalState = portal;
        studentDashboardMetaState = portal;
        renderStudentFormalLearningProgress(portal);
        const enrollmentApproved = portal.current_enrollment && String(portal.current_enrollment.status || '') === 'Active';
        const rows = Array.isArray(portal.current_session_grades) ? portal.current_session_grades : [];
        const gradedRows = rows.filter(row => Number(row.progress_id || 0) > 0);
        const pendingRows = rows.filter(row => Number(row.progress_id || 0) < 1);
        const packageSessions = Number(portal.current_enrollment?.package_sessions || portal.student?.package_sessions || 0);
        const completedSessions = Math.max(Number(portal.current_enrollment?.completed_sessions || 0), gradedRows.length);
        const remainingSessions = packageSessions > 0 ? Math.max(0, packageSessions - completedSessions) : null;
        const progressPercent = packageSessions > 0
            ? Math.max(0, Math.min(100, Math.round((completedSessions / packageSessions) * 100)))
            : 0;
        const averageValue = gradedRows.length
            ? String(Math.round(gradedRows.reduce((sum, row) => sum + Number(row.average_score || 0), 0) / gradedRows.length))
            : null;
        const latestGraded = gradedRows.find(row => row.assessment_date || row.updated_at) || null;

        setText('studentGradesPackage', portal.student?.package_name || 'No active package yet');
        setText('studentGradesSessionsDone', String(completedSessions));
        setText('studentGradesSessionsTotal', packageSessions > 0 ? String(packageSessions) : '—');
        setText(
            'studentGradesSessionsLeft',
            packageSessions > 0
                ? `${remainingSessions} purchased session${remainingSessions === 1 ? '' : 's'} remaining. Session usage does not determine level mastery.`
                : 'Session total not available yet'
        );
        setText('studentGradesAverage', averageValue ? `${averageValue}/5` : 'Pending');
        setText('studentGradesCompleted', String(completedSessions));
        setText('studentGradesPending', String(pendingRows.length));
        setText(
            'studentGradesLatest',
            latestGraded
                ? formatDateLong(latestGraded.assessment_date || latestGraded.session_date || '')
                : (enrollmentApproved ? 'No graded session yet' : 'Locked until approval')
        );
        const progressBar = document.getElementById('studentGradesProgressBar');
        if (progressBar) {
            progressBar.style.width = `${progressPercent}%`;
        }

        const gradesCertificateCard = document.getElementById('studentCertificateCard');
        if (gradesCertificateCard) {
            const certificateMarkup = renderStudentCertificateCard(portal);
            gradesCertificateCard.innerHTML = certificateMarkup;
            gradesCertificateCard.classList.toggle('hidden', certificateMarkup === '');
        }

        if (!enrollmentApproved) {
            listEl.innerHTML = `
                <div class="rounded-3xl border border-dashed border-zinc-300 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-6 py-12 text-center text-zinc-500 dark:text-zinc-400">
                    <i class="fas fa-lock text-2xl mb-3"></i>
                    <div class="font-semibold text-zinc-900 dark:text-white">Grades are locked for now</div>
                    <div class="text-sm mt-2">Your teacher assessments will appear here once your enrollment becomes active.</div>
                </div>
            `;
            return;
        }

        const sortedRows = [...rows].sort(compareSessionRowsChronologically);
        setText('studentSessionsCount', `${sortedRows.length} total`);
        const sortedGradedRows = sortedRows.filter(row => Number(row.progress_id || 0) > 0);
        const sortedPendingRows = sortedRows.filter(row => Number(row.progress_id || 0) < 1);

        if (!sortedRows.length) {
            setText('studentSessionsCount', '0 total');
            listEl.innerHTML = `
                <div class="rounded-3xl border border-dashed border-zinc-300 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-6 py-12 text-center text-zinc-500 dark:text-zinc-400">
                    <i class="fas fa-chart-line text-2xl mb-3"></i>
                    <div class="font-semibold text-zinc-900 dark:text-white">No session grades yet</div>
                    <div class="text-sm mt-2">Your grade history will appear here as soon as your teacher records session assessments.</div>
                </div>
            `;
            return;
        }

        window.__studentGradesRows = sortedRows;
        const gradedSection = sortedGradedRows.length
            ? `
                <section class="space-y-4">
                    <div class="flex items-center justify-between gap-3">
                        <div>
                            <div class="text-xs uppercase tracking-[0.25em] text-zinc-500 dark:text-zinc-400 font-bold">Graded Sessions</div>
                            <div class="mt-2 text-lg font-extrabold text-zinc-900 dark:text-white">Sessions with recorded grades</div>
                        </div>
                    </div>
                    ${sortedGradedRows.map((row) => {
                        const index = sortedRows.indexOf(row);
                        const dateLabel = row.session_date ? formatDateLong(row.session_date) : 'Date pending';
                        const timeLabel = row.start_time && row.end_time
                            ? `${formatTime12Hour(row.start_time)} - ${formatTime12Hour(row.end_time)}`
                            : (row.start_time ? formatTime12Hour(row.start_time) : 'Time pending');
                        return `
                            <article class="rounded-3xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 p-5 shadow-lg dark:shadow-black/20">
                                <div class="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                                    <div>
                                        <div class="text-xs uppercase tracking-[0.22em] text-zinc-500 dark:text-zinc-400 font-bold">Session ${escapeHtml(String(row.session_number || ''))}</div>
                                        <h3 class="mt-2 text-lg font-black text-zinc-900 dark:text-white">${escapeHtml(row.instrument_name || 'Instrument Session')}</h3>
                                        <div class="mt-2 text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(dateLabel)} • ${escapeHtml(timeLabel)}</div>
                                        <div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(row.teacher_name || 'Teacher not assigned')} • ${escapeHtml(row.room_name || 'Room to be announced')}</div>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-2">
                                        ${renderAttendanceStatusBadge(row.attendance_status && row.attendance_status !== 'Pending' ? row.attendance_status : (row.status || 'Scheduled'))}
                                        ${renderStudentGradeBadge(row.average_score, row.progress_id)}
                                        <button type="button" onclick="openStudentGradeDetails(${index})" class="inline-flex items-center px-4 py-2 rounded-2xl bg-gold-500 hover:bg-gold-400 text-black text-sm font-extrabold transition">
                                            View Grades
                                        </button>
                                    </div>
                                </div>
                            </article>
                        `;
                    }).join('')}
                </section>
            `
            : `
                <section class="rounded-3xl border border-dashed border-zinc-300 dark:border-white/10 bg-zinc-50 dark:bg-white/5 px-6 py-10 text-center text-zinc-500 dark:text-zinc-400">
                    <div class="font-semibold text-zinc-900 dark:text-white">No graded sessions yet</div>
                    <div class="text-sm mt-2">Your graded sessions will appear here once your teacher records assessments.</div>
                </section>
            `;

        const pendingSection = sortedPendingRows.length
            ? `
                <section class="rounded-3xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 p-5 shadow-lg dark:shadow-black/20">
                    <div class="flex items-center justify-between gap-3">
                        <div>
                            <div class="text-xs uppercase tracking-[0.25em] text-zinc-500 dark:text-zinc-400 font-bold">Waiting for Grade</div>
                            <div class="mt-2 text-lg font-extrabold text-zinc-900 dark:text-white">Upcoming or ungraded sessions</div>
                        </div>
                        <div class="text-sm text-zinc-500 dark:text-zinc-400">${sortedPendingRows.length} session${sortedPendingRows.length > 1 ? 's' : ''}</div>
                    </div>
                    <div class="mt-4 space-y-3">
                        ${sortedPendingRows.map((row) => {
                            const index = sortedRows.indexOf(row);
                            const dateLabel = row.session_date ? formatDateLong(row.session_date) : 'Date pending';
                            const timeLabel = row.start_time && row.end_time
                                ? `${formatTime12Hour(row.start_time)} - ${formatTime12Hour(row.end_time)}`
                                : (row.start_time ? formatTime12Hour(row.start_time) : 'Time pending');
                            return `
                                <div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 px-4 py-4 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
                                    <div>
                                        <div class="text-sm font-bold text-zinc-900 dark:text-white">Session ${escapeHtml(String(row.session_number || ''))} • ${escapeHtml(row.instrument_name || 'Instrument Session')}</div>
                                        <div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(dateLabel)} • ${escapeHtml(timeLabel)}</div>
                                    </div>
                                    <div class="flex flex-wrap items-center gap-2">
                                        ${renderAttendanceStatusBadge(row.attendance_status && row.attendance_status !== 'Pending' ? row.attendance_status : (row.status || 'Scheduled'))}
                                        ${renderStudentGradeBadge(row.average_score, row.progress_id)}
                                        <button type="button" onclick="openStudentGradeDetails(${index})" class="inline-flex items-center px-3 py-2 rounded-2xl bg-zinc-900 dark:bg-white/10 hover:bg-zinc-800 dark:hover:bg-white/20 text-white text-xs font-bold transition">
                                            View Session
                                        </button>
                                    </div>
                                </div>
                            `;
                        }).join('')}
                    </div>
                </section>
            `
            : '';

        listEl.innerHTML = `
            <div class="space-y-5">
                ${gradedSection}
                ${pendingSection}
            </div>
        `;
    } catch (error) {
        console.error('Failed to initialize student grades page:', error);
        listEl.innerHTML = `
            <div class="rounded-3xl border border-dashed border-red-200 bg-red-50 px-6 py-12 text-center text-red-600">
                <div class="font-semibold">Unable to load grade data right now</div>
                <div class="text-sm mt-2">${escapeHtml(error?.message || 'Unexpected student grade page error.')}</div>
            </div>
        `;
    }
}

async function initStudentAttendancePage() {
    if (!checkStudentAuth()) return;
    const user = Auth.getUser();
    const portal = await fetchStudentPortalDataByEmail(user.email);
    if (await handleStudentRegistrationReset(portal, 'This registration was rejected or removed. Please register again.')) return;
    if (!portal.success) {
        showMessage(portal.error || 'Failed to load attendance.', 'error');
        return;
    }

    const s = portal.student || {};
    applyStudentPortalIdentity(user, portal);
    const enrollmentApproved = portal.current_enrollment && String(portal.current_enrollment.status || '') === 'Active';
    const totalSessions = Number(portal.current_enrollment?.package_sessions || s.package_sessions || 0);

    if (!enrollmentApproved) {
        setText('attendanceCompletedCount', '0');
        setText('attendanceRemainingCount', totalSessions > 0 ? String(totalSessions) : '—');
        setText('attendancePackageTotal', totalSessions > 0 ? String(totalSessions) : '—');
        setText('attendanceLastDate', 'Locked until enrollment approval');
        setHtml('studentAttendanceTableBody', `
            <tr>
                <td colspan="5" class="px-6 py-10 text-center text-zinc-400">
                    <i class="fas fa-lock text-2xl mb-2"></i>
                    <div class="font-semibold">Attendance is locked</div>
                    <div class="text-xs text-zinc-500 mt-1">Your attendance records will appear here after admin approves your enrollment.</div>
                </td>
            </tr>
        `);
        return;
    }

    const [summaryRes, listRes] = await Promise.all([
        fetchAttendanceSummary(s.student_id),
        fetchAttendanceList(s.student_id, 200)
    ]);

    const completedCount = Number(summaryRes?.summary?.present_count || 0) + Number(summaryRes?.summary?.late_count || 0);
    const remainingCount = totalSessions > 0 ? Math.max(0, totalSessions - completedCount) : 0;
    const lastAttendedAt = summaryRes?.summary?.last_attended_at
        ? new Date(summaryRes.summary.last_attended_at).toLocaleString()
        : '—';

    setText('attendanceCompletedCount', String(completedCount));
    setText('attendanceRemainingCount', totalSessions > 0 ? String(remainingCount) : '—');
    setText('attendancePackageTotal', totalSessions > 0 ? String(totalSessions) : '—');
    setText('attendanceLastDate', lastAttendedAt);

    if (!listRes.success) {
        setHtml('studentAttendanceTableBody', `
            <tr>
                <td colspan="5" class="px-6 py-10 text-center text-zinc-400">Failed to load attendance records.</td>
            </tr>
        `);
        return;
    }

    const rows = Array.isArray(listRes.attendance) ? listRes.attendance : [];
    const sortedRows = [...rows].sort((a, b) => {
        const recordedStatuses = new Set([
            'present', 'late', 'absent', 'excused', 'ci', 'teacher absent',
            'completed', 'no show', 'cancelled', 'cancelled_by_teacher'
        ]);
        const aIsRecorded = recordedStatuses.has(String(a?.status || '').trim().toLowerCase());
        const bIsRecorded = recordedStatuses.has(String(b?.status || '').trim().toLowerCase());

        // Keep actual attendance visible above future scheduled sessions.
        if (aIsRecorded !== bIsRecorded) return aIsRecorded ? -1 : 1;

        const aTime = new Date(`${a?.session_date || ''}T${a?.start_time || '00:00:00'}`).getTime() || 0;
        const bTime = new Date(`${b?.session_date || ''}T${b?.start_time || '00:00:00'}`).getTime() || 0;
        return bTime - aTime;
    });
    if (sortedRows.length === 0) {
        setHtml('studentAttendanceTableBody', `
            <tr>
                <td colspan="5" class="px-6 py-10 text-center text-zinc-400">
                    <i class="fas fa-calendar-minus text-2xl mb-2"></i>
                    <div class="font-semibold">No attendance records yet</div>
                    <div class="text-xs text-zinc-500 mt-1">Your attendance history will appear here once sessions are recorded.</div>
                </td>
            </tr>
        `);
        return;
    }

    setHtml('studentAttendanceTableBody', sortedRows.map(r => {
        const dateLabel = r.session_date ? formatDateLong(r.session_date) : (r.attended_at ? new Date(r.attended_at).toLocaleDateString() : '—');
        const start = r.start_time ? formatTime12Hour(r.start_time) : '';
        const end = r.end_time ? formatTime12Hour(r.end_time) : '';
        const timeLabel = start && end ? `${start} - ${end}` : (start || (r.attended_at ? new Date(r.attended_at).toLocaleTimeString() : '—'));
        const roomLabel = r.room_name || '—';
        const notes = escapeHtml(cleanSessionNoteText(r.notes, '—'));
        return `
            <tr class="border-t border-zinc-200 dark:border-white/10 hover:bg-zinc-50 dark:hover:bg-white/5 transition">
                <td class="px-6 py-4 text-sm text-zinc-900 dark:text-white">${escapeHtml(dateLabel)}</td>
                <td class="px-6 py-4 text-sm text-zinc-700 dark:text-zinc-200">${escapeHtml(timeLabel)}</td>
                <td class="px-6 py-4 text-sm text-zinc-700 dark:text-zinc-200">${escapeHtml(roomLabel)}</td>
                <td class="px-6 py-4 text-sm">${renderAttendanceStatusBadge(r.status)}</td>
                <td class="px-6 py-4 text-sm text-zinc-500 dark:text-zinc-400">${notes}</td>
            </tr>
        `;
    }).join(''));
}

async function initStudentProfilePage() {
    if (!checkStudentAuth()) return;
    const user = Auth.getUser();

    const portal = await fetchStudentPortalDataByEmail(user.email);
    if (await handleStudentRegistrationReset(portal, 'This registration was rejected or removed. Please register again.')) return;
    if (!portal.success) {
        showMessage(portal.error || 'Failed to load profile.', 'error');
        return;
    }

    const s = portal.student;
    applyStudentPortalIdentity(user, portal);
    setText('profileStudentName', `${s.first_name || ''} ${s.last_name || ''}`.trim());
    setText('profileBranch', s.branch_name || '—');
    setHtml('profileStatusBadge', `<span class="inline-flex items-center px-3 py-1 rounded-full text-xs font-bold ${badgeClassForRegistrationStatus(s.registration_status)}">${escapeHtml(s.registration_status || '—')}</span>`);

    const enrollment = portal.current_enrollment || null;
    const enrollmentStatus = enrollment?.status || '';
    const teacherName = `${enrollment?.teacher_first_name || ''} ${enrollment?.teacher_last_name || ''}`.trim() || 'Teacher not assigned yet';
    const sessionDate = formatDateLong(enrollment?.first_session_date || enrollment?.start_date || '');
    const sessionStart = enrollment?.first_start_time ? formatTime12Hour(enrollment.first_start_time) : '';
    const sessionEnd = enrollment?.first_end_time ? formatTime12Hour(enrollment.first_end_time) : '';
    const sessionTime = sessionStart && sessionEnd ? `${sessionStart} - ${sessionEnd}` : '';
    const roomName = enrollment?.first_room || 'Room to be announced';
    const isActiveEnrollment = enrollmentStatus === 'Active';
    const isPendingEnrollment = enrollmentStatus === 'Pending';

    let quickSummary = 'Keep your phone number and address updated for school records.';
    if (isActiveEnrollment) {
        quickSummary = `You are currently enrolled in ${enrollment.package_name || 'your package'}. Check your schedule below for the next class details.`;
    } else if (isPendingEnrollment) {
        quickSummary = `Your ${enrollment.package_name || 'package'} enrollment is pending approval. Schedule details will appear here once finalized.`;
    } else if (s.registration_status === 'Approved') {
        quickSummary = 'Your registration is approved. You can open Sessions when you are ready to request or review enrollment.';
    }
    setText('profileQuickSummary', quickSummary);

    if (isActiveEnrollment && (sessionDate || sessionTime)) {
        setText('profileScheduleTitle', sessionDate || 'Schedule confirmed');
        setText('profileScheduleMeta', `${teacherName} • ${sessionTime || 'Time to be announced'} • ${roomName}`);
    } else if (isPendingEnrollment) {
        setText('profileScheduleTitle', 'Schedule being finalized');
        setText('profileScheduleMeta', 'Admin is still confirming your teacher, date, and room.');
    } else {
        setText('profileScheduleTitle', 'No approved class schedule yet');
        setText('profileScheduleMeta', 'Your next approved class will appear here once enrollment is active.');
    }

    setText('profileEnrollmentTitle', enrollment?.package_name || 'No active package yet');
    setHtml('profileEnrollmentMeta', renderStudentProfileEnrollmentMeta(enrollment, portal.instruments || [], s.branch_name || '—'));

    try {
        const requestMeta = await fetchStudentRequestMetaByEmail(user.email);
        bindStudentAdditionalSessionsForm(s, enrollment, requestMeta?.success ? requestMeta : null);
    } catch (error) {
        bindStudentAdditionalSessionsForm(s, enrollment, null);
    }

    const enrollmentHint = document.getElementById('profileEnrollmentHint');
    if (enrollmentHint) {
        if (isActiveEnrollment) {
            enrollmentHint.textContent = 'You are already enrolled. This page is mainly for viewing your details and making simple profile updates.';
        } else if (isPendingEnrollment) {
            enrollmentHint.textContent = 'Your enrollment is pending. Watch the schedule section above for the approved class details.';
        } else {
            enrollmentHint.textContent = 'Your approved enrollment details will appear here once admin finalizes them.';
        }
    }

    const form = document.getElementById('profileForm');
    if (!form) return;

    // Fill fields
    form.student_id.value = s.student_id || '';
    form.first_name.value = s.first_name || '';
    form.last_name.value = s.last_name || '';
    form.middle_name.value = s.middle_name || '';
    form.email.value = s.email || '';
    form.phone.value = s.phone || '';
    form.address.value = s.address || '';
    form.grade_year.value = s.grade_year || '';
    form.branch_id.value = s.branch_id || '';

    // Primary guardian (read-only display)
    const g = portal.primary_guardian;
    if (g) {
        setText('guardianName', `${g.first_name || ''} ${g.last_name || ''}`.trim());
        setText('guardianPhone', g.phone || '—');
        setText('guardianRelationship', g.relationship_type || '—');
    } else {
        setText('guardianName', '—');
        setText('guardianPhone', '—');
        setText('guardianRelationship', '—');
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const payload = {
            action: 'update-student',
            student_id: parseInt(form.student_id.value, 10),
            first_name: form.first_name.value.trim(),
            last_name: form.last_name.value.trim(),
            middle_name: form.middle_name.value.trim(),
            email: form.email.value.trim(),
            phone: form.phone.value.trim(),
            address: form.address.value.trim(),
            grade_year: form.grade_year.value.trim(),
            branch_id: parseInt(form.branch_id.value, 10)
        };

        try {
            const res = await axios.post(`${baseApiUrl}/students.php`, payload);
            const data = res.data;
            if (data.success) {
                showMessage('Profile updated successfully.', 'success');
            } else {
                showMessage(data.error || 'Failed to update profile.', 'error');
            }
        } catch (err) {
            console.error('Profile update error:', err);
            showMessage('Network error. Please try again.', 'error');
        }
    });
}

function renderStudentFormalLearningProgress(portal) {
    const currentEl = document.getElementById('studentFormalLearningProgress');
    const historyEl = document.getElementById('studentLearningHistory');
    if (!currentEl || !historyEl) return;
    const current = Array.isArray(portal?.learning_progress) ? portal.learning_progress : [];
    const history = Array.isArray(portal?.learning_history) ? portal.learning_history : [];
    const exams = Array.isArray(portal?.promotional_exams) ? portal.promotional_exams : [];

    currentEl.innerHTML = current.length ? current.map(row => `
        <article class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 p-5">
            <div class="flex items-start justify-between gap-3">
                <div><div class="text-xs font-bold uppercase tracking-widest text-gold-600 dark:text-gold-300">${escapeHtml(row.instrument_name || 'Instrument')}</div><h3 class="mt-1 text-xl font-black text-zinc-900 dark:text-white">${escapeHtml(row.level_name || 'Level not set')}</h3></div>
                <span class="rounded-full border border-blue-200 bg-blue-50 px-3 py-1 text-xs font-bold text-blue-700 dark:border-blue-500/20 dark:bg-blue-500/10 dark:text-blue-300">In Progress</span>
            </div>
            <div class="mt-4 space-y-2 text-sm text-zinc-600 dark:text-zinc-300">
                <div><span class="text-zinc-500">Book / material:</span> <strong class="text-zinc-900 dark:text-white">${escapeHtml(row.book_material || 'Not set')}</strong></div>
                <div><span class="text-zinc-500">Current topic:</span> <strong class="text-zinc-900 dark:text-white">${escapeHtml(row.current_topic || 'Not set')}</strong></div>
                <div><span class="text-zinc-500">Skills:</span> ${escapeHtml(row.skills_developing || 'Not set')}</div>
                <div><span class="text-zinc-500">Areas to improve:</span> ${escapeHtml(row.areas_for_improvement || 'Not set')}</div>
            </div>
            <div class="mt-4 rounded-xl border border-zinc-200 dark:border-white/10 bg-white dark:bg-white/5 px-4 py-3"><div class="text-xs uppercase tracking-widest text-zinc-500">Assessment readiness</div><div class="mt-1 font-bold text-zinc-900 dark:text-white">${escapeHtml(row.assessment_readiness || 'Not Ready')}</div></div>
            ${row.instructor_notes ? `<div class="mt-3 text-sm text-zinc-600 dark:text-zinc-300"><span class="font-semibold">Instructor note:</span> ${escapeHtml(row.instructor_notes)}</div>` : ''}
        </article>
    `).join('') : '<div class="lg:col-span-2 rounded-2xl border border-dashed border-zinc-300 dark:border-white/10 px-5 py-8 text-center text-sm text-zinc-500 dark:text-zinc-400">Your instructor has not created a formal learning-progress record yet.</div>';

    historyEl.innerHTML = history.length ? history.map(row => {
        const exam = exams.find(item => Number(item.exam_id || 0) === Number(row.achieved_exam_id || 0));
        return `<article class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 px-4 py-4 sm:flex sm:items-center sm:justify-between sm:gap-4">
            <div><div class="font-extrabold text-zinc-900 dark:text-white">${escapeHtml(row.instrument_name || 'Instrument')} · ${escapeHtml(row.level_name || 'Level')}</div><div class="mt-1 text-sm text-zinc-500 dark:text-zinc-400">${escapeHtml(row.book_material || 'No book recorded')} · Achieved ${escapeHtml(formatDateLong(row.achieved_at || row.issued_at || '') || 'date not set')}</div>${exam ? `<div class="mt-1 text-xs text-zinc-500">Exam rating: ${escapeHtml(exam.grade_rating || '—')} · ${escapeHtml(exam.result || 'Passed')}</div>` : ''}</div>
            <div class="mt-3 flex flex-wrap gap-2 sm:mt-0"><span class="rounded-full bg-emerald-100 px-3 py-1 text-xs font-bold text-emerald-700">Passed</span>${row.certificate_id ? '<span class="rounded-full bg-gold-100 px-3 py-1 text-xs font-bold text-gold-700">Certificate Issued</span>' : ''}</div>
        </article>`;
    }).join('') : '<div class="rounded-2xl border border-dashed border-zinc-300 dark:border-white/10 px-5 py-6 text-center text-sm text-zinc-500 dark:text-zinc-400">No achieved levels yet. Current records remain in progress until a promotional exam is passed.</div>';
}

async function openGuardianAdditionalSessions(index) {
    const item = guardianPortalStudents[Number(index)];
    const student = item?.student || {};
    const enrollment = item?.current_enrollment || null;
    if (!student.student_id || !enrollment || !['Active', 'Completed'].includes(String(enrollment.status || ''))) {
        showMessage('This student needs an approved enrollment first.', 'error');
        return;
    }
    const totalSessions = Number(enrollment.package_sessions || enrollment.total_sessions || 0);
    const usedSessions = Math.max(Number(enrollment.used_sessions || enrollment.completed_sessions || 0), getUsedPackageSessionCount(item));
    if (totalSessions < 1 || usedSessions < totalSessions) {
        const remaining = Math.max(0, totalSessions - usedSessions);
        showMessage(`Additional sessions become available after the current package is fully used. ${remaining} session${remaining === 1 ? '' : 's'} remaining.`, 'error');
        return;
    }
    if (String(item?.latest_session_extension_request?.status || '') === 'Pending') {
        showMessage('An additional-session request is already pending for this student.', 'error');
        return;
    }

    const result = await Swal.fire({
        title: 'Request Additional Sessions',
        width: 480,
        confirmButtonText: 'Submit Request',
        showCancelButton: true,
        confirmButtonColor: '#d4a62a',
        customClass: {
            popup: 'guardian-additional-sessions-popup'
        },
        html: `
            <div class="space-y-3 text-left">
                <p class="text-sm leading-5 text-zinc-600"><strong>${escapeHtml(`${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student')}</strong> · ₱650 per session</p>
                <div><label class="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-zinc-500">Number of sessions</label><input id="guardianAdditionalQuantity" type="number" min="1" max="50" value="1" class="swal2-input guardian-additional-field !m-0 !w-full"></div>
                <div><label class="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-zinc-500">Payment method</label><select id="guardianAdditionalPaymentMethod" class="swal2-select guardian-additional-field !m-0 !w-full"><option value="GCash">GCash</option><option value="Bank Transfer">Bank Transfer</option><option value="Cash">Cash</option></select></div>
                <div><label class="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-zinc-500">Payment proof</label><input id="guardianAdditionalProof" type="file" accept=".jpg,.jpeg,.png,.webp,.pdf" class="block w-full text-xs"><div class="mt-1 text-[11px] text-zinc-500">Required for GCash and bank transfer.</div></div>
                <div><label class="mb-1.5 block text-[11px] font-bold uppercase tracking-wider text-zinc-500">Notes <span class="font-medium normal-case tracking-normal">(optional)</span></label><textarea id="guardianAdditionalNotes" class="swal2-textarea guardian-additional-field !m-0 !w-full" rows="2"></textarea></div>
                <div class="flex items-center justify-between rounded-xl bg-amber-50 px-3.5 py-2.5"><span class="text-sm text-zinc-600">Total</span><strong id="guardianAdditionalTotal" class="text-base">₱650.00</strong></div>
            </div>`,
        didOpen: () => {
            const quantity = document.getElementById('guardianAdditionalQuantity');
            quantity?.addEventListener('input', () => {
                const count = Math.min(50, Math.max(1, Number(quantity.value || 1)));
                const total = document.getElementById('guardianAdditionalTotal');
                if (total) total.textContent = formatCurrencyPHP(count * 650);
            });
        },
        preConfirm: () => {
            const quantity = Math.min(50, Math.max(1, Number(document.getElementById('guardianAdditionalQuantity')?.value || 1)));
            const paymentMethod = document.getElementById('guardianAdditionalPaymentMethod')?.value || '';
            const proof = document.getElementById('guardianAdditionalProof')?.files?.[0] || null;
            if (paymentMethod !== 'Cash' && !proof) {
                Swal.showValidationMessage('Upload proof of payment for this payment method.');
                return false;
            }
            return { quantity, paymentMethod, proof, notes: document.getElementById('guardianAdditionalNotes')?.value.trim() || '' };
        }
    });
    if (!result.isConfirmed || !result.value) return;

    const payload = new FormData();
    payload.append('action', 'submit-session-extension-request');
    payload.append('student_id', String(student.student_id));
    payload.append('requested_sessions', String(result.value.quantity));
    payload.append('payment_method', result.value.paymentMethod);
    payload.append('notes', result.value.notes);
    if (result.value.proof) payload.append('session_payment_proof_file', result.value.proof);
    try {
        const response = await axios.post(`${baseApiUrl}/students.php`, payload, { headers: { 'Content-Type': 'multipart/form-data' } });
        if (!response.data?.success) throw new Error(response.data?.error || 'Unable to submit request.');
        item.latest_session_extension_request = {
            status: 'Pending',
            requested_sessions: result.value.quantity,
            requested_amount: result.value.quantity * 650
        };
        showMessage(response.data.message || 'Additional-session request submitted.', 'success');
        closeGuardianStudentModal();
        setHtml('guardianStudentsList', renderGuardianStudentsList(guardianPortalStudents));
    } catch (error) {
        showMessage(error?.response?.data?.error || error.message || 'Unable to submit request.', 'error');
    }
}

window.openGuardianAdditionalSessions = openGuardianAdditionalSessions;

function renderAdditionalSessionRequestStatus(request) {
    if (!request) {
        return '<div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 px-4 py-3 text-sm text-zinc-600 dark:text-zinc-300">No additional-session request is currently under review.</div>';
    }
    const status = String(request.status || 'Pending');
    const quantity = Number(request.requested_sessions || 0);
    const color = status === 'Approved'
        ? 'border-emerald-300 bg-emerald-50 text-emerald-800 dark:border-emerald-500/20 dark:bg-emerald-500/10 dark:text-emerald-200'
        : status === 'Rejected'
            ? 'border-red-300 bg-red-50 text-red-800 dark:border-red-500/20 dark:bg-red-500/10 dark:text-red-200'
            : 'border-amber-300 bg-amber-50 text-amber-800 dark:border-amber-500/20 dark:bg-amber-500/10 dark:text-amber-200';
    return `<div class="rounded-2xl border px-4 py-3 text-sm ${color}">
        <div class="font-bold">Latest request: ${escapeHtml(status)}</div>
        <div class="mt-1">${escapeHtml(String(quantity))} session${quantity === 1 ? '' : 's'} · ${formatCurrencyPHP(request.requested_amount || quantity * 650)}</div>
        ${request.admin_notes ? `<div class="mt-1 text-xs">Staff note: ${escapeHtml(request.admin_notes)}</div>` : ''}
    </div>`;
}

function bindStudentAdditionalSessionsForm(student, enrollment, requestMeta) {
    const card = document.getElementById('studentAdditionalSessionsCard');
    const form = document.getElementById('studentAdditionalSessionsForm');
    if (!card || !form) return;

    const total = Number(enrollment?.package_sessions || 0);
    const base = Number(enrollment?.base_package_sessions || total || 0);
    const additional = Math.max(0, total - base);
    const used = Math.max(0, Number(enrollment?.used_sessions || enrollment?.completed_sessions || 0));
    const remaining = Math.max(0, total - used);
    const approvedEnrollment = enrollment && ['Active', 'Completed'].includes(String(enrollment.status || ''));
    const canRequestAdditionalSessions = approvedEnrollment && total > 0 && remaining === 0;
    card.classList.toggle('hidden', !canRequestAdditionalSessions);
    if (!canRequestAdditionalSessions) return;
    const balanceEl = document.getElementById('studentAdditionalSessionBalance');
    if (balanceEl) {
        balanceEl.innerHTML = [
            ['Base sessions', base],
            ['Additional', additional],
            ['Used', used],
            ['Remaining', remaining]
        ].map(([label, value]) => `<div class="rounded-2xl border border-zinc-200 dark:border-white/10 bg-zinc-50 dark:bg-black/20 px-4 py-3"><div class="text-xs text-zinc-500">${label}</div><div class="mt-1 text-xl font-black text-zinc-900 dark:text-white">${value}</div></div>`).join('');
    }

    const latest = requestMeta?.latest_session_extension_request || null;
    setHtml('studentAdditionalSessionRequestStatus', renderAdditionalSessionRequestStatus(latest));
    const hasPending = String(latest?.status || '') === 'Pending';
    const quantityEl = document.getElementById('studentAdditionalSessionsQuantity');
    const paymentMethodEl = document.getElementById('studentAdditionalSessionsPaymentMethod');
    const proofEl = document.getElementById('studentAdditionalSessionsProof');
    const proofHint = document.getElementById('studentAdditionalSessionsProofHint');
    const totalEl = document.getElementById('studentAdditionalSessionsTotal');
    const submitBtn = document.getElementById('studentAdditionalSessionsSubmit');

    const refreshPrice = () => {
        const quantity = Math.min(50, Math.max(1, Number(quantityEl?.value || 1)));
        if (totalEl) totalEl.textContent = formatCurrencyPHP(quantity * 650);
    };
    const refreshProof = () => {
        const required = String(paymentMethodEl?.value || '') !== 'Cash';
        if (proofEl) proofEl.required = required;
        if (proofHint) proofHint.textContent = required ? 'Required for this payment method.' : 'Not required for a cash payment.';
    };
    quantityEl?.addEventListener('input', refreshPrice);
    paymentMethodEl?.addEventListener('change', refreshProof);
    refreshPrice();
    refreshProof();

    Array.from(form.elements).forEach(control => { control.disabled = hasPending; });
    if (submitBtn) submitBtn.disabled = hasPending;
    if (form.dataset.bound === 'true') return;
    form.dataset.bound = 'true';
    form.addEventListener('submit', async (event) => {
        event.preventDefault();
        const quantity = Math.min(50, Math.max(1, Number(quantityEl?.value || 1)));
        const paymentMethod = String(paymentMethodEl?.value || '');
        if (paymentMethod !== 'Cash' && !proofEl?.files?.length) {
            showMessage('Upload proof of payment before submitting.', 'error');
            return;
        }
        const payload = new FormData();
        payload.append('action', 'submit-session-extension-request');
        payload.append('student_id', String(student.student_id || ''));
        payload.append('requested_sessions', String(quantity));
        payload.append('payment_method', paymentMethod);
        payload.append('notes', document.getElementById('studentAdditionalSessionsNotes')?.value.trim() || '');
        if (proofEl?.files?.[0]) payload.append('session_payment_proof_file', proofEl.files[0]);
        if (submitBtn) submitBtn.disabled = true;
        try {
            const response = await axios.post(`${baseApiUrl}/students.php`, payload, { headers: { 'Content-Type': 'multipart/form-data' } });
            if (!response.data?.success) throw new Error(response.data?.error || 'Unable to submit request.');
            showMessage(response.data.message || 'Additional-session request submitted.', 'success');
            setHtml('studentAdditionalSessionRequestStatus', renderAdditionalSessionRequestStatus({
                status: 'Pending', requested_sessions: quantity, requested_amount: quantity * 650
            }));
            Array.from(form.elements).forEach(control => { control.disabled = true; });
        } catch (error) {
            showMessage(error?.response?.data?.error || error.message || 'Unable to submit request.', 'error');
            if (submitBtn) submitBtn.disabled = false;
        }
    });
}

// Logout
function logout() {
    const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;

    if (user && typeof baseApiUrl !== 'undefined' && typeof fetch === 'function') {
        try {
            fetch(`${baseApiUrl}/audit_logs.php?action=log`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    action_name: 'User Logout',
                    module: 'Authentication',
                    description: 'User signed out successfully.',
                    severity: 'info',
                    user_id: user.user_id || null,
                    user_name: user.email || user.username || null,
                    user_role: user.role_name || null
                }),
                keepalive: true
            }).catch(() => {});
        } catch (e) {
            // Ignore logging failures on logout.
        }
        setTimeout(() => Auth.logout(), 150);
        return;
    }

    Auth.logout();
}

// Load branches for walk-in admin form
async function loadWalkinBranches() {
    const branchSelect = document.getElementById('walkin_branch_id');
    if (!branchSelect) return;

    try {
        const response = await axios.get(`${baseApiUrl}/branch.php?action=get-branches`);
        const data = response.data;

        if (data.success && data.branches) {
            branchSelect.innerHTML = '<option value=\"\">Select Branch</option>';
            data.branches.forEach(branch => {
                const option = document.createElement('option');
                option.value = branch.branch_id;
                option.textContent = branch.branch_name;
                branchSelect.appendChild(option);
            });
        } else {
            branchSelect.innerHTML = '<option value=\"\">No branches available</option>';
        }
    } catch (error) {
        console.error('Error loading branches for walk-in:', error);
        branchSelect.innerHTML = '<option value=\"\">Error loading branches</option>';
    }
}

// ===== Walk-in (Admin) registration – rich form mirroring public registration =====

let walkinSessionPackages = [];
let walkinAvailableInstruments = [];

// Load session packages into admin walk-in form
async function loadWalkinSessionPackages() {
    const select = document.getElementById('walkin_sessionPackage');
    if (!select) return;

    try {
        const response = await axios.get(`${baseApiUrl}/sessions.php?action=get-packages`);
        const data = response.data;

        if (data.success && data.packages) {
            walkinSessionPackages = data.packages;
            select.innerHTML = '<option value="">Select Package</option>';
            data.packages.forEach(pkg => {
                const option = document.createElement('option');
                option.value = pkg.package_id;
                option.textContent = `${pkg.package_name} (${pkg.sessions} sessions, ${pkg.max_instruments} instrument${pkg.max_instruments > 1 ? 's' : ''})`;
                option.setAttribute('data-sessions', pkg.sessions);
                option.setAttribute('data-max-instruments', pkg.max_instruments);
                option.setAttribute('data-price', (pkg.price != null && !isNaN(pkg.price)) ? String(pkg.price) : '0');
                select.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Failed to load walk-in session packages:', error);
        // Fallback to same defaults as public registration
        walkinSessionPackages = [
            { package_id: 1, sessions: 12, max_instruments: 1, price: 7450 },
            { package_id: 2, sessions: 20, max_instruments: 2, price: 11800 }
        ];
        select.innerHTML = `
            <option value="">Select Package</option>
            <option value="1" data-sessions="12" data-max-instruments="1" data-price="7450">Basic (12 Sessions, 1 instrument)</option>
            <option value="2" data-sessions="20" data-max-instruments="2" data-price="11800">Standard (20 Sessions, 2 instruments)</option>
        `;
    }
}

// Load instruments for walk-in registration (per-branch)
async function loadWalkinInstruments(branchId) {
    const container = document.getElementById('walkin_instrumentsContainer');
    if (!branchId) {
        if (container) {
            container.textContent = 'Select a branch and session package first';
        }
        walkinAvailableInstruments = [];
        return;
    }

    try {
        const response = await axios.get(`${baseApiUrl}/instruments.php?action=get-instruments&branch_id=${branchId}`);
        const data = response.data;

        if (data.success && data.instruments) {
            walkinAvailableInstruments = data.instruments;
            updateWalkinInstrumentSelection();
        } else if (container) {
            container.innerHTML = '<p class="text-sm text-red-400">No instruments available for this branch</p>';
        }
    } catch (error) {
        console.error('Failed to load walk-in instruments:', error);
        if (container) {
            container.innerHTML = '<p class="text-sm text-red-400">Failed to load instruments</p>';
        }
    }
}

// Helpers for walk-in instrument UI
function walkinGetAvailableTypes() {
    const seen = new Set();
    const types = [];
    walkinAvailableInstruments.forEach(inst => {
        const id = inst.type_id;
        const name = inst.type_name || 'Other';
        if (id != null && !seen.has(id)) {
            seen.add(id);
            types.push({ type_id: id, type_name: name });
        }
    });
    return types.sort((a, b) => (a.type_name || '').localeCompare(b.type_name || ''));
}

function walkinGetInstrumentsByType(typeId) {
    if (!typeId) return [];
    return walkinAvailableInstruments.filter(inst => inst.type_id == typeId);
}

// Build instrument selectors for walk-in form
function updateWalkinInstrumentSelection() {
    const container = document.getElementById('walkin_instrumentsContainer');
    if (!container) return;

    const sessionPackageSelect = document.getElementById('walkinSessionPackageId');
    if (!sessionPackageSelect || !sessionPackageSelect.value) {
        container.textContent = 'Select a branch and session package first';
        return;
    }

    if (walkinAvailableInstruments.length === 0) {
        container.textContent = 'Select a branch to see available instruments';
        return;
    }

    const selectedOption = sessionPackageSelect.options[sessionPackageSelect.selectedIndex];
    const maxInstruments = parseInt(selectedOption.getAttribute('data-max-instruments') || '1', 10);

    const types = walkinGetAvailableTypes();
    const typeOptionsHtml = types.map(t =>
        `<option value="${t.type_id}">${escapeHtml(t.type_name)}</option>`
    ).join('');

    let html = '';
    for (let i = 1; i <= maxInstruments; i++) {
        const slotLabel = maxInstruments === 1 ? 'Instrument Type' : `Instrument Type ${i}`;
        html += `
            <div class="p-3 bg-zinc-900/60 rounded-lg border border-zinc-700 space-y-2">
                <label class="block text-sm font-medium text-zinc-200">${slotLabel} *</label>
                <div>
                    <label class="block text-xs text-zinc-400 mb-1">Type</label>
                    <select class="walkin-instrument-type-select w-full px-4 py-2 bg-zinc-900 border border-zinc-700 rounded-lg text-white focus:outline-none focus:border-gold-400" data-slot="${i}" onchange="onWalkinInstrumentTypeChange(${i})">
                        <option value="">Select type...</option>
                        ${typeOptionsHtml}
                    </select>
                </div>
                <p class="text-xs text-zinc-400">An available instrument from this type will be assigned automatically.</p>
            </div>
        `;
    }
    container.innerHTML = html;
}

// Global handlers for instrument dropdowns (used in HTML onchange attributes)
function onWalkinInstrumentTypeChange(slot) {
    const typeSelect = document.querySelector(`select.walkin-instrument-type-select[data-slot="${slot}"]`);
    if (!typeSelect) return;

    const typeId = typeSelect.value;
    onWalkinInstrumentDropdownChange();
}

function onWalkinInstrumentDropdownChange() {
    const selects = document.querySelectorAll('select.walkin-instrument-select');
    if (!selects.length) {
        calculateWalkinTotalFee();
        return;
    }
    const used = new Set();
    selects.forEach(select => {
        const val = select.value;
        if (val) used.add(val);
    });
    selects.forEach(select => {
        const currentVal = select.value;
        Array.from(select.options).forEach(opt => {
            if (opt.value === '') return;
            const othersUsed = used.has(opt.value) && opt.value !== currentVal;
            opt.disabled = othersUsed;
        });
    });
    calculateWalkinTotalFee();
}

// Calculate total fee for walk-in admin registration (mirrors public logic)
function calculateWalkinTotalFee() {
    const registrationFee = 1000;
    const sessionPackageSelect = document.getElementById('walkinSessionPackageId');
    const paymentTypeSelect = document.getElementById('walkin_paymentType');

    const sessionFeeEl = document.getElementById('walkin_sessionFeeDisplay');
    const totalEl = document.getElementById('walkin_totalAmountDisplay');
    const feeInput = document.getElementById('walkin_registration_fee_amount');

    if (!sessionPackageSelect || !sessionPackageSelect.value || !paymentTypeSelect || !paymentTypeSelect.value) {
        if (sessionFeeEl) sessionFeeEl.textContent = '₱0.00';
        if (totalEl) {
            totalEl.innerHTML = `
                <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                        <div class="text-[11px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">Registration Fee</div>
                        <div class="mt-1 font-bold text-zinc-900 dark:text-white">${formatCurrencyPHP(registrationFee)}</div>
                    </div>
                    <div>
                        <div class="text-[11px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">Enrollment Fee</div>
                        <div class="mt-1 font-bold text-zinc-900 dark:text-white">${formatCurrencyPHP(0)}</div>
                    </div>
                    <div>
                        <div class="text-[11px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">Total Due</div>
                        <div class="mt-1 font-bold text-gold-700 dark:text-gold-300">${formatCurrencyPHP(registrationFee)}</div>
                    </div>
                </div>
            `;
        }
        if (feeInput) feeInput.value = registrationFee;
        return registrationFee;
    }

    const selectedOption = sessionPackageSelect.options[sessionPackageSelect.selectedIndex];
    const sessions = parseInt(selectedOption.getAttribute('data-sessions') || '0', 10);
    const paymentType = paymentTypeSelect.value;
    const basePrice = parseFloat(selectedOption.getAttribute('data-price') || '0');

    // Check if saxophone selected
    const selectedInstruments = getWalkinSelectedInstrumentIds();
    const hasSaxophone = selectedInstruments.some(id => {
        const instrument = walkinAvailableInstruments.find(inst => inst.instrument_id === id);
        return instrument && (instrument.instrument_name.toLowerCase().includes('saxophone') ||
                             instrument.type_name?.toLowerCase().includes('saxophone'));
    });

    let sessionFee = 0;
    if (basePrice > 0) {
        if (paymentType === 'Partial Payment') {
            const downpaymentRatio = sessions === 12 ? (3000 / 7450) : (sessions === 20 ? (5000 / 11800) : 0.42);
            sessionFee = Math.round(basePrice * downpaymentRatio);
        } else if (paymentType === 'Full Payment') {
            if (hasSaxophone) {
                const saxophoneMultiplier = sessions === 12 ? (8100 / 7450) : (sessions === 20 ? (13000 / 11800) : 1.09);
                sessionFee = Math.round(basePrice * saxophoneMultiplier);
            } else {
                sessionFee = basePrice;
            }
        } else if (paymentType === 'Installment') {
            const installmentRatio = sessions === 12 ? (3000 / 7450) : (sessions === 20 ? (5000 / 11800) : 0.42);
            sessionFee = Math.round(basePrice * installmentRatio);
        }
    } else {
        if (paymentType === 'Partial Payment' || paymentType === 'Installment') {
            if (sessions === 12) sessionFee = 3000;
            else if (sessions === 20) sessionFee = 5000;
        } else if (paymentType === 'Full Payment') {
            if (hasSaxophone) {
                if (sessions === 12) sessionFee = 8100;
                else if (sessions === 20) sessionFee = 13000;
            } else {
                if (sessions === 12) sessionFee = 7450;
                else if (sessions === 20) sessionFee = 11800;
            }
        }
    }

    const total = registrationFee + sessionFee;

    if (sessionFeeEl) sessionFeeEl.textContent = `₱${sessionFee.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    if (totalEl) {
        totalEl.innerHTML = `
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                    <div class="text-[11px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">Registration Fee</div>
                    <div class="mt-1 font-bold text-zinc-900 dark:text-white">${formatCurrencyPHP(registrationFee)}</div>
                </div>
                <div>
                    <div class="text-[11px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">Enrollment Fee</div>
                    <div class="mt-1 font-bold text-zinc-900 dark:text-white">${formatCurrencyPHP(sessionFee)}</div>
                </div>
                <div>
                    <div class="text-[11px] uppercase tracking-wider text-zinc-500 dark:text-zinc-400">Total Due</div>
                    <div class="mt-1 font-bold text-gold-700 dark:text-gold-300">${formatCurrencyPHP(total)}</div>
                </div>
            </div>
        `;
    }
    if (feeInput) feeInput.value = total;

    return total;
}

// Calculate age from date string (YYYY-MM-DD)
function calculateAgeFromBirthdate(dateStr) {
    if (!dateStr) return null;
    const dob = new Date(dateStr);
    if (isNaN(dob.getTime())) return null;
    const now = new Date();
    let age = now.getFullYear() - dob.getFullYear();
    const m = now.getMonth() - dob.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < dob.getDate())) age--;
    return age;
}

function updatePublicGuardianRequiredState() {
    const dobInput = document.getElementById('student_date_of_birth');
    const guardianFields = document.querySelectorAll('.guardian-field-public');
    const guardianLabels = document.querySelectorAll('.guardian-label-public');
    const badge = document.getElementById('guardian_required_badge_public');
    if (!dobInput) return;

    const age = calculateAgeFromBirthdate(dobInput.value);
    const isMinorOr18Below = age !== null && age <= 18;

    if (badge) badge.classList.toggle('hidden', !isMinorOr18Below);

    guardianFields.forEach(el => {
        if (isMinorOr18Below) el.setAttribute('required', 'required');
        else el.removeAttribute('required');
    });

    guardianLabels.forEach(el => {
        const text = el.textContent.replace(/\s*\*\s*$/, '').trim();
        el.textContent = text + (isMinorOr18Below ? ' *' : '');
    });
}

// Update age display and guardian required state for walk-in form
function updateWalkinAgeAndGuardianRequired() {
    const dobInput = document.getElementById('walkin_student_dob');
    const ageDisplay = document.getElementById('walkin_student_age_display');
    const guardianSection = document.getElementById('walkin_guardian_section');
    const guardianFields = document.querySelectorAll('.guardian-field');
    const guardianLabels = document.querySelectorAll('.guardian-label');
    const badge = document.getElementById('guardian_required_badge');

    if (!dobInput || !ageDisplay) return;

    const age = calculateAgeFromBirthdate(dobInput.value);
    const isMinor = age !== null && age <= 18;
    const allowRealEmail = age !== null && age > 18;

    if (age !== null) {
        ageDisplay.textContent = age + ' years old';
    } else {
        ageDisplay.textContent = '— Select date of birth —';
    }

    if (guardianSection) guardianSection.classList.toggle('hidden', !isMinor);
    if (badge) badge.classList.toggle('hidden', !isMinor);
    syncWalkinLoginModeUI(allowRealEmail);

    guardianFields.forEach(el => {
        if (isMinor) {
            el.setAttribute('required', 'required');
        } else {
            el.removeAttribute('required');
        }
    });

    guardianLabels.forEach(el => {
        const text = el.textContent.replace(/\s*\*\s*$/, '').trim();
        el.textContent = text + (isMinor ? ' *' : '');
    });
}

let walkinPackages = [];

async function loadWalkinPackages(branchId = 0) {
    const select = document.getElementById('walkinSessionPackageId');
    if (!select) return;

    try {
        let url = `${baseApiUrl}/sessions.php?action=get-packages`;
        if (branchId) {
            url += `&branch_id=${branchId}`;
        }
        const response = await axios.get(url);
        const data = response.data;
        const packages = data.success && Array.isArray(data.packages) ? data.packages : [];
        walkinPackages = packages;

        select.innerHTML = '<option value="">Select package</option>' + packages.map(pkg => {
            const maxInstruments = Number(pkg.max_instruments || 1);
            const price = Number(pkg.price || 0);
            return `<option value="${pkg.package_id}" data-sessions="${Number(pkg.sessions || 0)}" data-max-instruments="${maxInstruments}" data-price="${price}">${pkg.package_name} (${pkg.sessions} sessions)</option>`;
        }).join('');
    } catch (error) {
        console.error('Failed to load packages for walk-in registration:', error);
        if (select) {
            select.innerHTML = '<option value="">Unable to load packages</option>';
        }
    }
}

function updateWalkinPackageDetails() {
    const select = document.getElementById('walkinSessionPackageId');
    const details = document.getElementById('walkinPackageDetails');
    if (!select || !details) return;

    const pkgId = select.value;
    const pkg = walkinPackages.find(p => String(p.package_id) === String(pkgId));
    if (!pkg) {
        details.textContent = 'Select a package to view details.';
        return;
    }

    details.innerHTML = `
        <div class="text-sm font-semibold text-white">${pkg.package_name}</div>
        <div class="mt-1 text-xs text-zinc-300">${pkg.sessions} sessions</div>
        <div class="mt-1 text-xs text-zinc-300">${pkg.description ? pkg.description : ''}</div>
        <div class="mt-2 text-xs text-gold-200">Amount: ₱${Number(pkg.price || 0).toLocaleString('en-US', {minimumFractionDigits: 2, maximumFractionDigits: 2})}</div>
    `;
}

function getWalkinSelectedInstrumentIds() {
    return getResolvedInstrumentIdsFromSelectors(
        '#walkinInstrumentsContainer',
        'select.student-request-instrument-type',
        'select.student-request-instrument',
        studentRequestAvailableInstruments
    );
}

function getWalkinEnrollmentPayload() {
    const packageSelect = document.getElementById('walkinSessionPackageId');
    const paymentTypeEl = document.getElementById('walkin_paymentType');
    const paymentProofEl = document.getElementById('walkinPackagePaymentProof');

    if (!packageSelect || !paymentTypeEl) {
        return null;
    }

    const packageId = parseInt(packageSelect.value, 10);
    const paymentType = String(paymentTypeEl.value || '').trim();
    const instrumentIds = getWalkinSelectedInstrumentIds();
    const selectedOption = packageSelect.options[packageSelect.selectedIndex];
    const maxInstruments = Number(selectedOption?.getAttribute('data-max-instruments') || 1);

    if (!packageId || !paymentType || instrumentIds.length < 1) {
        return { error: 'Please complete package, payment type, and instruments.' };
    }

    if (!['Full Payment', 'Partial Payment', 'Installment'].includes(paymentType)) {
        return { error: 'Invalid package payment type selected.' };
    }

    if (instrumentIds.length > maxInstruments) {
        return { error: `You can select up to ${maxInstruments} instrument(s) for this package.` };
    }

    return {
        packageId,
        paymentType,
        instrumentIds,
        paymentProofFile: paymentProofEl && paymentProofEl.files && paymentProofEl.files[0] ? paymentProofEl.files[0] : null
    };
}

async function submitWalkinEnrollmentRequest(studentId) {
    const enrollment = getWalkinEnrollmentPayload();
    if (!enrollment || enrollment.error) {
        return { success: false, error: enrollment?.error || 'Walk-in enrollment details are incomplete.' };
    }

    const requestFormData = new FormData();
    requestFormData.append('action', 'submit-package-request');
    requestFormData.append('student_id', String(Number(studentId)));
    requestFormData.append('package_id', String(enrollment.packageId));
    requestFormData.append('payment_type', enrollment.paymentType);
    requestFormData.append('instrument_ids_json', JSON.stringify(enrollment.instrumentIds));
    if (enrollment.paymentProofFile) {
        requestFormData.append('package_payment_proof_file', enrollment.paymentProofFile);
    }

    return await postStudentPackageRequest(requestFormData);
}

function setupWalkinEnrollmentForm() {
    const branchSelect = document.getElementById('walkin_branch_id');
    const packageSelect = document.getElementById('walkinSessionPackageId');
    const paymentTypeEl = document.getElementById('walkin_paymentType');
    if (branchSelect && !branchSelect.dataset.walkinEnrollmentBound) {
        branchSelect.addEventListener('change', async function () {
            const branchId = Number(this.value || 0);
            await loadWalkinPackages(branchId);
            await loadWalkinInstruments(branchId);
            updateWalkinPackageDetails();
            calculateWalkinTotalFee();
        });
        branchSelect.dataset.walkinEnrollmentBound = '1';
    }

    if (packageSelect && !packageSelect.dataset.walkinEnrollmentBound) {
        packageSelect.addEventListener('change', function () {
            updateWalkinPackageDetails();
            updateWalkinInstrumentSelection();
            calculateWalkinTotalFee();
        });
        packageSelect.dataset.walkinEnrollmentBound = '1';
    }

    if (paymentTypeEl && !paymentTypeEl.dataset.walkinEnrollmentBound) {
        paymentTypeEl.addEventListener('change', calculateWalkinTotalFee);
        paymentTypeEl.dataset.walkinEnrollmentBound = '1';
    }

    const activeBranchId = Number(branchSelect?.value || 0);
    if (activeBranchId > 0) {
        loadWalkinPackages(activeBranchId);
        loadWalkinInstruments(activeBranchId);
    } else {
        loadWalkinPackages();
    }
    updateWalkinPackageDetails();
    calculateWalkinTotalFee();
}

function syncWalkinLoginModeUI(allowRealEmail = false) {
    const emailInput = document.getElementById('walkin_student_email');
    const emailLabel = document.getElementById('walkin_student_email_label');
    const emailHint = document.getElementById('walkin_student_email_hint');
    if (!emailInput) return;

    emailInput.type = 'text';
    emailInput.autocomplete = 'off';
    emailInput.placeholder = allowRealEmail ? 'Real email or login name' : 'Login name';
    emailInput.required = true;

    if (emailLabel) {
        emailLabel.textContent = allowRealEmail
            ? 'Student Email or Login Name'
            : 'Login Name (Becomes @fas.com)';
    }

    if (emailHint) {
        emailHint.innerHTML = allowRealEmail
            ? 'Adults can use a real email address for verification, or enter a simple login name and the system will turn it into a <code>@fas.com</code> login automatically.'
            : 'Enter a simple name or username. The system will turn it into a <code>@fas.com</code> login automatically.';
    }
}

function syncWalkinGuardianLoginModeUI() {
    const emailInput = document.getElementById('walkin_guardian_email');
    const emailLabel = document.getElementById('walkin_guardian_email_label');
    const emailHint = document.getElementById('walkin_guardian_email_hint');
    if (!emailInput) return;

    emailInput.type = 'text';
    emailInput.autocomplete = 'off';
    emailInput.placeholder = 'Login name or real email';

    if (emailLabel) {
        emailLabel.textContent = 'Login Email (Becomes @fas.com)';
    }

    if (emailHint) {
        emailHint.innerHTML = 'Use a real email address, or enter a simple login name and the system will turn it into a <code>@fas.com</code> account automatically.';
    }
}

// Initialize walk-in admin page (used on admin_registration.html)
function initWalkinPage() {
    const form = document.getElementById('walkinForm');
    if (!form) return;

    if (window.FasIntlPhone) {
        window.FasIntlPhone.init(form);
    }

    // Seed dropdowns
    loadWalkinBranches();
    syncWalkinLoginModeUI();
    syncWalkinGuardianLoginModeUI();

    const branchSelect = document.getElementById('walkin_branch_id');
    const dobInput = document.getElementById('walkin_student_dob');

    if (dobInput) {
        dobInput.addEventListener('change', updateWalkinAgeAndGuardianRequired);
        dobInput.addEventListener('input', updateWalkinAgeAndGuardianRequired);
        // Initial state (e.g. if form is pre-filled)
        updateWalkinAgeAndGuardianRequired();
    }

    if (branchSelect) {
        branchSelect.addEventListener('change', function () {
            // Branch still matters for profile and assignment later.
        });
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();

        const btn = document.getElementById('walkinSubmitBtn');
        const btnText = document.getElementById('walkinSubmitBtnText');

        // Prevent double submit (first request can succeed, second can duplicate the walk-in account)
        if (form.dataset.submitting === '1') {
            return;
        }
        form.dataset.submitting = '1';
        if (btn) btn.disabled = true;
        if (btnText) btnText.textContent = 'Creating...';

        const formData = new FormData(form);
        const data = {};
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        data['registration_fee_amount'] = 1000;

        try {
            const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
            const role = String(user?.role_name || '').toLowerCase();
            if (['staff', 'desk', 'front desk'].includes(role)) {
                data['registration_source'] = 'staff';
                const deskBranchId = Number(user?.branch_id || 0);
                if (deskBranchId > 0) data['desk_branch_id'] = deskBranchId;
            } else if (['manager', 'branch manager'].includes(role)) {
                data['registration_source'] = 'manager';
                const managerBranchId = Number(user?.branch_id || 0);
                if (managerBranchId > 0) data['manager_branch_id'] = managerBranchId;
            } else {
                data['registration_source'] = 'admin';
            }
        } catch (_) {
            data['registration_source'] = 'admin';
        }

        try {
            const response = await axios.post(`${baseApiUrl}/walkin_register.php?action=register`, data);

            const responseText = typeof response.data === 'string' ? response.data : JSON.stringify(response.data);
            let result;
            try {
                result = typeof response.data === 'string' ? JSON.parse(responseText) : response.data;
            } catch (parseErr) {
                console.error('Walk-in registration 400 - Response was not JSON:', responseText);
                showMessage('Registration failed. The server returned an invalid response. Check the browser console (F12) for details.', 'error');
                return;
            }

            if (result.success) {
                const guardianLabel = result.guardian_username
                    ? `<strong>Guardian ID:</strong> ${escapeHtml(result.guardian_username)}<br><strong>Guardian Password:</strong> Saved from registration<br>`
                    : '';
                const loginLabel = 'Login Email';
                const loginValue = result.login_email || result.username || data['student_email'] || '—';
                const isWalkInAccount = Boolean(result.walkin_login_generated);
                const needsVerification = Boolean(result.verification_required);

                // Reset form and hide modal if present
                form.reset();
                syncWalkinLoginModeUI();
                const modal = document.getElementById('registerStudentModal');
                if (modal) {
                    modal.classList.add('hidden');
                    modal.classList.remove('flex');
                }

                Swal.fire({
                    icon: 'success',
                    title: 'Student Registered',
                    html: `Student account was created successfully.<br><br>
                           <strong>${loginLabel}:</strong> ${escapeHtml(loginValue)}<br>
                           <strong>Student Temporary Password:</strong> ${escapeHtml(result.temporary_password || 'Check the account email')}<br>
                           ${guardianLabel}
                           ${needsVerification
                         ? '<br>Next step: verify the email inbox before logging in.'
                         : isWalkInAccount
                         ? '<br>Give this one-time password to the student privately. They must change it when they sign in.'
                         : '<br>Next step: confirm the walk-in registration payment method.'}`,
                    confirmButtonColor: '#b8860b'
                }).then(() => {
                    if (needsVerification) {
                        return;
                    }
                    if (!isWalkInAccount) {
                        const redirectTemplate = String(form.dataset.paymentRedirectTemplate || '').trim();
                        const redirectUrl = sanitizeInternalRedirectUrl(
                            redirectTemplate
                                ? redirectTemplate.replace('{student_id}', encodeURIComponent(String(result.student_id)))
                                : String(form.dataset.paymentRedirectUrl || '').trim()
                        );
                        openPaymentModal(result.student_id, { forceSource: 'walkin', redirectUrl });
                    }
                });
            } else {
                const errMsg = result.error || 'Registration failed. Please check all required fields and try again.';
                console.error('Walk-in registration failed (400):', errMsg, result);
                showMessage(errMsg, 'error');
            }
        } catch (error) {
            console.error('Walk-in create error:', error);
            showMessage(
                error?.response?.data?.error || error.message || 'An error occurred. Please try again.',
                'error'
            );
        } finally {
            form.dataset.submitting = '0';
            if (btn) btn.disabled = false;
            if (btnText) btnText.textContent = 'Proceed Payment';
        }
    });
}

// Load and display all students for admin_students page
async function loadStudentsForAdmin() {
    const tableBody = document.getElementById('studentsTable');
    if (!tableBody) return;

    try {
        const res = await axios.get(`${baseApiUrl}/students.php?action=get-all-students`);
        const data = res.data;
        const students = data.success ? data.students : [];

        if (!students || students.length === 0) {
            tableBody.innerHTML = `
                <tr>
                    <td colspan="6" class="px-6 py-8 text-center text-zinc-400">
                        <i class="fas fa-inbox text-2xl mb-2"></i>
                        <p>No students found</p>
                    </td>
                </tr>
            `;
            return;
        }

        tableBody.innerHTML = students.map(s => {
            const statusColors = {
                'Pending': 'text-yellow-400 bg-yellow-400/10',
                'Fee Paid': 'text-green-400 bg-green-400/10',
                'Approved': 'text-blue-400 bg-blue-400/10',
                'Rejected': 'text-red-400 bg-red-400/10',
                'Walk-In': 'text-purple-400 bg-purple-400/10'
            };
            const displayStatus = getWalkInRegistrationDisplayStatus(s);
            const statusClass = statusColors[displayStatus] || 'text-zinc-400 bg-zinc-400/10';

            const activeBadge = s.status === 'Active'
                ? '<span class="px-2 py-1 rounded text-xs font-semibold bg-green-400/10 text-green-400">Active</span>'
                : '<span class="px-2 py-1 rounded text-xs font-semibold bg-zinc-400/10 text-zinc-300">Inactive</span>';

            return `
                <tr class="hover:bg-gold-500/5 transition">
                    <td class="px-6 py-4">
                        <div class="font-medium text-white">${s.first_name} ${s.last_name}</div>
                    </td>
                    <td class="px-6 py-4 text-sm text-zinc-300">
                        <div>${s.email || ''}</div>
                        <div class="text-zinc-500">${s.phone || ''}</div>
                    </td>
                    <td class="px-6 py-4 text-zinc-300">
                        ${s.branch_name || ''}
                    </td>
                    <td class="px-6 py-4 text-sm text-zinc-300">
                        <div>Fee: ₱${parseFloat(s.registration_fee_amount || 0).toFixed(2)}</div>
                        <div>Paid: ₱${parseFloat(s.registration_fee_paid || 0).toFixed(2)}</div>
                    </td>
                    <td class="px-6 py-4 text-sm">
                        <div class="mb-1">
                            <span class="px-2 py-1 rounded text-xs font-semibold ${statusClass}">
                                ${displayStatus}
                            </span>
                        </div>
                        ${activeBadge}
                    </td>
                    <td class="px-6 py-4 text-sm text-zinc-400">
                        ${new Date(s.created_at).toLocaleDateString()}
                    </td>
                </tr>
            `;
        }).join('');
    } catch (error) {
        console.error('Failed to load students:', error);
        tableBody.innerHTML = `
            <tr>
                <td colspan="6" class="px-6 py-8 text-center text-red-400">
                    Failed to load students.
                </td>
            </tr>
        `;
    }
}

// Show message (SweetAlert)
function showMessage(message, type = 'error') {
    if (window.__portalBackgroundRefresh && type === 'error') {
        console.warn('Background portal refresh:', message);
        return;
    }
    if (typeof Swal !== 'undefined') {
        Swal.fire({
            icon: type === 'success' ? 'success' : 'error',
            title: type === 'success' ? 'Success' : 'Error',
            text: message,
            confirmButtonColor: '#b8860b'
        });
    } else {
        alert(message);
    }
}

function showPortalToast(message, type = 'info', title = '') {
    if (typeof Swal !== 'undefined' && typeof Swal.mixin === 'function') {
        const toast = Swal.mixin({
            toast: true,
            position: 'top-end',
            showConfirmButton: false,
            timer: 3600,
            timerProgressBar: true,
            didOpen: (popup) => {
                popup.addEventListener('mouseenter', Swal.stopTimer);
                popup.addEventListener('mouseleave', Swal.resumeTimer);
            }
        });
        return toast.fire({
            icon: ['success', 'error', 'warning', 'info'].includes(type) ? type : 'info',
            title: title || message,
            text: title ? message : ''
        });
    }

    alert(message);
    return Promise.resolve();
}

// Track server-side decisions while a student or guardian portal is open.
// The first response establishes a baseline; later responses produce a toast
// only when a status actually changes, so refresh polling never repeats alerts.
const portalDecisionSnapshots = new Map();
const guardianAbsenceDecisionSnapshots = new Map();
let portalDecisionToastQueue = Promise.resolve();
let instructorAvailabilitySnapshot = null;

function queuePortalDecisionToast(message, type, title) {
    portalDecisionToastQueue = portalDecisionToastQueue
        .catch(() => undefined)
        .then(() => showPortalToast(message, type, title));
}

function normalizePortalDecisionStatus(value) {
    return String(value || '').trim().toLowerCase();
}

function buildPortalDecisionSnapshot(portal) {
    const student = portal?.student || {};
    const enrollmentRows = [portal?.current_enrollment, ...(Array.isArray(portal?.enrollment_history) ? portal.enrollment_history : [])]
        .filter(Boolean);
    const enrollments = {};
    enrollmentRows.forEach(row => {
        const enrollmentId = Number(row?.enrollment_id || 0);
        if (enrollmentId < 1 || enrollments[enrollmentId]) return;
        enrollments[enrollmentId] = {
            status: normalizePortalDecisionStatus(row.status),
            scheduleRequestStatus: normalizePortalDecisionStatus(row.schedule_request_status),
            scheduleStatus: normalizePortalDecisionStatus(row.schedule_status),
            paidAmount: Number(row.paid_amount || 0),
            packageName: String(row.package_name || 'lesson package')
        };
    });
    const extension = portal?.latest_session_extension_request || null;
    return {
        studentId: Number(student.student_id || 0),
        studentName: `${student.first_name || ''} ${student.last_name || ''}`.trim() || 'Student',
        registrationStatus: normalizePortalDecisionStatus(student.registration_status),
        registrationPaymentStatus: normalizePortalDecisionStatus(student.registration_payment_status),
        enrollments,
        extension: extension ? {
            requestId: Number(extension.request_id || 0),
            status: normalizePortalDecisionStatus(extension.status),
            requestedSessions: Number(extension.requested_sessions || 0)
        } : null
    };
}

function capturePortalDecisionState(portal, context = 'student') {
    const current = buildPortalDecisionSnapshot(portal);
    if (current.studentId < 1) return;
    const key = `${context}:${current.studentId}`;
    const previous = portalDecisionSnapshots.get(key);
    portalDecisionSnapshots.set(key, current);
    if (!previous) return;

    const subject = context === 'guardian' ? current.studentName : 'Your';
    const possessive = context === 'guardian' ? `${current.studentName}'s` : 'Your';
    let notice = null;

    if (previous.registrationStatus !== current.registrationStatus) {
        if (['approved', 'fee paid'].includes(current.registrationStatus)) {
            notice = { title: 'Registration Approved', type: 'success', message: `${possessive} registration has been approved. Enrollment is now available.` };
        } else if (current.registrationStatus === 'rejected') {
            notice = { title: 'Registration Rejected', type: 'error', message: `${possessive} registration was not approved. Check the registration page for details.` };
        }
    }

    Object.entries(current.enrollments).some(([enrollmentId, enrollment]) => {
        if (notice) return true;
        const before = previous.enrollments?.[enrollmentId];
        if (!before) return false;

        if (before.status !== enrollment.status) {
            if (enrollment.status === 'active') {
                notice = { title: 'Enrollment Approved', type: 'success', message: `${possessive} ${enrollment.packageName} enrollment and schedule are approved.` };
                return true;
            }
            if (enrollment.status === 'rejected') {
                notice = { title: 'Enrollment Rejected', type: 'error', message: `${possessive} enrollment request was rejected. Open Enrollment for details.` };
                return true;
            }
            if (enrollment.status === 'expired') {
                notice = { title: 'Request Expired', type: 'warning', message: `${possessive} temporary schedule reservation expired. Please choose another available schedule.` };
                return true;
            }
        }

        if (before.scheduleRequestStatus !== enrollment.scheduleRequestStatus) {
            const scheduleNotices = {
                approved: { title: 'Schedule Approved', type: 'success', message: `${possessive} requested schedule has been approved.` },
                suggested: { title: 'New Schedule Suggested', type: 'info', message: `The desk suggested another schedule for ${subject.toLowerCase() === 'your' ? 'you' : current.studentName}. Open Enrollment to review it.` },
                'schedule conflict': { title: 'Schedule Conflict', type: 'warning', message: `${possessive} requested time is no longer available. Please review the alternative schedule.` },
                rejected: { title: 'Schedule Request Rejected', type: 'error', message: `${possessive} schedule request was rejected.` },
                expired: { title: 'Schedule Reservation Expired', type: 'warning', message: `${possessive} temporary reservation expired. Please select another available time.` }
            };
            notice = scheduleNotices[enrollment.scheduleRequestStatus] || null;
            if (notice) return true;
        }

        if (enrollment.paidAmount > before.paidAmount) {
            notice = { title: 'Payment Confirmed', type: 'success', message: `${possessive} payment of ${formatCurrencyPHP(enrollment.paidAmount - before.paidAmount)} was confirmed.` };
            return true;
        }
        return false;
    });

    if (!notice && previous.registrationPaymentStatus !== current.registrationPaymentStatus) {
        if (current.registrationPaymentStatus === 'paid') {
            notice = { title: 'Payment Confirmed', type: 'success', message: `${possessive} registration payment was confirmed.` };
        } else if (current.registrationPaymentStatus === 'rejected') {
            notice = { title: 'Payment Rejected', type: 'error', message: `${possessive} submitted payment could not be confirmed.` };
        }
    }

    if (!notice && previous.extension?.requestId && previous.extension.requestId === current.extension?.requestId
        && previous.extension.status !== current.extension.status) {
        if (current.extension.status === 'approved') {
            notice = { title: 'Additional Sessions Approved', type: 'success', message: `${possessive} request for ${current.extension.requestedSessions || 'additional'} sessions was approved.` };
        } else if (['rejected', 'declined'].includes(current.extension.status)) {
            notice = { title: 'Additional Sessions Declined', type: 'error', message: `${possessive} additional-session request was declined.` };
        }
    }

    if (notice) queuePortalDecisionToast(notice.message, notice.type, notice.title);
}

function captureGuardianAbsenceDecisionState(requests) {
    (Array.isArray(requests) ? requests : []).forEach(row => {
        const requestId = Number(row?.request_id || 0);
        if (requestId < 1) return;
        const currentStatus = normalizePortalDecisionStatus(row.status);
        const previousStatus = guardianAbsenceDecisionSnapshots.get(requestId);
        guardianAbsenceDecisionSnapshots.set(requestId, currentStatus);
        if (!previousStatus || previousStatus === currentStatus) return;
        const studentName = String(row.student_name || `${row.student_first_name || row.first_name || ''} ${row.student_last_name || row.last_name || ''}`.trim() || 'the student');
        if (currentStatus === 'approved') {
            queuePortalDecisionToast(`${studentName}'s absence notice was approved.`, 'success', 'Absence Approved');
        } else if (['declined', 'rejected'].includes(currentStatus)) {
            queuePortalDecisionToast(`${studentName}'s absence notice was declined.`, 'error', 'Absence Declined');
        } else if (currentStatus === 'reviewed') {
            queuePortalDecisionToast(`${studentName}'s absence notice was reviewed by the desk.`, 'info', 'Absence Reviewed');
        }
    });
}

function buildInstructorAvailabilitySignature(rows) {
    return (Array.isArray(rows) ? rows : [])
        .map(row => [
            String(row.day_of_week || ''),
            String(row.start_time || '').slice(0, 5),
            String(row.end_time || '').slice(0, 5),
            normalizePortalDecisionStatus(row.status),
            Number(row.branch_id || 0)
        ].join('|'))
        .sort()
        .join('||');
}

async function refreshInstructorAvailabilityDecisionState() {
    const user = Auth.getUser();
    if (getRoleCategory(user?.role_name) !== 'instructor' || !user?.user_id) return;
    const response = await axios.get(`${baseApiUrl}/teachers.php?action=get-teacher-availability&user_id=${encodeURIComponent(user.user_id)}`);
    const rows = response.data?.success && Array.isArray(response.data.availability) ? response.data.availability : [];
    const signature = buildInstructorAvailabilitySignature(rows);
    const previousSignature = instructorAvailabilitySnapshot;
    instructorAvailabilitySnapshot = signature;
    if (previousSignature === null || previousSignature === signature) return;

    queuePortalDecisionToast(
        'Your assigned weekly days and times were updated by an administrator or branch manager.',
        'info',
        'Availability Updated'
    );
    window.dispatchEvent(new CustomEvent('fas:instructor-availability-updated', { detail: { rows } }));
}

function isPortalInteractionInProgress() {
    if (document.visibilityState !== 'visible') return true;
    if (document.body?.classList.contains('swal2-shown')) return true;
    if (typeof Swal !== 'undefined' && typeof Swal.isVisible === 'function' && Swal.isVisible()) return true;

    const activeElement = document.activeElement;
    if (activeElement && (
        activeElement.matches?.('input, select, textarea, [contenteditable="true"]')
        || activeElement.closest?.('form')
    )) return true;

    const modalIds = [
        'studentRequestModal',
        'studentRegistrationModal',
        'studentInstructorAvailabilityModal',
        'guardianStudentModal',
        'guardianAbsenceModal',
        'proofViewerModal'
    ];
    return modalIds.some(id => {
        const modal = document.getElementById(id);
        return modal && !modal.classList.contains('hidden') && getComputedStyle(modal).display !== 'none';
    });
}

function stopPortalPageAutoRefresh() {
    if (window.__portalPageAutoRefreshTimer) {
        window.clearInterval(window.__portalPageAutoRefreshTimer);
        window.__portalPageAutoRefreshTimer = null;
    }
    if (window.__portalPageVisibilityHandler) {
        document.removeEventListener('visibilitychange', window.__portalPageVisibilityHandler);
        window.removeEventListener('focus', window.__portalPageVisibilityHandler);
        window.__portalPageVisibilityHandler = null;
    }
}

function startPortalPageAutoRefresh(pageKey, refreshCallback, intervalMs = 10000) {
    if (typeof refreshCallback !== 'function') return;
    stopPortalPageAutoRefresh();
    window.__portalPageAutoRefreshBusy = false;
    window.__portalPageAutoRefreshLastRun = Date.now();

    const refresh = async () => {
        if (window.__portalPageAutoRefreshBusy || isPortalInteractionInProgress()) return;
        window.__portalPageAutoRefreshBusy = true;
        window.__portalBackgroundRefresh = true;
        try {
            await refreshCallback();
            window.__portalPageAutoRefreshLastRun = Date.now();
        } catch (error) {
            console.warn(`Background refresh skipped for ${pageKey}:`, error);
        } finally {
            window.__portalBackgroundRefresh = false;
            window.__portalPageAutoRefreshBusy = false;
        }
    };

    window.__portalPageAutoRefreshTimer = window.setInterval(refresh, Math.max(8000, Number(intervalMs || 10000)));
    window.__portalPageVisibilityHandler = () => {
        if (document.visibilityState !== 'visible') return;
        if ((Date.now() - Number(window.__portalPageAutoRefreshLastRun || 0)) < 5000) return;
        void refresh();
    };
    document.addEventListener('visibilitychange', window.__portalPageVisibilityHandler);
    window.addEventListener('focus', window.__portalPageVisibilityHandler);
}

function startPortalStatusOnlyWatcher(intervalMs = 10000) {
    if (window.__portalStatusOnlyTimer) window.clearInterval(window.__portalStatusOnlyTimer);
    const role = getRoleCategory(Auth.getUser()?.role_name);
    if (!['student', 'guardian', 'instructor'].includes(role)) return;

    window.__portalStatusOnlyBusy = false;
    const refresh = async () => {
        if (window.__portalStatusOnlyBusy || isPortalInteractionInProgress()) return;
        window.__portalStatusOnlyBusy = true;
        try {
            const email = Auth.getUser()?.email || '';
            if (role === 'instructor') {
                await refreshInstructorAvailabilityDecisionState();
            } else {
                if (!email) return;
                if (role === 'student') await fetchStudentPortalDataByEmail(email);
                else await fetchGuardianPortalDataByEmail(email);
            }
        } catch (error) {
            console.warn('Portal status refresh skipped:', error);
        } finally {
            window.__portalStatusOnlyBusy = false;
        }
    };
    window.__portalStatusOnlyTimer = window.setInterval(refresh, Math.max(8000, Number(intervalMs || 10000)));
    if (window.__portalStatusOnlyVisibilityHandler) {
        document.removeEventListener('visibilitychange', window.__portalStatusOnlyVisibilityHandler);
        window.removeEventListener('focus', window.__portalStatusOnlyVisibilityHandler);
    }
    window.__portalStatusOnlyVisibilityHandler = () => {
        if (document.visibilityState === 'visible') void refresh();
    };
    document.addEventListener('visibilitychange', window.__portalStatusOnlyVisibilityHandler);
    window.addEventListener('focus', window.__portalStatusOnlyVisibilityHandler);
    if (role === 'instructor') void refresh();
}

async function refreshCurrentPortalPage() {
    if (document.getElementById('studentDashboardRoot')) return initStudentDashboardPage();
    if (document.getElementById('studentSessionsRoot')) return initStudentSessionsPage();
    if (document.getElementById('studentGradesRoot')) return initStudentGradesPage();
    if (document.getElementById('studentAttendanceRoot')) return initStudentAttendancePage();
    if (document.getElementById('studentQrRoot')) return initStudentQrPage();
    if (document.getElementById('studentProfileRoot')) return initStudentProfilePage();
    if (document.getElementById('guardianDashboardRoot')) return initGuardianDashboardPage();
    if (document.getElementById('guardianStudentsRoot')) return initGuardianStudentsPage();
    if (document.getElementById('guardianPaymentsRoot')) return initGuardianPaymentsPage();
    if (document.getElementById('guardianProfileRoot')) return initGuardianProfilePage();
    if (document.getElementById('guardianAbsenceRoot')) return initGuardianAbsencePage();
    if (typeof window.loadStudentSongs === 'function') return window.loadStudentSongs();
    return undefined;
}

function getFreezeRestoreToastKey(context, enrollmentId) {
    return `fas_freeze_restored_${String(context || 'student')}_${Number(enrollmentId || 0)}`;
}

function readFreezeRestoreToastState(context, enrollmentId) {
    try {
        return localStorage.getItem(getFreezeRestoreToastKey(context, enrollmentId)) || '';
    } catch (e) {
        return '';
    }
}

function writeFreezeRestoreToastState(context, enrollmentId, state) {
    try {
        localStorage.setItem(getFreezeRestoreToastKey(context, enrollmentId), String(state || ''));
    } catch (e) {
        // Ignore storage issues.
    }
}

function getEnrollmentFreezePresenceState(enrollment) {
    const scheduleStatus = String(enrollment?.schedule_status || '').trim().toLowerCase();
    const paymentStatus = String(enrollment?.__freeze_payment_status || '').trim().toLowerCase();
    if (scheduleStatus === 'frozen' || paymentStatus === 'pending' || paymentStatus === 'rejected') {
        return 'frozen';
    }
    if (scheduleStatus === 'active') {
        return 'active';
    }
    return scheduleStatus || 'active';
}

function notifyFreezeRestored(enrollment, personName = 'Your account', context = 'student') {
    const enrollmentId = Number(enrollment?.enrollment_id || 0);
    if (enrollmentId < 1) return false;

    const currentState = getEnrollmentFreezePresenceState(enrollment);
    const previousState = readFreezeRestoreToastState(context, enrollmentId);
    const wasFrozenBefore = ['frozen', 'pending'].includes(previousState);
    const isNowActive = currentState === 'active';

    if (isNowActive && wasFrozenBefore) {
        showPortalToast(
            `${personName} can go back to sessions now. The frozen reservation has been cleared.`,
            'success',
            'Account Restored'
        );
    }

    writeFreezeRestoreToastState(context, enrollmentId, currentState);
    return isNowActive && wasFrozenBefore;
}

function notifyFreezeRestoredForStudentPortal(portal, student) {
    const enrollment = portal?.current_enrollment || null;
    const studentName = `${student?.first_name || ''} ${student?.last_name || ''}`.trim() || 'Your account';
    notifyFreezeRestored(enrollment, studentName, 'student');
}

function notifyFreezeRestoredForGuardianPortal(students) {
    (Array.isArray(students) ? students : []).forEach((item) => {
        const s = item?.student || {};
        const studentName = `${s.first_name || ''} ${s.last_name || ''}`.trim() || 'A linked student';
        notifyFreezeRestored(item?.current_enrollment || null, studentName, 'guardian');
    });
}

function getGuardianSessionCompletionState(row) {
    const status = String(row?.status || '').trim().toLowerCase();
    const attendance = String(row?.attendance_status || '').trim().toLowerCase();
    if (status === 'completed' || attendance === 'present' || attendance === 'late' || status === 'late') {
        return 'completed';
    }
    if (['cancelled', 'no show', 'cancelled_by_teacher', 'rescheduled'].includes(status) || ['absent', 'ci'].includes(attendance)) {
        return 'inactive';
    }
    return 'pending';
}

function getGuardianSessionToastKey(sessionId) {
    return `fas_guardian_session_${Number(sessionId || 0)}`;
}

function readGuardianSessionToastState(sessionId) {
    try {
        return localStorage.getItem(getGuardianSessionToastKey(sessionId)) || '';
    } catch (e) {
        return '';
    }
}

function writeGuardianSessionToastState(sessionId, state) {
    try {
        localStorage.setItem(getGuardianSessionToastKey(sessionId), String(state || ''));
    } catch (e) {
        // Ignore storage failures.
    }
}

function getLocalYmd(date = new Date()) {
    return getManilaYmd(date);
}

function isGuardianSessionCompletionTrackable(row) {
    if (!row?.session_id || !row?.session_date) return false;
    const sessionDate = String(row.session_date || '');
    const todayYmd = getLocalYmd();
    return sessionDate >= todayYmd;
}

function notifyGuardianSessionCompletion(row, studentName = 'A linked student') {
    const sessionId = Number(row?.session_id || 0);
    if (sessionId < 1 || !isGuardianSessionCompletionTrackable(row)) return false;

    const currentState = String(row?.instructor_completed_at || '').trim() !== ''
        ? 'completed'
        : 'pending';
    const previousState = readGuardianSessionToastState(sessionId);
    writeGuardianSessionToastState(sessionId, currentState);

    if (currentState === 'completed' && previousState !== 'completed') {
        const dateLabel = row?.session_date ? formatDateLong(row.session_date) : 'today';
        showPortalToast(
            `${studentName} has finished the session for ${dateLabel}.`,
            'success',
            'Session Completed'
        );
        return true;
    }

    return false;
}

function notifyGuardianSessionCompletions(students) {
    let notified = false;
    (Array.isArray(students) ? students : []).forEach((item) => {
        const s = item?.student || {};
        const studentName = `${s.first_name || ''} ${s.last_name || ''}`.trim() || 'A linked student';
        getGuardianSessionRows(item)
            .filter(isGuardianSessionCompletionTrackable)
            .forEach((row) => {
                if (notifyGuardianSessionCompletion(row, studentName)) {
                    notified = true;
                }
            });
    });
    return notified;
}

function getStudentSessionCompletionKey(sessionId) {
    return `fas_student_session_completed_${Number(sessionId || 0)}`;
}

function readStudentSessionCompletionState(sessionId) {
    try { return localStorage.getItem(getStudentSessionCompletionKey(sessionId)) || ''; }
    catch (e) { return ''; }
}

function writeStudentSessionCompletionState(sessionId, state) {
    try { localStorage.setItem(getStudentSessionCompletionKey(sessionId), String(state || '')); }
    catch (e) { /* Ignore storage failures. */ }
}

function getStudentPortalSessionRows(portal) {
    return (Array.isArray(portal?.current_session_grades) ? portal.current_session_grades : [])
        .slice()
        .sort((a, b) => {
            const aTime = new Date(`${a?.session_date || ''}T${a?.start_time || '00:00:00'}`).getTime() || 0;
            const bTime = new Date(`${b?.session_date || ''}T${b?.start_time || '00:00:00'}`).getTime() || 0;
            return bTime - aTime;
        });
}

function dismissStudentSessionCompletion(sessionId) {
    writeStudentSessionCompletionState(sessionId, 'dismissed');
    const alert = document.getElementById('studentSessionCompletionAlert');
    if (alert) { alert.innerHTML = ''; alert.classList.add('hidden'); }
}
window.dismissStudentSessionCompletion = dismissStudentSessionCompletion;

function renderStudentSessionCompletionAlert(portal) {
    const alert = document.getElementById('studentSessionCompletionAlert');
    if (!alert) return;
    const completed = getStudentPortalSessionRows(portal).find(row => {
        const sessionId = Number(row?.session_id || 0);
        return sessionId > 0
            && isGuardianSessionCompletionTrackable(row)
            && String(row?.instructor_completed_at || '').trim() !== ''
            && readStudentSessionCompletionState(sessionId) !== 'dismissed';
    });
    if (!completed) {
        alert.innerHTML = '';
        alert.classList.add('hidden');
        return;
    }
    const sessionId = Number(completed.session_id || 0);
    const dateLabel = completed.session_date ? formatDateLong(completed.session_date) : 'Today';
    const timeLabel = completed.start_time && completed.end_time
        ? `${formatTime12Hour(completed.start_time)} - ${formatTime12Hour(completed.end_time)}` : '';
    alert.innerHTML = `
        <div class="rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-4 shadow-sm dark:border-emerald-500/25 dark:bg-emerald-500/10">
            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div class="flex items-start gap-3">
                    <div class="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-emerald-100 text-emerald-700 dark:bg-emerald-500/20 dark:text-emerald-300"><i class="fas fa-circle-check"></i></div>
                    <div>
                        <div class="text-xs font-black uppercase tracking-[0.16em] text-emerald-700 dark:text-emerald-300">Session Ended</div>
                        <div class="mt-0.5 text-sm font-bold text-zinc-900 dark:text-white">Your instructor completed this lesson.</div>
                        <div class="mt-1 text-xs text-zinc-600 dark:text-zinc-300">${escapeHtml(completed.instrument_name || 'Music lesson')} · ${escapeHtml(dateLabel)}${timeLabel ? ` · ${escapeHtml(timeLabel)}` : ''}</div>
                    </div>
                </div>
                <div class="flex gap-2">
                    <a href="student_grades.html" class="rounded-xl bg-emerald-700 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-600">View lesson</a>
                    <button type="button" onclick="dismissStudentSessionCompletion(${sessionId})" class="rounded-xl border border-emerald-200 bg-white px-3 py-2 text-xs font-bold text-zinc-700 hover:bg-emerald-100">Dismiss</button>
                </div>
            </div>
        </div>`;
    alert.classList.remove('hidden');
}

function notifyStudentSessionCompletions(portal) {
    let notified = false;
    getStudentPortalSessionRows(portal).filter(isGuardianSessionCompletionTrackable).forEach(row => {
        const sessionId = Number(row?.session_id || 0);
        if (sessionId < 1) return;
        const currentState = String(row?.instructor_completed_at || '').trim() !== '' ? 'completed' : 'pending';
        const previousState = readStudentSessionCompletionState(sessionId);
        if (previousState !== 'dismissed') writeStudentSessionCompletionState(sessionId, currentState);
        if (currentState === 'completed' && previousState === 'pending') {
            showPortalToast('Your instructor has ended the session. You can now review the lesson update.', 'success', 'Session Ended');
            notified = true;
        }
    });
    renderStudentSessionCompletionAlert(portal);
    return notified;
}

function stopStudentSessionRefreshWatcher() {
    if (window.__studentSessionRefreshTimer) {
        window.clearInterval(window.__studentSessionRefreshTimer);
        window.__studentSessionRefreshTimer = null;
    }
}

function startStudentSessionRefreshWatcher() {
    stopStudentSessionRefreshWatcher();
    const rows = getStudentPortalSessionRows(studentDashboardPortalState).filter(isGuardianSessionCompletionTrackable);
    if (!rows.length) return;
    rows.forEach(row => {
        const sessionId = Number(row?.session_id || 0);
        if (sessionId > 0 && !readStudentSessionCompletionState(sessionId)) {
            writeStudentSessionCompletionState(sessionId, String(row?.instructor_completed_at || '').trim() ? 'completed' : 'pending');
        }
    });
    window.__studentSessionRefreshBusy = false;
    window.__studentSessionRefreshTimer = window.setInterval(async () => {
        if (window.__studentSessionRefreshBusy) return;
        window.__studentSessionRefreshBusy = true;
        try {
            const user = Auth.getUser();
            const portal = await fetchStudentPortalDataByEmail(user?.email || '');
            if (portal?.success) {
                studentDashboardPortalState = portal;
                notifyStudentSessionCompletions(portal);
            }
        } catch (e) {
            // Non-critical polling failure.
        } finally {
            window.__studentSessionRefreshBusy = false;
        }
    }, 15000);
}

function stopGuardianSessionRefreshWatcher() {
    if (window.__guardianSessionRefreshTimer) {
        window.clearInterval(window.__guardianSessionRefreshTimer);
        window.__guardianSessionRefreshTimer = null;
    }
}

function startGuardianSessionRefreshWatcher() {
    stopGuardianSessionRefreshWatcher();
    const needsPolling = (Array.isArray(guardianPortalStudents) ? guardianPortalStudents : [])
        .some((item) => getGuardianSessionRows(item).some(isGuardianSessionCompletionTrackable));
    if (!needsPolling) return;

    window.__guardianSessionRefreshBusy = false;
    window.__guardianSessionRefreshTimer = window.setInterval(async () => {
        if (window.__guardianSessionRefreshBusy) return;
        window.__guardianSessionRefreshBusy = true;
        try {
            const user = Auth.getUser();
            const portal = await fetchGuardianPortalDataByEmail(user?.email || '');
            if (portal?.success && Array.isArray(portal.students)) {
                guardianPortalStudents = portal.students;
                const notified = notifyGuardianSessionCompletions(portal.students);
                if (notified) {
                    stopGuardianSessionRefreshWatcher();
                    await refreshCurrentPortalPage();
                }
            }
        } catch (e) {
            // Non-critical polling failure.
        } finally {
            window.__guardianSessionRefreshBusy = false;
        }
    }, 15000);
}

function hasPendingFreezeRestoration(enrollment) {
    if (!enrollment) return false;
    const presenceState = getEnrollmentFreezePresenceState(enrollment);
    const paymentStatus = String(enrollment.__freeze_payment_status || '').trim().toLowerCase();
    const scheduleStatus = String(enrollment.schedule_status || '').trim().toLowerCase();
    if (paymentStatus === 'paid' || scheduleStatus === 'active') return false;
    return ['frozen', 'pending', 'rejected'].includes(presenceState)
        || ['pending', 'rejected'].includes(paymentStatus)
        || (scheduleStatus && scheduleStatus !== 'active' && Number(enrollment.enrollment_id || 0) > 0);
}

function stopStudentFreezeRefreshWatcher() {
    if (window.__studentFreezeRefreshTimer) {
        window.clearInterval(window.__studentFreezeRefreshTimer);
        window.__studentFreezeRefreshTimer = null;
    }
}

function startStudentFreezeRefreshWatcher() {
    stopStudentFreezeRefreshWatcher();
    const enrollment = studentDashboardPortalState?.current_enrollment || null;
    if (!hasPendingFreezeRestoration(enrollment)) return;
    window.__studentFreezeRefreshBusy = false;
    window.__studentFreezeRefreshTimer = window.setInterval(async () => {
        if (window.__studentFreezeRefreshBusy) return;
        window.__studentFreezeRefreshBusy = true;
        try {
            const restored = await refreshStudentFreezeStatusAndNotify();
            if (restored) {
                stopStudentFreezeRefreshWatcher();
                await refreshCurrentPortalPage();
            }
        } finally {
            window.__studentFreezeRefreshBusy = false;
        }
    }, 15000);
}

function stopGuardianFreezeRefreshWatcher() {
    if (window.__guardianFreezeRefreshTimer) {
        window.clearInterval(window.__guardianFreezeRefreshTimer);
        window.__guardianFreezeRefreshTimer = null;
    }
}

function startGuardianFreezeRefreshWatcher() {
    stopGuardianFreezeRefreshWatcher();
    const needsPolling = (Array.isArray(guardianPortalStudents) ? guardianPortalStudents : [])
        .some((item) => hasPendingFreezeRestoration(item?.current_enrollment || null));
    if (!needsPolling) return;
    window.__guardianFreezeRefreshBusy = false;
    window.__guardianFreezeRefreshTimer = window.setInterval(async () => {
        if (window.__guardianFreezeRefreshBusy) return;
        window.__guardianFreezeRefreshBusy = true;
        try {
            const restored = await refreshGuardianFreezeStatusAndNotify();
            if (restored) {
                stopGuardianFreezeRefreshWatcher();
                await refreshCurrentPortalPage();
            }
        } finally {
            window.__guardianFreezeRefreshBusy = false;
        }
    }, 15000);
}

async function refreshStudentFreezeStatusAndNotify() {
    const portal = studentDashboardPortalState;
    const enrollment = portal?.current_enrollment || null;
    if (!portal?.student || !enrollment?.enrollment_id) return false;

    try {
        const res = await axios.get(`${baseApiUrl}/students.php?action=get-student-freeze-payment-status&enrollment_id=${encodeURIComponent(enrollment.enrollment_id)}`);
        const data = res.data || {};
        if (!data.success || !data.payment) return false;

        const previousState = String(enrollment.__freeze_payment_status || '').trim();
        enrollment.__freeze_payment_status = data.payment.status || '';
        if (String(data.payment.status || '').toLowerCase() === 'paid') {
            enrollment.schedule_status = 'Active';
        }

        const restored = notifyFreezeRestoredForStudentPortal(portal, portal.student);
        if (restored && previousState !== 'Paid') {
            return true;
        }
    } catch (e) {
        // Non-critical polling failure.
    }

    return false;
}

async function refreshGuardianFreezeStatusAndNotify() {
    if (!Array.isArray(guardianPortalStudents) || guardianPortalStudents.length === 0) return false;
    let restoredAny = false;

    for (const item of guardianPortalStudents) {
        const enrollment = item?.current_enrollment || null;
        const student = item?.student || null;
        if (!enrollment?.enrollment_id) continue;

        try {
            const res = await axios.get(`${baseApiUrl}/students.php?action=get-student-freeze-payment-status&enrollment_id=${encodeURIComponent(enrollment.enrollment_id)}`);
            const data = res.data || {};
            if (!data.success || !data.payment) continue;

            const previousState = String(enrollment.__freeze_payment_status || '').trim();
            enrollment.__freeze_payment_status = data.payment.status || '';
            if (String(data.payment.status || '').toLowerCase() === 'paid') {
                enrollment.schedule_status = 'Active';
            }

            const before = readFreezeRestoreToastState('guardian', enrollment.enrollment_id);
            const restored = notifyFreezeRestored(enrollment, `${student?.first_name || ''} ${student?.last_name || ''}`.trim() || 'A linked student', 'guardian');
            if (restored && (previousState !== 'Paid' || before !== 'active')) {
                restoredAny = true;
            }
        } catch (e) {
            // Non-critical polling failure.
        }
    }

    return restoredAny;
}

// Load Pending Registrations
async function loadPendingRegistrations() {
    const tableTitle = document.getElementById('tableTitle');
    if (tableTitle) {
        tableTitle.textContent = 'Pending Registrations';
    }

    try {
        const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
        const role = String(user?.role_name || '').toLowerCase();
        const branchScopedRole = user && ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);
        const staffBranchId = branchScopedRole ? Number(user.branch_id || 0) : 0;
        let url = `${baseApiUrl}/admin.php?action=get-pending-registrations`;
        if (staffBranchId > 0) url += `&branch_id=${encodeURIComponent(staffBranchId)}`;

        const res = await axios.get(url);
        const data = res.data;

        if (data.success) {
            displayRegistrations(data.registrations);
            updateStats(data.registrations);
        }
    } catch (error) {
        showMessage('Failed to load registrations: ' + (error.message || error), 'error');
    }
}

// Load All Registrations
async function loadAllRegistrations() {
    const tableTitle = document.getElementById('tableTitle');
    if (tableTitle) {
        tableTitle.textContent = 'All Registrations';
    }

    try {
        const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
        const role = String(user?.role_name || '').toLowerCase();
        const branchScopedRole = user && ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);
        const staffBranchId = branchScopedRole ? Number(user.branch_id || 0) : 0;
        let url = `${baseApiUrl}/admin.php?action=get-all-registrations`;
        if (staffBranchId > 0) url += `&branch_id=${encodeURIComponent(staffBranchId)}`;

        const res = await axios.get(url);
        const data = res.data;

        if (data.success) {
            displayRegistrations(data.registrations);
            updateStats(data.registrations);
        }
    } catch (error) {
        showMessage('Failed to load registrations: ' + (error.message || error), 'error');
    }
}

const registrationsTableState = {
    allRows: [],
    rows: [],
    page: 1,
    pageSize: 10
};

function applyRegistrationTableFilters() {
    const search = String(document.getElementById('registrationsSearch')?.value || '').trim().toLowerCase();
    const branchId = String(document.getElementById('registrationsBranchFilter')?.value || '');
    registrationsTableState.rows = registrationsTableState.allRows.filter(reg => {
        if (branchId && String(reg.branch_id || '') !== branchId) return false;
        if (!search) return true;
        const haystack = [reg.first_name, reg.last_name, reg.email, reg.student_code,
            reg.guardian_first_name, reg.guardian_last_name, reg.guardian_phone,
            reg.branch_name, reg.registration_status, reg.registration_source]
            .map(value => String(value || '').toLowerCase()).join(' ');
        return haystack.includes(search);
    });
    registrationsTableState.page = 1;
    renderRegistrationsTable();
}

function sortNewestRegistrationsFirst(rows) {
    return (Array.isArray(rows) ? rows.slice() : []).sort((a, b) => {
        const timeA = new Date(a?.created_at || 0).getTime();
        const timeB = new Date(b?.created_at || 0).getTime();
        if (timeA !== timeB) return timeB - timeA;
        return Number(b?.student_id || 0) - Number(a?.student_id || 0);
    });
}

function getWalkInRegistrationDisplayStatus(registration) {
    const status = String(registration?.registration_status || 'Pending').trim() || 'Pending';
    return status;
}

function getWalkInRegistrationRemainingAmount(registration) {
    const source = String(registration?.registration_source || 'online').toLowerCase();
    const status = String(registration?.registration_status || 'Pending').trim() || 'Pending';
    if (source === 'walkin' && ['Approved', 'Fee Paid', 'Active'].includes(status)) {
        return 0;
    }
    const total = Number(registration?.registration_fee_amount || 0);
    const paid = Number(registration?.registration_fee_paid || 0);
    return Math.max(0, total - paid);
}

function getRegistrationStudentLoginId(registration) {
    const explicitCode = String(registration?.student_code || registration?.student_login_identifier || '').trim();
    if (explicitCode !== '') {
        return explicitCode;
    }

    const studentId = Number(registration?.student_id || 0);
    if (studentId < 1) {
        return '';
    }

    const createdAt = registration?.created_at ? new Date(registration.created_at) : null;
    const year = createdAt && !Number.isNaN(createdAt.getTime())
        ? createdAt.getFullYear()
        : new Date().getFullYear();

    return `STU-${year}-${String(studentId).padStart(4, '0')}`;
}

function getRegistrationsModeFromHash() {
    const hash = (window.location.hash || '').replace('#', '').toLowerCase();
    return hash === 'pending' ? 'pending' : 'all';
}

function reloadRegistrationsByActiveMode() {
    if (getRegistrationsModeFromHash() === 'pending') {
        loadPendingRegistrations();
    } else {
        loadAllRegistrations();
    }
}

function initRegistrationsPaginationControls() {
    const pageSizeEl = document.getElementById('registrationsPageSize');
    const prevBtn = document.getElementById('registrationsPrevBtn');
    const nextBtn = document.getElementById('registrationsNextBtn');
    const searchEl = document.getElementById('registrationsSearch');
    const branchEl = document.getElementById('registrationsBranchFilter');

    if (searchEl && searchEl.dataset.bound !== '1') {
        searchEl.addEventListener('input', applyRegistrationTableFilters);
        searchEl.dataset.bound = '1';
    }
    if (branchEl && branchEl.dataset.bound !== '1') {
        branchEl.addEventListener('change', applyRegistrationTableFilters);
        branchEl.dataset.bound = '1';
    }

    if (pageSizeEl && pageSizeEl.dataset.bound !== '1') {
        pageSizeEl.addEventListener('change', () => {
            const nextSize = parseInt(pageSizeEl.value, 10);
            registrationsTableState.pageSize = Number.isFinite(nextSize) && nextSize > 0 ? nextSize : 5;
            registrationsTableState.page = 1;
            renderRegistrationsTable();
        });
        pageSizeEl.dataset.bound = '1';
    }

    if (prevBtn && prevBtn.dataset.bound !== '1') {
        prevBtn.addEventListener('click', () => {
            registrationsTableState.page = Math.max(1, registrationsTableState.page - 1);
            renderRegistrationsTable();
        });
        prevBtn.dataset.bound = '1';
    }

    if (nextBtn && nextBtn.dataset.bound !== '1') {
        nextBtn.addEventListener('click', () => {
            const totalPages = Math.max(1, Math.ceil(registrationsTableState.rows.length / registrationsTableState.pageSize));
            registrationsTableState.page = Math.min(totalPages, registrationsTableState.page + 1);
            renderRegistrationsTable();
        });
        nextBtn.dataset.bound = '1';
    }
}

function renderRegistrationsTable() {
    const tbody = document.getElementById('registrationsTable');
    if (!tbody) return;

    const infoEl = document.getElementById('registrationsPaginationInfo');
    const prevBtn = document.getElementById('registrationsPrevBtn');
    const nextBtn = document.getElementById('registrationsNextBtn');
    const pageSizeEl = document.getElementById('registrationsPageSize');

    if (pageSizeEl) {
        pageSizeEl.value = String(registrationsTableState.pageSize);
    }

    const rows = Array.isArray(registrationsTableState.rows) ? registrationsTableState.rows : [];
    const totalRows = rows.length;
    const totalPages = Math.max(1, Math.ceil(totalRows / registrationsTableState.pageSize));
    if (registrationsTableState.page > totalPages) registrationsTableState.page = totalPages;
    if (registrationsTableState.page < 1) registrationsTableState.page = 1;

    const startIndex = (registrationsTableState.page - 1) * registrationsTableState.pageSize;
    const endIndex = Math.min(totalRows, startIndex + registrationsTableState.pageSize);
    const pageRows = rows.slice(startIndex, endIndex);

    if (infoEl) {
        infoEl.textContent = totalRows === 0
            ? 'No records'
            : `Page ${registrationsTableState.page} of ${totalPages} • ${startIndex + 1}-${endIndex} of ${totalRows}`;
    }
    if (prevBtn) prevBtn.disabled = registrationsTableState.page <= 1;
    if (nextBtn) nextBtn.disabled = registrationsTableState.page >= totalPages || totalRows === 0;

    if (totalRows === 0) {
        tbody.innerHTML = `
            <tr>
                <td colspan="7" class="px-6 py-8 text-center text-zinc-400">
                    <i class="fas fa-inbox text-2xl mb-2"></i>
                    <p>No registrations found</p>
                </td>
            </tr>
        `;
        return;
    }

    tbody.innerHTML = pageRows.map(reg => {
        const statusColors = {
            'Pending': 'text-amber-700 bg-amber-100',
            'Fee Paid': 'text-emerald-700 bg-emerald-100',
            'Approved': 'text-blue-700 bg-blue-100',
            'Rejected': 'text-red-700 bg-red-100',
            'Walk-In': 'text-purple-700 bg-purple-100'
        };

        const displayStatus = getWalkInRegistrationDisplayStatus(reg);
        const statusClass = statusColors[displayStatus] || 'text-slate-700 bg-slate-100';
        const remaining = getWalkInRegistrationRemainingAmount(reg);
        const registrationSource = String(reg.registration_source || 'online').toLowerCase() === 'walkin' ? 'walkin' : 'online';
        const sourceBadgeClass = registrationSource === 'walkin'
            ? 'bg-purple-100 text-purple-700'
            : 'bg-sky-100 text-sky-700';
        const sourceLabel = registrationSource === 'walkin' ? 'Walk-In' : 'Online';
        const studentLoginId = getRegistrationStudentLoginId(reg);

        // Create button-style proof links that open in modal
        const registrationProofLink = reg.registration_proof_path
            ? `<button type="button" class="view-proof-btn inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-blue-50 text-blue-700
                         hover:bg-blue-100 border border-blue-200 text-[10px] font-semibold transition-colors"
                         data-proof-url="${buildPublicFileUrl(reg.registration_proof_path)}" data-proof-title="Payment Proof">
                  <i class="fas fa-receipt"></i>
                  <span>Payment</span>
               </button>`
            : (registrationSource === 'walkin'
                ? '<div class="text-[10px] text-slate-400 mt-1 italic">Walk-in payment handled at branch</div>'
                : '<div class="text-[10px] text-slate-400 mt-1 italic">No proof uploaded</div>');

        const ageProofLink = reg.age_verification_proof_path
            ? `<button type="button" class="view-proof-btn inline-flex items-center gap-1 px-1.5 py-0.5 rounded-md bg-emerald-50 text-emerald-700
                         hover:bg-emerald-100 border border-emerald-200 text-[10px] font-semibold transition-colors"
                         data-proof-url="${buildPublicFileUrl(reg.age_verification_proof_path)}" data-proof-title="ID Proof">
                  <i class="fas fa-id-card"></i>
                  <span>ID</span>
               </button>`
            : (registrationSource === 'walkin'
                ? '<div class="text-[10px] text-slate-400 mt-1 italic">Proof ID not required for walk-in</div>'
                : '<div class="text-[10px] text-slate-400 mt-1 italic">No proof ID uploaded</div>');

        return `
            <tr class="hover:bg-gold-500/5 transition">
                <td class="px-4 py-2.5 table-name-cell">
                    <div class="text-sm font-semibold text-slate-900 wrap-text" style="color:#0f172a;" title="${escapeHtml(reg.first_name + ' ' + reg.last_name)}">${escapeHtml(reg.first_name || '')} ${escapeHtml(reg.last_name || '')}</div>
                    <div class="mt-1 flex flex-wrap items-center gap-1.5"><span class="text-xs text-slate-500 truncate-text" style="color:#64748b;" title="Student ID: ${escapeHtml(studentLoginId || 'Not assigned')}">${escapeHtml(studentLoginId || 'Not assigned')}</span><span class="inline-flex items-center px-1.5 py-0.5 rounded text-[9px] font-bold ${sourceBadgeClass}">${sourceLabel}</span></div>
                </td>
                <td class="px-4 py-2.5 table-text-cell">
                    <div class="text-sm font-medium text-slate-900 wrap-text" style="color:#0f172a;" title="${escapeHtml((reg.guardian_first_name || '') + ' ' + (reg.guardian_last_name || ''))}">${escapeHtml(reg.guardian_first_name || '')} ${escapeHtml(reg.guardian_last_name || '')}</div>
                    <div class="text-xs text-slate-500 truncate-text" style="color:#64748b;" title="${escapeHtml(reg.guardian_phone || '')}">${escapeHtml(reg.guardian_phone || '')}</div>
                </td>
                <td class="px-4 py-2.5 text-sm text-slate-700 table-text-cell truncate-text" style="color:#334155;" title="${escapeHtml(reg.branch_name || '')}">${escapeHtml(reg.branch_name || '')}</td>
                <td class="px-4 py-2.5 table-money-cell">
                    <div class="text-sm text-slate-900 font-semibold" style="color:#0f172a;">₱${parseFloat(reg.registration_fee_amount || 0).toFixed(2)}</div>
                    ${remaining > 0 ? `<div class="text-xs text-red-600">Remaining: ₱${remaining.toFixed(2)}</div>` : ''}
                    <div class="mt-1 flex flex-wrap gap-1">${registrationProofLink}${ageProofLink}</div>
                </td>
                <td class="px-4 py-2.5 table-status-cell">
                    <span class="px-2 py-1 rounded text-[11px] font-semibold ${statusClass}">
                        ${escapeHtml(displayStatus)}
                    </span>
                </td>
                <td class="px-4 py-2.5 text-slate-600 text-xs table-date-cell" style="color:#475569;">
                    ${new Date(reg.created_at).toLocaleDateString()}
                </td>
                <td class="px-4 py-2.5 table-actions-cell-wide">
                   <div class="flex items-center gap-1.5 whitespace-nowrap">

    <!-- VIEW -->
    <button onclick="viewDetails(${reg.student_id})"
        class="inline-flex items-center gap-1 px-2.5 py-1.5
               bg-blue-50 text-blue-600 border border-blue-100
               hover:bg-blue-600 hover:text-white
               rounded-lg text-xs font-semibold
               transition-all duration-200 shadow-sm hover:shadow">
        <i class="fas fa-eye text-xs"></i>
        <span>View</span>
    </button>

    ${reg.registration_status === 'Pending' ? `

        <!-- PAY -->
        <button onclick="openPaymentModal(${reg.student_id})"
            class="inline-flex items-center gap-1 px-2.5 py-1.5
                   bg-amber-50 text-amber-600 border border-amber-100
                   hover:bg-amber-500 hover:text-white
                   rounded-lg text-xs font-semibold
                   transition-all duration-200 shadow-sm hover:shadow">
            <i class="fas fa-money-bill-wave text-xs"></i>
            <span>Pay</span>
        </button>

        <!-- REJECT -->
        <button onclick="rejectRegistration(${reg.student_id})"
            class="inline-flex items-center gap-1 px-2.5 py-1.5
                   bg-red-50 text-red-600 border border-red-100
                   hover:bg-red-600 hover:text-white
                   rounded-lg text-xs font-semibold
                   transition-all duration-200 shadow-sm hover:shadow">
            <i class="fas fa-times text-xs"></i>
            <span>Reject</span>
        </button>


                        ` : ''}
                    </div>
                </td>
            </tr>
        `;
    }).join('');

    // Add event delegation for proof view buttons in table
    setTimeout(() => {
        if (!tbody.dataset.proofListenerAdded) {
            tbody.addEventListener('click', (e) => {
                const proofBtn = e.target.closest('.view-proof-btn');
                if (proofBtn) {
                    e.preventDefault();
                    e.stopPropagation();
                    const proofUrl = proofBtn.getAttribute('data-proof-url');
                    const proofTitle = proofBtn.getAttribute('data-proof-title') || 'Proof';
                    if (proofUrl) {
                        openProofViewerModal(proofUrl, proofTitle);
                    }
                }
            });
            tbody.dataset.proofListenerAdded = 'true';
        }
    }, 100);
}

// Display Registrations
function displayRegistrations(registrations) {
    if (!document.getElementById('registrationsTable')) {
        return;
    }
    registrationsTableState.allRows = sortNewestRegistrationsFirst(registrations);
    initRegistrationsPaginationControls();
    applyRegistrationTableFilters();
}

// Update Stats
function updateStats(registrations) {
    const stats = {
        pending: 0,
        feePaid: 0,
        approved: 0,
        total: registrations ? registrations.length : 0
    };

    if (registrations) {
        registrations.forEach(reg => {
            if (reg.registration_status === 'Pending') stats.pending++;
            if (reg.registration_status === 'Fee Paid') stats.feePaid++;
            if (reg.registration_status === 'Approved') stats.approved++;
        });
    }

    const statPending = document.getElementById('statPending');
    const statFeePaid = document.getElementById('statFeePaid');
    const statApproved = document.getElementById('statApproved');
    const statTotal = document.getElementById('statTotal');

    if (statPending) statPending.textContent = stats.pending;
    if (statFeePaid) statFeePaid.textContent = stats.feePaid;
    if (statApproved) statApproved.textContent = stats.approved;
    if (statTotal) statTotal.textContent = stats.total;
}

// View Details
async function viewDetails(studentId) {
    try {
        const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
        const role = String(user?.role_name || '').toLowerCase();
        const branchScopedRole = user && ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);
        const staffBranchId = branchScopedRole ? Number(user.branch_id || 0) : 0;
        let url = `${baseApiUrl}/admin.php?action=get-registration-details&student_id=${studentId}`;
        if (staffBranchId > 0) url += `&branch_id=${encodeURIComponent(staffBranchId)}`;

        const res = await axios.get(url);
        const data = res.data;

        if (data.success) {
            const { student, guardians, payments, user_account } = data;
            const studentName = [student?.first_name, student?.middle_name, student?.last_name]
                .map(part => String(part || '').trim())
                .filter(Boolean)
                .join(' ') || 'Student';
            const sourceLabel = String(student?.registration_source || 'online').toLowerCase() === 'walkin' ? 'Walk-In' : 'Online';
            const feeAmount = Number(student?.registration_fee_amount || 0);
            const paidAmount = Number(student?.registration_fee_paid || 0);
            const remainingAmount = getWalkInRegistrationRemainingAmount(student);
            const formatMoney = value => `&#8369;${Number(value || 0).toFixed(2)}`;
            const detailRow = (label, value) => `
                <div class="rounded-2xl border border-slate-200 bg-white px-4 py-3 shadow-sm">
                    <div class="text-[11px] uppercase tracking-[0.22em] text-slate-500">${escapeHtml(label)}</div>
                    <div class="mt-1 text-sm font-semibold text-slate-900 break-words">${value}</div>
                </div>
            `;
            const statCard = (label, value) => `
                <div class="rounded-2xl border border-slate-200 bg-slate-50 px-4 py-4 shadow-sm">
                    <div class="text-[11px] uppercase tracking-[0.22em] text-slate-500">${escapeHtml(label)}</div>
                    <div class="mt-2 text-lg font-bold text-slate-900">${value}</div>
                </div>
            `;
            const paymentProofValue = student?.registration_proof_path
                ? `<button type="button" class="view-proof-btn text-amber-700 underline decoration-amber-300/60 underline-offset-4 hover:text-amber-900 cursor-pointer" data-proof-url="${buildPublicFileUrl(student.registration_proof_path)}" data-proof-title="Payment Proof">View file</button>`
                : escapeHtml(String(student?.registration_source || 'online').toLowerCase() === 'walkin' ? 'Not required for walk-in' : 'N/A');
            const proofIdValue = student?.age_verification_proof_path
                ? `<button type="button" class="view-proof-btn text-amber-700 underline decoration-amber-300/60 underline-offset-4 hover:text-amber-900 cursor-pointer" data-proof-url="${buildPublicFileUrl(student.age_verification_proof_path)}" data-proof-title="ID Proof">View file</button>`
                : escapeHtml(String(student?.registration_source || 'online').toLowerCase() === 'walkin' ? 'Not required for walk-in' : 'N/A');
            const detailsHTML = `
                <div class="space-y-5">
                    <div class="rounded-3xl border border-slate-200 bg-gradient-to-r from-white to-slate-50 p-5 shadow-sm">
                        <div class="flex flex-wrap items-center justify-between gap-3">
                            <div>
                                <p class="text-[11px] uppercase tracking-[0.3em] text-amber-700/80">Registration</p>
                                <h4 class="mt-1 text-xl font-bold text-slate-900">Registration Details</h4>
                            </div>
                            <span class="inline-flex items-center rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-xs font-semibold text-amber-800">${escapeHtml(getWalkInRegistrationDisplayStatus(student))}</span>
                        </div>
                        <div class="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                            ${statCard('Fee Amount', formatMoney(feeAmount))}
                            ${statCard('Paid Amount', formatMoney(paidAmount))}
                            ${statCard('Remaining', formatMoney(remainingAmount))}
                        </div>
                    </div>

                    <div class="grid grid-cols-1 lg:grid-cols-[1.15fr_0.85fr] gap-4">
                        <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <h4 class="text-sm font-semibold uppercase tracking-[0.22em] text-amber-700">Student Information</h4>
                            <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                                ${detailRow('Name', escapeHtml(studentName))}
                                ${detailRow('Email', escapeHtml(student?.email || 'N/A'))}
                                ${detailRow('Phone', escapeHtml(student?.phone || 'N/A'))}
                                ${detailRow('Date of Birth', escapeHtml(student?.date_of_birth || 'N/A'))}
                                ${detailRow('Branch', escapeHtml(student?.branch_name || 'N/A'))}
                                ${detailRow('Source', escapeHtml(sourceLabel))}
                            </div>
                        </section>

                        <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <h4 class="text-sm font-semibold uppercase tracking-[0.22em] text-amber-700">Registration Status</h4>
                            <div class="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-3">
                                ${detailRow('Status', escapeHtml(getWalkInRegistrationDisplayStatus(student)))}
                                ${detailRow('Payment Proof', paymentProofValue)}
                                ${detailRow('Proof ID', proofIdValue)}
                            </div>
                        </section>
                    </div>

                    ${guardians && guardians.length > 0 ? `
                        <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <h4 class="text-sm font-semibold uppercase tracking-[0.22em] text-amber-700">Guardian Information</h4>
                            <div class="mt-4 grid grid-cols-1 md:grid-cols-2 gap-3">
                                ${guardians.map(g => `
                                    <div class="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                                        <p class="font-semibold text-slate-900">${escapeHtml(`${g.first_name || ''} ${g.last_name || ''}`.trim() || 'Guardian')}</p>
                                        <p class="mt-1 text-sm text-slate-600">${escapeHtml(g.relationship_type || 'Relationship not set')} · ${escapeHtml(g.phone || 'N/A')}</p>
                                    </div>
                                `).join('')}
                            </div>
                        </section>
                    ` : ''}

                    ${user_account ? `
                        <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <h4 class="text-sm font-semibold uppercase tracking-[0.22em] text-amber-700">User Account</h4>
                            <div class="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
                                ${detailRow('Username', escapeHtml(user_account.username || 'N/A'))}
                                ${detailRow('Email', escapeHtml(user_account.email || 'N/A'))}
                                ${detailRow('Status', escapeHtml(user_account.status || 'N/A'))}
                            </div>
                        </section>
                    ` : ''}

                    ${payments && payments.length > 0 ? `
                        <section class="rounded-3xl border border-slate-200 bg-white p-5 shadow-sm">
                            <div class="flex flex-wrap items-center justify-between gap-3">
                                <div>
                                    <h4 class="text-sm font-semibold uppercase tracking-[0.22em] text-amber-700">Payment History</h4>
                                    <p class="mt-1 text-sm text-slate-500">${payments.length} payment${payments.length === 1 ? '' : 's'} recorded</p>
                                </div>
                                <span class="rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-xs font-semibold text-slate-600">Scrollable list</span>
                            </div>
                            <div class="mt-4 overflow-hidden rounded-2xl border border-slate-200">
                                <div class="max-h-72 overflow-y-auto">
                                    <table class="min-w-full text-sm text-slate-900">
                                        <thead class="sticky top-0 z-10 bg-slate-100 backdrop-blur">
                                            <tr>
                                                <th class="px-4 py-3 text-left text-slate-700 font-semibold">Date</th>
                                                <th class="px-4 py-3 text-left text-slate-700 font-semibold">Amount</th>
                                                <th class="px-4 py-3 text-left text-slate-700 font-semibold">Method</th>
                                                <th class="px-4 py-3 text-left text-slate-700 font-semibold">Receipt</th>
                                                <th class="px-4 py-3 text-left text-slate-700 font-semibold">Reference</th>
                                            </tr>
                                        </thead>
                                        <tbody class="divide-y divide-slate-200">
                                            ${payments.map((p, index) => `
                                                <tr class="${index % 2 === 0 ? 'bg-white' : 'bg-slate-50'} hover:bg-amber-50 transition-colors">
                                                    <td class="px-4 py-3 whitespace-nowrap text-slate-700">${escapeHtml(new Date(p.payment_date).toLocaleDateString())}</td>
                                                    <td class="px-4 py-3 whitespace-nowrap text-slate-900 font-semibold">${formatMoney(p.amount)}</td>
                                                    <td class="px-4 py-3 text-slate-700">${escapeHtml(p.payment_method || 'N/A')}</td>
                                                    <td class="px-4 py-3 text-slate-700">${escapeHtml(p.receipt_number || 'N/A')}</td>
                                                    <td class="px-4 py-3 text-slate-700">${escapeHtml(p.reference_number || 'N/A')}</td>
                                                </tr>
                                            `).join('')}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </section>
                    ` : ''}
                </div>
            `;

            document.getElementById('detailsContent').innerHTML = detailsHTML;
            document.getElementById('detailsModal').classList.remove('hidden');
            document.getElementById('detailsModal').classList.add('flex');
            document.body.classList.add('overflow-hidden');

            // Add event delegation for proof viewing buttons
            setTimeout(() => {
                const detailsContent = document.getElementById('detailsContent');
                if (detailsContent) {
                    detailsContent.addEventListener('click', (e) => {
                        const proofBtn = e.target.closest('.view-proof-btn');
                        if (proofBtn) {
                            e.preventDefault();
                            const proofUrl = proofBtn.getAttribute('data-proof-url');
                            const proofTitle = proofBtn.getAttribute('data-proof-title') || 'Proof';
                            if (proofUrl) {
                                openProofViewerModal(proofUrl, proofTitle);
                            }
                        }
                    });
                }
            }, 100);
        }
    } catch (error) {
        showMessage('Failed to load details: ' + (error.message || error), 'error');
    }
}

// Open Proof Viewer Modal
function openProofViewerModal(proofUrl, title) {
    const modal = document.getElementById('proofViewerModal');

    if (!modal) {
        // Create compact modal with higher z-index
        const modalHTML = `
            <div id="proofViewerModal" class="fixed inset-0 z-[1300] hidden items-center justify-center overflow-hidden bg-black/90 p-3 backdrop-blur-sm sm:p-6" role="dialog" aria-modal="true" aria-labelledby="proofViewerTitle">
                <div class="flex w-full max-w-4xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl" style="max-height: min(90vh, 90dvh);">
                    <div class="flex shrink-0 items-center justify-between gap-3 border-b border-slate-200 bg-white px-4 py-3">
                        <h3 id="proofViewerTitle" class="min-w-0 truncate text-sm font-bold text-slate-900">Proof</h3>
                        <button type="button" data-proof-viewer-close aria-label="Close proof preview" class="grid h-10 w-10 shrink-0 place-items-center rounded-full border border-slate-200 bg-white text-slate-600 transition hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-amber-500">
                            <i class="fas fa-times" aria-hidden="true"></i>
                        </button>
                    </div>
                    <div class="flex min-h-0 flex-1 items-center justify-center overflow-hidden bg-slate-100 p-3 sm:p-5">
                        <img id="proofViewerImage" alt="Proof preview" class="block h-auto w-auto max-w-full object-contain" style="display: none; max-height: calc(min(90vh, 90dvh) - 5.5rem);" />
                        <iframe id="proofViewerIframe" title="Proof document preview" class="h-full min-h-[260px] w-full border-0 bg-white sm:min-h-[420px]" style="display: none;"></iframe>
                        <div id="proofViewerLoading" class="text-slate-400">
                            <i class="fas fa-spinner fa-spin text-2xl"></i>
                        </div>
                    </div>
                </div>
            </div>
        `;
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        const createdModal = document.getElementById('proofViewerModal');
        createdModal?.addEventListener('click', (event) => {
            if (event.target === createdModal || event.target.closest('[data-proof-viewer-close]')) {
                closeProofViewerModal();
            }
        });
    }

    const actualModal = document.getElementById('proofViewerModal');
    const actualIframe = document.getElementById('proofViewerIframe');
    const actualImage = document.getElementById('proofViewerImage');
    const actualTitle = document.getElementById('proofViewerTitle');
    const loadingEl = document.getElementById('proofViewerLoading');

    if (actualTitle) actualTitle.textContent = title;

    // Check if it's an image or PDF
    const isImage = /\.(jpg|jpeg|png|gif|webp|bmp)$/i.test(proofUrl);

    if (isImage && actualImage) {
        // Display as image for better fitting
        actualImage.style.display = 'block';
        if (actualIframe) actualIframe.style.display = 'none';
        if (loadingEl) loadingEl.style.display = 'flex';

        actualImage.onload = () => {
            if (loadingEl) loadingEl.style.display = 'none';
        };
        actualImage.onerror = () => {
            if (loadingEl) loadingEl.style.display = 'none';
            // Fallback to iframe if image fails
            if (actualIframe) {
                actualIframe.style.display = 'block';
                actualIframe.src = proofUrl;
            }
            actualImage.style.display = 'none';
        };
        actualImage.src = proofUrl;
    } else if (actualIframe) {
        // Display PDF in iframe
        actualImage.style.display = 'none';
        actualIframe.style.display = 'block';
        if (loadingEl) loadingEl.style.display = 'none';
        actualIframe.src = proofUrl;
    }

    if (actualModal) {
        actualModal.classList.remove('hidden');
        actualModal.classList.add('flex');
        actualModal.dataset.previousBodyOverflow = document.body.style.overflow || '';
        document.body.style.overflow = 'hidden';
        actualModal.querySelector('[data-proof-viewer-close]')?.focus({ preventScroll: true });
    }
}

// Close Proof Viewer Modal
function closeProofViewerModal() {
    const modal = document.getElementById('proofViewerModal');
    const iframe = document.getElementById('proofViewerIframe');
    if (modal) {
        modal.classList.add('hidden');
        modal.classList.remove('flex');
        document.body.style.overflow = modal.dataset.previousBodyOverflow || '';
        delete modal.dataset.previousBodyOverflow;
    }
    if (iframe) {
        iframe.src = '';
    }
}

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape' && !document.getElementById('proofViewerModal')?.classList.contains('hidden')) {
        event.preventDefault();
        closeProofViewerModal();
    }
});

// Close Details Modal
function closeDetailsModal() {
    const modal = document.getElementById('detailsModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    document.body.classList.remove('overflow-hidden');
}

function sanitizeInternalRedirectUrl(value) {
    const raw = String(value || '').trim();
    if (!raw) return '';

    try {
        const resolved = new URL(raw, window.location.href);
        if (resolved.origin !== window.location.origin) {
            return '';
        }

        const appBasePath = (() => {
            try {
                const base = (typeof appBaseUrl === 'string' && appBaseUrl)
                    ? appBaseUrl
                    : `${window.location.origin}/FAS_music`;
                return new URL(base, window.location.origin).pathname.replace(/\/+$/, '');
            } catch (e) {
                return '/FAS_music';
            }
        })();

        const normalizedPath = resolved.pathname.replace(/\/+$/, '');
        if (appBasePath && normalizedPath && !normalizedPath.startsWith(appBasePath)) {
            return '';
        }

        return `${resolved.pathname}${resolved.search}${resolved.hash}`;
    } catch (e) {
        return '';
    }
}

// Open Payment Modal
async function openPaymentModal(studentId, options = {}) {
    currentStudentId = studentId;
    currentPaymentRedirectUrl = sanitizeInternalRedirectUrl(options.redirectUrl || '');

    try {
        const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
        const role = String(user?.role_name || '').toLowerCase();
        const branchScopedRole = user && ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);
        const staffBranchId = branchScopedRole ? Number(user.branch_id || 0) : 0;
        let url = `${baseApiUrl}/admin.php?action=get-registration-details&student_id=${studentId}`;
        if (staffBranchId > 0) url += `&branch_id=${encodeURIComponent(staffBranchId)}`;

        const res = await axios.get(url);
        const data = res.data;
        if (data.success) {
            const student = data.student;
            const registrationSource = String(options.forceSource || student.registration_source || '').toLowerCase() === 'walkin' ? 'walkin' : 'online';
            currentPaymentSource = registrationSource;
            const remaining = getWalkInRegistrationRemainingAmount(student);
            const payments = Array.isArray(data.payments) ? data.payments : [];
            const receiptPayment = payments.find(payment => String(payment.status || '').toLowerCase() === 'pending')
                || payments.find(payment => Number(payment.amount || 0) > 0)
                || null;
            const selectedMethod = (receiptPayment?.payment_method || '').trim();
            const selectedAmount = Number(receiptPayment?.amount || 0);
            const paymentStudentInfoEl = document.getElementById('paymentStudentInfo');
            const paymentAmountEl = document.getElementById('paymentAmount');
            const paymentAmountDisplayEl = document.getElementById('paymentAmountDisplay');
            const paymentAmountHintEl = document.getElementById('paymentAmountHint');
            const paymentMethodEl = document.getElementById('paymentMethod');
            const paymentMethodDisplayEl = document.getElementById('paymentMethodDisplay');
            const paymentMethodSelectEl = document.getElementById('paymentMethodSelect');
            const paymentMethodReadonlyWrap = document.getElementById('paymentMethodReadonlyWrap');
            const paymentMethodSelectWrap = document.getElementById('paymentMethodSelectWrap');
            const paymentMethodReadonlyHint = document.getElementById('paymentMethodReadonlyHint');
            const paymentReferenceWrap = document.getElementById('paymentReferenceWrap');
            const paymentReferenceDisplay = document.getElementById('paymentReferenceDisplay');
            const modal = document.getElementById('paymentModal');

            if (!paymentStudentInfoEl || !paymentAmountEl || !paymentMethodEl || !modal) {
                throw new Error('Payment modal is missing required fields. Please refresh the page and try again.');
            }

            paymentStudentInfoEl.textContent =
                `Student: ${student.first_name} ${student.last_name} | Remaining: ₱${remaining.toFixed(2)}`;
            const receiptAmount = selectedAmount > 0
                ? selectedAmount
                : (remaining > 0 ? remaining : student.registration_fee_amount);
            paymentAmountEl.value = receiptAmount;
            if (paymentAmountDisplayEl) {
                paymentAmountDisplayEl.textContent =
                    `₱${Number(receiptAmount || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
            }
            if (paymentAmountHintEl) {
                paymentAmountHintEl.textContent = registrationSource === 'walkin'
                    ? 'This is the lifetime ₱1,000.00 registration fee for the walk-in student.'
                    : 'This amount comes from the student\'s submitted registration payment request.';
            }
            paymentMethodEl.value = selectedMethod;
            if (paymentMethodDisplayEl) {
                paymentMethodDisplayEl.textContent = selectedMethod || (registrationSource === 'walkin' ? 'Choose below' : 'No method submitted');
            }
            if (paymentMethodReadonlyWrap && paymentMethodSelectWrap) {
                paymentMethodReadonlyWrap.classList.toggle('hidden', registrationSource === 'walkin');
                paymentMethodSelectWrap.classList.toggle('hidden', registrationSource !== 'walkin');
            }
            if (paymentMethodSelectEl) {
                paymentMethodSelectEl.value = registrationSource === 'walkin' ? selectedMethod : '';
            }
            if (paymentMethodReadonlyHint) {
                paymentMethodReadonlyHint.textContent = registrationSource === 'walkin'
                    ? ''
                    : 'This method was already selected by the student during registration.';
            }
            const submittedReferenceNumber = String(receiptPayment?.reference_number || '').trim();
            if (paymentReferenceWrap) {
                paymentReferenceWrap.classList.toggle('hidden', registrationSource === 'walkin');
            }
            if (paymentReferenceDisplay) {
                paymentReferenceDisplay.textContent = submittedReferenceNumber || 'Not provided';
                paymentReferenceDisplay.classList.toggle('text-zinc-500', !submittedReferenceNumber);
                paymentReferenceDisplay.classList.toggle('text-blue-900', Boolean(submittedReferenceNumber));
            }

            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
    } catch (error) {
        showMessage('Failed to load student info: ' + (error.message || error), 'error');
    }
}

// Close Payment Modal
function closePaymentModal() {
    const modal = document.getElementById('paymentModal');
    if (!modal) return;
    modal.classList.add('hidden');
    modal.classList.remove('flex');
    const paymentForm = document.getElementById('paymentForm');
    const paymentAmountEl = document.getElementById('paymentAmount');
    const paymentAmountDisplayEl = document.getElementById('paymentAmountDisplay');
    const paymentAmountHintEl = document.getElementById('paymentAmountHint');
    const paymentMethodEl = document.getElementById('paymentMethod');
    const paymentMethodDisplayEl = document.getElementById('paymentMethodDisplay');
    const paymentMethodSelectEl = document.getElementById('paymentMethodSelect');
    const paymentMethodReadonlyWrap = document.getElementById('paymentMethodReadonlyWrap');
    const paymentMethodSelectWrap = document.getElementById('paymentMethodSelectWrap');
    const paymentReferenceWrap = document.getElementById('paymentReferenceWrap');
    const paymentReferenceDisplay = document.getElementById('paymentReferenceDisplay');

    if (paymentForm) paymentForm.reset();
    if (paymentAmountEl) paymentAmountEl.value = '';
    if (paymentAmountDisplayEl) paymentAmountDisplayEl.textContent = '₱0.00';
    if (paymentAmountHintEl) paymentAmountHintEl.textContent = 'This amount comes from the student\'s submitted registration payment request.';
    if (paymentMethodEl) paymentMethodEl.value = '';
    if (paymentMethodDisplayEl) paymentMethodDisplayEl.textContent = 'Not available';
    if (paymentMethodSelectEl) paymentMethodSelectEl.value = '';
    if (paymentReferenceWrap) paymentReferenceWrap.classList.add('hidden');
    if (paymentReferenceDisplay) paymentReferenceDisplay.textContent = 'Not provided';
    if (paymentMethodReadonlyWrap) paymentMethodReadonlyWrap.classList.remove('hidden');
    if (paymentMethodSelectWrap) paymentMethodSelectWrap.classList.add('hidden');
    currentStudentId = null;
    currentPaymentRedirectUrl = '';
    currentPaymentSource = '';
}

// Confirm Payment Handler
function initPaymentForm() {
    const paymentForm = document.getElementById('paymentForm');
    if (!paymentForm) return;

    paymentForm.addEventListener('submit', async (e) => {
        e.preventDefault();

        const btn = document.getElementById('confirmPaymentBtn');
        const btnText = document.getElementById('confirmPaymentBtnText');

        btn.disabled = true;
        btnText.textContent = 'Processing...';

        const selectedMethod = currentPaymentSource === 'walkin'
            ? (document.getElementById('paymentMethodSelect')?.value || '').trim()
            : (document.getElementById('paymentMethod').value || '').trim();
        if (!selectedMethod) {
            showMessage(currentPaymentSource === 'walkin'
                ? 'Please select the registration payment method.'
                : 'No payment method was submitted by the student for this registration.', 'error');
            btn.disabled = false;
            btnText.textContent = 'Confirm Payment';
            return;
        }

        const lockedAmount = parseFloat(document.getElementById('paymentAmount').value || '0');
        if (!(lockedAmount > 0)) {
            showMessage('No submitted payment amount was found for this registration.', 'error');
            btn.disabled = false;
            btnText.textContent = 'Confirm Payment';
            return;
        }

        const paymentData = {
            student_id: currentStudentId,
            amount: lockedAmount,
            payment_method: selectedMethod
        };

        try {
            const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
            const role = String(user?.role_name || '').toLowerCase();
            const branchScopedRole = user && ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);
            const staffBranchId = branchScopedRole ? Number(user.branch_id || 0) : 0;
            if (staffBranchId > 0) paymentData.branch_id = staffBranchId;

            // Performer identity for audit log
            if (user) {
                const firstName = String(user.first_name || '').trim();
                const lastName  = String(user.last_name  || '').trim();
                paymentData.performed_by_id    = user.user_id  || null;
                paymentData.performed_by_name  = [firstName, lastName].filter(Boolean).join(' ') || user.username || null;
                paymentData.performed_by_role  = user.role_name || null;
                paymentData.performed_by_email = user.email || user.username || null;
            }

            const res = await axios.post(`${baseApiUrl}/admin.php?action=confirm-payment`, paymentData);
            const data = res.data;
            if (data.success) {
                const redirectUrl = currentPaymentRedirectUrl;
                showMessage(data.message, 'success');
                closePaymentModal();
                reloadRegistrationsByActiveMode();
                if (redirectUrl) {
                    window.location.href = redirectUrl;
                }
            }
        } catch (error) {
            showMessage('Failed to confirm payment: ' + (error.message || error), 'error');
        } finally {
            btn.disabled = false;
            btnText.textContent = 'Confirm Payment';
        }
    });
}

// Reject Registration
async function rejectRegistration(studentId) {
    const result = await Swal.fire({
        title: 'Reject Registration?',
        text: 'Are you sure you want to reject this registration?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, Reject',
        cancelButtonText: 'Cancel',
        confirmButtonColor: '#dc2626',
        cancelButtonColor: '#6b7280'
    });
    if (!result.isConfirmed) return;

    try {
        const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
        const role = String(user?.role_name || '').toLowerCase();
        const branchScopedRole = user && ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);
        const staffBranchId = branchScopedRole ? Number(user.branch_id || 0) : 0;
        const payload = { student_id: studentId };
        if (staffBranchId > 0) payload.branch_id = staffBranchId;

        // Performer identity for audit log
        if (user) {
            const firstName = String(user.first_name || '').trim();
            const lastName  = String(user.last_name  || '').trim();
            payload.performed_by_id    = user.user_id  || null;
            payload.performed_by_name  = [firstName, lastName].filter(Boolean).join(' ') || user.username || null;
            payload.performed_by_role  = user.role_name || null;
            payload.performed_by_email = user.email || user.username || null;
        }

        const res = await axios.post(`${baseApiUrl}/admin.php?action=reject-registration`, payload);
        const data = res.data;
        if (data.success) {
            showMessage(data.message, 'success');
            reloadRegistrationsByActiveMode();
        }
    } catch (error) {
        showMessage('Failed to reject registration: ' + (error.message || error), 'error');
    }
}

// Admin Users - load all users into admin_users.html table
async function loadAdminUsers() {
    try {
        const res = await axios.get(`${baseApiUrl}/admin.php?action=get-users`);
        const data = res.data;
        if (data && data.success && Array.isArray(data.users)) {
            if (typeof setAdminUsersRows === 'function') {
                setAdminUsersRows(data.users);
            }
        }
    } catch (error) {
        console.error('Failed to load admin users', error);
    }
}

function initAdminSidebarMenu() {
    const pathname = String(window.location.pathname || '').replace(/\\/g, '/').toLowerCase();
    if (!pathname.includes('/pages/admin/')) return;

    // Admin pages have a dedicated responsive shell. Let it be the sole owner
    // of sidebar and top-nav positioning to prevent two initializers fighting.
    if (document.querySelector('script[src*="/js/admin/admin_responsive.js"]')) return;

    const nav = document.querySelector('body > nav');
    const sidebar = document.querySelector('body > aside');
    if (!nav || !sidebar || sidebar.dataset.mobileMenuEnhanced === '1') return;

    sidebar.dataset.mobileMenuEnhanced = '1';

    const desktopMedia = window.matchMedia('(min-width: 1024px)');
    const sidebarId = sidebar.id || 'adminSidebar';
    sidebar.id = sidebarId;

    sidebar.classList.remove('hidden');
    sidebar.classList.add(
        'flex',
        'max-lg:-translate-x-full',
        'max-lg:transition-transform',
        'max-lg:duration-300',
        'max-lg:ease-out',
        'max-lg:z-[60]',
        'max-lg:w-[18.5rem]',
        'max-lg:shadow-2xl'
    );

    const overlay = document.createElement('button');
    overlay.type = 'button';
    overlay.setAttribute('aria-label', 'Close admin menu');
    overlay.className = 'fixed inset-0 z-[55] bg-slate-950/60 opacity-0 pointer-events-none transition-opacity duration-300 lg:hidden';
    document.body.appendChild(overlay);

    const firstNavChild = Array.from(nav.children).find((child) => child.nodeType === 1) || null;
    let leftCluster = firstNavChild;

    if (!leftCluster || !leftCluster.classList.contains('flex')) {
        leftCluster = document.createElement('div');
        leftCluster.className = 'flex items-center gap-3 lg:gap-8';
        if (firstNavChild) {
            nav.insertBefore(leftCluster, firstNavChild);
            leftCluster.appendChild(firstNavChild);
        } else {
            nav.prepend(leftCluster);
        }
    } else {
        leftCluster.classList.add('gap-3', 'lg:gap-8');
    }

    const menuButton = document.createElement('button');
    menuButton.type = 'button';
    menuButton.setAttribute('aria-controls', sidebarId);
    menuButton.setAttribute('aria-expanded', 'false');
    menuButton.setAttribute('aria-label', 'Open admin menu');
    menuButton.className = 'lg:hidden inline-flex h-11 w-11 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-white transition hover:bg-white/10 focus:outline-none focus:ring-2 focus:ring-gold-400/60';
    menuButton.innerHTML = '<i class="fas fa-bars text-base"></i><span class="sr-only">Open admin menu</span>';
    leftCluster.prepend(menuButton);

    const menuIcon = menuButton.querySelector('i');

    function setMenuState(isOpen) {
        const open = !desktopMedia.matches && Boolean(isOpen);
        sidebar.classList.toggle('max-lg:-translate-x-full', !open);
        sidebar.classList.toggle('max-lg:translate-x-0', open);
        overlay.classList.toggle('opacity-0', !open);
        overlay.classList.toggle('pointer-events-none', !open);
        overlay.classList.toggle('opacity-100', open);
        overlay.classList.toggle('pointer-events-auto', open);
        menuButton.setAttribute('aria-expanded', open ? 'true' : 'false');
        menuButton.setAttribute('aria-label', open ? 'Close admin menu' : 'Open admin menu');

        if (menuIcon) {
            menuIcon.classList.toggle('fa-bars', !open);
            menuIcon.classList.toggle('fa-xmark', open);
        }

        document.body.style.overflow = open ? 'hidden' : '';
    }

    function syncForViewport() {
        if (desktopMedia.matches) {
            setMenuState(false);
        }
    }

    menuButton.addEventListener('click', () => {
        const isOpen = menuButton.getAttribute('aria-expanded') === 'true';
        setMenuState(!isOpen);
    });

    overlay.addEventListener('click', () => setMenuState(false));

    sidebar.addEventListener('click', (event) => {
        if (desktopMedia.matches) return;
        if (event.target.closest('a[href]')) {
            setMenuState(false);
        }
    });

    document.addEventListener('keydown', (event) => {
        if (event.key === 'Escape') {
            setMenuState(false);
        }
    });

    if (typeof desktopMedia.addEventListener === 'function') {
        desktopMedia.addEventListener('change', syncForViewport);
    } else if (typeof desktopMedia.addListener === 'function') {
        desktopMedia.addListener(syncForViewport);
    }

    syncForViewport();
}

function initAdminResponsiveTables() {
    const pathname = String(window.location.pathname || '').replace(/\\/g, '/').toLowerCase();
    if (!pathname.includes('/pages/admin/')) return;

    if (!document.getElementById('adminResponsiveTableStyles')) {
        const style = document.createElement('style');
        style.id = 'adminResponsiveTableStyles';
        style.textContent = `
            .admin-table-scroll {
                scrollbar-width: thin;
                scrollbar-color: rgba(148, 163, 184, 0.9) rgba(226, 232, 240, 0.9);
                scrollbar-gutter: stable both-edges;
            }
            .admin-table-scroll::-webkit-scrollbar {
                height: 12px;
            }
            .admin-table-scroll::-webkit-scrollbar-track {
                background: rgba(226, 232, 240, 0.9);
                border-radius: 9999px;
            }
            .admin-table-scroll::-webkit-scrollbar-thumb {
                background: rgba(148, 163, 184, 0.95);
                border-radius: 9999px;
                border: 2px solid rgba(226, 232, 240, 0.9);
            }
            @media (min-width: 1024px) {
                .admin-table-scroll {
                    overflow-x: visible !important;
                    scrollbar-width: none;
                }
                .admin-table-scroll::-webkit-scrollbar {
                    height: 0;
                }
            }
        `;
        document.head.appendChild(style);
    }

    const tableWrappers = document.querySelectorAll('.overflow-x-auto');
    if (!tableWrappers.length) return;

    tableWrappers.forEach((wrapper) => {
        const table = wrapper.querySelector('table');
        if (!table) return;

        wrapper.classList.remove('overflow-x-auto', 'overflow-visible');
        wrapper.classList.add('overflow-x-scroll', 'lg:overflow-visible', 'overscroll-x-contain', 'pb-2', 'admin-table-scroll');
        wrapper.style.webkitOverflowScrolling = 'touch';

        const hasDeclaredMinWidth = /(^|\s)min-w-/.test(table.className) || table.style.minWidth;
        if (!hasDeclaredMinWidth) {
            const headerCount = table.querySelectorAll('thead th').length || table.querySelectorAll('tr:first-child th, tr:first-child td').length || 1;
            const estimatedMinWidth = Math.max(720, headerCount * 140);
            table.style.minWidth = `${estimatedMinWidth}px`;
        }

        if (wrapper.dataset.mobileScrollHint === '1') return;
        wrapper.dataset.mobileScrollHint = '1';

        const hint = document.createElement('p');
        hint.className = 'px-4 pt-3 text-[11px] font-medium tracking-wide text-slate-400 sm:hidden';
        hint.textContent = 'Swipe left or right to view the full table.';
        wrapper.insertAdjacentElement('afterend', hint);
    });
}

// Initialize
document.addEventListener('DOMContentLoaded', async () => {
    initPaymentDestinationReferences();
    if (window.fasServerTimeReady) {
        await window.fasServerTimeReady;
    }
    if (window.__fasAuthReady) {
        await window.__fasAuthReady;
    }
    // Check if we're on index.html or admin page
    const loginForm = document.getElementById('loginForm');
    const adminTable = document.getElementById('registrationsTable');
    const walkinForm = document.getElementById('walkinForm');
    const studentDashboard = document.getElementById('studentDashboardRoot');
    const studentProfile = document.getElementById('studentProfileRoot');
    const studentSessions = document.getElementById('studentSessionsRoot');
    const studentGrades = document.getElementById('studentGradesRoot');
    const studentAttendance = document.getElementById('studentAttendanceRoot');
    const studentQr = document.getElementById('studentQrRoot');
    const guardianStudentsRoot = document.getElementById('guardianStudentsRoot');
    const guardianPaymentsRoot = document.getElementById('guardianPaymentsRoot');
    const guardianProfileRoot = document.getElementById('guardianProfileRoot');
    const guardianAbsenceRoot = document.getElementById('guardianAbsenceRoot');

    initAdminSidebarMenu();
    initAdminResponsiveTables();

    if (loginForm) {
        // ── Already-logged-in redirect ─────────────────────────────────────────
        // If localStorage already has a user (shared with all tabs in the same
        // browser), skip the login page and go straight to their dashboard.
        // Ask the server about the HttpOnly JWT cookie. Only redirect if it confirms
        // user — never redirect back to index.html to avoid loops.
        (async () => {
            // Skip session check on public pages
            if (window.isPublicPage) {
                return;
            }

            try {
                const response = await axios.get(`${baseApiUrl}/users.php?action=optional-session`, {
                    validateStatus: () => true
                });
                const data = response.data || {};
                if (response.status === 200 && data.authenticated && data.user) {
                    const url = _getDashboardUrl(data.user.role_name);
                    if (url) {
                        Auth.setUser(data.user);
                        window.location.href = url;
                        return;
                    }
                }
                if (response.status === 200 && data.authenticated === false) Auth.clearStoredUser();
            } catch (_) { /* network error — show login normally */ }

            initIndexPage();
        })();

        function _getDashboardUrl(roleName) {
            const roleCategory = getRoleCategory(roleName);
            const base = (typeof appBaseUrl === 'string' && appBaseUrl) ? appBaseUrl : '';
            const routes = {
                admin:      `${base}/pages/admin/admin_dashboard.html`,
                manager:    `${base}/pages/manager/manager_dashboard.html`,
                staff:      `${base}/pages/desk/desk_attendance.html`,
                instructor: `${base}/pages/instructor/instructor_dashboard.html`,
                student:    `${base}/pages/student/student_dashboard.html`,
                guardian:   `${base}/pages/guardian/guardian_dashboard.html`,
            };
            return routes[roleCategory] || null;
        }
    } else if (walkinForm) {
        const user = Auth.getUser();
        const role = String(user?.role_name || '').toLowerCase();
        const isAdminRole = ['admin', 'superadmin'].includes(role);
        const isBranchScopedRole = ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);

        if (isAdminRole) {
            checkAuth();
        } else if (!isBranchScopedRole) {
            checkAuth();
            return;
        }

        initWalkinPage();
    } else if (adminTable) {
        const user = (typeof Auth !== 'undefined' && Auth.getUser) ? Auth.getUser() : null;
        const role = String(user?.role_name || '').toLowerCase();
        const isAdminRole = ['admin', 'superadmin'].includes(role);
        const isBranchScopedRole = ['staff', 'desk', 'front desk', 'manager', 'branch manager'].includes(role);

        if (isAdminRole) {
            checkAuth();
        } else if (!isBranchScopedRole) {
            checkAuth();
            return;
        }

        initPaymentForm();
        if (document.body?.dataset?.customRegistrationMode !== '1') {
            reloadRegistrationsByActiveMode();
        }
    } else if (studentDashboard) {
        initStudentDashboardPage();
        startPortalPageAutoRefresh('student-dashboard', initStudentDashboardPage);
    } else if (studentProfile) {
        initStudentProfilePage();
    } else if (studentSessions) {
        initStudentSessionsPage();
        startPortalPageAutoRefresh('student-sessions', initStudentSessionsPage);
    } else if (studentGrades) {
        initStudentGradesPage();
        startPortalPageAutoRefresh('student-grades', initStudentGradesPage);
    } else if (studentAttendance) {
        initStudentAttendancePage();
        startPortalPageAutoRefresh('student-attendance', initStudentAttendancePage);
    } else if (studentQr) {
        initStudentQrPage();
    } else if (document.getElementById('guardianDashboardRoot')) {
        initGuardianDashboardPage();
        startPortalPageAutoRefresh('guardian-dashboard', initGuardianDashboardPage);
    } else if (guardianStudentsRoot) {
        initGuardianStudentsPage();
        startPortalPageAutoRefresh('guardian-students', initGuardianStudentsPage);
    } else if (guardianPaymentsRoot) {
        initGuardianPaymentsPage();
        startPortalPageAutoRefresh('guardian-payments', initGuardianPaymentsPage);
    } else if (guardianProfileRoot) {
        initGuardianProfilePage();
    } else if (guardianAbsenceRoot) {
        initGuardianAbsencePage();
        startPortalPageAutoRefresh('guardian-absence', initGuardianAbsencePage);
    }

    // Profile, QR, songs, instructor, and any other portal page without a page
    // renderer still receives live decision notifications in the background.
    if (!window.__portalPageAutoRefreshTimer) startPortalStatusOnlyWatcher();
});
