<?php
// Suppress error display for JSON APIs
error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);

// ── Timezone: set explicitly so date calculations match the Philippines (UTC+8) ──
if (!ini_get('date.timezone') || ini_get('date.timezone') === 'UTC') {
    date_default_timezone_set('Asia/Manila');
}

require_once 'db_connect.php';
require_once 'instrument_specialization_sync.php';
require_once 'auth_session.php';
require_once 'enrollment_payment_rules.php';
require_once 'xss_protection.php';  // XSS Protection utilities

header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Send security headers
XSSProtection::sendSecurityHeaders();

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') exit(0);

// Check if database connection exists
if (!isset($conn) || $conn === null) {
    http_response_code(500);
    echo json_encode(['error' => 'Database connection failed']);
    exit;
}

class StudentsApi
{
    private $conn;
    private $phpMailerLoaded = false;
    private $lastMailError = null;
    private $existingTableCache = [];
    private $existingColumnCache = [];

    private function pendingReservationMinutes()
    {
        $value = getenv('FAS_PENDING_RESERVATION_MINUTES');
        $minutes = $value === false ? 1440 : (int)$value;
        return max(5, min(10080, $minutes));
    }

    private function decodeRequestMeta($value)
    {
        $decoded = json_decode((string)$value, true);
        return is_array($decoded) ? $decoded : [];
    }

    private function reservationIsActive($row, $meta = null)
    {
        $meta = is_array($meta) ? $meta : $this->decodeRequestMeta($row['request_notes'] ?? '');
        if (!empty($meta['is_walkin_request'])) return false;
        $state = (string)($row['schedule_request_status'] ?? $meta['schedule_request_status'] ?? 'Pending');
        if ($state !== 'Pending') return false;
        $expiresAt = trim((string)($row['reservation_expires_at'] ?? $meta['reservation_expires_at'] ?? ''));
        if ($expiresAt === '' && !empty($row['created_at'])) {
            $expiresAt = date('Y-m-d H:i:s', strtotime((string)$row['created_at']) + ($this->pendingReservationMinutes() * 60));
        }
        return $expiresAt !== '' && strtotime($expiresAt) !== false && strtotime($expiresAt) > time();
    }

    private function expirePendingScheduleReservations()
    {
        if (!$this->tableExists('tbl_enrollments')) return;
        $stmt = $this->conn->query("SELECT enrollment_id, student_id, request_notes, created_at, schedule_request_status, reservation_expires_at FROM tbl_enrollments WHERE status = 'Pending'");
        $update = $this->conn->prepare("UPDATE tbl_enrollments SET status = 'Expired', schedule_request_status = 'Expired', reservation_expires_at = NULL, request_notes = ? WHERE enrollment_id = ? AND status = 'Pending'");
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            $meta = $this->decodeRequestMeta($row['request_notes'] ?? '');
            if (!empty($meta['is_walkin_request'])) continue;
            $expiresAt = trim((string)($row['reservation_expires_at'] ?? $meta['reservation_expires_at'] ?? ''));
            if ($expiresAt === '' && !empty($row['created_at'])) $expiresAt = date('Y-m-d H:i:s', strtotime((string)$row['created_at']) + ($this->pendingReservationMinutes() * 60));
            if (($row['schedule_request_status'] ?? $meta['schedule_request_status'] ?? 'Pending') === 'Pending' && $expiresAt !== '' && strtotime($expiresAt) <= time()) {
                $meta['schedule_request_status'] = 'Expired';
                $meta['reservation_expired_at'] = date('Y-m-d H:i:s');
                $update->execute([json_encode($meta), (int)$row['enrollment_id']]);
            }
        }
    }

    /**
     * Expand weekly request choices into the exact lesson dates covered by the
     * package. A preferred slot is a recurrence seed, not a permanent hold.
     */
    private function projectRequestedSessionSlots($meta)
    {
        $meta = is_array($meta) ? $meta : [];
        $slots = is_array($meta['preferred_slots'] ?? null) ? array_values($meta['preferred_slots']) : [];
        $total = max(1, min(100, (int)($meta['requested_session_count'] ?? $meta['base_package_sessions'] ?? 12)));
        $queue = [];

        foreach ($slots as $index => $slot) {
            if (!is_array($slot)) continue;
            $date = trim((string)($slot['session_date'] ?? ''));
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) continue;
            $queue[] = ['index' => (int)$index, 'next_date' => $date, 'slot' => $slot];
        }

        $result = [];
        for ($sessionNumber = 1; $sessionNumber <= $total && !empty($queue); $sessionNumber++) {
            usort($queue, function ($a, $b) {
                $dateCompare = strcmp((string)$a['next_date'], (string)$b['next_date']);
                if ($dateCompare !== 0) return $dateCompare;
                $timeCompare = strcmp((string)($a['slot']['start_time'] ?? ''), (string)($b['slot']['start_time'] ?? ''));
                if ($timeCompare !== 0) return $timeCompare;
                return ((int)$a['index']) <=> ((int)$b['index']);
            });

            $current = &$queue[0];
            $projected = $current['slot'];
            $projected['session_date'] = $current['next_date'];
            $projected['day_of_week'] = $this->dayOfWeekFromDate($current['next_date']);
            $projected['session_number'] = $sessionNumber;
            $result[] = $projected;
            $current['next_date'] = date('Y-m-d', strtotime($current['next_date'] . ' +7 days'));
            unset($current);
        }

        return $result;
    }

    private function getPendingReservationConflicts($teacherId, $sessionDate, $dayOfWeek, $startTime, $endTime, $excludeRequestIds = [], $lockRows = false)
    {
        if ((int)$teacherId < 1 || !$this->tableExists('tbl_enrollments')) return [];
        $sql = "
            SELECT e.enrollment_id AS request_id, e.request_notes, e.created_at, e.schedule_request_status, e.reservation_expires_at,
                   s.student_id, s.first_name, s.last_name, s.email, s.branch_id,
                   e.enrolled_by_type, g.first_name AS guardian_first_name,
                   g.last_name AS guardian_last_name, g.email AS guardian_email,
                   b.branch_name, sp.package_name,
                   i.instrument_name, it.type_name,
                   CONCAT_WS(' ', t.first_name, t.last_name) AS instructor_name
            FROM tbl_enrollments e
            INNER JOIN tbl_students s ON s.student_id = e.student_id
            LEFT JOIN tbl_branches b ON b.branch_id = s.branch_id
            LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id
            LEFT JOIN tbl_instruments i ON i.instrument_id = e.instrument_id
            LEFT JOIN tbl_instrument_types it ON it.type_id = i.type_id
            LEFT JOIN tbl_teachers t ON t.teacher_id = ?
            LEFT JOIN tbl_student_guardians sg ON sg.student_guardian_id = e.student_guardian_id
            LEFT JOIN tbl_guardians g ON g.guardian_id = sg.guardian_id
            WHERE e.status = 'Pending'
        ";
        $params = [(int)$teacherId];
        $excludeIds = $this->normalizeExcludedIds($excludeRequestIds);
        if ($excludeIds) {
            $sql .= ' AND e.enrollment_id NOT IN (' . implode(',', array_fill(0, count($excludeIds), '?')) . ')';
            $params = array_merge($params, $excludeIds);
        }
        $sql .= ' ORDER BY e.enrollment_id ASC';
        if ($lockRows && $this->conn->inTransaction()) $sql .= ' FOR UPDATE';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        $conflicts = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            $meta = $this->decodeRequestMeta($row['request_notes'] ?? '');
            if (!$this->reservationIsActive($row, $meta)) continue;
            $slots = $this->projectRequestedSessionSlots($meta);
            foreach ($slots as $slot) {
                $existingTeacher = (int)($slot['teacher_id'] ?? $meta['preferred_teacher_id'] ?? 0);
                $existingDate = trim((string)($slot['session_date'] ?? $meta['preferred_date'] ?? ''));
                $existingDay = trim((string)($slot['day_of_week'] ?? $meta['preferred_day_of_week'] ?? ''));
                $existingStart = trim((string)($slot['start_time'] ?? $meta['preferred_start_time'] ?? ''));
                $existingEnd = trim((string)($slot['end_time'] ?? $meta['preferred_end_time'] ?? ''));
                if ($existingTeacher !== (int)$teacherId || $existingStart === '' || $existingEnd === '') continue;
                $sameSchedule = $sessionDate !== ''
                    ? $existingDate === $sessionDate
                    : ($dayOfWeek !== '' && $existingDay === $dayOfWeek);
                if (!$sameSchedule || !($startTime < $existingEnd && $endTime > $existingStart)) continue;
                $conflicts[] = [
                    'request_id' => (int)$row['request_id'],
                    'requester' => strcasecmp((string)($row['enrolled_by_type'] ?? ''), 'Guardian') === 0
                        ? trim(($row['guardian_first_name'] ?? '') . ' ' . ($row['guardian_last_name'] ?? ''))
                        : trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? '')),
                    'student_id' => (int)($row['student_id'] ?? 0),
                    'email' => strcasecmp((string)($row['enrolled_by_type'] ?? ''), 'Guardian') === 0
                        ? ($row['guardian_email'] ?? '')
                        : ($row['email'] ?? ''),
                    'instructor' => $row['instructor_name'] ?? ($slot['teacher_name'] ?? 'Instructor'),
                    'teacher_id' => $existingTeacher,
                    'session_date' => $existingDate,
                    'day_of_week' => $existingDay,
                    'start_time' => $existingStart,
                    'end_time' => $existingEnd,
                    'branch_id' => (int)($row['branch_id'] ?? 0),
                    'branch' => $row['branch_name'] ?? '',
                    'instrument' => $row['type_name'] ?: ($row['instrument_name'] ?? ''),
                    'submitted_at' => $row['created_at'] ?? '',
                    'reservation_expires_at' => $row['reservation_expires_at'] ?? $meta['reservation_expires_at'] ?? null
                ];
                break;
            }
        }
        return $conflicts;
    }

    public function __construct($pdo)
    {
        $this->conn = $pdo;
        ensure_specialization_instrument_link($this->conn);
        $this->ensureEnrollmentAssignedTeacherColumn();
        $this->ensureEnrollmentFixedScheduleColumns();
        $this->ensureEnrollmentScheduleSlotsTable();
        $this->ensurePendingScheduleReservationColumns();
        $this->ensureSessionSchedulingColumns();
        $this->ensureStudentProgressTable();
        $this->ensureStudentSessionExtensionRequestsTable();
        $this->ensurePromotionalAssessmentTables();
        $this->ensureLearningProgressTable();
        $this->ensureScheduleOperationLookupTable();
        $this->ensureSessionRescheduleWorkflow();
    }

    private function ensurePendingScheduleReservationColumns()
    {
        if (!$this->tableExists('tbl_enrollments')) return;
        try {
            if (!$this->tableHasColumn('tbl_enrollments', 'schedule_request_status')) {
                $this->conn->exec("ALTER TABLE tbl_enrollments ADD COLUMN schedule_request_status ENUM('Pending','Schedule Conflict','Suggested','Approved','Rejected','Expired') NULL AFTER schedule_status");
                $this->existingColumnCache['tbl_enrollments.schedule_request_status'] = true;
            }
            if (!$this->tableHasColumn('tbl_enrollments', 'reservation_expires_at')) {
                $this->conn->exec("ALTER TABLE tbl_enrollments ADD COLUMN reservation_expires_at DATETIME NULL AFTER schedule_request_status");
                $this->existingColumnCache['tbl_enrollments.reservation_expires_at'] = true;
            }
            $indexStmt = $this->conn->query("SHOW INDEX FROM tbl_enrollments WHERE Key_name = 'idx_pending_schedule_reservation'");
            if (!$indexStmt->fetch(PDO::FETCH_ASSOC)) {
                $this->conn->exec("ALTER TABLE tbl_enrollments ADD INDEX idx_pending_schedule_reservation (status, schedule_request_status, reservation_expires_at)");
            }
        } catch (PDOException $e) {
            error_log('Unable to initialize pending schedule reservation columns: ' . $e->getMessage());
        }
    }

    private function ensurePhpMailerLoaded()
    {
        if ($this->phpMailerLoaded) {
            return;
        }
        require_once dirname(__DIR__) . '/phpmailer/src/Exception.php';
        require_once dirname(__DIR__) . '/phpmailer/src/PHPMailer.php';
        require_once dirname(__DIR__) . '/phpmailer/src/SMTP.php';
        $this->phpMailerLoaded = true;
    }

    private function isValidEmailAddress($email)
    {
        return filter_var(trim((string)$email), FILTER_VALIDATE_EMAIL) !== false;
    }

    private function calculateAgeFromDateOfBirth($dateOfBirth)
    {
        $dateOfBirth = trim((string)$dateOfBirth);
        if ($dateOfBirth === '') {
            return null;
        }

        try {
            $birthDate = new DateTime($dateOfBirth);
            $today = new DateTime('today');
            if ($birthDate > $today) {
                return null;
            }

            return (int)$birthDate->diff($today)->y;
        } catch (Exception $e) {
            return null;
        }
    }

    private function isWalkInSystemEmail($email)
    {
        return preg_match('/@fas\.com$/i', trim((string)$email)) === 1;
    }

    private function ensureUserVerificationColumns()
    {
        try {
            if (!$this->hasUserColumn('email_verified_at')) {
                $this->conn->exec("ALTER TABLE tbl_users ADD COLUMN email_verified_at DATETIME NULL AFTER status");
            }
            if (!$this->hasUserColumn('email_verification_code_hash')) {
                $this->conn->exec("ALTER TABLE tbl_users ADD COLUMN email_verification_code_hash VARCHAR(255) NULL AFTER email_verified_at");
            }
            if (!$this->hasUserColumn('email_verification_code_expires_at')) {
                $this->conn->exec("ALTER TABLE tbl_users ADD COLUMN email_verification_code_expires_at DATETIME NULL AFTER email_verification_code_hash");
            }
            if (!$this->hasUserColumn('email_verification_sent_at')) {
                $this->conn->exec("ALTER TABLE tbl_users ADD COLUMN email_verification_sent_at DATETIME NULL AFTER email_verification_code_expires_at");
            }
        } catch (PDOException $e) {
            // Keep API working even if migration is incomplete.
        }
    }

    private function generateEmailVerificationCode()
    {
        return str_pad((string) random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    }

    private function getMailSettings()
    {
        $env = static function ($key, $default = '') {
            $value = getenv($key);
            if ($value === false || $value === null || $value === '') {
                $value = $_ENV[$key] ?? $_SERVER[$key] ?? $default;
            }
            return is_string($value) ? trim($value) : $default;
        };

        $fileConfig = [];
        $mailConfigPath = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'api' . DIRECTORY_SEPARATOR . 'mail_config.php';
        if (is_file($mailConfigPath)) {
            $loadedConfig = include $mailConfigPath;
            if (is_array($loadedConfig)) {
                $fileConfig = $loadedConfig;
            }
        }

        return [
            'host' => $fileConfig['MAIL_HOST'] ?? $env('MAIL_HOST', ''),
            'username' => $fileConfig['MAIL_USERNAME'] ?? $env('MAIL_USERNAME', ''),
            'password' => $fileConfig['MAIL_PASSWORD'] ?? $env('MAIL_PASSWORD', ''),
            'port' => (int)($fileConfig['MAIL_PORT'] ?? $env('MAIL_PORT', 465)),
            'from_address' => $fileConfig['MAIL_FROM_ADDRESS'] ?? $env('MAIL_FROM_ADDRESS', $env('MAIL_USERNAME', '')),
            'from_name' => $fileConfig['MAIL_FROM_NAME'] ?? $env('MAIL_FROM_NAME', 'Father & Sons Music School'),
            'encryption' => strtolower((string)($fileConfig['MAIL_ENCRYPTION'] ?? $env('MAIL_ENCRYPTION', 'ssl'))),
            'verify_peer' => filter_var($fileConfig['MAIL_VERIFY_PEER'] ?? $env('MAIL_VERIFY_PEER', 'true'), FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE),
        ];
    }

    private function configurePhpMailer($mailer, array $mail)
    {
        $mailer->isSMTP();
        $mailer->Host = $mail['host'];
        $mailer->SMTPAuth = true;
        $mailer->Username = $mail['username'];
        $mailer->Password = $mail['password'];
        $mailer->Port = (int)$mail['port'];
        if (($mail['encryption'] ?? '') === 'ssl') {
            $mailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_SMTPS;
        } elseif (($mail['encryption'] ?? '') === 'tls') {
            $mailer->SMTPSecure = \PHPMailer\PHPMailer\PHPMailer::ENCRYPTION_STARTTLS;
        } else {
            $mailer->SMTPSecure = '';
        }
        $mailer->SMTPOptions = [
            'ssl' => [
                'verify_peer' => $mail['verify_peer'] !== false,
                'verify_peer_name' => $mail['verify_peer'] !== false,
                'allow_self_signed' => $mail['verify_peer'] === false
            ]
        ];
        $mailer->setFrom($mail['from_address'], $mail['from_name']);
        $mailer->isHTML(true);
    }

    private function sendVerificationEmail($toEmail, $toName, $verificationCode)
    {
        $this->ensurePhpMailerLoaded();
        $mail = $this->getMailSettings();
        if (!$this->isValidEmailAddress($mail['from_address'])) {
            throw new Exception('This email is invalid. Please check the address or choose No email account.');
        }
        if (empty($mail['host'])) {
            throw new Exception('Mail service is not configured.');
        }

        $mailer = new \PHPMailer\PHPMailer\PHPMailer(true);
        $this->configurePhpMailer($mailer, $mail);
        $mailer->addAddress($toEmail, $toName ?: $toEmail);

        $safeName = htmlspecialchars($toName ?: 'User', ENT_QUOTES, 'UTF-8');
        $safeCode = htmlspecialchars((string)$verificationCode, ENT_QUOTES, 'UTF-8');
        $year = date('Y');

        $mailer->Subject = 'Your Father & Sons Music verification code';
        $mailer->Body = '
            <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #111827;">
                <h2 style="margin: 0 0 12px;">Verify your email address</h2>
                <p>Hello ' . $safeName . ',</p>
                <p>Your verification code is:</p>
                <p style="font-size: 24px; font-weight: 700; margin: 16px 0; color: #b8860b;">' . $safeCode . '</p>
                <p>This code expires in 15 minutes.</p>
                <p>Please enter it to activate your account.</p>
                <p style="margin-top: 24px; color: #6b7280; font-size: 12px;">&copy; ' . $year . ' Father &amp; Sons Music School</p>
            </div>
        ';
        $mailer->AltBody = "Your verification code is {$verificationCode}. It expires in 15 minutes.";
        $mailer->send();
        return true;
    }

    private function issueEmailVerificationCode($userId, $toEmail, $toName)
    {
        $this->ensureUserVerificationColumns();
        $verificationCode = $this->generateEmailVerificationCode();
        $verificationHash = password_hash($verificationCode, PASSWORD_DEFAULT);
        $expiresAt = date('Y-m-d H:i:s', time() + (15 * 60));

        $stmt = $this->conn->prepare("
            UPDATE tbl_users
            SET email_verification_code_hash = ?,
                email_verification_code_expires_at = ?,
                email_verification_sent_at = NOW(),
                email_verified_at = NULL
            WHERE user_id = ?
        ");
        $stmt->execute([
            $verificationHash,
            $expiresAt,
            (int)$userId
        ]);

        $emailSent = false;
        $mailError = null;
        try {
            $emailSent = $this->sendVerificationEmail($toEmail, $toName, $verificationCode);
        } catch (Exception $e) {
            $mailError = $e->getMessage();
            error_log('issueEmailVerificationCode mail error: ' . $mailError);
        }

        return [
            'verification_code' => $verificationCode,
            'email_sent' => (bool)$emailSent,
            'mail_configured' => true,
            'mail_error' => $mailError ?: $this->lastMailError
        ];
    }

    public function sendJSON($data, $status = 200)
    {
        http_response_code($status);
        echo json_encode($data);
        exit;
    }

    private function validateScheduleBranchAccess($enrollmentBranchId, $scopeBranchId, $roleName = '')
    {
        $normalizedRole = strtolower(trim((string)$roleName));
        $branchScopedRoles = ['staff', 'desk', 'front desk', 'manager', 'branch manager'];
        if (!in_array($normalizedRole, $branchScopedRoles, true)) {
            return;
        }

        if ($scopeBranchId < 1) {
            $this->sendJSON(['error' => 'Assigned branch is required for desk or manager schedule editing'], 403);
        }

        if ((int)$enrollmentBranchId !== (int)$scopeBranchId) {
            $this->sendJSON(['error' => 'Student schedule does not belong to your branch'], 403);
        }
    }

    private function isMultipartRequest()
    {
        $contentType = $_SERVER['CONTENT_TYPE'] ?? ($_SERVER['HTTP_CONTENT_TYPE'] ?? '');
        return stripos((string)$contentType, 'multipart/form-data') !== false;
    }

    private function ensureStudentRegistrationProofColumn()
    {
        if ($this->hasStudentColumn('registration_proof_path')) return;
        try {
            if ($this->hasStudentColumn('registration_fee_paid')) {
                $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN registration_proof_path VARCHAR(255) NULL AFTER registration_fee_paid");
            } else {
                $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN registration_proof_path VARCHAR(255) NULL");
            }
        } catch (PDOException $e) {
            // Keep API working even if alter fails
        }
    }

    private function ensureStudentRegistrationColumns()
    {
        // Registration fee state now comes from tbl_registration_payments.
        return;
    }

    private function ensureStudentRegistrationSourceColumn()
    {
        if ($this->hasStudentColumn('registration_source')) {
            return;
        }

        try {
            if ($this->hasStudentColumn('registration_proof_path')) {
                $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN registration_source VARCHAR(30) NULL AFTER registration_proof_path");
            } elseif ($this->hasStudentColumn('age_verification_proof_path')) {
                $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN registration_source VARCHAR(30) NULL AFTER age_verification_proof_path");
            } else {
                $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN registration_source VARCHAR(30) NULL");
            }
        } catch (PDOException $e) {
            // Keep API working even if the migration cannot be applied.
        }
    }

    private function hasStudentColumn($columnName)
    {
        try {
            $stmt = $this->conn->prepare("SHOW COLUMNS FROM tbl_students LIKE ?");
            $stmt->execute([$columnName]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function hasUserColumn($columnName)
    {
        try {
            $stmt = $this->conn->prepare("SHOW COLUMNS FROM tbl_users LIKE ?");
            $stmt->execute([$columnName]);
            return $stmt->rowCount() > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function isWalkInStudentRecord(array $student)
    {
        $source = strtolower(trim((string)($student['registration_source'] ?? '')));
        if ($source === 'walkin') {
            return true;
        }
        return preg_match('/@fas\.com$/i', trim((string)($student['email'] ?? ''))) === 1;
    }

    private function normalizeWalkInRegistrationStatus(array &$student)
    {
        if (!$this->isWalkInStudentRecord($student)) {
            return;
        }
        if ((string)($student['status'] ?? '') !== 'Active') {
            return;
        }
        $student['registration_status'] = 'Approved';
        if ((float)($student['registration_fee_paid'] ?? 0) < 1000) {
            $student['registration_fee_paid'] = 1000.00;
        }
    }

    private function storePaymentProofUpload($file, $scope = 'package_requests')
    {
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            throw new Exception('Failed to upload payment proof file.');
        }

        $maxBytes = 5 * 1024 * 1024; // 5MB
        $size = (int)($file['size'] ?? 0);
        if ($size < 1 || $size > $maxBytes) {
            throw new Exception('Payment proof file must be between 1 byte and 5MB.');
        }

        $tmpName = $file['tmp_name'] ?? '';
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            throw new Exception('Invalid uploaded file.');
        }

        $allowedExt = ['jpg', 'jpeg', 'png', 'pdf', 'webp'];
        $originalName = (string)($file['name'] ?? '');
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExt, true)) {
            throw new Exception('Payment proof must be JPG, JPEG, PNG, WEBP, or PDF.');
        }

        $baseDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'payment_proofs' . DIRECTORY_SEPARATOR . $scope;
        if (!is_dir($baseDir) && !mkdir($baseDir, 0777, true) && !is_dir($baseDir)) {
            throw new Exception('Unable to create upload directory.');
        }

        $safeName = date('YmdHis') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $targetPath = $baseDir . DIRECTORY_SEPARATOR . $safeName;
        if (!move_uploaded_file($tmpName, $targetPath)) {
            throw new Exception('Unable to save payment proof file.');
        }

        return 'uploads/payment_proofs/' . $scope . '/' . $safeName;
    }

    private function storeVerificationProofUpload($file, $scope = 'age_verification')
    {
        if (!is_array($file) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if (($file['error'] ?? UPLOAD_ERR_OK) !== UPLOAD_ERR_OK) {
            throw new Exception('Failed to upload verification proof file.');
        }

        $maxBytes = 5 * 1024 * 1024; // 5MB
        $size = (int)($file['size'] ?? 0);
        if ($size < 1 || $size > $maxBytes) {
            throw new Exception('Verification proof file must be between 1 byte and 5MB.');
        }

        $tmpName = $file['tmp_name'] ?? '';
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            throw new Exception('Invalid uploaded file.');
        }

        $allowedExt = ['jpg', 'jpeg', 'png', 'pdf', 'webp'];
        $originalName = (string)($file['name'] ?? '');
        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
        if (!in_array($ext, $allowedExt, true)) {
            throw new Exception('Verification proof must be JPG, JPEG, PNG, WEBP, or PDF.');
        }

        $baseDir = dirname(__DIR__) . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'payment_proofs' . DIRECTORY_SEPARATOR . $scope;
        if (!is_dir($baseDir) && !mkdir($baseDir, 0777, true) && !is_dir($baseDir)) {
            throw new Exception('Unable to create upload directory.');
        }

        $safeName = date('YmdHis') . '_' . bin2hex(random_bytes(8)) . '.' . $ext;
        $targetPath = $baseDir . DIRECTORY_SEPARATOR . $safeName;
        if (!move_uploaded_file($tmpName, $targetPath)) {
            throw new Exception('Unable to save verification proof file.');
        }

        return 'uploads/payment_proofs/' . $scope . '/' . $safeName;
    }

    /** Ensure session_package_id column exists on tbl_students (replaces add_session_package_to_students.php) */
    private function ensureSessionPackageColumn()
    {
        try {
            $stmt = $this->conn->query("DESCRIBE tbl_students");
            if ($stmt === false) return;
            $columns = $stmt->fetchAll(PDO::FETCH_COLUMN);
            if (in_array('session_package_id', $columns)) return;

            $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN session_package_id INT NULL");
            try {
                $this->conn->exec("
                    ALTER TABLE tbl_students
                    ADD CONSTRAINT fk_students_session_package
                    FOREIGN KEY (session_package_id) REFERENCES tbl_session_packages(package_id)
                ");
            } catch (PDOException $e) { /* tbl_session_packages may not exist yet */ }
        } catch (PDOException $e) {
            // Do not break API
        }
    }

    /** Determine whether a student is still in their initial enrollment stage. */
    private function getStudentEnrollmentContext($studentId)
    {
        $context = [
            'student_id' => (int) $studentId,
            'session_package_id' => null,
            'has_existing_enrollment' => false,
            'is_initial_enrollment' => true
        ];

        $studentId = (int) $studentId;
        if ($studentId < 1 || !$this->tableExists('tbl_students')) {
            return $context;
        }

        try {
            $hasSessionPackageCol = $this->hasStudentColumn('session_package_id');
            $sessionPackageExpr = $hasSessionPackageCol ? 's.session_package_id' : 'NULL AS session_package_id';

            $stmt = $this->conn->prepare("
                SELECT
                    {$sessionPackageExpr},
                    CASE WHEN EXISTS (
                        SELECT 1
                        FROM tbl_enrollments e
                        WHERE e.student_id = s.student_id
                          AND e.status IN ('Pending', 'Active', 'Frozen', 'Completed')
                    ) THEN 1 ELSE 0 END AS has_existing_enrollment
                FROM tbl_students s
                WHERE s.student_id = ?
                LIMIT 1
            ");
            $stmt->execute([$studentId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$row) {
                return $context;
            }

            $sessionPackageId = (int)($row['session_package_id'] ?? 0);
            $hasExistingEnrollment = (int)($row['has_existing_enrollment'] ?? 0) === 1;

            $context['session_package_id'] = $sessionPackageId > 0 ? $sessionPackageId : null;
            $context['has_existing_enrollment'] = $hasExistingEnrollment;
            // A student is considered "initial" until they have an actual enrollment history.
            // session_package_id may already be populated during registration and should not
            // move a brand-new student into the extension flow by itself.
            $context['is_initial_enrollment'] = !$hasExistingEnrollment;
        } catch (PDOException $e) {
            // Default to initial enrollment behavior on lookup failures.
        }

        return $context;
    }

    /** Keep only the 12-session package(s) for initial enrollment. */
    private function filterInitialEnrollmentPackages(array $packages)
    {
        $initialPackages = array_values(array_filter($packages, function ($package) {
            return (int)($package['sessions'] ?? 0) === 12;
        }));

        return $initialPackages;
    }

    /** Pick the package to preselect in the enrollment UI. */
    private function getDefaultEnrollmentPackageId(array $packages, $preferInitial = true)
    {
        if (!$preferInitial) {
            foreach ($packages as $package) {
                if ((int)($package['sessions'] ?? 0) > 12) {
                    return (int)($package['package_id'] ?? 0);
                }
            }
        }

        foreach ($packages as $package) {
            if ((int)($package['sessions'] ?? 0) === 12) {
                return (int)($package['package_id'] ?? 0);
            }
        }

        $firstPackage = $packages[0] ?? null;
        return $firstPackage ? (int)($firstPackage['package_id'] ?? 0) : 0;
    }

    /** Ensure tbl_student_instruments exists (created during registration) */
    private function ensureStudentInstrumentsTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_student_instruments (
                    student_instrument_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    instrument_id INT NOT NULL,
                    priority_order INT NOT NULL DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ");
            // Attempt to add indexes (safe if already exists)
            try { $this->conn->exec("CREATE INDEX idx_student_instruments_student ON tbl_student_instruments(student_id)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_instruments_instrument ON tbl_student_instruments(instrument_id)"); } catch (PDOException $e) {}
        } catch (PDOException $e) {
            // Do not break API
        }
    }

    /** Ensure tbl_student_package_requests exists (student availing flow) */
    private function ensureStudentPackageRequestsTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_student_package_requests (
                    request_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    branch_id INT NOT NULL,
                    package_id INT NOT NULL,
                    instrument_ids_json TEXT NULL,
                    selected_availability_id INT NULL,
                    preferred_date DATE NULL,
                    preferred_day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NULL,
                    preferred_start_time TIME NULL,
                    preferred_end_time TIME NULL,
                    assigned_teacher_id INT NULL,
                    payment_proof_path VARCHAR(255) NULL,
                    assigned_date DATE NULL,
                    assigned_day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NULL,
                    assigned_start_time TIME NULL,
                    assigned_end_time TIME NULL,
                    assigned_room VARCHAR(100) NULL,
                    requested_amount DECIMAL(10,2) NOT NULL DEFAULT 0,
                    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
                    admin_notes TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'preferred_day_of_week'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN preferred_day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NULL AFTER preferred_date");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'preferred_start_time'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN preferred_start_time TIME NULL AFTER preferred_day_of_week");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'preferred_end_time'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN preferred_end_time TIME NULL AFTER preferred_start_time");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'assigned_teacher_id'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN assigned_teacher_id INT NULL AFTER preferred_end_time");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'payment_proof_path'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN payment_proof_path VARCHAR(255) NULL AFTER assigned_teacher_id");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'payment_type'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN payment_type ENUM('Full Payment','Partial Payment','Installment') NOT NULL DEFAULT 'Partial Payment' AFTER requested_amount");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'assigned_date'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN assigned_date DATE NULL AFTER assigned_teacher_id");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'assigned_day_of_week'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN assigned_day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NULL AFTER assigned_date");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'assigned_start_time'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN assigned_start_time TIME NULL AFTER assigned_day_of_week");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'assigned_end_time'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN assigned_end_time TIME NULL AFTER assigned_start_time");
                }
            } catch (PDOException $e) {}
            try {
                $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_student_package_requests LIKE 'assigned_room'");
                if ($stmt && $stmt->rowCount() === 0) {
                    $this->conn->exec("ALTER TABLE tbl_student_package_requests ADD COLUMN assigned_room VARCHAR(100) NULL AFTER assigned_end_time");
                }
            } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_package_requests_student ON tbl_student_package_requests(student_id)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_package_requests_status ON tbl_student_package_requests(status)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_package_requests_created ON tbl_student_package_requests(created_at)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_package_requests_teacher ON tbl_student_package_requests(assigned_teacher_id)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_package_requests_assigned_date ON tbl_student_package_requests(assigned_date)"); } catch (PDOException $e) {}
        } catch (PDOException $e) {
            // Do not break API
        }
    }

    /** Ensure tbl_student_session_extension_requests exists (one-hour add-on session flow) */
    private function ensureStudentSessionExtensionRequestsTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_student_session_extension_requests (
                    request_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    branch_id INT NOT NULL,
                    enrollment_id INT NULL,
                    requested_sessions INT NOT NULL DEFAULT 1,
                    requested_amount DECIMAL(10,2) NOT NULL DEFAULT 650.00,
                    preferred_day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NULL,
                    preferred_start_time TIME NULL,
                    preferred_end_time TIME NULL,
                    payment_method ENUM('Cash','GCash','Bank Transfer','Other') NOT NULL DEFAULT 'Cash',
                    payment_proof_path VARCHAR(255) NULL,
                    notes TEXT NULL,
                    status ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
                    admin_notes TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            if (!$this->tableHasColumn('tbl_student_session_extension_requests', 'enrollment_id')) {
                $this->conn->exec("ALTER TABLE tbl_student_session_extension_requests ADD COLUMN enrollment_id INT NULL AFTER branch_id");
            }
            try { $this->conn->exec("CREATE INDEX idx_student_session_extension_requests_student ON tbl_student_session_extension_requests(student_id)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_session_extension_requests_status ON tbl_student_session_extension_requests(status)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_session_extension_requests_created ON tbl_student_session_extension_requests(created_at)"); } catch (PDOException $e) {}
        } catch (PDOException $e) {
            // Do not break API
        }
    }

    /** Formal academic assessments and awards, separate from lesson purchases. */
    private function ensurePromotionalAssessmentTables()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_promotional_exams (
                    exam_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    instrument_id INT NULL,
                    learning_level_id INT NULL,
                    teacher_id INT NULL,
                    assessed_level VARCHAR(100) NOT NULL,
                    exam_date DATE NULL,
                    grade_rating VARCHAR(100) NULL,
                    result ENUM('Pending','Passed','Retake') NOT NULL DEFAULT 'Pending',
                    examiner_notes TEXT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_student_certificates (
                    certificate_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    promotional_exam_id INT NULL,
                    learning_level_id INT NULL,
                    instrument_id INT NULL,
                    achieved_level VARCHAR(100) NOT NULL,
                    certificate_number VARCHAR(100) NULL,
                    issued_at DATE NOT NULL,
                    issued_by INT NULL,
                    status ENUM('Issued','Revoked') NOT NULL DEFAULT 'Issued',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ");
            $examColumns = [
                'learning_level_id' => "ALTER TABLE tbl_promotional_exams ADD COLUMN learning_level_id INT NULL AFTER instrument_id",
                'teacher_id' => "ALTER TABLE tbl_promotional_exams ADD COLUMN teacher_id INT NULL AFTER learning_level_id",
                'grade_rating' => "ALTER TABLE tbl_promotional_exams ADD COLUMN grade_rating VARCHAR(100) NULL AFTER exam_date"
            ];
            foreach ($examColumns as $column => $sql) {
                if (!$this->tableHasColumn('tbl_promotional_exams', $column)) $this->conn->exec($sql);
            }
            try { $this->conn->exec("ALTER TABLE tbl_promotional_exams MODIFY result ENUM('Pending','Passed','Failed','Retake') NOT NULL DEFAULT 'Pending'"); } catch (PDOException $e) {}
            try { $this->conn->exec("UPDATE tbl_promotional_exams SET result = 'Retake' WHERE result = 'Failed'"); } catch (PDOException $e) {}
            try { $this->conn->exec("ALTER TABLE tbl_promotional_exams MODIFY result ENUM('Pending','Passed','Retake') NOT NULL DEFAULT 'Pending'"); } catch (PDOException $e) {}
            if (!$this->tableHasColumn('tbl_student_certificates', 'learning_level_id')) {
                $this->conn->exec("ALTER TABLE tbl_student_certificates ADD COLUMN learning_level_id INT NULL AFTER promotional_exam_id");
            }
            try { $this->conn->exec("CREATE INDEX idx_promotional_exams_student ON tbl_promotional_exams(student_id)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_student_certificates_student ON tbl_student_certificates(student_id)"); } catch (PDOException $e) {}
        } catch (PDOException $e) {
            // Keep the portal available if a restricted database user cannot migrate.
        }
    }

    private function ensureLearningProgressTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_student_learning_levels (
                    learning_level_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    instrument_id INT NOT NULL,
                    teacher_id INT NULL,
                    level_name VARCHAR(100) NOT NULL,
                    book_material VARCHAR(255) NULL,
                    current_topic VARCHAR(255) NULL,
                    instructor_notes TEXT NULL,
                    skills_developing TEXT NULL,
                    areas_for_improvement TEXT NULL,
                    assessment_readiness ENUM('Not Ready','Developing','Improving','Ready for Assessment') NOT NULL DEFAULT 'Not Ready',
                    status ENUM('In Progress','Achieved') NOT NULL DEFAULT 'In Progress',
                    started_at DATE NOT NULL,
                    achieved_at DATE NULL,
                    achieved_exam_id INT NULL,
                    previous_learning_level_id INT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            try { $this->conn->exec("CREATE INDEX idx_learning_levels_student_instrument ON tbl_student_learning_levels(student_id, instrument_id, status)"); } catch (PDOException $e) {}
        } catch (PDOException $e) {
            // Keep portal reads available if schema migration is restricted.
        }
    }

    private function getLatestStudentSessionExtensionRequest(int $studentId): ?array
    {
        if ($studentId < 1 || !$this->tableExists('tbl_student_session_extension_requests')) {
            return null;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT
                    request_id,
                    student_id,
                    branch_id,
                    enrollment_id,
                    requested_sessions,
                    requested_amount,
                    preferred_day_of_week,
                    preferred_start_time,
                    preferred_end_time,
                    payment_method,
                    payment_proof_path,
                    notes,
                    status,
                    admin_notes,
                    created_at,
                    updated_at
                FROM tbl_student_session_extension_requests
                WHERE student_id = ?
                ORDER BY request_id DESC
                LIMIT 1
            ");
            $stmt->execute([$studentId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            return $row ?: null;
        } catch (PDOException $e) {
            return null;
        }
    }

    /**
     * Compatibility guard for DBs with legacy triggers on tbl_enrollments.
     * Those triggers reference split enrollment tables that may be missing.
     */
    private function ensureLegacyEnrollmentTables()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_enrollment_core (
                    enrollment_id INT NOT NULL PRIMARY KEY,
                    student_id INT NOT NULL,
                    package_id INT NOT NULL,
                    instrument_id INT NOT NULL,
                    teacher_id INT NOT NULL,
                    enrollment_date DATE DEFAULT NULL,
                    start_date DATE DEFAULT NULL,
                    end_date DATE DEFAULT NULL,
                    status ENUM('Pending Payment','Ongoing','Completed','Cancelled') NOT NULL DEFAULT 'Pending Payment',
                    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                )
            ");
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_enrollment_registration (
                    enrollment_id INT NOT NULL PRIMARY KEY,
                    registration_fee_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    registration_fee_paid DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    registration_status ENUM('Unpaid','Partial','Paid') NOT NULL DEFAULT 'Unpaid'
                )
            ");
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_enrollment_financials (
                    enrollment_id INT NOT NULL PRIMARY KEY,
                    total_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    paid_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    payment_deadline_session INT NOT NULL DEFAULT 7
                )
            ");
        } catch (PDOException $e) {
            // Do not break API. Trigger references can still fail if DB user lacks DDL permission.
        }
    }

    private function ensureEnrollmentPaymentTypeColumn()
    {
        try {
            $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_enrollments LIKE 'payment_type'");
            if ($stmt && $stmt->rowCount() > 0) {
                return;
            }
            $afterClause = $this->tableHasColumn('tbl_enrollments', 'payment_deadline_session')
                ? ' AFTER payment_deadline_session'
                : '';
            $this->conn->exec("
                ALTER TABLE tbl_enrollments
                ADD COLUMN payment_type ENUM('Full Payment','Partial Payment','Installment') NOT NULL DEFAULT 'Partial Payment'
                {$afterClause}
            ");
        } catch (PDOException $e) {
            // Do not break API.
        }
    }

    private function ensurePaymentsPaymentTypeColumn()
    {
        if (!$this->tableExists('tbl_payments')) {
            return;
        }
        try {
            $stmt = $this->conn->query("SHOW COLUMNS FROM tbl_payments LIKE 'payment_type'");
            if ($stmt && $stmt->rowCount() > 0) {
                return;
            }
            $afterClause = $this->tableHasColumn('tbl_payments', 'payment_method')
                ? ' AFTER payment_method'
                : ($this->tableHasColumn('tbl_payments', 'amount') ? ' AFTER amount' : '');
            $this->conn->exec("
                ALTER TABLE tbl_payments
                ADD COLUMN payment_type ENUM('Full Payment','Partial Payment','Installment') NOT NULL DEFAULT 'Partial Payment'
                {$afterClause}
            ");
        } catch (PDOException $e) {
            // Do not break API.
        }
    }

    private function normalizeEnrollmentPaymentType($raw)
    {
        $v = strtolower(trim((string)$raw));
        if ($v === '') return '';
        if (in_array($v, ['downpayment', 'partial', 'partialpayment', 'partial payment'], true)) {
            return 'Partial Payment';
        }
        if (in_array($v, ['full', 'fullpayment', 'full payment'], true)) {
            return 'Full Payment';
        }
        if (in_array($v, ['installment'], true)) {
            return 'Installment';
        }
        return '';
    }

    private function normalizeEnrollmentPaymentMethod($raw)
    {
        $v = strtolower(trim((string)$raw));
        if ($v === '') return '';
        if (in_array($v, ['cash'], true)) return 'Cash';
        if (in_array($v, ['gcash', 'g-cash'], true)) return 'GCash';
        if (in_array($v, ['bank transfer', 'banktransfer', 'bank'], true)) return 'Bank Transfer';
        if (in_array($v, ['other'], true)) return 'Other';
        return '';
    }

    private function computeEnrollmentPayableNow($basePrice, $sessions, $paymentType)
    {
        $price = (float) $basePrice;
        $sessionCount = max(1, (int) $sessions);
        $normalizedType = $this->normalizeEnrollmentPaymentType($paymentType);
        if ($price <= 0) {
            return 0.0;
        }

        $ratio = $sessionCount === 12 ? (3000 / 7450) : ($sessionCount === 20 ? (5000 / 11800) : 0.42);
        $partialAmount = round($price * $ratio);

        if ($normalizedType === 'Full Payment') {
            return round($price, 2);
        }
        if ($normalizedType === 'Installment') {
            return (float) max(1, round($price / $sessionCount));
        }

        return (float) max(1, $partialAmount);
    }

    /**
     * Persist the assigned first-session schedule for student visibility.
     */
    private function upsertFirstSessionSchedule($enrollmentId, $teacherId, $instrumentId, $sessionDate, $startTime, $endTime, $assignedRoom, $branchId)
    {
        if (!$this->tableExists('tbl_sessions')) {
            return;
        }

        $roomId = null;
        $assignedRoom = trim((string)$assignedRoom);
        if ($assignedRoom !== '' && $this->tableExists('tbl_rooms')) {
            try {
                $stmtRoom = $this->conn->prepare("
                    SELECT room_id
                    FROM tbl_rooms
                    WHERE branch_id = ?
                      AND room_name = ?
                    LIMIT 1
                ");
                $stmtRoom->execute([(int)$branchId, $assignedRoom]);
                $roomId = $stmtRoom->fetchColumn();
                if ($roomId !== false) {
                    $roomId = (int)$roomId;
                } else {
                    $roomId = null;
                }
            } catch (PDOException $e) {
                $roomId = null;
            }
        }

        $stmtExisting = $this->conn->prepare("
            SELECT session_id
            FROM tbl_sessions
            WHERE enrollment_id = ?
              AND session_number = 1
              AND status <> 'cancelled_by_teacher'
            ORDER BY session_id DESC
            LIMIT 1
        ");
        $stmtExisting->execute([(int)$enrollmentId]);
        $existingSessionId = (int)$stmtExisting->fetchColumn();

        if ($existingSessionId > 0) {
            if ($assignedRoom !== '') {
                $stmtUpdate = $this->conn->prepare("
                    UPDATE tbl_sessions
                    SET teacher_id = ?,
                        instrument_id = ?,
                        session_date = ?,
                        start_time = ?,
                        end_time = ?,
                        room_id = ?,
                        notes = ?,
                        status = 'Scheduled'
                    WHERE session_id = ?
                ");
                $stmtUpdate->execute([
                    (int)$teacherId,
                    (int)$instrumentId,
                    $sessionDate,
                    $startTime,
                    $endTime,
                    $roomId,
                    $assignedRoom,
                    $existingSessionId
                ]);
            } else {
                $stmtUpdate = $this->conn->prepare("
                    UPDATE tbl_sessions
                    SET teacher_id = ?,
                        instrument_id = ?,
                        session_date = ?,
                        start_time = ?,
                        end_time = ?,
                        room_id = ?,
                        status = 'Scheduled'
                    WHERE session_id = ?
                ");
                $stmtUpdate->execute([
                    (int)$teacherId,
                    (int)$instrumentId,
                    $sessionDate,
                    $startTime,
                    $endTime,
                    $roomId,
                    $existingSessionId
                ]);
            }
            return;
        }

        $stmtInsert = $this->conn->prepare("
            INSERT INTO tbl_sessions (
                enrollment_id,
                teacher_id,
                session_number,
                session_date,
                start_time,
                end_time,
                session_type,
                instrument_id,
                room_id,
                status,
                notes
            ) VALUES (?, ?, 1, ?, ?, ?, 'Regular', ?, ?, 'Scheduled', ?)
        ");
        $stmtInsert->execute([
            (int)$enrollmentId,
            (int)$teacherId,
            $sessionDate,
            $startTime,
            $endTime,
            (int)$instrumentId,
            $roomId,
            ($assignedRoom !== '' ? $assignedRoom : null)
        ]);
    }

    private function ensureEnrollmentFixedScheduleColumns()
    {
        if (!$this->tableExists('tbl_enrollments')) {
            return;
        }

        $columnSql = [
            'fixed_day_of_week' => "ALTER TABLE tbl_enrollments ADD COLUMN fixed_day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NULL AFTER assigned_teacher_id",
            'fixed_start_time' => "ALTER TABLE tbl_enrollments ADD COLUMN fixed_start_time TIME NULL AFTER fixed_day_of_week",
            'fixed_end_time' => "ALTER TABLE tbl_enrollments ADD COLUMN fixed_end_time TIME NULL AFTER fixed_start_time",
            'fixed_room_id' => "ALTER TABLE tbl_enrollments ADD COLUMN fixed_room_id INT NULL AFTER fixed_end_time",
            'schedule_status' => "ALTER TABLE tbl_enrollments ADD COLUMN schedule_status ENUM('Active','Frozen','Ended') NOT NULL DEFAULT 'Active' AFTER status",
            'allowed_absences' => "ALTER TABLE tbl_enrollments ADD COLUMN allowed_absences INT NOT NULL DEFAULT 0 AFTER total_sessions",
            'used_absences' => "ALTER TABLE tbl_enrollments ADD COLUMN used_absences INT NOT NULL DEFAULT 0 AFTER allowed_absences",
            'consecutive_absences' => "ALTER TABLE tbl_enrollments ADD COLUMN consecutive_absences INT NOT NULL DEFAULT 0 AFTER used_absences",
            'auto_generated_until' => "ALTER TABLE tbl_enrollments ADD COLUMN auto_generated_until DATE NULL AFTER consecutive_absences",
            'fixed_schedule_locked' => "ALTER TABLE tbl_enrollments ADD COLUMN fixed_schedule_locked TINYINT(1) NOT NULL DEFAULT 1 AFTER auto_generated_until",
            'current_operation_id' => "ALTER TABLE tbl_enrollments ADD COLUMN current_operation_id INT NULL AFTER fixed_schedule_locked"
        ];

        foreach ($columnSql as $column => $sql) {
            try {
                if (!$this->tableHasColumn('tbl_enrollments', $column)) {
                    $this->conn->exec($sql);
                }
            } catch (PDOException $e) {
                // Keep API working even if the migration cannot be applied.
            }
        }
    }

    private function ensureEnrollmentScheduleSlotsTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_enrollment_schedule_slots (
                    slot_id INT AUTO_INCREMENT PRIMARY KEY,
                    enrollment_id INT NOT NULL,
                    teacher_id INT NOT NULL,
                    instrument_id INT NULL,
                    day_of_week ENUM('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday') NOT NULL,
                    start_time TIME NOT NULL,
                    end_time TIME NOT NULL,
                    room_id INT NULL,
                    room_name VARCHAR(100) NULL,
                    sort_order INT NOT NULL DEFAULT 1,
                    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");
            if (!$this->tableHasColumn('tbl_enrollment_schedule_slots', 'instrument_id')) {
                $this->conn->exec("ALTER TABLE tbl_enrollment_schedule_slots ADD COLUMN instrument_id INT NULL AFTER teacher_id");
            }
            try { $this->conn->exec("CREATE INDEX idx_enrollment_schedule_slots_enrollment ON tbl_enrollment_schedule_slots(enrollment_id, status, sort_order)"); } catch (PDOException $e) {}
            try { $this->conn->exec("CREATE INDEX idx_enrollment_schedule_slots_teacher ON tbl_enrollment_schedule_slots(teacher_id, day_of_week, start_time, end_time)"); } catch (PDOException $e) {}
        } catch (PDOException $e) {
            // Ignore migration failures to keep existing API behavior available.
        }
    }

    private function ensureSessionSchedulingColumns()
    {
        if (!$this->tableExists('tbl_sessions')) {
            return;
        }

        $columnSql = [
            'operation_id' => "ALTER TABLE tbl_sessions ADD COLUMN operation_id INT NULL AFTER room_id",
            'attendance_status' => "ALTER TABLE tbl_sessions ADD COLUMN attendance_status ENUM('Pending','Present','Absent','Late','Excused','CI','Teacher Absent') NOT NULL DEFAULT 'Pending' AFTER status",
            'instructor_completed_at' => "ALTER TABLE tbl_sessions ADD COLUMN instructor_completed_at DATETIME NULL AFTER attendance_status",
            'absence_notice' => "ALTER TABLE tbl_sessions ADD COLUMN absence_notice ENUM('None','Prior','NoNotice','Teacher') NOT NULL DEFAULT 'None' AFTER attendance_status",
            'counted_in' => "ALTER TABLE tbl_sessions ADD COLUMN counted_in TINYINT(1) NOT NULL DEFAULT 0 AFTER absence_notice",
            'makeup_eligible' => "ALTER TABLE tbl_sessions ADD COLUMN makeup_eligible TINYINT(1) NOT NULL DEFAULT 0 AFTER counted_in",
            'makeup_required' => "ALTER TABLE tbl_sessions ADD COLUMN makeup_required TINYINT(1) NOT NULL DEFAULT 0 AFTER makeup_eligible"
        ];

        foreach ($columnSql as $column => $sql) {
            try {
                if (!$this->tableHasColumn('tbl_sessions', $column)) {
                    $this->conn->exec($sql);
                }
            } catch (PDOException $e) {
                // Ignore column migration issues in older environments.
            }
        }
    }

    private function ensureStudentProgressTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_student_progress (
                    progress_id INT AUTO_INCREMENT PRIMARY KEY,
                    student_id INT NOT NULL,
                    session_id INT NOT NULL,
                    instrument_id INT NOT NULL,
                    skill_level VARCHAR(50) NULL,
                    remarks TEXT NULL,
                    assessment_date DATE NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ");
        } catch (PDOException $e) {
            return;
        }

        $columnSql = [
            'performance_score' => "ALTER TABLE tbl_student_progress ADD COLUMN performance_score TINYINT UNSIGNED NULL AFTER skill_level",
            'technique_score' => "ALTER TABLE tbl_student_progress ADD COLUMN technique_score TINYINT UNSIGNED NULL AFTER performance_score",
            'rhythm_score' => "ALTER TABLE tbl_student_progress ADD COLUMN rhythm_score TINYINT UNSIGNED NULL AFTER technique_score",
            'focus_score' => "ALTER TABLE tbl_student_progress ADD COLUMN focus_score TINYINT UNSIGNED NULL AFTER rhythm_score",
            'assignment_score' => "ALTER TABLE tbl_student_progress ADD COLUMN assignment_score TINYINT UNSIGNED NULL AFTER focus_score",
            'criteria_scores' => "ALTER TABLE tbl_student_progress ADD COLUMN criteria_scores TEXT NULL AFTER assignment_score",
            'updated_at' => "ALTER TABLE tbl_student_progress ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER created_at"
        ];

        foreach ($columnSql as $column => $sql) {
            try {
                if (!$this->tableHasColumn('tbl_student_progress', $column)) {
                    $this->conn->exec($sql);
                }
            } catch (PDOException $e) {
                // Keep API available even if schema sync fails.
            }
        }

        try { $this->conn->exec("CREATE INDEX idx_student_progress_session ON tbl_student_progress(session_id)"); } catch (PDOException $e) {}
        try { $this->conn->exec("CREATE INDEX idx_student_progress_student ON tbl_student_progress(student_id)"); } catch (PDOException $e) {}
    }

    private function getStudentEnrollmentSessionGrades($studentId, $enrollmentId)
    {
        if ($studentId < 1 || $enrollmentId < 1 || !$this->tableExists('tbl_sessions')) {
            return [];
        }

        try {
            $packageJoin = $this->tableExists('tbl_session_packages')
                ? "LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id"
                : "";
            $packageNameExpr = $this->tableExists('tbl_session_packages')
                ? "COALESCE(sp.package_name, CONCAT('Package #', e.package_id))"
                : "CONCAT('Package #', e.package_id)";
            $roomJoin = $this->tableExists('tbl_rooms')
                ? "LEFT JOIN tbl_rooms rm ON rm.room_id = ts.room_id"
                : "";
            $roomExpr = $this->tableExists('tbl_rooms')
                ? "COALESCE(NULLIF(TRIM(rm.room_name), ''), NULLIF(TRIM(ts.notes), ''))"
                : "NULLIF(TRIM(ts.notes), '')";

            $stmt = $this->conn->prepare("
                SELECT
                    ts.session_id,
                    ts.enrollment_id,
                    ts.session_number,
                    ts.session_date,
                    ts.start_time,
                    ts.end_time,
                    ts.status,
                    ts.attendance_status,
                    ts.counted_in,
                    ts.instructor_completed_at,
                    ts.absence_notice,
                    ts.attendance_notes,
                    ts.notes,
                    ts.notes AS lesson_focus,
                    {$roomExpr} AS room_name,
                    {$packageNameExpr} AS package_name,
                    COALESCE(NULLIF(TRIM(inst_type.type_name), ''), inst.instrument_name, CONCAT('Instrument #', COALESCE(ts.instrument_id, e.instrument_id))) AS instrument_name,
                    CONCAT_WS(' ', t.first_name, t.last_name) AS teacher_name,
                    prog.progress_id,
                    prog.skill_level,
                    prog.performance_score,
                    prog.technique_score,
                    prog.rhythm_score,
                    prog.focus_score,
                    prog.assignment_score,
                    prog.criteria_scores,
                    prog.remarks,
                    COALESCE(
                        NULLIF(TRIM(prog.remarks), ''),
                        NULLIF(TRIM(ts.attendance_notes), ''),
                        NULLIF(TRIM(ts.notes), '')
                    ) AS teacher_remarks,
                    prog.assessment_date,
                    prog.updated_at
                FROM tbl_sessions ts
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ts.enrollment_id
                LEFT JOIN tbl_instruments inst ON inst.instrument_id = COALESCE(ts.instrument_id, e.instrument_id)
                LEFT JOIN tbl_instrument_types inst_type ON inst_type.type_id = inst.type_id
                LEFT JOIN tbl_teachers t ON t.teacher_id = ts.teacher_id
                {$packageJoin}
                {$roomJoin}
                LEFT JOIN tbl_student_progress prog
                    ON prog.session_id = ts.session_id
                   AND prog.student_id = e.student_id
                WHERE e.student_id = ?
                  AND ts.enrollment_id = ?
                ORDER BY ts.session_date DESC, ts.start_time DESC, ts.session_id DESC
            ");
            $stmt->execute([(int)$studentId, (int)$enrollmentId]);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            foreach ($rows as &$row) {
                $criteriaScores = json_decode((string)($row['criteria_scores'] ?? ''), true);
                if (!is_array($criteriaScores)) $criteriaScores = [];
                $scores = array_values(array_filter(array_map(function ($item) {
                    $score = (int)($item['score'] ?? 0);
                    return ($score >= 1 && $score <= 5) ? $score : null;
                }, $criteriaScores), function ($value) { return $value !== null; }));
                if (!$scores) $scores = [
                    $row['performance_score'] !== null ? (int)$row['performance_score'] : null,
                    $row['technique_score'] !== null ? (int)$row['technique_score'] : null,
                    $row['rhythm_score'] !== null ? (int)$row['rhythm_score'] : null,
                    $row['focus_score'] !== null ? (int)$row['focus_score'] : null,
                    $row['assignment_score'] !== null ? (int)$row['assignment_score'] : null
                ];
                $validScores = array_values(array_filter($scores, function ($value) {
                    return $value !== null;
                }));
                $row['average_score'] = !empty($validScores)
                    ? (int)round(array_sum($validScores) / count($validScores))
                    : null;
                $row['criteria_scores'] = $criteriaScores;
            }
            unset($row);

            return $rows;
        } catch (PDOException $e) {
            return [];
        }
    }

    private function ensureScheduleOperationLookupTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_schedule_operation_lookup (
                    operation_id INT AUTO_INCREMENT PRIMARY KEY,
                    operation_code VARCHAR(50) NOT NULL UNIQUE,
                    operation_name VARCHAR(100) NOT NULL,
                    applies_to ENUM('Enrollment','Session','Attendance','Request') NOT NULL,
                    counts_as_absence TINYINT(1) NOT NULL DEFAULT 0,
                    counts_as_consumed_session TINYINT(1) NOT NULL DEFAULT 0,
                    allows_makeup TINYINT(1) NOT NULL DEFAULT 0,
                    requires_admin_approval TINYINT(1) NOT NULL DEFAULT 0,
                    freezes_schedule TINYINT(1) NOT NULL DEFAULT 0,
                    requires_holding_fee TINYINT(1) NOT NULL DEFAULT 0,
                    description VARCHAR(255) NULL,
                    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
                )
            ");

            $rows = [
                ['REGULAR_SESSION', 'Regular Fixed Session', 'Session', 0, 0, 0, 0, 0, 0, 'Normal weekly generated session'],
                ['STUDENT_ABSENT_NOTICE', 'Student Absent With Notice', 'Attendance', 1, 0, 1, 0, 0, 0, 'Absent within allowed policy, makeup may be allowed'],
                ['STUDENT_ABSENT_NO_NOTICE', 'Student Absent No Notice / CI', 'Attendance', 1, 1, 0, 0, 0, 0, 'Session is counted-in and consumed'],
                ['TEACHER_ABSENT', 'Teacher Absent', 'Attendance', 0, 0, 1, 0, 0, 0, 'Does not count against student, makeup required'],
                ['MAKEUP_SESSION', 'Makeup Session', 'Session', 0, 0, 0, 0, 0, 0, 'Extra scheduled replacement lesson'],
                ['SCHEDULE_FREEZE', 'Schedule Freeze', 'Enrollment', 0, 0, 0, 0, 1, 1, 'Applied after consecutive absences']
            ];

            $stmt = $this->conn->prepare("
                INSERT INTO tbl_schedule_operation_lookup (
                    operation_code, operation_name, applies_to, counts_as_absence,
                    counts_as_consumed_session, allows_makeup, requires_admin_approval,
                    freezes_schedule, requires_holding_fee, description, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')
                ON DUPLICATE KEY UPDATE
                    operation_name = VALUES(operation_name),
                    applies_to = VALUES(applies_to),
                    counts_as_absence = VALUES(counts_as_absence),
                    counts_as_consumed_session = VALUES(counts_as_consumed_session),
                    allows_makeup = VALUES(allows_makeup),
                    requires_admin_approval = VALUES(requires_admin_approval),
                    freezes_schedule = VALUES(freezes_schedule),
                    requires_holding_fee = VALUES(requires_holding_fee),
                    description = VALUES(description),
                    status = 'Active'
            ");
            foreach ($rows as $row) {
                $stmt->execute($row);
            }
        } catch (PDOException $e) {
            // Do not break the API when the lookup migration fails.
        }
    }

    private function teacherSpecializationMatchesInstrument($specializationRaw, $keywordList)
    {
        $specNames = array_values(array_filter(array_map(function ($part) {
            return strtolower(trim((string) $part));
        }, explode(',', (string) $specializationRaw)), function ($part) {
            return $part !== '';
        }));

        foreach ($specNames as $specName) {
            foreach ((array) $keywordList as $kw) {
                $keyword = strtolower(trim((string) $kw));
                if ($keyword === '' || $specName === '') {
                    continue;
                }
                // Instrument types must match exactly. A partial match would
                // incorrectly treat "Guitar" as eligible for "Bass Guitar".
                if ($specName === $keyword) {
                    return true;
                }
            }
        }

        return false;
    }

    private function buildTeacherCandidates($branchId, $instrumentIds = [], $instrumentKeywords = [])
    {
        $candidates = [];
        if (!$this->tableExists('tbl_teachers')) {
            return $candidates;
        }

        try {
            ensure_specialization_instrument_link($this->conn);

            $instrumentIds = array_values(array_filter(array_map('intval', (array) $instrumentIds), function ($v) {
                return $v > 0;
            }));
            $instrumentTypeIds = [];
            if (!empty($instrumentIds)) {
                $placeholders = implode(',', array_fill(0, count($instrumentIds), '?'));
                $stmtTypes = $this->conn->prepare("SELECT DISTINCT type_id FROM tbl_instruments WHERE instrument_id IN ({$placeholders})");
                $stmtTypes->execute($instrumentIds);
                $instrumentTypeIds = array_values(array_unique(array_filter(array_map('intval', $stmtTypes->fetchAll(PDO::FETCH_COLUMN) ?: []), function ($v) {
                    return $v > 0;
                })));
            }

            $keywordList = [];
            foreach ((array) $instrumentKeywords as $kw) {
                $w = strtolower(trim((string) $kw));
                if ($w !== '') {
                    $keywordList[] = $w;
                }
            }
            $keywordList = array_values(array_unique($keywordList));

            $teacherSql = "
                SELECT
                    t.teacher_id,
                    t.first_name,
                    t.last_name,
                    COALESCE(
                        GROUP_CONCAT(DISTINCT s.specialization_name ORDER BY s.specialization_name SEPARATOR ', '),
                        ''
                    ) AS specialization,
                    COALESCE(
                        GROUP_CONCAT(DISTINCT s.type_id ORDER BY s.type_id SEPARATOR ','),
                        ''
                    ) AS specialization_type_ids
                FROM tbl_teachers t
                LEFT JOIN tbl_teacher_specializations ts ON ts.teacher_id = t.teacher_id
                LEFT JOIN tbl_specialization s ON s.specialization_id = ts.specialization_id
                WHERE t.branch_id = ?
                  AND t.status = 'Active'
                GROUP BY t.teacher_id
                ORDER BY t.first_name ASC, t.last_name ASC
            ";
            $stmtTeachers = $this->conn->prepare($teacherSql);
            $stmtTeachers->execute([(int) $branchId]);
            $teachers = $stmtTeachers->fetchAll(PDO::FETCH_ASSOC);

            foreach ($teachers as $t) {
                $teacherId = (int) ($t['teacher_id'] ?? 0);
                if ($teacherId < 1) {
                    continue;
                }
                $specializationRaw = trim((string) ($t['specialization'] ?? ''));
                $isAllAround = $this->isGeneralTeacherSpecialization($specializationRaw);

                $teacherTypeIds = array_values(array_unique(array_filter(array_map('intval', explode(',', (string) ($t['specialization_type_ids'] ?? ''))), function ($v) {
                    return $v > 0;
                })));
                $matchedByType = !empty($instrumentTypeIds) && !empty(array_intersect($teacherTypeIds, $instrumentTypeIds));
                $matchedByKeyword = $this->teacherSpecializationMatchesInstrument($specializationRaw, $keywordList);

                $eligible = empty($instrumentIds) || $matchedByType || $matchedByKeyword || $isAllAround;
                if (!$eligible) {
                    continue;
                }

                $candidates[] = [
                    'teacher_id' => $teacherId,
                    'teacher_name' => trim(($t['first_name'] ?? '') . ' ' . ($t['last_name'] ?? '')),
                    'specialization' => $specializationRaw !== '' ? $specializationRaw : 'General',
                    'specialization_type_ids' => $teacherTypeIds
                ];
            }

        } catch (PDOException $e) {
            return [];
        }

        return $candidates;
    }

    private function buildTeacherCandidatesForEnrollment($branchId, $instrumentIds = [], $instrumentKeywords = [], $currentTeacherId = 0, $currentTeacherName = '', $currentTeacherSpecialization = '')
    {
        $candidates = $this->buildTeacherCandidates($branchId, $instrumentIds, $instrumentKeywords);
        $currentTeacherId = (int)$currentTeacherId;
        $currentTeacherName = trim((string)$currentTeacherName);
        $currentTeacherSpecialization = trim((string)$currentTeacherSpecialization);

        if ($currentTeacherId > 0) {
            $found = false;
            foreach ($candidates as $candidate) {
                if ((int)($candidate['teacher_id'] ?? 0) === $currentTeacherId) {
                    $found = true;
                    break;
                }
            }

            if (!$found) {
                array_unshift($candidates, [
                    'teacher_id' => $currentTeacherId,
                    'teacher_name' => $currentTeacherName !== '' ? $currentTeacherName : 'Previous instructor',
                    'specialization' => $currentTeacherSpecialization !== '' ? $currentTeacherSpecialization : 'Previous instructor'
                ]);
            }
        }

        return $candidates;
    }

    private function isGeneralTeacherSpecialization($specialization)
    {
        $text = strtolower(trim((string)$specialization));
        $parts = array_values(array_filter(array_map('trim', explode(',', $text)), static function ($part) {
            return $part !== '';
        }));
        return $text !== '' && (
            strpos($text, 'all around') !== false ||
            strpos($text, 'all-around') !== false ||
            strpos($text, 'all instruments') !== false ||
            strpos($text, 'multi') !== false ||
            in_array('general', $parts, true)
        );
    }

    private function dayOfWeekFromDate($dateYmd)
    {
        $ts = strtotime((string)$dateYmd);
        if ($ts === false) return '';
        return date('l', $ts);
    }

    private function resolveRoomIdByName($branchId, $roomName)
    {
        $roomName = trim((string)$roomName);
        if ($roomName === '' || !$this->tableExists('tbl_rooms')) {
            return null;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT room_id
                FROM tbl_rooms
                WHERE branch_id = ?
                  AND room_name = ?
                LIMIT 1
            ");
            $stmt->execute([(int)$branchId, $roomName]);
            $roomId = $stmt->fetchColumn();
            return ($roomId !== false) ? (int)$roomId : null;
        } catch (PDOException $e) {
            return null;
        }
    }

    private function getAllowedAbsencesForSessionCount($sessionCount)
    {
        $sessionCount = max(0, (int)$sessionCount);
        if ($sessionCount <= 0) {
            return 0;
        }

        if ($this->tableExists('tbl_schedule_policy_lookup')) {
            try {
                $stmt = $this->conn->prepare("
                    SELECT allowed_absences
                    FROM tbl_schedule_policy_lookup
                    WHERE package_sessions = ?
                      AND status = 'Active'
                    LIMIT 1
                ");
                $stmt->execute([$sessionCount]);
                $value = $stmt->fetchColumn();
                if ($value !== false) {
                    return max(0, (int)$value);
                }
            } catch (PDOException $e) {
                // Fall through to defaults.
            }
        }

        if ($sessionCount <= 12) return 2;
        if ($sessionCount <= 20) return 3;
        if ($sessionCount <= 50) return 5;
        return 5;
    }

    private function getScheduleOperationIdByCode($operationCode)
    {
        $operationCode = trim((string)$operationCode);
        if ($operationCode === '' || !$this->tableExists('tbl_schedule_operation_lookup')) {
            return null;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT operation_id
                FROM tbl_schedule_operation_lookup
                WHERE operation_code = ?
                  AND status = 'Active'
                LIMIT 1
            ");
            $stmt->execute([$operationCode]);
            $value = $stmt->fetchColumn();
            return $value !== false ? (int)$value : null;
        } catch (PDOException $e) {
            return null;
        }
    }

    private function buildFixedScheduleLabel($dayOfWeek, $startTime, $endTime)
    {
        $parts = [];
        $day = trim((string)$dayOfWeek);
        if ($day !== '') {
            $parts[] = $day;
        }
        $start = trim((string)$startTime);
        $end = trim((string)$endTime);
        if ($start !== '' && $end !== '') {
            $parts[] = $start . '-' . $end;
        }
        return implode(' ', $parts);
    }

    private function getEnrollmentScheduleSlots($enrollmentId)
    {
        $enrollmentId = (int)$enrollmentId;
        if ($enrollmentId < 1 || !$this->tableExists('tbl_enrollment_schedule_slots')) {
            return [];
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT
                    slot_id,
                    enrollment_id,
                    teacher_id,
                    instrument_id,
                    day_of_week,
                    start_time,
                    end_time,
                    room_id,
                    room_name,
                    sort_order,
                    status
                FROM tbl_enrollment_schedule_slots
                WHERE enrollment_id = ?
                  AND status = 'Active'
                ORDER BY sort_order ASC, FIELD(day_of_week, 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), start_time ASC, slot_id ASC
            ");
            $stmt->execute([$enrollmentId]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            return [];
        }
    }

    private function formatScheduleSlotsSummary($slots)
    {
        $parts = [];
        foreach ((array)$slots as $slot) {
            $text = $this->buildFixedScheduleLabel($slot['day_of_week'] ?? '', $slot['start_time'] ?? '', $slot['end_time'] ?? '');
            if ($text !== '') {
                $parts[] = $text;
            }
        }
        return implode(' | ', $parts);
    }

    private function normalizeAssignedScheduleSlots($slotsInput, $teacherId, $branchId, $fallbackRoomName = '', $studentId = 0, $excludeEnrollmentIds = [], $instrumentLookup = [])
    {
        $validDays = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
        $teacherId = (int)$teacherId;
        $branchId = (int)$branchId;
        $studentId = (int)$studentId;
        $fallbackRoomName = trim((string)$fallbackRoomName);
        $instrumentLookup = is_array($instrumentLookup) ? $instrumentLookup : [];
        $allInstrumentIds = array_map('intval', array_keys($instrumentLookup));
        $allInstrumentKeywords = [];
        foreach ($instrumentLookup as $instrumentInfo) {
            if (!is_array($instrumentInfo)) continue;
            if (!empty($instrumentInfo['instrument_name'])) $allInstrumentKeywords[] = $instrumentInfo['instrument_name'];
            if (!empty($instrumentInfo['type_name'])) $allInstrumentKeywords[] = $instrumentInfo['type_name'];
        }
        $rows = [];

        foreach ((array)$slotsInput as $index => $slot) {
            if (!is_array($slot)) {
                continue;
            }
            $slotTeacherId = (int)($slot['teacher_id'] ?? $teacherId);
            $slotInstrumentId = (int)($slot['instrument_id'] ?? 0);
            $day = trim((string)($slot['day_of_week'] ?? ''));
            $start = trim((string)($slot['start_time'] ?? ''));
            $end = trim((string)($slot['end_time'] ?? ''));
            $roomName = trim((string)($slot['room_name'] ?? $fallbackRoomName));
            if ($day === '' || $start === '' || $end === '') {
                continue;
            }
            if (!in_array($day, $validDays, true)) {
                throw new InvalidArgumentException("Invalid day selected: {$day}");
            }
            if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $start) || !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $end)) {
                throw new InvalidArgumentException("Invalid time format for {$day}");
            }
            $start = strlen($start) === 5 ? $start . ':00' : $start;
            $end = strlen($end) === 5 ? $end . ':00' : $end;
            if (strtotime($end) <= strtotime($start)) {
                throw new InvalidArgumentException("End time must be later than start time for {$day}");
            }
            if ((strtotime($end) - strtotime($start)) !== 3600) {
                throw new InvalidArgumentException("Each weekly slot must be exactly 1 hour for {$day}");
            }

            $slotKey = $day . '|' . $start . '|' . $end;
            if (isset($rows[$slotKey])) {
                throw new InvalidArgumentException("The {$day} {$start}-{$end} weekly time was selected more than once");
            }

            $roomId = null;
            if ($roomName !== '') {
                $roomId = $this->resolveRoomIdByName($branchId, $roomName);
                if ($roomId === null) {
                    throw new InvalidArgumentException("Selected room {$roomName} is not available in this branch");
                }
            }

            $candidateTeacherIds = [];
            if ($slotInstrumentId > 0 && isset($instrumentLookup[$slotInstrumentId])) {
                $instrumentInfo = $instrumentLookup[$slotInstrumentId];
                $teacherCandidates = $this->buildTeacherCandidates($branchId, [$slotInstrumentId], [
                    $instrumentInfo['instrument_name'] ?? '',
                    $instrumentInfo['type_name'] ?? ''
                ]);
                $candidateTeacherIds = array_map(function ($t) {
                    return (int)($t['teacher_id'] ?? 0);
                }, $teacherCandidates);
            } elseif (!empty($allInstrumentIds)) {
                $teacherCandidates = $this->buildTeacherCandidates($branchId, $allInstrumentIds, $allInstrumentKeywords);
                $candidateTeacherIds = array_map(function ($t) {
                    return (int)($t['teacher_id'] ?? 0);
                }, $teacherCandidates);
            }
            $candidateTeacherIds = array_values(array_unique(array_filter($candidateTeacherIds, function ($v) { return $v > 0; })));
            if (!empty($candidateTeacherIds) && !in_array($slotTeacherId, $candidateTeacherIds, true)) {
                throw new InvalidArgumentException("Selected teacher is not eligible for the instrument row on {$day}");
            }

            if (!$this->teacherHasAvailabilityForSlot($slotTeacherId, $this->nextDateForDayOfWeek(date('Y-m-d'), $day), $start, $end, $branchId)) {
                throw new InvalidArgumentException("Teacher is not available for {$day} {$start}-{$end}");
            }
            $rows[$slotKey] = [
                'teacher_id' => $slotTeacherId,
                'instrument_id' => $slotInstrumentId > 0 ? $slotInstrumentId : null,
                'day_of_week' => $day,
                'start_time' => $start,
                'end_time' => $end,
                'room_id' => $roomId,
                'room_name' => $roomName !== '' ? $roomName : null,
                'sort_order' => count($rows) + 1
            ];
        }

        return array_values($rows);
    }

    private function saveEnrollmentScheduleSlots($enrollmentId, $slots)
    {
        $enrollmentId = (int)$enrollmentId;
        if ($enrollmentId < 1 || !$this->tableExists('tbl_enrollment_schedule_slots')) {
            return;
        }

        $stmtDelete = $this->conn->prepare("DELETE FROM tbl_enrollment_schedule_slots WHERE enrollment_id = ?");
        $stmtDelete->execute([$enrollmentId]);

        if (empty($slots)) {
            return;
        }

        $stmtInsert = $this->conn->prepare("
            INSERT INTO tbl_enrollment_schedule_slots (
                enrollment_id, teacher_id, instrument_id, day_of_week, start_time, end_time, room_id, room_name, sort_order, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'Active')
        ");

        foreach ($slots as $slot) {
            $stmtInsert->execute([
                $enrollmentId,
                (int)($slot['teacher_id'] ?? 0),
                !empty($slot['instrument_id']) ? (int)$slot['instrument_id'] : null,
                $slot['day_of_week'] ?? '',
                $slot['start_time'] ?? '',
                $slot['end_time'] ?? '',
                $slot['room_id'] ?? null,
                $slot['room_name'] ?? null,
                (int)($slot['sort_order'] ?? 1)
            ]);
        }
    }

    private function nextDateForDayOfWeek($startDate, $dayOfWeek)
    {
        $dayOfWeek = trim((string)$dayOfWeek);
        if ($dayOfWeek === '') {
            return null;
        }

        try {
            $date = new DateTimeImmutable((string)$startDate ?: 'today');
        } catch (Exception $e) {
            return null;
        }

        for ($i = 0; $i < 7; $i++) {
            $candidate = $date->modify('+' . $i . ' day');
            if ($candidate && $candidate->format('l') === $dayOfWeek) {
                return $candidate->format('Y-m-d');
            }
        }

        return null;
    }

    private function generateFixedScheduleSessions($enrollmentId)
    {
        $enrollmentId = (int)$enrollmentId;
        if ($enrollmentId < 1 || !$this->tableExists('tbl_sessions') || !$this->tableExists('tbl_enrollments')) {
            return ['created' => 0, 'updated' => 0];
        }

        $stmt = $this->conn->prepare("
            SELECT
                e.enrollment_id,
                e.student_id,
                e.instrument_id,
                e.assigned_teacher_id,
                e.start_date,
                e.total_sessions,
                e.fixed_day_of_week,
                e.fixed_start_time,
                e.fixed_end_time,
                e.fixed_room_id,
                e.schedule_status,
                s.branch_id
            FROM tbl_enrollments e
            INNER JOIN tbl_students s ON s.student_id = e.student_id
            WHERE e.enrollment_id = ?
            LIMIT 1
        ");
        $stmt->execute([$enrollmentId]);
        $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$enrollment) {
            return ['created' => 0, 'updated' => 0];
        }

        $teacherId = (int)($enrollment['assigned_teacher_id'] ?? 0);
        $studentId = (int)($enrollment['student_id'] ?? 0);
        $instrumentId = (int)($enrollment['instrument_id'] ?? 0);
        $totalSessions = max(0, (int)($enrollment['total_sessions'] ?? 0));
        $branchId = (int)($enrollment['branch_id'] ?? 0);
        $scheduleStatus = trim((string)($enrollment['schedule_status'] ?? 'Active'));
        $startDate = trim((string)($enrollment['start_date'] ?? ''));
        if ($teacherId < 1 || $studentId < 1 || $totalSessions < 1 || $scheduleStatus === 'Frozen') {
            return ['created' => 0, 'updated' => 0];
        }

        if ($instrumentId < 1 && $this->tableExists('tbl_student_instruments')) {
            $stmtInst = $this->conn->prepare("
                SELECT instrument_id
                FROM tbl_student_instruments
                WHERE student_id = ?
                ORDER BY priority_order ASC, student_instrument_id ASC
                LIMIT 1
            ");
            $stmtInst->execute([$studentId]);
            $instrumentId = (int)($stmtInst->fetchColumn() ?: 0);
        }

        $slots = $this->getEnrollmentScheduleSlots($enrollmentId);
        if (empty($slots)) {
            $legacyDay = trim((string)($enrollment['fixed_day_of_week'] ?? ''));
            $legacyStart = trim((string)($enrollment['fixed_start_time'] ?? ''));
            $legacyEnd = trim((string)($enrollment['fixed_end_time'] ?? ''));
            $legacyRoomId = !empty($enrollment['fixed_room_id']) ? (int)$enrollment['fixed_room_id'] : null;
            if ($legacyDay !== '' && $legacyStart !== '' && $legacyEnd !== '') {
                $legacyRoomName = null;
                if ($legacyRoomId !== null && $legacyRoomId > 0 && $this->tableExists('tbl_rooms')) {
                    try {
                        $stmtRoom = $this->conn->prepare("SELECT room_name FROM tbl_rooms WHERE room_id = ? LIMIT 1");
                        $stmtRoom->execute([$legacyRoomId]);
                        $legacyRoomName = $stmtRoom->fetchColumn() ?: null;
                    } catch (PDOException $e) {
                        $legacyRoomName = null;
                    }
                }
                $slots = [[
                    'teacher_id' => $teacherId,
                    'day_of_week' => $legacyDay,
                    'start_time' => $legacyStart,
                    'end_time' => $legacyEnd,
                    'room_id' => $legacyRoomId,
                    'room_name' => $legacyRoomName,
                    'sort_order' => 1
                ]];
            }
        }

        if (empty($slots)) {
            return ['created' => 0, 'updated' => 0];
        }

        $operationId = $this->getScheduleOperationIdByCode('REGULAR_SESSION');
        $startBase = $startDate !== '' ? $startDate : date('Y-m-d');
        $slotQueue = [];
        foreach ($slots as $slot) {
            $firstDate = $this->nextDateForDayOfWeek($startBase, $slot['day_of_week'] ?? '');
            if ($firstDate === null) {
                continue;
            }
            $slot['next_date'] = $firstDate;
            $slotQueue[] = $slot;
        }
        if (empty($slotQueue)) {
            return ['created' => 0, 'updated' => 0];
        }

        $stmtExisting = $this->conn->prepare("
            SELECT session_id
            FROM tbl_sessions
            WHERE enrollment_id = ?
              AND session_number = ?
              AND status <> 'cancelled_by_teacher'
            ORDER BY session_id DESC
            LIMIT 1
        ");

        $stmtUpdate = $this->conn->prepare("
            UPDATE tbl_sessions
            SET teacher_id = ?,
                session_date = ?,
                start_time = ?,
                end_time = ?,
                session_type = 'Regular',
                instrument_id = ?,
                room_id = ?,
                status = 'Scheduled',
                notes = ?,
                operation_id = COALESCE(?, operation_id)
            WHERE session_id = ?
        ");

        $stmtInsert = $this->conn->prepare("
            INSERT INTO tbl_sessions (
                enrollment_id,
                teacher_id,
                session_number,
                session_date,
                start_time,
                end_time,
                session_type,
                instrument_id,
                room_id,
                status,
                notes,
                operation_id
            ) VALUES (?, ?, ?, ?, ?, ?, 'Regular', ?, ?, 'Scheduled', ?, ?)
        ");

        $created    = 0;
        $updated    = 0;
        $skipped    = 0;       // consecutive skips (conflict protection)
        $sessionNumber = 1;
        $safety     = 0;
        $maxSafety  = max(200, $totalSessions * 60); // generous — handles up to 50 sessions + conflicts
        $lastGeneratedDate = null;
        while ($sessionNumber <= $totalSessions && $safety < $maxSafety) {
            usort($slotQueue, function ($a, $b) {
                $cmpDate = strcmp((string)($a['next_date'] ?? ''), (string)($b['next_date'] ?? ''));
                if ($cmpDate !== 0) return $cmpDate;
                $cmpTime = strcmp((string)($a['start_time'] ?? ''), (string)($b['start_time'] ?? ''));
                if ($cmpTime !== 0) return $cmpTime;
                return ((int)($a['sort_order'] ?? 0)) <=> ((int)($b['sort_order'] ?? 0));
            });
            $slot = $slotQueue[0];
            $slotTeacherId = (int)($slot['teacher_id'] ?? $teacherId);
            $slotInstrumentId = (int)($slot['instrument_id'] ?? $instrumentId);
            if ($slotTeacherId < 1) {
                $slotTeacherId = $teacherId;
            }
            $sessionDate = (string)($slot['next_date'] ?? '');
            $startTime = (string)($slot['start_time'] ?? '');
            $endTime = (string)($slot['end_time'] ?? '');
            $roomId = null;
            $roomName = null;
            if ($sessionDate === '' || $startTime === '' || $endTime === '') {
                break;
            }

            $stmtExisting->execute([$enrollmentId, $sessionNumber]);
            $existingSessionId = (int)($stmtExisting->fetchColumn() ?: 0);

            $excludeIds = $existingSessionId > 0 ? [$existingSessionId] : [];
            $isValid = $this->teacherHasAvailabilityForSlot($slotTeacherId, $sessionDate, $startTime, $endTime)
                && !$this->hasTeacherScheduleConflict($slotTeacherId, $sessionDate, $startTime, $endTime, $excludeIds)
                && !$this->hasStudentScheduleConflict($studentId, $sessionDate, $startTime, $endTime, $excludeIds)
                && !($roomId !== null && $roomId > 0 && $this->hasRoomScheduleConflict($roomId, $sessionDate, $startTime, $endTime, $excludeIds));

            if ($isValid) {
                if ($existingSessionId > 0) {
                    $stmtUpdate->execute([
                        $slotTeacherId,
                        $sessionDate,
                        $startTime,
                        $endTime,
                        $slotInstrumentId > 0 ? $slotInstrumentId : null,
                        $roomId,
                        $roomName,
                        $operationId,
                        $existingSessionId
                    ]);
                    $updated++;
                } else {
                    $stmtInsert->execute([
                        $enrollmentId,
                        $slotTeacherId,
                        $sessionNumber,
                        $sessionDate,
                        $startTime,
                        $endTime,
                        $slotInstrumentId > 0 ? $slotInstrumentId : null,
                        $roomId,
                        $roomName,
                        $operationId
                    ]);
                    $created++;
                }
                $sessionNumber++;
                $lastGeneratedDate = $sessionDate;
            }

            $slotQueue[0]['next_date'] = date('Y-m-d', strtotime($sessionDate . ' +7 days'));
            $safety++;
        }

        try {
            if ($this->tableHasColumn('tbl_enrollments', 'auto_generated_until')) {
                if ($lastGeneratedDate === null) {
                    $lastGeneratedDate = $startBase;
                }
                $stmtGenerated = $this->conn->prepare("
                    UPDATE tbl_enrollments
                    SET auto_generated_until = ?
                    WHERE enrollment_id = ?
                ");
                $stmtGenerated->execute([$lastGeneratedDate, $enrollmentId]);
            }
        } catch (PDOException $e) {
            // Ignore post-generation metadata update failures.
        }

        return [
            'created' => $created,
            'updated' => $updated,
            'required' => $totalSessions,
            'complete' => (($created + $updated) >= $totalSessions)
        ];
    }

    public function repairFixedScheduleSessions()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $singleEnrollmentId = (int)($data['enrollment_id'] ?? 0);
        $branchId = (int)($data['branch_id'] ?? 0);

        if (!$this->tableExists('tbl_enrollments') || !$this->tableExists('tbl_sessions')) {
            $this->sendJSON(['error' => 'Required tables are missing'], 500);
        }

        try {
            $sql = "
                SELECT e.enrollment_id
                FROM tbl_enrollments e
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                WHERE e.status = 'Active'
                  AND e.schedule_status = 'Active'
            ";
            $params = [];
            if ($singleEnrollmentId > 0) {
                $sql .= " AND e.enrollment_id = ? ";
                $params[] = $singleEnrollmentId;
            }
            if ($branchId > 0) {
                $sql .= " AND s.branch_id = ? ";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY e.enrollment_id ASC ";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $enrollmentIds = $stmt->fetchAll(PDO::FETCH_COLUMN, 0) ?: [];

            $results = [];
            $totalCreated = 0;
            $totalUpdated = 0;

            foreach ($enrollmentIds as $enrollmentId) {
                $enrollmentId = (int)$enrollmentId;
                if ($enrollmentId < 1) {
                    continue;
                }
                $result = $this->generateFixedScheduleSessions($enrollmentId);
                $created = (int)($result['created'] ?? 0);
                $updated = (int)($result['updated'] ?? 0);
                $totalCreated += $created;
                $totalUpdated += $updated;
                $results[] = [
                    'enrollment_id' => $enrollmentId,
                    'created' => $created,
                    'updated' => $updated,
                    'complete' => !empty($result['complete'])
                ];
            }

            $this->sendJSON([
                'success' => true,
                'message' => 'Fixed schedules repaired successfully.',
                'processed' => count($results),
                'created' => $totalCreated,
                'updated' => $totalUpdated,
                'results' => $results
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    private function canEditEnrollmentScheduleBeforeFirstWeek($enrollmentId)
    {
        $enrollmentId = (int)$enrollmentId;
        if ($enrollmentId < 1 || !$this->tableExists('tbl_enrollments')) {
            return false;
        }

        $earliestDate = '';
        if ($this->tableExists('tbl_sessions')) {
            try {
                $stmt = $this->conn->prepare("
                    SELECT MIN(session_date)
                    FROM tbl_sessions
                    WHERE enrollment_id = ?
                      AND session_date IS NOT NULL
                      AND session_date <> ''
                      AND status NOT IN ('cancelled_by_teacher', 'rescheduled')
                ");
                $stmt->execute([$enrollmentId]);
                $earliestDate = (string)($stmt->fetchColumn() ?: '');
            } catch (PDOException $e) {
                $earliestDate = '';
            }
        }

        if ($earliestDate === '') {
            try {
                $stmt = $this->conn->prepare("
                    SELECT start_date
                    FROM tbl_enrollments
                    WHERE enrollment_id = ?
                    LIMIT 1
                ");
                $stmt->execute([$enrollmentId]);
                $earliestDate = (string)($stmt->fetchColumn() ?: '');
            } catch (PDOException $e) {
                $earliestDate = '';
            }
        }

        if ($earliestDate === '') {
            return false;
        }

        try {
            $today = new DateTimeImmutable('today');
            $firstDate = new DateTimeImmutable($earliestDate);
            return $today < $firstDate;
        } catch (Exception $e) {
            return false;
        }
    }

    private function canEditScheduledSession($sessionDate, $sessionStatus = '')
    {
        $dateText = trim((string)$sessionDate);
        $status = strtolower(trim((string)$sessionStatus));
        if ($dateText === '' || $status !== 'scheduled') {
            return false;
        }

        try {
            $today = new DateTimeImmutable('today');
            $targetDate = new DateTimeImmutable($dateText);
            return $targetDate >= $today;
        } catch (Exception $e) {
            return false;
        }
    }

    private function isFutureOrTodayDate($dateText)
    {
        $value = trim((string)$dateText);
        if ($value === '') {
            return false;
        }

        try {
            $today = new DateTimeImmutable('today');
            $target = new DateTimeImmutable($value);
            return $target >= $today;
        } catch (Exception $e) {
            return false;
        }
    }

    private function ensureFutureOrTodayDateOrFail($dateText, $message = 'Past dates are not allowed.')
    {
        if (!$this->isFutureOrTodayDate($dateText)) {
            $this->sendJSON(['error' => $message], 400);
        }
    }

    private function updateFixedEnrollmentScheduleBeforeStart($enrollment, $sessionNumber, $sessionDate, $startTime, $endTime)
    {
        $enrollmentId = (int)($enrollment['enrollment_id'] ?? 0);
        $teacherId = (int)($enrollment['assigned_teacher_id'] ?? 0);
        $branchId = (int)($enrollment['branch_id'] ?? 0);
        $studentId = (int)($enrollment['student_id'] ?? 0);
        $startBase = trim((string)($enrollment['start_date'] ?? ''));
        $slots = $this->getEnrollmentScheduleSlots($enrollmentId);
        $updatedStartDate = null;

        if ($enrollmentId < 1 || $teacherId < 1 || empty($slots)) {
            throw new InvalidArgumentException('Fixed weekly schedule was not found for this enrollment.');
        }
        if (!$this->canEditEnrollmentScheduleBeforeFirstWeek($enrollmentId)) {
            throw new InvalidArgumentException('Recurring schedule pattern can only be edited before the first scheduled week starts.');
        }

        $orderedSlots = [];
        foreach ($slots as $index => $slot) {
            $firstDate = $this->nextDateForDayOfWeek($startBase !== '' ? $startBase : date('Y-m-d'), $slot['day_of_week'] ?? '');
            $slot['_original_index'] = $index;
            $slot['_first_date'] = $firstDate ?: '9999-12-31';
            $orderedSlots[] = $slot;
        }

        usort($orderedSlots, function ($a, $b) {
            $cmpDate = strcmp((string)($a['_first_date'] ?? ''), (string)($b['_first_date'] ?? ''));
            if ($cmpDate !== 0) return $cmpDate;
            $cmpTime = strcmp((string)($a['start_time'] ?? ''), (string)($b['start_time'] ?? ''));
            if ($cmpTime !== 0) return $cmpTime;
            return ((int)($a['sort_order'] ?? 0)) <=> ((int)($b['sort_order'] ?? 0));
        });

        if ($sessionNumber < 1 || $sessionNumber > count($orderedSlots)) {
            throw new InvalidArgumentException('Only first-week recurring schedule slots can be edited before classes start.');
        }

        $targetOriginalIndex = (int)$orderedSlots[$sessionNumber - 1]['_original_index'];
        $newDay = date('l', strtotime($sessionDate));
        if ($newDay === '' || !strtotime($sessionDate)) {
            throw new InvalidArgumentException('Invalid edited session date.');
        }

        $slots[$targetOriginalIndex]['day_of_week'] = $newDay;
        $slots[$targetOriginalIndex]['start_time'] = $startTime;
        $slots[$targetOriginalIndex]['end_time'] = $endTime;

        // If the first recurring session is being moved, anchor the entire
        // enrollment to the new date so generated sessions follow it.
        if ($sessionNumber === 1) {
            $updatedStartDate = $sessionDate;
            $startBase = $sessionDate;
        }

        $slotsInput = [];
        foreach ($slots as $slot) {
            $slotsInput[] = [
                'day_of_week' => $slot['day_of_week'] ?? '',
                'start_time' => $slot['start_time'] ?? '',
                'end_time' => $slot['end_time'] ?? ''
            ];
        }

        $normalizedSlots = $this->normalizeAssignedScheduleSlots(
            $slotsInput,
            $teacherId,
            $branchId,
            '',
            $studentId,
            [$enrollmentId]
        );

        if (count($normalizedSlots) !== count($slotsInput)) {
            throw new InvalidArgumentException('Edited schedule produced duplicate or invalid recurring slots.');
        }

        $this->saveEnrollmentScheduleSlots($enrollmentId, $normalizedSlots);

        $firstSlot = $normalizedSlots[0] ?? null;
        if ($firstSlot && $this->tableExists('tbl_enrollments')) {
            $summary = $this->formatScheduleSlotsSummary($normalizedSlots);
            $updateSql = "
                UPDATE tbl_enrollments
                SET fixed_day_of_week = ?,
                    fixed_start_time = ?,
                    fixed_end_time = ?,
                    fixed_room_id = NULL,
                    preferred_schedule = ?
            ";
            $updateParams = [
                $firstSlot['day_of_week'] ?? null,
                $firstSlot['start_time'] ?? null,
                $firstSlot['end_time'] ?? null,
                $summary !== '' ? $summary : null
            ];
            if ($updatedStartDate !== null) {
                $updateSql .= ", start_date = ?";
                $updateParams[] = $updatedStartDate;
            }
            $updateSql .= " WHERE enrollment_id = ?";
            $updateParams[] = $enrollmentId;
            $stmt = $this->conn->prepare("
                {$updateSql}
            ");
            $stmt->execute($updateParams);
        }

        return $this->generateFixedScheduleSessions($enrollmentId);
    }

    private function normalizeExcludedIds($excludeSessionIds)
    {
        $values = is_array($excludeSessionIds) ? $excludeSessionIds : [$excludeSessionIds];
        $ids = [];
        foreach ($values as $value) {
            $id = (int)$value;
            if ($id > 0) {
                $ids[] = $id;
            }
        }
        return array_values(array_unique($ids));
    }

    private function getEnrollmentAssignedTeacherId($enrollmentId)
    {
        $enrollmentId = (int)$enrollmentId;
        if ($enrollmentId < 1 || !$this->tableExists('tbl_enrollments')) {
            return 0;
        }

        try {
            if ($this->tableHasColumn('tbl_enrollments', 'assigned_teacher_id')) {
                $stmt = $this->conn->prepare("
                    SELECT assigned_teacher_id
                    FROM tbl_enrollments
                    WHERE enrollment_id = ?
                    LIMIT 1
                ");
                $stmt->execute([$enrollmentId]);
                $teacherId = (int)($stmt->fetchColumn() ?: 0);
                if ($teacherId > 0) {
                    return $teacherId;
                }
            }

            if ($this->tableExists('tbl_sessions')) {
                $stmt = $this->conn->prepare("
                    SELECT teacher_id
                    FROM tbl_sessions
                    WHERE enrollment_id = ?
                      AND teacher_id IS NOT NULL
                    ORDER BY session_id ASC
                    LIMIT 1
                ");
                $stmt->execute([$enrollmentId]);
                return (int)($stmt->fetchColumn() ?: 0);
            }
        } catch (PDOException $e) {
            return 0;
        }

        return 0;
    }

    private function teacherHasAvailabilityForSlot($teacherId, $sessionDate, $startTime, $endTime, $branchId = 0)
    {
        if ($teacherId < 1 || !$this->tableExists('tbl_teacher_availability')) {
            return true;
        }

        $dayOfWeek = $this->dayOfWeekFromDate($sessionDate);
        if ($dayOfWeek === '') {
            return false;
        }

        try {
            $sql = "
                SELECT COUNT(*) AS match_count
                FROM tbl_teacher_availability
                WHERE teacher_id = ?
                  AND day_of_week = ?
                  AND status = 'Available'
                  AND start_time <= ?
                  AND end_time >= ?
                  AND NOT EXISTS (
                      SELECT 1
                      FROM tbl_teacher_availability blocked
                      WHERE blocked.teacher_id = tbl_teacher_availability.teacher_id
                        AND blocked.day_of_week = tbl_teacher_availability.day_of_week
                        AND blocked.status = 'Unavailable'
                        AND blocked.start_time < ?
                        AND blocked.end_time > ?
                  )
            ";
            $params = [(int)$teacherId, $dayOfWeek, $startTime, $endTime, $endTime, $startTime];
            if ((int)$branchId > 0 && $this->tableHasColumn('tbl_teacher_availability', 'branch_id')) {
                $sql .= ' AND branch_id = ?';
                $params[] = (int)$branchId;
            }
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function hasTeacherScheduleConflict($teacherId, $sessionDate, $startTime, $endTime, $excludeSessionIds = [])
    {
        if ($teacherId < 1 || !$this->tableExists('tbl_sessions')) {
            return false;
        }
        try {
            $sql = "
                SELECT COUNT(*) AS conflict_count
                FROM tbl_sessions
                WHERE teacher_id = ?
                  AND session_date = ?
                  AND status NOT IN ('Cancelled', 'No Show', 'cancelled_by_teacher', 'rescheduled')
                  AND start_time < ?
                  AND end_time > ?
            ";
            $params = [(int)$teacherId, $sessionDate, $endTime, $startTime];
            $excludeIds = $this->normalizeExcludedIds($excludeSessionIds);
            if (!empty($excludeIds)) {
                $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
                $sql .= " AND session_id NOT IN ({$placeholders})";
                $params = array_merge($params, $excludeIds);
            }
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function hasRoomScheduleConflict($roomId, $sessionDate, $startTime, $endTime, $excludeSessionIds = [])
    {
        if ($roomId === null || $roomId < 1 || !$this->tableExists('tbl_sessions')) {
            return false;
        }
        try {
            $sql = "
                SELECT COUNT(*) AS conflict_count
                FROM tbl_sessions
                WHERE room_id = ?
                  AND session_date = ?
                  AND status NOT IN ('Cancelled', 'No Show', 'cancelled_by_teacher', 'rescheduled')
                  AND start_time < ?
                  AND end_time > ?
            ";
            $params = [(int)$roomId, $sessionDate, $endTime, $startTime];
            $excludeIds = $this->normalizeExcludedIds($excludeSessionIds);
            if (!empty($excludeIds)) {
                $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
                $sql .= " AND session_id NOT IN ({$placeholders})";
                $params = array_merge($params, $excludeIds);
            }
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function hasStudentScheduleConflict($studentId, $sessionDate, $startTime, $endTime, $excludeSessionIds = [])
    {
        if ($studentId < 1 || !$this->tableExists('tbl_sessions') || !$this->tableExists('tbl_enrollments')) {
            return false;
        }

        try {
            $sql = "
                SELECT COUNT(*) AS conflict_count
                FROM tbl_sessions ts
                INNER JOIN tbl_enrollments te ON te.enrollment_id = ts.enrollment_id
                WHERE te.student_id = ?
                  AND ts.session_date = ?
                  AND ts.status NOT IN ('Cancelled', 'No Show', 'cancelled_by_teacher', 'rescheduled')
                  AND ts.start_time < ?
                  AND ts.end_time > ?
            ";
            $params = [(int)$studentId, $sessionDate, $endTime, $startTime];
            $excludeIds = $this->normalizeExcludedIds($excludeSessionIds);
            if (!empty($excludeIds)) {
                $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
                $sql .= " AND ts.session_id NOT IN ({$placeholders})";
                $params = array_merge($params, $excludeIds);
            }
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function hasTeacherRecurringScheduleConflict($teacherId, $dayOfWeek, $startTime, $endTime, $excludeEnrollmentIds = [])
    {
        if ($teacherId < 1 || !$this->tableExists('tbl_enrollment_schedule_slots') || !$this->tableExists('tbl_enrollments')) {
            return false;
        }

        try {
            // Only block if the recurring slot has at least one upcoming (future/today) scheduled session
            // This prevents completed/expired enrollments from permanently blocking a teacher's slot
            $sql = "
                SELECT COUNT(*) AS conflict_count
                FROM tbl_enrollment_schedule_slots ess
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ess.enrollment_id
                INNER JOIN tbl_sessions s ON s.enrollment_id = ess.enrollment_id
                WHERE ess.teacher_id = ?
                  AND ess.day_of_week = ?
                  AND ess.status = 'Active'
                  AND e.status = 'Active'
                  AND ess.start_time < ?
                  AND ess.end_time > ?
                  AND s.session_date >= CURDATE()
                  AND s.start_time = ess.start_time
                  AND s.end_time   = ess.end_time
                  AND s.status NOT IN ('Cancelled', 'No Show', 'cancelled_by_teacher', 'rescheduled', 'Completed')
            ";
            $params = [(int)$teacherId, $dayOfWeek, $endTime, $startTime];
            $excludeIds = $this->normalizeExcludedIds($excludeEnrollmentIds);
            if (!empty($excludeIds)) {
                $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
                $sql .= " AND ess.enrollment_id NOT IN ({$placeholders})";
                $params = array_merge($params, $excludeIds);
            }
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function hasRoomRecurringScheduleConflict($roomId, $dayOfWeek, $startTime, $endTime, $excludeEnrollmentIds = [])
    {
        if ($roomId === null || $roomId < 1 || !$this->tableExists('tbl_enrollment_schedule_slots') || !$this->tableExists('tbl_enrollments')) {
            return false;
        }

        try {
            $sql = "
                SELECT COUNT(*) AS conflict_count
                FROM tbl_enrollment_schedule_slots ess
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ess.enrollment_id
                WHERE ess.room_id = ?
                  AND ess.day_of_week = ?
                  AND ess.status = 'Active'
                  AND e.status = 'Active'
                  AND ess.start_time < ?
                  AND ess.end_time > ?
            ";
            $params = [(int)$roomId, $dayOfWeek, $endTime, $startTime];
            $excludeIds = $this->normalizeExcludedIds($excludeEnrollmentIds);
            if (!empty($excludeIds)) {
                $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
                $sql .= " AND ess.enrollment_id NOT IN ({$placeholders})";
                $params = array_merge($params, $excludeIds);
            }
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function hasStudentRecurringScheduleConflict($studentId, $dayOfWeek, $startTime, $endTime, $excludeEnrollmentIds = [])
    {
        if ($studentId < 1 || !$this->tableExists('tbl_enrollment_schedule_slots') || !$this->tableExists('tbl_enrollments')) {
            return false;
        }

        try {
            // Only block if there's an actual upcoming scheduled session for this slot
            $sql = "
                SELECT COUNT(*) AS conflict_count
                FROM tbl_enrollment_schedule_slots ess
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ess.enrollment_id
                INNER JOIN tbl_sessions s ON s.enrollment_id = ess.enrollment_id
                WHERE e.student_id = ?
                  AND ess.day_of_week = ?
                  AND ess.status = 'Active'
                  AND e.status = 'Active'
                  AND ess.start_time < ?
                  AND ess.end_time > ?
                  AND s.session_date >= CURDATE()
                  AND s.start_time = ess.start_time
                  AND s.end_time   = ess.end_time
                  AND s.status NOT IN ('Cancelled', 'No Show', 'cancelled_by_teacher', 'rescheduled', 'Completed')
            ";
            $params = [(int)$studentId, $dayOfWeek, $endTime, $startTime];
            $excludeIds = $this->normalizeExcludedIds($excludeEnrollmentIds);
            if (!empty($excludeIds)) {
                $placeholders = implode(',', array_fill(0, count($excludeIds), '?'));
                $sql .= " AND ess.enrollment_id NOT IN ({$placeholders})";
                $params = array_merge($params, $excludeIds);
            }
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return ((int)$stmt->fetchColumn()) > 0;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function buildTeacherAvailableSlots($teacherId, $branchId, $studentId, $roomId = null, $excludeSessionIds = [], $daysAhead = 30, $rangeStartDate = '', $excludeRequestIds = [])
    {
        $teacherId = (int)$teacherId;
        $branchId = (int)$branchId;
        $studentId = (int)$studentId;
        $daysAhead = max(1, min(365, (int)$daysAhead));
        if ($teacherId < 1 || !$this->tableExists('tbl_teacher_availability')) {
            return [];
        }

        try {
            $sql = "
                SELECT day_of_week, start_time, end_time
                FROM tbl_teacher_availability
                WHERE teacher_id = ?
                  AND status = 'Available'
            ";
            $params = [$teacherId];
            if ($branchId > 0 && $this->tableHasColumn('tbl_teacher_availability', 'branch_id')) {
                $sql .= " AND branch_id = ? ";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY FIELD(day_of_week, 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'), start_time ASC ";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $availabilityRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            if (empty($availabilityRows)) {
                return [];
            }

            $slots = [];
            $today = new DateTimeImmutable('today');
            $now = new DateTimeImmutable();
            $calendarStartDate = $today;
            $requestedRangeStart = trim((string)$rangeStartDate);
            if ($requestedRangeStart !== '') {
                try {
                    $parsedRangeStart = new DateTimeImmutable($requestedRangeStart);
                    $parsedRangeStart = $parsedRangeStart->setTime(0, 0, 0);
                    if ($parsedRangeStart > $today) {
                        $calendarStartDate = $parsedRangeStart;
                    }
                } catch (Exception $e) {
                    $calendarStartDate = $today;
                }
            }
            $reservationEndDate = $calendarStartDate->modify('+' . $daysAhead . ' day')->format('Y-m-d');
            $pendingReservationSlots = $this->getTeacherReservationSlots(
                $teacherId,
                $calendarStartDate->format('Y-m-d'),
                $reservationEndDate,
                $excludeRequestIds
            );

            foreach ($availabilityRows as $availability) {
                $dayOfWeek = trim((string)($availability['day_of_week'] ?? ''));
                $rangeStart = trim((string)($availability['start_time'] ?? ''));
                $rangeEnd = trim((string)($availability['end_time'] ?? ''));
                if ($dayOfWeek === '' || $rangeStart === '' || $rangeEnd === '') {
                    continue;
                }

                for ($offset = 0; $offset <= $daysAhead; $offset++) {
                    $date = $calendarStartDate->modify('+' . $offset . ' day');
                    if ($date->format('l') !== $dayOfWeek) {
                        continue;
                    }

                    $cursor = strtotime($date->format('Y-m-d') . ' ' . $rangeStart);
                    $limit = strtotime($date->format('Y-m-d') . ' ' . $rangeEnd);
                    if ($cursor === false || $limit === false) {
                        continue;
                    }

                    while (($cursor + 3600) <= $limit) {
                        $slotDate = $date->format('Y-m-d');
                        $slotStart = date('H:i:s', $cursor);
                        $slotEnd = date('H:i:s', $cursor + 3600);
                        $slotDateTime = new DateTimeImmutable($slotDate . ' ' . $slotStart);
                        if ($slotDateTime <= $now) {
                            $cursor += 3600;
                            continue;
                        }
                        if ($this->hasTeacherScheduleConflict($teacherId, $slotDate, $slotStart, $slotEnd, $excludeSessionIds)) {
                            $cursor += 3600;
                            continue;
                        }
                        if ($studentId > 0 && $this->hasStudentScheduleConflict($studentId, $slotDate, $slotStart, $slotEnd, $excludeSessionIds)) {
                            $cursor += 3600;
                            continue;
                        }
                        if ($roomId !== null && $roomId > 0 && $this->hasRoomScheduleConflict($roomId, $slotDate, $slotStart, $slotEnd, $excludeSessionIds)) {
                            $cursor += 3600;
                            continue;
                        }
                        $reserved = false;
                        foreach ($pendingReservationSlots as $reservation) {
                            if ((string)$reservation['session_date'] === $slotDate
                                && $slotStart < (string)$reservation['end_time']
                                && $slotEnd > (string)$reservation['start_time']) {
                                $reserved = true;
                                break;
                            }
                        }
                        if ($reserved) {
                            $cursor += 3600;
                            continue;
                        }

                        $slotKey = $slotDate . '|' . $slotStart . '|' . $slotEnd;
                        $slots[$slotKey] = [
                            'session_date' => $slotDate,
                            'day_of_week' => $dayOfWeek,
                            'start_time' => $slotStart,
                            'end_time' => $slotEnd
                        ];
                        $cursor += 3600;
                    }
                }
            }

            ksort($slots);
            return array_values($slots);
        } catch (PDOException $e) {
            return [];
        }
    }

    private function getTeacherReservationSlots($teacherId, $startDate = '', $endDate = '', $excludeRequestIds = [])
    {
        if (!$this->tableExists('tbl_enrollments')) return [];
        $stmt = $this->conn->query("SELECT enrollment_id, request_notes, created_at, schedule_request_status, reservation_expires_at FROM tbl_enrollments WHERE status = 'Pending'");
        $result = [];
        $excluded = array_flip($this->normalizeExcludedIds($excludeRequestIds));
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            if (isset($excluded[(int)$row['enrollment_id']])) continue;
            $meta = $this->decodeRequestMeta($row['request_notes'] ?? '');
            if (!$this->reservationIsActive($row, $meta)) continue;
            foreach ($this->projectRequestedSessionSlots($meta) as $slot) {
                $date = trim((string)($slot['session_date'] ?? ''));
                if ((int)($slot['teacher_id'] ?? 0) !== (int)$teacherId || $date === '') continue;
                if ($startDate !== '' && $date < $startDate) continue;
                if ($endDate !== '' && $date > $endDate) continue;
                $result[] = [
                    'request_id' => (int)$row['enrollment_id'],
                    'student_id' => (int)($row['student_id'] ?? 0),
                    'session_number' => (int)($slot['session_number'] ?? 0),
                    'session_date' => $date,
                    'day_of_week' => trim((string)($slot['day_of_week'] ?? $this->dayOfWeekFromDate($date))),
                    'start_time' => $slot['start_time'] ?? '',
                    'end_time' => $slot['end_time'] ?? '',
                    'status' => 'reserved',
                    'reservation_expires_at' => $row['reservation_expires_at'] ?? $meta['reservation_expires_at'] ?? null
                ];
            }
        }
        return $result;
    }

    private function getTeacherOccupiedSlots($teacherId, $startDate = '', $endDate = '')
    {
        if (!$this->tableExists('tbl_sessions')) return [];
        $sql = "SELECT session_date, start_time, end_time, status FROM tbl_sessions
                WHERE teacher_id = ? AND status NOT IN ('Cancelled','No Show','cancelled_by_teacher','rescheduled')";
        $params = [(int)$teacherId];
        if ($startDate !== '') { $sql .= ' AND session_date >= ?'; $params[] = $startDate; }
        if ($endDate !== '') { $sql .= ' AND session_date <= ?'; $params[] = $endDate; }
        $sql .= ' ORDER BY session_date, start_time';
        $stmt = $this->conn->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
    }

    private function getStudentBookedSessionsForTeacher($teacherId, $studentId, $branchId = 0)
    {
        $teacherId = (int)$teacherId;
        $studentId = (int)$studentId;
        $branchId = (int)$branchId;
        if ($teacherId < 1 || $studentId < 1 || !$this->tableExists('tbl_sessions')) {
            return [];
        }

        try {
            $packageJoin = $this->tableExists('tbl_session_packages')
                ? "LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id"
                : "";
            $packageNameExpr = $this->tableExists('tbl_session_packages')
                ? "COALESCE(sp.package_name, CONCAT('Package #', e.package_id))"
                : "CONCAT('Package #', e.package_id)";

            $sql = "
                SELECT
                    ts.session_id,
                    ts.enrollment_id,
                    ts.session_number,
                    ts.session_date,
                    ts.start_time,
                    ts.end_time,
                    ts.status,
                    {$packageNameExpr} AS package_name,
                    CONCAT_WS(' ', t.first_name, t.last_name) AS teacher_name
                FROM tbl_sessions ts
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ts.enrollment_id
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                LEFT JOIN tbl_teachers t ON t.teacher_id = COALESCE(e.assigned_teacher_id, ts.teacher_id)
                {$packageJoin}
                WHERE e.student_id = ?
                  AND COALESCE(e.assigned_teacher_id, ts.teacher_id) = ?
                  AND ts.status NOT IN ('Cancelled', 'cancelled_by_teacher', 'rescheduled')
            ";
            $params = [$studentId, $teacherId];
            if ($branchId > 0) {
                $sql .= " AND s.branch_id = ? ";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY ts.session_date ASC, ts.start_time ASC, ts.session_id ASC ";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
        } catch (PDOException $e) {
            return [];
        }
    }

    public function getTeacherAvailableSlots()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $teacherId = (int)($_GET['teacher_id'] ?? 0);
        $branchId = (int)($_GET['branch_id'] ?? 0);
        $studentId = (int)($_GET['student_id'] ?? 0);
        $roomName = trim((string)($_GET['room_name'] ?? ''));
        $startDate = trim((string)($_GET['start_date'] ?? ''));
        $endDate = trim((string)($_GET['end_date'] ?? ''));
        $daysAhead = (int)($_GET['days_ahead'] ?? 60); // enough for the visible scheduling window without a full-year scan
        $excludeRequestId = (int)($_GET['exclude_request_id'] ?? 0);

        if ($teacherId < 1) {
            $this->sendJSON(['error' => 'teacher_id is required'], 400);
        }

        $roomId = null;
        if ($branchId > 0 && $roomName !== '') {
            $resolvedRoomId = $this->resolveRoomIdByName($branchId, $roomName);
            if ($resolvedRoomId > 0) $roomId = $resolvedRoomId;
        }

        if ($startDate !== '' && $endDate !== '') {
            try {
                $effectiveStart = new DateTimeImmutable($startDate);
                $today = new DateTimeImmutable('today');
                if ($effectiveStart < $today) $effectiveStart = $today;
                $effectiveEnd = new DateTimeImmutable($endDate);
                if ($effectiveEnd >= $effectiveStart) {
                    $daysAhead = min(62, (int)$effectiveStart->diff($effectiveEnd)->format('%a'));
                }
            } catch (Exception $e) {
                // Fall back to the requested days_ahead window.
            }
        }
        $this->expirePendingScheduleReservations();
        $excludeRequestIds = $excludeRequestId > 0 ? [$excludeRequestId] : [];
        $slots = $this->buildTeacherAvailableSlots($teacherId, $branchId, $studentId, $roomId, [], $daysAhead, $startDate, $excludeRequestIds);
        $calendarRangeStart = $startDate !== '' ? $startDate : date('Y-m-d');
        $calendarRangeEnd = $endDate !== '' ? $endDate : date('Y-m-d', strtotime($calendarRangeStart . ' +' . max(1, $daysAhead) . ' days'));
        $reservedSlots = $this->getTeacherReservationSlots($teacherId, $calendarRangeStart, $calendarRangeEnd, $excludeRequestIds);
        $occupiedSlots = $this->getTeacherOccupiedSlots($teacherId, $calendarRangeStart, $calendarRangeEnd);
        $bookedSessions = $this->getStudentBookedSessionsForTeacher($teacherId, $studentId, $branchId);
        $elapsedAvailabilityDates = [];
        try {
            $todayDate = date('Y-m-d');
            $todayDay = date('l');
            $currentTime = date('H:i:s');
            $elapsedSql = "
                SELECT COUNT(*) AS window_count,
                       SUM(CASE WHEN end_time > ? THEN 1 ELSE 0 END) AS future_window_count
                FROM tbl_teacher_availability
                WHERE teacher_id = ?
                  AND day_of_week = ?
                  AND status = 'Available'
            ";
            $elapsedParams = [$currentTime, $teacherId, $todayDay];
            if ($branchId > 0 && $this->tableHasColumn('tbl_teacher_availability', 'branch_id')) {
                $elapsedSql .= " AND branch_id = ? ";
                $elapsedParams[] = $branchId;
            }
            $elapsedStmt = $this->conn->prepare($elapsedSql);
            $elapsedStmt->execute($elapsedParams);
            $elapsedRow = $elapsedStmt->fetch(PDO::FETCH_ASSOC) ?: [];
            if ((int)($elapsedRow['window_count'] ?? 0) > 0 && (int)($elapsedRow['future_window_count'] ?? 0) === 0) {
                $elapsedAvailabilityDates[] = $todayDate;
            }
        } catch (PDOException $e) {
            $elapsedAvailabilityDates = [];
        }
        if ($startDate !== '') {
            $slots = array_values(array_filter($slots, function ($slot) use ($startDate) {
                return !empty($slot['session_date']) && strcmp((string)$slot['session_date'], $startDate) >= 0;
            }));
        }

        $this->sendJSON([
            'success' => true,
            'teacher_id' => $teacherId,
            'slots' => $slots,
            'reserved_slots' => $reservedSlots,
            'occupied_slots' => $occupiedSlots,
            'elapsed_availability_dates' => $elapsedAvailabilityDates,
            'booked_sessions' => $bookedSessions
        ]);
    }

    /** Check whether a table exists in current DB */
    private function tableExists($tableName)
    {
        $cacheKey = (string)$tableName;
        if (!empty($this->existingTableCache[$cacheKey])) {
            return true;
        }
        try {
            $stmt = $this->conn->prepare("SHOW TABLES LIKE ?");
            $stmt->execute([$tableName]);
            $exists = $stmt->rowCount() > 0;
            if ($exists) $this->existingTableCache[$cacheKey] = true;
            return $exists;
        } catch (PDOException $e) {
            return false;
        }
    }

    /** Check whether a table has a specific column */
    private function tableHasColumn($tableName, $columnName)
    {
        if (!preg_match('/^[A-Za-z0-9_]+$/', (string) $tableName)) {
            return false;
        }
        $cacheKey = (string)$tableName . '.' . (string)$columnName;
        if (!empty($this->existingColumnCache[$cacheKey])) {
            return true;
        }
        try {
            $stmt = $this->conn->prepare("SHOW COLUMNS FROM `{$tableName}` LIKE ?");
            $stmt->execute([$columnName]);
            $exists = $stmt->rowCount() > 0;
            if ($exists) $this->existingColumnCache[$cacheKey] = true;
            return $exists;
        } catch (PDOException $e) {
            return false;
        }
    }

    private function buildTemporaryStudentNumber($studentId)
    {
        $studentId = (int) $studentId;
        $base = null;

        try {
            if ($studentId > 0 && $this->tableHasColumn('tbl_students', 'student_code')) {
                $stmt = $this->conn->prepare("
                    SELECT student_code, created_at
                    FROM tbl_students
                    WHERE student_id = ?
                    LIMIT 1
                ");
                $stmt->execute([$studentId]);
                $student = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

                $studentCode = trim((string)($student['student_code'] ?? ''));
                if ($studentCode !== '') {
                    $base = $studentCode;
                } else {
                    $createdAt = trim((string)($student['created_at'] ?? ''));
                    $year = $createdAt !== '' ? (int)date('Y', strtotime($createdAt)) : (int)date('Y');
                    $base = sprintf('STU-%04d-%04d', $year, $studentId);
                }

                if ($studentCode === '') {
                    $stmtUpdate = $this->conn->prepare("
                        UPDATE tbl_students
                        SET student_code = ?
                        WHERE student_id = ?
                          AND (student_code IS NULL OR TRIM(student_code) = '')
                    ");
                    $stmtUpdate->execute([$base, $studentId]);
                }
            }
        } catch (PDOException $e) {
            $base = null;
        }

        if ($base === null || trim((string)$base) === '') {
            $base = sprintf('STU-%04d-%04d', (int)date('Y'), max(1, $studentId));
        }

        $candidate = $base;
        $suffix = 2;
        while ($this->loginIdentifierExists($candidate)) {
            $candidate = $base . '-' . $suffix;
            $suffix++;
        }

        return $candidate;
    }

    private function buildStudentLoginIdentifier($studentId)
    {
        $studentId = (int) $studentId;
        if ($studentId < 1) {
            return '';
        }

        try {
            if ($this->tableHasColumn('tbl_students', 'student_code')) {
                $stmt = $this->conn->prepare("
                    SELECT student_code, created_at
                    FROM tbl_students
                    WHERE student_id = ?
                    LIMIT 1
                ");
                $stmt->execute([$studentId]);
                $student = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

                $studentCode = trim((string)($student['student_code'] ?? ''));
                if ($studentCode !== '') {
                    return $studentCode;
                }

                $createdAt = trim((string)($student['created_at'] ?? ''));
                $year = $createdAt !== '' ? (int)date('Y', strtotime($createdAt)) : (int)date('Y');
                $studentCode = sprintf('STU-%04d-%04d', $year, $studentId);

                $stmtUpdate = $this->conn->prepare("
                    UPDATE tbl_students
                    SET student_code = ?
                    WHERE student_id = ?
                      AND (student_code IS NULL OR TRIM(student_code) = '')
                ");
                $stmtUpdate->execute([$studentCode, $studentId]);

                return $studentCode;
            }
        } catch (PDOException $e) {
            // Fall through to the formatted identifier below.
        }

        return sprintf('STU-%04d-%04d', (int)date('Y'), $studentId);
    }

    private function ensureStudentCodesAssigned()
    {
        if (!$this->tableHasColumn('tbl_students', 'student_code')) {
            return;
        }

        try {
            $this->conn->exec("
                UPDATE tbl_students
                SET student_code = CONCAT(
                    'STU-',
                    YEAR(COALESCE(created_at, CURRENT_DATE)),
                    '-',
                    LPAD(student_id, 4, '0')
                )
                WHERE student_code IS NULL OR TRIM(student_code) = ''
            ");
        } catch (PDOException $e) {
            error_log('Unable to backfill student codes: ' . $e->getMessage());
        }
    }

    /**
     * Attendance makes a session immutable.  tbl_sessions is the primary
     * source, while tbl_attendance is a backstop for older/check-in records
     * that may have been written before the session outcome was synchronized.
     */
    private function sessionHasRecordedAttendance($session, $studentId = 0)
    {
        if (!is_array($session)) {
            return false;
        }

        $attendanceStatus = strtolower(trim((string)($session['attendance_status'] ?? '')));
        if ($attendanceStatus !== '' && $attendanceStatus !== 'pending') {
            return true;
        }
        if ((int)($session['counted_in'] ?? 0) === 1 || !empty($session['instructor_completed_at'])) {
            return true;
        }

        $studentId = (int)$studentId;
        $sessionDate = trim((string)($session['session_date'] ?? ''));
        if ($studentId < 1 || $sessionDate === '' || !$this->tableExists('tbl_attendance')) {
            return false;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT attendance_id
                FROM tbl_attendance
                WHERE student_id = ?
                  AND attended_at >= CONCAT(?, ' 00:00:00')
                  AND attended_at < DATE_ADD(CONCAT(?, ' 00:00:00'), INTERVAL 1 DAY)
                LIMIT 1
            ");
            $stmt->execute([$studentId, $sessionDate, $sessionDate]);
            return $stmt->fetchColumn() !== false;
        } catch (PDOException $e) {
            // The session-level attendance fields still enforce the invariant
            // if a legacy attendance table cannot be queried.
            return false;
        }
    }

    private function buildGuardianUsername($studentId, $guardianEmail)
    {
        $studentId = (int)$studentId;
        $guardianEmail = trim((string)$guardianEmail);
        if ($guardianEmail !== '' && strpos($guardianEmail, '@') !== false) {
            return strtolower($guardianEmail);
        }

        return sprintf('GUA-%04d-%04d', (int)date('Y'), max(1, $studentId));
    }

    private function loginIdentifierExists($identifier)
    {
        $identifier = trim((string)$identifier);
        if ($identifier === '') {
            return true;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT 1
                FROM tbl_users
                WHERE username = ? OR email = ?
                LIMIT 1
            ");
            $stmt->execute([$identifier, $identifier]);
            if ($stmt->fetchColumn()) {
                return true;
            }

            $stmtGuardian = $this->conn->prepare("
                SELECT 1
                FROM tbl_guardians
                WHERE email = ?
                LIMIT 1
            ");
            $stmtGuardian->execute([$identifier]);
            return (bool)$stmtGuardian->fetchColumn();
        } catch (PDOException $e) {
            return false;
        }
    }

    // Get all students for admin_students page
    public function getAllStudents()
    {
        try {
            $this->ensureSessionPackageColumn();
            $this->ensureStudentRegistrationFeesTable();
            $this->ensureStudentCodesAssigned();
            $studentCodeSelect = $this->tableHasColumn('tbl_students', 'student_code')
                ? 's.student_code'
                : 'NULL AS student_code';
            $stmt = $this->conn->prepare("
                SELECT
                    s.student_id,
                    {$studentCodeSelect},
                    s.first_name,
                    s.last_name,
                    s.email,
                    s.phone,
                    COALESCE(rf.registration_fee_amount, 1000.00) AS registration_fee_amount,
                    COALESCE(rf.registration_fee_paid, 0.00) AS registration_fee_paid,
                    COALESCE(rf.registration_status, 'Pending') AS registration_status,
                    s.status,
                    s.created_at,
                    s.branch_id,
                    b.branch_name
                FROM tbl_students s
                LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
                LEFT JOIN (
                    SELECT
                        rp.student_id,
                        1000.00 AS registration_fee_amount,
                        COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) AS registration_fee_paid,
                        CASE
                            WHEN COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) >= 1000.00 THEN 'Approved'
                            ELSE 'Pending'
                        END AS registration_status
                    FROM tbl_registration_payments rp
                    GROUP BY rp.student_id
                ) rf ON rf.student_id = s.student_id
                WHERE (
                    s.status = 'Active'
                    OR COALESCE(rf.registration_fee_paid, 0.00) >= 1000.00
                )
                ORDER BY s.created_at DESC
            ");

            $stmt->execute();
            $this->sendJSON([
                'success'   => true,
                'students'  => $stmt->fetchAll(PDO::FETCH_ASSOC)
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Get one student by ID (for view/edit)
    public function getStudent()
    {
        $studentId = (int) ($_GET['student_id'] ?? 0);
        if ($studentId < 1) {
            $this->sendJSON(['error' => 'Student ID is required'], 400);
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT s.*, b.branch_name
                FROM tbl_students s
                LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
                WHERE s.student_id = ?
            ");
            $stmt->execute([$studentId]);
            $student = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendJSON(['error' => 'Student not found'], 404);
            }
            $this->sendJSON(['success' => true, 'student' => $student]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Update student
    public function updateStudent()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $id = (int) ($data['student_id'] ?? 0);
        $firstName = trim($data['first_name'] ?? '');
        $lastName = trim($data['last_name'] ?? '');
        $middleName = trim($data['middle_name'] ?? '');
        $email = trim($data['email'] ?? '');
        $phone = trim($data['phone'] ?? '');
        $address = trim($data['address'] ?? '');
        $branchId = (int) ($data['branch_id'] ?? 0);
        $dateOfBirth = !empty($data['date_of_birth']) ? $data['date_of_birth'] : null;
        $age = isset($data['age']) ? (int) $data['age'] : null;
        $school = trim($data['school'] ?? '');
        $gradeYear = trim($data['grade_year'] ?? '');
        $registrationFeeAmount = isset($data['registration_fee_amount']) ? (float) $data['registration_fee_amount'] : null;
        $registrationFeePaid = isset($data['registration_fee_paid']) ? (float) $data['registration_fee_paid'] : null;
        $registrationStatus = isset($data['registration_status']) && in_array($data['registration_status'], ['Pending', 'Fee Paid', 'Approved', 'Rejected'], true) ? $data['registration_status'] : null;
        $status = isset($data['status']) && in_array($data['status'], ['Active', 'Inactive'], true) ? $data['status'] : null;

        if ($id < 1) {
            $this->sendJSON(['error' => 'Student ID is required'], 400);
        }
        if ($firstName === '' || $lastName === '') {
            $this->sendJSON(['error' => 'First name and last name are required'], 400);
        }
        if ($branchId < 1) {
            $this->sendJSON(['error' => 'Branch is required'], 400);
        }

        // ═══ XSS PROTECTION: Validate name fields ═══
        $firstNameValidation = XSSProtection::validateName($firstName);
        if (!$firstNameValidation['valid']) {
            XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid first name in updateStudent', ['value' => substr($firstName, 0, 50)]);
            $this->sendJSON(['error' => $firstNameValidation['error']], 400);
        }

        $lastNameValidation = XSSProtection::validateName($lastName);
        if (!$lastNameValidation['valid']) {
            XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid last name in updateStudent', ['value' => substr($lastName, 0, 50)]);
            $this->sendJSON(['error' => $lastNameValidation['error']], 400);
        }

        if ($middleName !== '') {
            $middleNameValidation = XSSProtection::validateName($middleName);
            if (!$middleNameValidation['valid']) {
                XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid middle name in updateStudent', ['value' => substr($middleName, 0, 50)]);
                $this->sendJSON(['error' => $middleNameValidation['error']], 400);
            }
        }

        // ═══ XSS PROTECTION: Validate email ═══
        if ($email !== '') {
            $emailValidation = XSSProtection::validateEmail($email);
            if (!$emailValidation['valid']) {
                XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid email in updateStudent', ['value' => substr($email, 0, 50)]);
                $this->sendJSON(['error' => $emailValidation['error']], 400);
            }
        }

        // ═══ XSS PROTECTION: Validate phone ═══
        if ($phone !== '') {
            $phoneValidation = XSSProtection::validatePhone($phone);
            if (!$phoneValidation['valid']) {
                XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid phone in updateStudent', ['value' => substr($phone, 0, 50)]);
                $this->sendJSON(['error' => $phoneValidation['error']], 400);
            }
        }

        // ═══ XSS PROTECTION: Validate address ═══
        if ($address !== '') {
            $addressValidation = XSSProtection::sanitizeAddress($address);
            if (!$addressValidation['valid']) {
                XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid address in updateStudent', ['value' => substr($address, 0, 50)]);
                $this->sendJSON(['error' => $addressValidation['error']], 400);
            }
            $address = $addressValidation['value'];
        }

        // ═══ XSS PROTECTION: Validate school and grade/year ═══
        if ($school !== '') {
            $schoolValidation = XSSProtection::sanitizeText($school, 200);
            if (!$schoolValidation['valid']) {
                XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid school in updateStudent', ['value' => substr($school, 0, 50)]);
                $this->sendJSON(['error' => $schoolValidation['error']], 400);
            }
            $school = $schoolValidation['value'];
        }

        if ($gradeYear !== '') {
            $gradeYearValidation = XSSProtection::sanitizeText($gradeYear, 50);
            if (!$gradeYearValidation['valid']) {
                XSSProtection::logSecurityEvent('XSS_ATTEMPT', 'Invalid grade/year in updateStudent', ['value' => substr($gradeYear, 0, 50)]);
                $this->sendJSON(['error' => $gradeYearValidation['error']], 400);
            }
            $gradeYear = $gradeYearValidation['value'];
        }

        try {
            $this->ensureStudentRegistrationFeesTable();
            $stmtExists = $this->conn->prepare("SELECT student_id FROM tbl_students WHERE student_id = ? LIMIT 1");
            $stmtExists->execute([$id]);
            if (!$stmtExists->fetchColumn()) {
                $this->sendJSON(['error' => 'Student not found'], 404);
            }

            $stmtCurrent = $this->conn->prepare("SELECT email FROM tbl_students WHERE student_id = ? LIMIT 1");
            $stmtCurrent->execute([$id]);
            $currentStudent = $stmtCurrent->fetch(PDO::FETCH_ASSOC) ?: [];
            $currentEmail = trim((string)($currentStudent['email'] ?? ''));

            $this->conn->beginTransaction();
            $stmt = $this->conn->prepare("
                UPDATE tbl_students SET
                    first_name = ?, last_name = ?, middle_name = ?, email = ?, phone = ?, address = ?,
                    branch_id = ?, date_of_birth = ?, age = ?, school = ?, grade_year = ?,
                    status = COALESCE(?, status)
                WHERE student_id = ?
            ");
            $stmt->execute([
                $firstName, $lastName, $middleName ?: null, $email ?: null, $phone ?: null, $address ?: null,
                $branchId, $dateOfBirth, $age ?: null, $school ?: null, $gradeYear ?: null,
                $status, $id
            ]);

            $normalizedEmail = trim((string)$email);
            if ($currentEmail !== '') {
                if ($normalizedEmail === '') {
                    $stmtDeleteUser = $this->conn->prepare("
                        DELETE u
                        FROM tbl_users u
                        INNER JOIN tbl_roles r ON r.role_id = u.role_id
                        WHERE (u.email = ? OR u.username = ?)
                          AND LOWER(r.role_name) = 'student'
                    ");
                    $stmtDeleteUser->execute([$currentEmail, $currentEmail]);
                } elseif (strcasecmp($currentEmail, $normalizedEmail) !== 0) {
                    $stmtUpdateUser = $this->conn->prepare("
                        UPDATE tbl_users u
                        INNER JOIN tbl_roles r ON r.role_id = u.role_id
                        SET u.email = ?, u.username = ?
                        WHERE (u.email = ? OR u.username = ?)
                          AND LOWER(r.role_name) = 'student'
                    ");
                    $stmtUpdateUser->execute([$normalizedEmail, $normalizedEmail, $currentEmail, $currentEmail]);
                }
            }

            if ($registrationFeeAmount !== null || $registrationFeePaid !== null || $registrationStatus !== null) {
                // Registration fee table was removed; values now come from tbl_registration_payments.
            }
            $this->conn->commit();
            $this->sendJSON(['success' => true, 'message' => 'Student updated']);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Delete student and remove the linked login row
    public function deleteStudent()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $studentId = (int) ($data['student_id'] ?? 0);
        if ($studentId < 1) {
            $this->sendJSON(['error' => 'Student ID is required'], 400);
        }

        try {
            $this->conn->beginTransaction();

            $stmtStudent = $this->conn->prepare("SELECT email FROM tbl_students WHERE student_id = ? LIMIT 1");
            $stmtStudent->execute([$studentId]);
            $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Student not found'], 404);
            }

            if (!empty($student['email'])) {
                $stmtUser = $this->conn->prepare("
                    DELETE u
                    FROM tbl_users u
                    INNER JOIN tbl_roles r ON r.role_id = u.role_id
                    WHERE (u.email = ? OR u.username = ?)
                      AND LOWER(r.role_name) = 'student'
                ");
                $stmtUser->execute([$student['email'], $student['email']]);
            }

            $stmt = $this->conn->prepare("DELETE FROM tbl_students WHERE student_id = ?");
            $stmt->execute([$studentId]);
            if ($stmt->rowCount() === 0) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Student not found'], 404);
            }

            $this->conn->commit();
            $this->sendJSON(['success' => true, 'message' => 'Student deleted']);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Get active students with session package info for admin_package page
    public function getActiveStudents()
    {
        $this->ensureSessionPackageColumn();
        $this->ensureStudentRegistrationFeesTable();
        $branchId = $_GET['branch_id'] ?? null;
        $hasRegistrationSourceCol = $this->tableHasColumn('tbl_students', 'registration_source');

        // Check if session_package_id exists and tbl_session_packages exists (avoid SQL errors)
        $hasPackageCol = false;
        $hasPackagesTable = false;
        try {
            $colCheck = $this->conn->query("SHOW COLUMNS FROM tbl_students LIKE 'session_package_id'");
            $hasPackageCol = $colCheck && $colCheck->rowCount() > 0;
            $tblCheck = $this->conn->query("SHOW TABLES LIKE 'tbl_session_packages'");
            $hasPackagesTable = $tblCheck && $tblCheck->rowCount() > 0;
        } catch (PDOException $e) {
            // Ignore
        }

        if ($hasPackageCol && $hasPackagesTable) {
            $sql = "
                SELECT
                    s.student_id,
                    s.first_name,
                    s.last_name,
                    s.email,
                    s.phone,
                    COALESCE(rf.registration_fee_amount, 1000.00) AS registration_fee_amount,
                    COALESCE(rf.registration_fee_paid, 0.00) AS registration_fee_paid,
                    COALESCE(rf.registration_status, 'Pending') AS registration_status,
                    s.status,
                    s.branch_id,
                    " . ($hasRegistrationSourceCol ? "s.registration_source" : "'online'") . " AS registration_source,
                    s.session_package_id,
                    b.branch_name,
                    sp.package_name,
                    sp.sessions,
                    sp.max_instruments,
                    s.created_at,
                    COALESCE(enr.latest_enrollment_status, '') AS enrollment_status,
                    COALESCE(enr.has_active_enrollment, 0) AS has_active_enrollment,
                    COALESCE(enr.has_completed_enrollment, 0) AS has_completed_enrollment
                FROM tbl_students s
                LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
                LEFT JOIN tbl_session_packages sp ON s.session_package_id = sp.package_id
                LEFT JOIN (
                    SELECT
                        rp.student_id,
                        1000.00 AS registration_fee_amount,
                        COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) AS registration_fee_paid,
                        CASE
                            WHEN COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) >= 1000.00 THEN 'Approved'
                            ELSE 'Pending'
                        END AS registration_status
                    FROM tbl_registration_payments rp
                    GROUP BY rp.student_id
                ) rf ON rf.student_id = s.student_id
                LEFT JOIN (
                    SELECT
                        e.student_id,
                        MAX(CASE WHEN e.status IN ('Active','Pending') THEN 1 ELSE 0 END) AS has_active_enrollment,
                        MAX(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) AS has_completed_enrollment,
                        (SELECT e2.status FROM tbl_enrollments e2
                         WHERE e2.student_id = e.student_id
                         ORDER BY e2.enrollment_id DESC LIMIT 1) AS latest_enrollment_status
                    FROM tbl_enrollments e
                    GROUP BY e.student_id
                ) enr ON enr.student_id = s.student_id
                WHERE 1=1
            ";
        } else {
            $sql = "
                SELECT
                    s.student_id,
                    s.first_name,
                    s.last_name,
                    s.email,
                    s.phone,
                    COALESCE(rf.registration_fee_amount, 1000.00) AS registration_fee_amount,
                    COALESCE(rf.registration_fee_paid, 0.00) AS registration_fee_paid,
                    COALESCE(rf.registration_status, 'Pending') AS registration_status,
                    s.status,
                    s.branch_id,
                    " . ($hasRegistrationSourceCol ? "s.registration_source" : "'online'") . " AS registration_source,
                    b.branch_name,
                    s.created_at,
                    COALESCE(enr.latest_enrollment_status, '') AS enrollment_status,
                    COALESCE(enr.has_active_enrollment, 0) AS has_active_enrollment,
                    COALESCE(enr.has_completed_enrollment, 0) AS has_completed_enrollment
                FROM tbl_students s
                LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
                LEFT JOIN (
                    SELECT
                        rp.student_id,
                        1000.00 AS registration_fee_amount,
                        COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) AS registration_fee_paid,
                        CASE
                            WHEN COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) >= 1000.00 THEN 'Approved'
                            ELSE 'Pending'
                        END AS registration_status
                    FROM tbl_registration_payments rp
                    GROUP BY rp.student_id
                ) rf ON rf.student_id = s.student_id
                LEFT JOIN (
                    SELECT
                        e.student_id,
                        MAX(CASE WHEN e.status IN ('Active','Pending') THEN 1 ELSE 0 END) AS has_active_enrollment,
                        MAX(CASE WHEN e.status = 'Completed' THEN 1 ELSE 0 END) AS has_completed_enrollment,
                        (SELECT e2.status FROM tbl_enrollments e2
                         WHERE e2.student_id = e.student_id
                         ORDER BY e2.enrollment_id DESC LIMIT 1) AS latest_enrollment_status
                    FROM tbl_enrollments e
                    GROUP BY e.student_id
                ) enr ON enr.student_id = s.student_id
                WHERE 1=1
            ";
        }

        $params = [];
        if ($branchId) {
            $sql .= " AND s.branch_id = ?";
            $params[] = $branchId;
        }
        $sql .= " ORDER BY s.first_name ASC, s.last_name ASC";

        try {
            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $students = $stmt->fetchAll(PDO::FETCH_ASSOC);
            // Ensure package fields exist for frontend
            if (!$hasPackageCol || !$hasPackagesTable) {
                foreach ($students as &$row) {
                    $row['session_package_id'] = null;
                    $row['package_name'] = null;
                    $row['sessions'] = null;
                    $row['max_instruments'] = null;
                }
                unset($row);
            }
            foreach ($students as &$row) {
                $this->normalizeWalkInRegistrationStatus($row);
            }
            unset($row);
            $this->sendJSON([
                'success' => true,
                'students' => $students
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Assign/Update session package for a student
    public function assignPackage()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $studentId = (int) ($data['student_id'] ?? 0);
        $packageId = (int) ($data['session_package_id'] ?? 0);

        if ($studentId < 1) {
            $this->sendJSON(['error' => 'Student ID is required'], 400);
        }

        if ($packageId < 1) {
            $this->sendJSON(['error' => 'Session package ID is required'], 400);
        }

        try {
            // Check if student exists
            $checkStudent = $this->conn->prepare("SELECT student_id, branch_id FROM tbl_students WHERE student_id = ?");
            $checkStudent->execute([$studentId]);
            $studentRow = $checkStudent->fetch(PDO::FETCH_ASSOC);
            if (!$studentRow) {
                $this->sendJSON(['error' => 'Student not found'], 404);
            }
            $studentBranchId = (int) ($studentRow['branch_id'] ?? 0);

            // Check if package exists (and enforce branch match when branch_id exists on tbl_session_packages)
            $hasPackageBranchCol = $this->tableHasColumn('tbl_session_packages', 'branch_id');
            if ($hasPackageBranchCol) {
                $checkPackage = $this->conn->prepare("SELECT package_id, branch_id FROM tbl_session_packages WHERE package_id = ?");
                $checkPackage->execute([$packageId]);
                $packageRow = $checkPackage->fetch(PDO::FETCH_ASSOC);
                if (!$packageRow) {
                    $this->sendJSON(['error' => 'Session package not found'], 404);
                }

                $packageBranchId = (int) ($packageRow['branch_id'] ?? 0);
                if ($studentBranchId > 0 && $packageBranchId > 0 && $packageBranchId !== $studentBranchId) {
                    $this->sendJSON(['error' => 'Selected package is not available for this student branch'], 400);
                }
            } else {
                $checkPackage = $this->conn->prepare("SELECT package_id FROM tbl_session_packages WHERE package_id = ?");
                $checkPackage->execute([$packageId]);
                if (!$checkPackage->fetch()) {
                    $this->sendJSON(['error' => 'Session package not found'], 404);
                }
            }

            // Check if session_package_id column exists
            $hasCol = false;
            try {
                $checkCol = $this->conn->query("SHOW COLUMNS FROM tbl_students LIKE 'session_package_id'");
                $hasCol = $checkCol->rowCount() > 0;
            } catch (PDOException $e) {
                // Column might not exist
            }

            if ($hasCol) {
                $stmt = $this->conn->prepare("UPDATE tbl_students SET session_package_id = ? WHERE student_id = ?");
                $stmt->execute([$packageId, $studentId]);
            } else {
                // Try to add column if it doesn't exist
                try {
                    $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN session_package_id INT NULL");
                    $stmt = $this->conn->prepare("UPDATE tbl_students SET session_package_id = ? WHERE student_id = ?");
                    $stmt->execute([$packageId, $studentId]);
                } catch (PDOException $e) {
                    $this->sendJSON(['error' => 'Failed to update student package. Please run migration first.'], 500);
                }
            }

            $this->sendJSON([
                'success' => true,
                'message' => 'Package assigned successfully'
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    /**
     * Student Portal payload:
     * - profile (tbl_students)
     * - branch
     * - session package (if available)
     * - instruments (tbl_student_instruments -> tbl_instruments + type)
     * - guardians (primary + all)
     * - computed balance (registration_fee_amount - registration_fee_paid)
     */
    private function buildStudentPortalById($studentId)
    {
        $this->ensureStudentRegistrationFeesTable();
        $this->ensureStudentInstrumentsTable();
        $this->ensureFreezePaymentsTable();
        $this->ensureStudentRegistrationFeesTable();
        $this->ensureStudentAgeVerificationProofColumn();
        $hasRegistrationReferenceColumn = $this->tableHasColumn('tbl_registration_payments', 'reference_number');
        $registrationReferenceSelect = $hasRegistrationReferenceColumn
            ? "(SELECT rp.reference_number FROM tbl_registration_payments rp WHERE rp.student_id = s.student_id ORDER BY rp.registration_payment_id DESC LIMIT 1) AS registration_reference_number,"
            : "NULL AS registration_reference_number,";

        $stmtStudent = $this->conn->prepare("
            SELECT
                s.*,
                COALESCE(rf.registration_fee_amount, 1000.00) AS registration_fee_amount,
                COALESCE(rf.registration_fee_paid, 0.00) AS registration_fee_paid,
                COALESCE(rf.registration_status, 'Pending') AS registration_status,
                (SELECT rp.status FROM tbl_registration_payments rp WHERE rp.student_id = s.student_id ORDER BY rp.registration_payment_id DESC LIMIT 1) AS registration_payment_status,
                (SELECT rp.payment_method FROM tbl_registration_payments rp WHERE rp.student_id = s.student_id ORDER BY rp.registration_payment_id DESC LIMIT 1) AS registration_payment_method,
                (SELECT rp.receipt_number FROM tbl_registration_payments rp WHERE rp.student_id = s.student_id ORDER BY rp.registration_payment_id DESC LIMIT 1) AS registration_receipt_number,
                {$registrationReferenceSelect}
                b.branch_name
            FROM tbl_students s
            LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
            LEFT JOIN (
                SELECT
                    rp.student_id,
                    1000.00 AS registration_fee_amount,
                    COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) AS registration_fee_paid,
                    CASE
                        WHEN COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) >= 1000.00 THEN 'Approved'
                        ELSE 'Pending'
                    END AS registration_status
                FROM tbl_registration_payments rp
                GROUP BY rp.student_id
            ) rf ON rf.student_id = s.student_id
            WHERE s.student_id = ?
            LIMIT 1
        ");
        $stmtStudent->execute([(int)$studentId]);
        $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);

        if (!$student) {
            return null;
        }

        if (!isset($student['registration_fee_amount'])) $student['registration_fee_amount'] = 1000;
        if (!isset($student['registration_fee_paid'])) $student['registration_fee_paid'] = 0;
        if ((string)($student['status'] ?? '') === 'Rejected') {
            $student['registration_status'] = 'Rejected';
        } elseif (!isset($student['registration_status'])) {
            $student['registration_status'] = 'Pending';
        }
        $this->normalizeWalkInRegistrationStatus($student);
        $student['balance_due'] = 0;
        $student['package_name'] = null;
        $student['package_sessions'] = null;
        $student['package_max_instruments'] = null;
        $student['package_price'] = 0;

        // Instruments currently associated with student
        $instruments = [];
        try {
            $stmtInstruments = $this->conn->prepare("
                SELECT
                    si.instrument_id,
                    si.priority_order,
                    i.instrument_name,
                    i.serial_number,
                    i.`condition`,
                    i.status,
                    it.type_name
                FROM tbl_student_instruments si
                INNER JOIN tbl_instruments i ON si.instrument_id = i.instrument_id
                LEFT JOIN tbl_instrument_types it ON i.type_id = it.type_id
                WHERE si.student_id = ?
                ORDER BY si.priority_order ASC, si.student_instrument_id ASC
            ");
            $stmtInstruments->execute([(int) $student['student_id']]);
            $instruments = $stmtInstruments->fetchAll(PDO::FETCH_ASSOC);
        } catch (PDOException $e) {
            $instruments = [];
        }

        // Guardians
        $guardians = [];
        $primaryGuardian = null;
        try {
            $stmtGuardians = $this->conn->prepare("
                SELECT
                    g.*,
                    sg.is_primary_guardian
                FROM tbl_guardians g
                INNER JOIN tbl_student_guardians sg ON g.guardian_id = sg.guardian_id
                WHERE sg.student_id = ?
                ORDER BY (sg.is_primary_guardian = 'Y') DESC, g.guardian_id ASC
            ");
            $stmtGuardians->execute([(int) $student['student_id']]);
            $guardians = $stmtGuardians->fetchAll(PDO::FETCH_ASSOC);
            if (!empty($guardians)) {
                $primaryGuardian = $guardians[0];
            }
        } catch (PDOException $e) {
            $guardians = [];
            $primaryGuardian = null;
        }

        // Enrollment timeline (current + history)
        $currentEnrollment = null;
        $enrollmentHistory = [];
        $currentSessionGrades = [];
        $issuedCertificate = null;
        $certificateStrengths = [];
        try {
            $paymentsHasType = $this->tableExists('tbl_payments') && $this->tableHasColumn('tbl_payments', 'payment_type');
            $paySummaryPaymentTypeSelect = $paymentsHasType
                ? "SUBSTRING_INDEX(GROUP_CONCAT(p.payment_type ORDER BY p.payment_date DESC, p.payment_id DESC), ',', 1) AS payment_type"
                : "'Partial Payment' AS payment_type";
            $packageNameExpr = "CONCAT('Package #', e.package_id)";
            $packageSessionsExpr = "e.total_sessions";
            $basePackageSessionsExpr = "e.total_sessions";
            $packagePriceExpr = "0";
            $packageJoin = "";
            if ($this->tableExists('tbl_session_packages')) {
                $packageNameExpr = "COALESCE(sp.package_name, CONCAT('Package #', e.package_id))";
                // The enrollment owns the purchased entitlement. The package row
                // is only the base product and must not hide approved add-ons.
                $packageSessionsExpr = "COALESCE(e.total_sessions, sp.sessions, 0)";
                $basePackageSessionsExpr = "COALESCE(sp.sessions, e.total_sessions, 0)";
                $packagePriceExpr = "COALESCE(sp.price, 0)";
                $packageJoin = "LEFT JOIN tbl_session_packages sp ON e.package_id = sp.package_id";
            }

            $sessionJoin = "";
            $firstDateExpr = "e.start_date";
            $firstStartExpr = "NULL";
            $firstEndExpr = "NULL";
            $firstRoomExpr = "NULL";
            $teacherIdExpr = "e.assigned_teacher_id";
            $usedSessionsExpr = "COALESCE(e.completed_sessions, 0)";
            if ($this->tableExists('tbl_sessions')) {
                $usedSessionCondition = $this->tableHasColumn('tbl_sessions', 'counted_in')
                    ? "(COALESCE(used_ts.counted_in, 0) = 1 OR used_ts.status IN ('Completed', 'Late'))"
                    : "used_ts.status IN ('Completed', 'Late')";
                $usedSessionsExpr = "GREATEST(COALESCE(e.completed_sessions, 0), (SELECT COUNT(*) FROM tbl_sessions used_ts WHERE used_ts.enrollment_id = e.enrollment_id AND {$usedSessionCondition}))";
                $todayYmd = date('Y-m-d');
                $excludedUpcomingStatuses = "'Completed', 'Late', 'Cancelled', 'No Show', 'cancelled_by_teacher', 'rescheduled'";
                $sessionJoin = "
                    LEFT JOIN (
                        SELECT
                            s.enrollment_id,
                            s.session_date,
                            s.start_time,
                            s.end_time,
                            s.room_id,
                            s.notes,
                            s.teacher_id
                        FROM tbl_sessions s
                        INNER JOIN (
                            SELECT
                                enrollment_id,
                                MIN(CONCAT(session_date, ' ', COALESCE(start_time, '00:00:00'), ' ', LPAD(session_id, 10, '0'))) AS first_sort_key
                            FROM tbl_sessions
                            WHERE session_date >= " . $this->conn->quote($todayYmd) . "
                              AND status NOT IN ({$excludedUpcomingStatuses})
                            GROUP BY enrollment_id
                        ) first_row
                            ON first_row.enrollment_id = s.enrollment_id
                           AND CONCAT(s.session_date, ' ', COALESCE(s.start_time, '00:00:00'), ' ', LPAD(s.session_id, 10, '0')) = first_row.first_sort_key
                        WHERE s.session_date >= " . $this->conn->quote($todayYmd) . "
                          AND s.status NOT IN ({$excludedUpcomingStatuses})
                    ) fs ON fs.enrollment_id = e.enrollment_id
                ";
                $firstDateExpr = "fs.session_date";
                $firstStartExpr = "fs.start_time";
                $firstEndExpr = "fs.end_time";
                $teacherIdExpr = "COALESCE(e.assigned_teacher_id, fs.teacher_id)";
                if ($this->tableExists('tbl_rooms')) {
                    $sessionJoin .= " LEFT JOIN tbl_rooms rm ON fs.room_id = rm.room_id ";
                    $firstRoomExpr = "COALESCE(NULLIF(TRIM(rm.room_name), ''), NULLIF(TRIM(fs.notes), ''))";
                } else {
                    $firstRoomExpr = "NULLIF(TRIM(fs.notes), '')";
                }
            }

            $stmtEnrollments = $this->conn->prepare("
                SELECT
                    e.enrollment_id,
                    {$packageNameExpr} AS package_name,
                    e.start_date,
                    e.end_date,
                    e.completed_sessions,
                    {$usedSessionsExpr} AS used_sessions,
                    {$firstDateExpr} AS first_session_date,
                    {$firstStartExpr} AS first_start_time,
                    {$firstEndExpr} AS first_end_time,
                    {$firstRoomExpr} AS first_room,
                    COALESCE(pay.payment_type, 'Partial Payment') AS payment_type,
                    {$packagePriceExpr} AS total_amount,
                    COALESCE(pay.paid_amount, 0) AS paid_amount,
                    e.status,
                    e.schedule_request_status,
                    e.reservation_expires_at,
                    e.allowed_absences,
                    e.used_absences,
                    e.consecutive_absences,
                    e.schedule_status,
                    COALESCE((
                        SELECT fp.status
                        FROM tbl_freeze_payments fp
                        WHERE fp.enrollment_id = e.enrollment_id
                        ORDER BY fp.created_at DESC, fp.freeze_payment_id DESC
                        LIMIT 1
                    ), 'None') AS __freeze_payment_status,
                    CASE WHEN COALESCE(e.used_absences, 0) >= GREATEST(
                        CASE
                            WHEN COALESCE(e.allowed_absences, 0) > 0 THEN e.allowed_absences
                            WHEN COALESCE(e.total_sessions, 0) <= 12 THEN 2
                            WHEN COALESCE(e.total_sessions, 0) <= 20 THEN 3
                            ELSE 5
                        END, 1)
                    THEN 1 ELSE 0 END AS schedule_freeze_required,
                    CASE WHEN COALESCE(e.used_absences, 0) >= GREATEST(
                        CASE
                            WHEN COALESCE(e.allowed_absences, 0) > 0 THEN e.allowed_absences
                            WHEN COALESCE(e.total_sessions, 0) <= 12 THEN 2
                            WHEN COALESCE(e.total_sessions, 0) <= 20 THEN 3
                            ELSE 5
                        END, 1)
                    THEN 100 ELSE 0 END AS reservation_fee_amount,
                    {$packageSessionsExpr} AS package_sessions,
                    {$basePackageSessionsExpr} AS base_package_sessions,
                    1 AS package_max_instruments,
                    t.first_name AS teacher_first_name,
                    t.last_name AS teacher_last_name
                FROM tbl_enrollments e
                {$packageJoin}
                {$sessionJoin}
                LEFT JOIN (
                    SELECT
                        p.enrollment_id,
                        SUM(CASE WHEN p.status = 'Paid' THEN p.amount ELSE 0 END) AS paid_amount,
                        {$paySummaryPaymentTypeSelect}
                    FROM tbl_payments p
                    GROUP BY p.enrollment_id
                ) pay ON pay.enrollment_id = e.enrollment_id
                LEFT JOIN tbl_teachers t ON t.teacher_id = {$teacherIdExpr}
                WHERE e.student_id = ?
                ORDER BY e.enrollment_id DESC
            ");
            $stmtEnrollments->execute([(int)$student['student_id']]);
            $allEnrollments = $stmtEnrollments->fetchAll(PDO::FETCH_ASSOC);

            foreach ($allEnrollments as &$enrollmentRow) {
                $balanceData = $this->balanceEnrollment((int)$enrollmentRow['enrollment_id']);
                if ($balanceData) {
                    foreach (['total_amount', 'paid_amount', 'balance_amount', 'deadline_session',
                        'sessions_used', 'sessions_remaining', 'payment_status', 'payment_history'] as $field) {
                        $enrollmentRow[$field] = $balanceData[$field];
                    }
                }
            }
            unset($enrollmentRow);

            if (!empty($allEnrollments)) {
                $currentIndex = null;
                foreach ($allEnrollments as $idx => $row) {
                    $st = (string)($row['status'] ?? '');
                    if ($st === 'Active' || $st === 'Pending') {
                        $currentIndex = $idx;
                        break;
                    }
                }
                if ($currentIndex === null) $currentIndex = 0;
                $currentEnrollment = $allEnrollments[$currentIndex];
                $student['package_name'] = $currentEnrollment['package_name'] ?? null;
                $student['package_sessions'] = $currentEnrollment['package_sessions'] ?? null;
                $student['package_max_instruments'] = $currentEnrollment['package_max_instruments'] ?? null;
                $student['package_price'] = (float)($currentEnrollment['total_amount'] ?? 0);
                $student['balance_due'] = max(0, (float)$student['package_price'] - (float)($currentEnrollment['paid_amount'] ?? 0));
                $currentSessionGrades = $this->getStudentEnrollmentSessionGrades((int)$student['student_id'], (int)($currentEnrollment['enrollment_id'] ?? 0));
                $packageSessions = max(0, (int)($currentEnrollment['package_sessions'] ?? 0));
                $completedSessions = max(0, (int)($currentEnrollment['completed_sessions'] ?? 0));
                $gradedSessions = 0;
                if (!empty($currentSessionGrades)) {
                    foreach ($currentSessionGrades as $gradeRow) {
                        if ((int)($gradeRow['progress_id'] ?? 0) > 0) {
                            $gradedSessions++;
                        }
                    }
                }
                $currentEnrollment['certificate_available'] = 0;
                foreach ($allEnrollments as $idx => $row) {
                    if ($idx === $currentIndex) continue;
                    $enrollmentHistory[] = $row;
                }
            }

            // Certificates come only from explicitly issued achievement records,
            // never from enrollment status or the number of lessons used.
            if ($this->tableExists('tbl_student_certificates')) {
                try {
                    $stmtCertificate = $this->conn->prepare("
                        SELECT c.certificate_id, c.certificate_number, c.achieved_level,
                               c.issued_at, c.instrument_id,
                               COALESCE(NULLIF(TRIM(it.type_name), ''), i.instrument_name) AS instrument_name,
                               pe.exam_id AS promotional_exam_id, pe.exam_date, pe.result AS exam_result,
                               pe.grade_rating AS exam_rating, pe.examiner_notes,
                               CONCAT(COALESCE(ct.first_name, ''), ' ', COALESCE(ct.last_name, '')) AS issuing_teacher_name
                        FROM tbl_student_certificates c
                        LEFT JOIN tbl_instruments i ON i.instrument_id = c.instrument_id
                        LEFT JOIN tbl_instrument_types it ON it.type_id = i.type_id
                        LEFT JOIN tbl_promotional_exams pe ON pe.exam_id = c.promotional_exam_id
                        LEFT JOIN tbl_teachers ct ON ct.teacher_id = c.issued_by
                        WHERE c.student_id = ? AND c.status = 'Issued' AND pe.result = 'Passed'
                        ORDER BY c.issued_at DESC, c.certificate_id DESC
                        LIMIT 1
                    ");
                    $stmtCertificate->execute([(int)$student['student_id']]);
                    $issuedCertificate = $stmtCertificate->fetch(PDO::FETCH_ASSOC) ?: null;
                    if ($issuedCertificate && $this->tableExists('tbl_student_progress')) {
                        $strengthStmt = $this->conn->prepare("SELECT p.criteria_scores,p.performance_score,p.technique_score,p.rhythm_score,p.focus_score,p.assignment_score FROM tbl_student_progress p LEFT JOIN tbl_sessions ts ON ts.session_id=p.session_id LEFT JOIN tbl_enrollments e ON e.enrollment_id=ts.enrollment_id WHERE p.student_id=? AND COALESCE(p.instrument_id,ts.instrument_id,e.instrument_id)=? AND (p.assessment_date IS NULL OR p.assessment_date<=?) ORDER BY p.assessment_date DESC,p.progress_id DESC");
                        $strengthStmt->execute([(int)$student['student_id'],(int)$issuedCertificate['instrument_id'],(string)($issuedCertificate['exam_date']??$issuedCertificate['issued_at'])]);
                        $scoreGroups = [];
                        foreach ($strengthStmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $grade) {
                            $criteria = json_decode((string)($grade['criteria_scores']??''),true);
                            if (is_array($criteria) && $criteria) {
                                foreach ($criteria as $criterion) {
                                    $label=trim((string)($criterion['name']??'')); $score=(int)round((float)($criterion['score']??0));
                                    if ($label!=='' && $score>=1 && $score<=5) $scoreGroups[$label][]=$score;
                                }
                            } else {
                                foreach (['Performance'=>'performance_score','Technique'=>'technique_score','Rhythm'=>'rhythm_score','Focus'=>'focus_score','Practice'=>'assignment_score'] as $label=>$column) {
                                    $score=(int)round((float)($grade[$column]??0)); if ($score>=1 && $score<=5) $scoreGroups[$label][]=$score;
                                }
                            }
                        }
                        foreach ($scoreGroups as $label=>$scores) $certificateStrengths[]=['name'=>$label,'average'=>(int)round(array_sum($scores)/count($scores))];
                        usort($certificateStrengths,function($a,$b){return $b['average']<=>$a['average'];});
                        $certificateStrengths=array_slice(array_values(array_filter($certificateStrengths,function($row){return $row['average']>=4;})),0,3);
                    }
                } catch (PDOException $e) {
                    $issuedCertificate = null;
                }
            }
            if ($currentEnrollment) {
                $currentEnrollment['certificate_available'] = $issuedCertificate ? 1 : 0;
            }
        } catch (PDOException $e) {
            $currentEnrollment = null;
            $enrollmentHistory = [];
            $currentSessionGrades = [];
        }

        $learningProgress = [];
        $learningHistory = [];
        $promotionalExams = [];
        try {
            if ($this->tableExists('tbl_student_learning_levels')) {
                $stmtLearning = $this->conn->prepare("
                    SELECT ll.learning_level_id, ll.student_id, ll.instrument_id,
                           COALESCE(NULLIF(TRIM(it.type_name), ''), i.instrument_name) AS instrument_name,
                           ll.teacher_id, ll.level_name,
                           ll.book_material, ll.current_topic, ll.instructor_notes,
                           ll.skills_developing, ll.areas_for_improvement,
                           ll.assessment_readiness, ll.status, ll.started_at,
                           ll.achieved_at, ll.achieved_exam_id,
                           c.certificate_id, c.certificate_number, c.issued_at
                    FROM tbl_student_learning_levels ll
                    LEFT JOIN tbl_instruments i ON i.instrument_id = ll.instrument_id
                    LEFT JOIN tbl_instrument_types it ON it.type_id = i.type_id
                    LEFT JOIN tbl_student_certificates c
                      ON c.learning_level_id = ll.learning_level_id AND c.status = 'Issued'
                    WHERE ll.student_id = ?
                    ORDER BY ll.instrument_id, ll.started_at DESC, ll.learning_level_id DESC
                ");
                $stmtLearning->execute([(int)$student['student_id']]);
                $learningRows = $stmtLearning->fetchAll(PDO::FETCH_ASSOC) ?: [];
                foreach ($learningRows as $row) {
                    if (($row['status'] ?? '') === 'In Progress') $learningProgress[] = $row;
                    else $learningHistory[] = $row;
                }
            }
            if ($this->tableExists('tbl_promotional_exams')) {
                $stmtExams = $this->conn->prepare("
                    SELECT pe.exam_id, pe.instrument_id,
                           COALESCE(NULLIF(TRIM(it.type_name), ''), i.instrument_name) AS instrument_name,
                           pe.learning_level_id, pe.assessed_level, pe.exam_date,
                           pe.grade_rating, pe.result, pe.examiner_notes
                    FROM tbl_promotional_exams pe
                    LEFT JOIN tbl_instruments i ON i.instrument_id = pe.instrument_id
                    LEFT JOIN tbl_instrument_types it ON it.type_id = i.type_id
                    WHERE pe.student_id = ?
                    ORDER BY pe.exam_date DESC, pe.exam_id DESC
                ");
                $stmtExams->execute([(int)$student['student_id']]);
                $promotionalExams = $stmtExams->fetchAll(PDO::FETCH_ASSOC) ?: [];
            }
        } catch (PDOException $e) {
            $learningProgress = [];
            $learningHistory = [];
            $promotionalExams = [];
        }

        return [
            'student' => $student,
            'guardians' => $guardians,
            'primary_guardian' => $primaryGuardian,
            'instruments' => $instruments,
            'current_enrollment' => $currentEnrollment,
            'enrollment_history' => $enrollmentHistory,
            'current_session_grades' => $currentSessionGrades,
            'learning_progress' => $learningProgress,
            'learning_history' => $learningHistory,
            'promotional_exams' => $promotionalExams,
            'latest_session_extension_request' => $this->getLatestStudentSessionExtensionRequest((int)$student['student_id']),
            'certificate' => [
                'available' => $issuedCertificate !== null,
                'certificate_id' => $issuedCertificate['certificate_id'] ?? null,
                'certificate_number' => $issuedCertificate['certificate_number'] ?? null,
                'achieved_level' => $issuedCertificate['achieved_level'] ?? null,
                'instrument_name' => $issuedCertificate['instrument_name'] ?? null,
                'promotional_exam_id' => $issuedCertificate['promotional_exam_id'] ?? null,
                'exam_date' => $issuedCertificate['exam_date'] ?? null,
                'exam_result' => $issuedCertificate['exam_result'] ?? null,
                'exam_rating' => $issuedCertificate['exam_rating'] ?? null,
                'examiner_notes' => $issuedCertificate['examiner_notes'] ?? null,
                'strengths' => $certificateStrengths,
                'student_name' => trim((string)($student['first_name'] ?? '') . ' ' . (string)($student['last_name'] ?? '')),
                'teacher_name' => trim((string)($issuedCertificate['issuing_teacher_name'] ?? '')),
                'issue_date' => $issuedCertificate['issued_at'] ?? null
            ]
        ];
    }

    // Set student status (Active/Inactive) and sync login account
    public function setStudentStatus()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $studentId = (int) ($data['student_id'] ?? 0);
        $status = isset($data['status']) ? trim((string)$data['status']) : '';

        if ($studentId < 1) {
            $this->sendJSON(['error' => 'Student ID is required'], 400);
        }
        if (!in_array($status, ['Active', 'Inactive'], true)) {
            $this->sendJSON(['error' => 'Invalid status'], 400);
        }

        try {
            $stmtStudent = $this->conn->prepare("SELECT email FROM tbl_students WHERE student_id = ? LIMIT 1");
            $stmtStudent->execute([$studentId]);
            $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendJSON(['error' => 'Student not found'], 404);
            }

            $stmt = $this->conn->prepare("UPDATE tbl_students SET status = ? WHERE student_id = ?");
            $stmt->execute([$status, $studentId]);

            if (!empty($student['email'])) {
                $stmtUser = $this->conn->prepare("
                    UPDATE tbl_users
                    SET status = ?
                    WHERE email = ?
                ");
                $stmtUser->execute([$status, $student['email']]);
            }

            $this->sendJSON(['success' => true, 'message' => "Student status updated to {$status}"]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function getStudentPortal()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $email = trim($_GET['email'] ?? '');
        if ($email === '') {
            $this->sendJSON(['error' => 'Email is required'], 400);
        }

        $actor = fas_require_authenticated_user($this->conn);
        if (fas_normalize_role_category($actor['role_name'] ?? '') === 'student'
            && strcasecmp((string)($actor['email'] ?? ''), $email) !== 0) {
            $this->sendJSON(['error' => 'You can only view your own student portal'], 403);
        }

        try {
            $stmt = $this->conn->prepare("SELECT student_id FROM tbl_students WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $studentId = (int) $stmt->fetchColumn();
            $role = fas_normalize_role_category($actor['role_name'] ?? '');
            if ($studentId > 0 && $role === 'guardian') {
                $access = $this->conn->prepare('SELECT 1 FROM tbl_student_guardians sg JOIN tbl_guardians g ON g.guardian_id = sg.guardian_id WHERE sg.student_id = ? AND g.email = ? LIMIT 1');
                $access->execute([$studentId, (string)($actor['email'] ?? '')]);
                if (!$access->fetchColumn()) $this->sendJSON(['error' => 'Student is not linked to this guardian'], 403);
            } elseif ($studentId > 0 && in_array($role, ['staff', 'manager'], true)) {
                $access = $this->conn->prepare('SELECT 1 FROM tbl_students WHERE student_id = ? AND branch_id = ? LIMIT 1');
                $access->execute([$studentId, (int)($actor['branch_id'] ?? 0)]);
                if (!$access->fetchColumn()) $this->sendJSON(['error' => 'Student is outside your branch'], 403);
            } elseif ($studentId > 0 && !in_array($role, ['student', 'guardian', 'staff', 'manager', 'admin', 'owner'], true)) {
                $this->sendJSON(['error' => 'Student portal access denied'], 403);
            }
            if ($studentId < 1) {
                $this->sendJSON([
                    'success' => true,
                    'registration_required' => true,
                    'message' => 'Your previous registration is no longer active. Please register again to continue.',
                    'student' => null,
                    'guardians' => [],
                    'primary_guardian' => null,
                    'instruments' => [],
                    'current_enrollment' => null,
                    'enrollment_history' => [],
                    'current_session_grades' => []
                ]);
            }

            $payload = $this->buildStudentPortalById($studentId);
            if (!$payload) {
                $this->sendJSON([
                    'success' => true,
                    'registration_required' => true,
                    'message' => 'Your previous registration is no longer active. Please register again to continue.',
                    'student' => null,
                    'guardians' => [],
                    'primary_guardian' => null,
                    'instruments' => [],
                    'current_enrollment' => null,
                    'enrollment_history' => [],
                    'current_session_grades' => []
                ]);
            }

            $this->sendJSON(array_merge(['success' => true], $payload));
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function findGuardianByEmail()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $email = trim($_GET['email'] ?? '');
        if ($email === '') {
            $this->sendJSON(['error' => 'Email is required'], 400);
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT guardian_id, first_name, last_name, email, phone, relationship_type, status
                FROM tbl_guardians
                WHERE email = ?
                LIMIT 1
            ");
            $stmt->execute([$email]);
            $guardian = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$guardian) {
                $this->sendJSON(['error' => 'Guardian not found for this email'], 404);
            }

            $stmtUser = $this->conn->prepare("
                SELECT u.user_id
                FROM tbl_users u
                INNER JOIN tbl_roles r ON r.role_id = u.role_id
                WHERE r.role_name = 'Guardians'
                  AND (u.email = ? OR u.username = ?)
                LIMIT 1
            ");
            $stmtUser->execute([$email, $email]);
            if (!$stmtUser->fetch()) {
                $this->sendJSON([
                    'error' => 'Guardian account exists in records but has no active user login. Please ask the guardian to register first.'
                ], 400);
            }

            $this->sendJSON(['success' => true, 'guardian' => $guardian]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function setGuardianMode()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $studentId = (int)($data['student_id'] ?? 0);
        $mode = trim((string)($data['guardian_mode'] ?? ''));
        $guardianEmail = trim((string)($data['guardian_email'] ?? ''));
        $guardianFirstName = trim((string)($data['guardian_first_name'] ?? ''));
        $guardianLastName = trim((string)($data['guardian_last_name'] ?? ''));
        $guardianPhone = trim((string)($data['guardian_phone'] ?? ''));
        $guardianRelationship = trim((string)($data['guardian_relationship'] ?? ''));
        $guardianPasswordMode = strtolower(trim((string)($data['guardian_password_mode'] ?? 'default')));
        $guardianCustomPassword = (string)($data['guardian_password'] ?? '');

        if ($studentId < 1) {
            $this->sendJSON(['error' => 'student_id is required'], 400);
        }
        if (!in_array($mode, ['With Guardian', 'Without Guardian'], true)) {
            $this->sendJSON(['error' => 'guardian_mode must be With Guardian or Without Guardian'], 400);
        }

        try {
            if ($mode === 'Without Guardian') {
                $stmtDel = $this->conn->prepare("DELETE FROM tbl_student_guardians WHERE student_id = ?");
                $stmtDel->execute([$studentId]);
                $this->sendJSON([
                    'success' => true,
                    'message' => 'Guardian removed. You can proceed without a guardian.'
                ]);
            }

            if ($guardianEmail === '') {
                $this->sendJSON(['error' => 'guardian_email is required for With Guardian'], 400);
            }
            if (!filter_var($guardianEmail, FILTER_VALIDATE_EMAIL)) {
                $this->sendJSON(['error' => 'A valid guardian email is required'], 400);
            }

            $stmtGuardian = $this->conn->prepare("
                SELECT guardian_id, first_name, last_name, email, phone, relationship_type, status
                FROM tbl_guardians
                WHERE email = ?
                LIMIT 1
            ");
            $stmtGuardian->execute([$guardianEmail]);
            $guardian = $stmtGuardian->fetch(PDO::FETCH_ASSOC);

            $guardianUserId = null;
            $guardianRoleId = null;
            $guardianNeedsVerification = false;
            $roleStmt = $this->conn->prepare("SELECT role_id FROM tbl_roles WHERE role_name = 'Guardians' LIMIT 1");
            $roleStmt->execute();
            $role = $roleStmt->fetch(PDO::FETCH_ASSOC);
            if ($role && isset($role['role_id'])) {
                $guardianRoleId = (int)$role['role_id'];
            }
            if ($guardianRoleId < 1) {
                $this->sendJSON(['error' => 'Guardian role not found. Please contact admin.'], 500);
            }

            if ($guardianPasswordMode === 'custom') {
                if (strlen($guardianCustomPassword) < 8) {
                    $this->sendJSON(['error' => 'Custom guardian password must be at least 8 characters long'], 400);
                }
                if (!preg_match('/[A-Z]/', $guardianCustomPassword)) {
                    $this->sendJSON(['error' => 'Custom guardian password must contain at least one uppercase letter'], 400);
                }
                if (!preg_match('/[a-z]/', $guardianCustomPassword)) {
                    $this->sendJSON(['error' => 'Custom guardian password must contain at least one lowercase letter'], 400);
                }
                if (!preg_match('/[0-9]/', $guardianCustomPassword)) {
                    $this->sendJSON(['error' => 'Custom guardian password must contain at least one number'], 400);
                }
                if (!preg_match('/[!@#$%^&*]/', $guardianCustomPassword)) {
                    $this->sendJSON(['error' => 'Custom guardian password must contain at least one special character (!@#$%^&*)'], 400);
                }
            }

            $stmtUser = $this->conn->prepare("
                SELECT u.user_id, u.status, u.email_verified_at, r.role_name
                FROM tbl_users u
                INNER JOIN tbl_roles r ON r.role_id = u.role_id
                WHERE (LOWER(TRIM(u.email)) = LOWER(TRIM(?))
                    OR LOWER(TRIM(u.username)) = LOWER(TRIM(?)))
                  AND LOWER(TRIM(r.role_name)) IN ('guardian', 'guardians')
                LIMIT 1
            ");
            $stmtUser->execute([$guardianEmail, $guardianEmail]);
            $guardianUser = $stmtUser->fetch(PDO::FETCH_ASSOC);
            $guardianLoginIdentifier = $this->buildGuardianUsername($studentId, $guardianEmail);
            $guardianDbUsername = $guardianLoginIdentifier;
            if ($guardianUser) {
                $guardianUserId = (int)$guardianUser['user_id'];
            }

            $createdGuardianAccount = false;
            $guardianPasswordToUse = trim($guardianCustomPassword);
            $mailError = null;
            $this->conn->beginTransaction();

            if (!$guardian) {
                if ($guardianFirstName === '' || $guardianLastName === '' || $guardianPhone === '' || $guardianRelationship === '') {
                    $this->sendJSON([
                        'error' => 'Guardian details (name, phone, relationship) are required when creating a new guardian.'
                    ], 400);
                }

                $stmtInsertGuardian = $this->conn->prepare("
                    INSERT INTO tbl_guardians (
                        first_name, last_name, relationship_type, phone, email, status
                    ) VALUES (?, ?, ?, ?, ?, 'Active')
                ");
                $stmtInsertGuardian->execute([
                    $guardianFirstName,
                    $guardianLastName,
                    $guardianRelationship,
                    $guardianPhone,
                    $guardianEmail
                ]);

                $guardian = [
                    'guardian_id' => (int)$this->conn->lastInsertId(),
                    'first_name' => $guardianFirstName,
                    'last_name' => $guardianLastName,
                    'email' => $guardianEmail,
                    'phone' => $guardianPhone,
                    'relationship_type' => $guardianRelationship,
                    'status' => 'Active'
                ];
            }

            if (!$guardianUserId) {
                if ($guardianPasswordToUse === '') {
                    $this->sendJSON(['error' => 'guardian_password is required'], 400);
                }
                $hashedPassword = password_hash($guardianPasswordToUse, PASSWORD_DEFAULT);
                $guardianUserStatus = $guardianNeedsVerification ? 'Inactive' : 'Active';
                $stmtCreateUser = $this->conn->prepare("
                    INSERT INTO tbl_users (
                        username, password, role_id, first_name, last_name, email, phone, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $stmtCreateUser->execute([
                    $guardianDbUsername,
                    $hashedPassword,
                    $guardianRoleId,
                    $guardian['first_name'] ?? $guardianFirstName,
                    $guardian['last_name'] ?? $guardianLastName,
                    $guardianEmail,
                    $guardian['phone'] ?? $guardianPhone,
                    $guardianUserStatus
                ]);
                $guardianUserId = (int)$this->conn->lastInsertId();
                $createdGuardianAccount = true;
            } else {
                $stmtUpdateUser = $this->conn->prepare("
                    UPDATE tbl_users
                    SET username = ?,
                        email = ?,
                        first_name = ?,
                        last_name = ?,
                        phone = ?,
                        status = 'Active'
                    WHERE user_id = ?
                ");
                $stmtUpdateUser->execute([
                    $guardianDbUsername,
                    $guardianEmail,
                    $guardian['first_name'] ?? $guardianFirstName,
                    $guardian['last_name'] ?? $guardianLastName,
                    $guardian['phone'] ?? $guardianPhone,
                    $guardianUserId
                ]);
            }

            if ($guardianNeedsVerification) {
                $stmtDeactivateGuardian = $this->conn->prepare("
                    UPDATE tbl_users
                    SET status = 'Inactive'
                    WHERE user_id = ?
                ");
                $stmtDeactivateGuardian->execute([$guardianUserId]);

                $verificationResult = $this->issueEmailVerificationCode(
                    $guardianUserId,
                    $guardianEmail,
                    trim(($guardian['first_name'] ?? $guardianFirstName) . ' ' . ($guardian['last_name'] ?? $guardianLastName))
                );
                if (!(bool)($verificationResult['email_sent'] ?? false)) {
                    $mailError = $verificationResult['mail_error'] ?? 'Verification email could not be sent.';
                }
            } elseif ($this->hasUserColumn('email_verified_at')) {
                $stmtActivateGuardian = $this->conn->prepare("
                    UPDATE tbl_users
                    SET status = 'Active',
                        email_verified_at = COALESCE(email_verified_at, NOW()),
                        email_verification_code_hash = NULL,
                        email_verification_code_expires_at = NULL,
                        email_verification_sent_at = NULL
                    WHERE user_id = ?
                ");
                $stmtActivateGuardian->execute([$guardianUserId]);
            }

            $stmtUnset = $this->conn->prepare("
                UPDATE tbl_student_guardians
                SET is_primary_guardian = 'N'
                WHERE student_id = ?
            ");
            $stmtUnset->execute([$studentId]);

            $stmtCheck = $this->conn->prepare("
                SELECT student_guardian_id
                FROM tbl_student_guardians
                WHERE student_id = ? AND guardian_id = ?
                LIMIT 1
            ");
            $stmtCheck->execute([$studentId, (int)$guardian['guardian_id']]);
            $existing = $stmtCheck->fetch(PDO::FETCH_ASSOC);

            if ($existing) {
                $stmtUpdateLink = $this->conn->prepare("
                    UPDATE tbl_student_guardians
                    SET is_primary_guardian = 'Y', can_enroll = 'Y', can_pay = 'Y', emergency_contact = 'Y'
                    WHERE student_guardian_id = ?
                ");
                $stmtUpdateLink->execute([(int)$existing['student_guardian_id']]);
            } else {
                $stmtLink = $this->conn->prepare("
                    INSERT INTO tbl_student_guardians (
                        student_id, guardian_id, is_primary_guardian, can_enroll, can_pay, emergency_contact
                    ) VALUES (?, ?, 'Y', 'Y', 'Y', 'Y')
                ");
                $stmtLink->execute([$studentId, (int)$guardian['guardian_id']]);
            }

            $this->conn->commit();

            $message = 'Guardian linked successfully.';
            if ($createdGuardianAccount) {
                $message = $guardianPasswordMode === 'custom'
                    ? 'Guardian account created and linked with the password you provided.'
                    : 'Guardian account created and linked with the same password used during registration.';
            }

            $this->sendJSON([
                'success' => true,
                'message' => $message,
                'guardian' => $guardian,
                'guardian_created' => $createdGuardianAccount,
                'guardian_login_generated' => true,
                'guardian_username' => $guardianLoginIdentifier,
                'guardian_temporary_password' => $guardianPasswordToUse,
                'student_login_identifier' => $this->buildStudentLoginIdentifier($studentId),
                'mail_error' => $mailError,
                'guardian_password_mode' => $guardianPasswordMode
            ]);
        } catch (PDOException $e) {
            if ($this->conn && $this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            error_log('setGuardianMode PDOException: ' . $e->getMessage());
            $this->sendJSON([
                'error' => 'Database error: ' . $e->getMessage(),
                'sqlstate' => $e->getCode()
            ], 500);
        }
    }

    public function guardianRegisterChild()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $isMultipart = $this->isMultipartRequest();
        $data = $isMultipart ? ($_POST ?: []) : (json_decode(file_get_contents('php://input'), true) ?: []);

        foreach (['guardian_email', 'student_first_name', 'student_last_name', 'student_date_of_birth', 'branch_id', 'password', 'payment_method', 'reference_number'] as $key) {
            if (isset($data[$key]) && is_string($data[$key])) {
                $data[$key] = trim($data[$key]);
            }
        }

        $guardianEmail = trim((string)($data['guardian_email'] ?? ''));
        $studentFirstName = trim((string)($data['student_first_name'] ?? ''));
        $studentLastName = trim((string)($data['student_last_name'] ?? ''));
        $studentDob = trim((string)($data['student_date_of_birth'] ?? ''));
        $branchId = (int)($data['branch_id'] ?? 0);
        $password = (string)($data['password'] ?? '');
        $paymentMethod = trim((string)($data['payment_method'] ?? ''));
        $referenceNumber = trim((string)($data['reference_number'] ?? ''));

        if ($guardianEmail === '') {
            $this->sendJSON(['error' => 'guardian_email is required'], 400);
        }
        if ($studentFirstName === '' || $studentLastName === '' || $studentDob === '' || $branchId < 1 || $password === '' || $paymentMethod === '' || $referenceNumber === '') {
            $this->sendJSON(['error' => 'All required child details and payment information must be filled in'], 400);
        }

        $age = $this->calculateAgeFromDateOfBirth($studentDob);
        if ($age === null || $age < 3) {
            $this->sendJSON(['error' => 'Student date of birth is invalid or too young'], 400);
        }
        if (strlen($password) < 8 || !preg_match('/[A-Z]/', $password) || !preg_match('/[a-z]/', $password) || !preg_match('/[0-9]/', $password) || !preg_match('/[!@#$%^&*]/', $password)) {
            $this->sendJSON(['error' => 'Password must be at least 8 characters and include uppercase, lowercase, number, and special character'], 400);
        }

        $registrationFeeAmount = 1000.00;
        $registrationProofPath = null;
        $ageVerificationProofPath = null;
        if ($isMultipart && isset($_FILES['registration_proof_file'])) {
            try {
                $registrationProofPath = $this->storePaymentProofUpload($_FILES['registration_proof_file'], 'registration');
            } catch (Exception $e) {
                $this->sendJSON(['error' => $e->getMessage()], 400);
            }
        }
        if ($isMultipart && isset($_FILES['age_verification_proof_file'])) {
            try {
                $ageVerificationProofPath = $this->storeVerificationProofUpload($_FILES['age_verification_proof_file'], 'age_verification');
            } catch (Exception $e) {
                $this->sendJSON(['error' => $e->getMessage()], 400);
            }
        }
        if (empty($registrationProofPath)) {
            $this->sendJSON(['error' => 'Registration payment proof is required'], 400);
        }
        if (empty($ageVerificationProofPath)) {
            $this->sendJSON(['error' => 'ID proof is required'], 400);
        }

        try {
            $this->ensureUserVerificationColumns();
            $this->ensureStudentRegistrationColumns();
            $this->ensureStudentRegistrationSourceColumn();
            $this->ensureStudentRegistrationProofColumn();
            $this->ensureStudentAgeVerificationProofColumn();

            $studentPhone = trim((string)($data['student_phone'] ?? ''));
            $studentAddress = trim((string)($data['student_address'] ?? ''));
            $studentEmail = '';

            $stmtGuardian = $this->conn->prepare("
                SELECT g.guardian_id, g.first_name, g.last_name, g.email, g.phone, r.role_name, u.user_id AS guardian_user_id
                FROM tbl_guardians g
                LEFT JOIN tbl_users u ON LOWER(TRIM(u.email)) = LOWER(TRIM(g.email)) OR LOWER(TRIM(u.username)) = LOWER(TRIM(g.email))
                LEFT JOIN tbl_roles r ON r.role_id = u.role_id
                WHERE LOWER(TRIM(g.email)) = LOWER(TRIM(?))
                LIMIT 1
            ");
            $stmtGuardian->execute([$guardianEmail]);
            $guardian = $stmtGuardian->fetch(PDO::FETCH_ASSOC);
            if (!$guardian) {
                $this->sendJSON(['error' => 'Guardian not found for this email'], 404);
            }

            $this->conn->beginTransaction();

            $studentColumns = ['branch_id', 'first_name', 'last_name', 'phone', 'email', 'status'];
            $studentValues = [
                $branchId,
                $studentFirstName,
                $studentLastName,
                $studentPhone !== '' ? $studentPhone : '',
                $studentEmail,
                'Inactive'
            ];
            if ($this->hasStudentColumn('date_of_birth')) {
                $studentColumns[] = 'date_of_birth';
                $studentValues[] = $studentDob;
            }
            if ($this->hasStudentColumn('age')) {
                $studentColumns[] = 'age';
                $studentValues[] = $age;
            }
            if ($this->hasStudentColumn('address')) {
                $studentColumns[] = 'address';
                $studentValues[] = $studentAddress !== '' ? $studentAddress : '';
            }
            if ($this->hasStudentColumn('registration_source')) {
                $studentColumns[] = 'registration_source';
                $studentValues[] = 'guardian-portal';
            }

            $studentPlaceholders = implode(', ', array_fill(0, count($studentColumns), '?'));
            $stmtStudent = $this->conn->prepare("
                INSERT INTO tbl_students (" . implode(', ', $studentColumns) . ")
                VALUES ({$studentPlaceholders})
            ");
            $stmtStudent->execute($studentValues);
            $studentId = (int)$this->conn->lastInsertId();
            $studentLoginIdentifier = $this->buildStudentLoginIdentifier($studentId);
            $studentEmail = $studentLoginIdentifier;
            if ($this->hasStudentColumn('email')) {
                $stmtUpdateStudentEmail = $this->conn->prepare("
                    UPDATE tbl_students
                    SET email = ?
                    WHERE student_id = ?
                ");
                $stmtUpdateStudentEmail->execute([$studentEmail, $studentId]);
            }

            if ($this->hasStudentColumn('registration_proof_path')) {
                $stmtProof = $this->conn->prepare("
                    UPDATE tbl_students
                    SET registration_proof_path = ?
                    WHERE student_id = ?
                ");
                $stmtProof->execute([$registrationProofPath, $studentId]);
            }
            if ($this->hasStudentColumn('age_verification_proof_path')) {
                $stmtAgeProof = $this->conn->prepare("
                    UPDATE tbl_students
                    SET age_verification_proof_path = ?
                    WHERE student_id = ?
                ");
                $stmtAgeProof->execute([$ageVerificationProofPath, $studentId]);
            }

            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $studentRoleId = null;
            $stmtRole = $this->conn->prepare("SELECT role_id FROM tbl_roles WHERE role_name = 'Student' LIMIT 1");
            $stmtRole->execute();
            $studentRoleId = (int)($stmtRole->fetchColumn() ?: 0);
            if ($studentRoleId < 1) {
                throw new Exception('Student role not found');
            }

            $stmtUser = $this->conn->prepare("
                INSERT INTO tbl_users (
                    username, password, role_id, first_name, last_name, email, phone, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, 'Inactive')
            ");
            $stmtUser->execute([
                $studentLoginIdentifier,
                $hashedPassword,
                $studentRoleId,
                $studentFirstName,
                $studentLastName,
                $studentEmail,
                $studentPhone
            ]);
            $studentUserId = (int)$this->conn->lastInsertId();
            if ($this->hasUserColumn('email_verified_at')) {
                $stmtMarkUnverified = $this->conn->prepare("
                    UPDATE tbl_users
                    SET status = 'Inactive',
                        email_verified_at = NULL,
                        email_verification_code_hash = NULL,
                        email_verification_code_expires_at = NULL,
                        email_verification_sent_at = NULL
                    WHERE user_id = ?
                ");
                $stmtMarkUnverified->execute([$studentUserId]);
            }

            $paymentColumns = ['student_id', 'payment_date', 'amount', 'payment_method', 'status', 'receipt_number'];
            $paymentPlaceholders = ['?', 'CURRENT_DATE', '?', '?', "'Pending'", '?'];
            $paymentValues = [
                $studentId,
                $registrationFeeAmount,
                $paymentMethod,
                'REG-GUARDIAN-' . time()
            ];
            if ($this->tableHasColumn('tbl_registration_payments', 'reference_number')) {
                $paymentColumns[] = 'reference_number';
                $paymentPlaceholders[] = '?';
                $paymentValues[] = $referenceNumber;
            }

            $stmtPayment = $this->conn->prepare(sprintf(
                "INSERT INTO tbl_registration_payments (%s) VALUES (%s)",
                implode(', ', $paymentColumns),
                implode(', ', $paymentPlaceholders)
            ));
            $stmtPayment->execute($paymentValues);

            $stmtLink = $this->conn->prepare("
                INSERT INTO tbl_student_guardians (
                    student_id, guardian_id, is_primary_guardian, can_enroll, can_pay, emergency_contact
                ) VALUES (?, ?, 'Y', 'Y', 'Y', 'Y')
            ");
            $stmtLink->execute([$studentId, (int)$guardian['guardian_id']]);

            $this->conn->commit();

            $this->sendJSON([
                'success' => true,
                'message' => 'Child registration submitted successfully and is now pending review.',
                'student_id' => $studentId,
                'student_user_id' => $studentUserId,
                'student_login_identifier' => null,
                'verification_required' => false,
                'verification_email' => $studentEmail,
                'guardian_id' => (int)$guardian['guardian_id'],
                'guardian_email' => $guardianEmail,
                'registration_status' => 'Pending',
                'registration_fee_amount' => $registrationFeeAmount,
                'payment_method' => $paymentMethod,
                'reference_number' => $referenceNumber
            ]);
        } catch (PDOException $e) {
            if ($this->conn && $this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            error_log('guardianRegisterChild PDOException: ' . $e->getMessage());
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        } catch (Exception $e) {
            if ($this->conn && $this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => $e->getMessage()], 400);
        }
    }

    public function getGuardianPortal()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $email = trim($_GET['email'] ?? '');
        if ($email === '') {
            $this->sendJSON(['error' => 'Email is required'], 400);
        }

        $actor = fas_require_authenticated_user($this->conn);
        if (fas_normalize_role_category($actor['role_name'] ?? '') === 'guardian') {
            $actorEmail = trim((string)($actor['email'] ?? ''));
            if ($actorEmail === '' || strcasecmp($actorEmail, $email) !== 0) {
                $this->sendJSON(['error' => 'You can only view students linked to your guardian account'], 403);
            }
        }

        try {
            $stmtGuardians = $this->conn->prepare("
                SELECT guardian_id, first_name, last_name, email, phone, relationship_type, status
                FROM tbl_guardians
                WHERE email = ?
            ");
            $stmtGuardians->execute([$email]);
            $guardians = $stmtGuardians->fetchAll(PDO::FETCH_ASSOC);

            if (empty($guardians)) {
                $this->sendJSON(['error' => 'Guardian not found for this email'], 404);
            }

            $guardianIds = array_values(array_filter(array_map(function ($g) {
                return (int)($g['guardian_id'] ?? 0);
            }, $guardians)));

            if (empty($guardianIds)) {
                $this->sendJSON(['success' => true, 'guardians' => $guardians, 'students' => []]);
            }

            $placeholders = implode(',', array_fill(0, count($guardianIds), '?'));
            $stmtStudents = $this->conn->prepare("
                SELECT DISTINCT sg.student_id
                FROM tbl_student_guardians sg
                WHERE sg.guardian_id IN ({$placeholders})
            ");
            $stmtStudents->execute($guardianIds);
            $studentIds = $stmtStudents->fetchAll(PDO::FETCH_COLUMN);

            $students = [];
            foreach ($studentIds as $sid) {
                $payload = $this->buildStudentPortalById((int)$sid);
                if ($payload) {
                    $students[] = $payload;
                }
            }

            $this->sendJSON([
                'success' => true,
                'guardians' => $guardians,
                'students' => $students
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function updateGuardianProfile()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $guardianId = (int)($data['guardian_id'] ?? 0);
        $userId = (int)($data['user_id'] ?? 0);
        $firstName = trim((string)($data['first_name'] ?? ''));
        $lastName = trim((string)($data['last_name'] ?? ''));
        $email = trim((string)($data['email'] ?? ''));
        $phone = trim((string)($data['phone'] ?? ''));
        $relationship = trim((string)($data['relationship_type'] ?? ''));
        $occupation = trim((string)($data['occupation'] ?? ''));
        $address = trim((string)($data['address'] ?? ''));

        if ($guardianId < 1 || $userId < 1) {
            $this->sendJSON(['error' => 'Guardian account reference is required'], 400);
        }
        if ($firstName === '' || $lastName === '' || $email === '') {
            $this->sendJSON(['error' => 'First name, last name, and email are required'], 400);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $this->sendJSON(['error' => 'Invalid email address'], 400);
        }

        $allowedRelationships = ['Father', 'Mother', 'Legal Guardian', 'Other'];
        if ($relationship !== '' && !in_array($relationship, $allowedRelationships, true)) {
            $this->sendJSON(['error' => 'Invalid relationship type'], 400);
        }

        try {
            $stmtGuardian = $this->conn->prepare("SELECT guardian_id, email FROM tbl_guardians WHERE guardian_id = ? LIMIT 1");
            $stmtGuardian->execute([$guardianId]);
            $guardian = $stmtGuardian->fetch(PDO::FETCH_ASSOC);
            if (!$guardian) {
                $this->sendJSON(['error' => 'Guardian record not found'], 404);
            }

            $stmtUser = $this->conn->prepare("
                SELECT u.user_id, u.email, r.role_name
                FROM tbl_users u
                INNER JOIN tbl_roles r ON r.role_id = u.role_id
                WHERE u.user_id = ?
                LIMIT 1
            ");
            $stmtUser->execute([$userId]);
            $user = $stmtUser->fetch(PDO::FETCH_ASSOC);
            if (!$user || !in_array(strtolower(trim((string)($user['role_name'] ?? ''))), ['guardian', 'guardians'], true)) {
                $this->sendJSON(['error' => 'Guardian user account not found'], 404);
            }

            $dupGuardian = $this->conn->prepare("SELECT guardian_id FROM tbl_guardians WHERE email = ? AND guardian_id <> ? LIMIT 1");
            $dupGuardian->execute([$email, $guardianId]);
            if ($dupGuardian->fetch(PDO::FETCH_ASSOC)) {
                $this->sendJSON(['error' => 'Email is already used by another guardian record'], 400);
            }

            $dupUser = $this->conn->prepare("
                SELECT u.user_id
                FROM tbl_users u
                INNER JOIN tbl_roles r ON r.role_id = u.role_id
                WHERE u.email = ?
                  AND u.user_id <> ?
                  AND LOWER(TRIM(r.role_name)) IN ('guardian', 'guardians')
                LIMIT 1
            ");
            $dupUser->execute([$email, $userId]);
            if ($dupUser->fetch(PDO::FETCH_ASSOC)) {
                $this->sendJSON(['error' => 'Email is already used by another guardian account'], 400);
            }

            $this->conn->beginTransaction();

            $updateGuardian = $this->conn->prepare("
                UPDATE tbl_guardians
                SET first_name = ?, last_name = ?, email = ?, phone = ?, relationship_type = ?, occupation = ?, address = ?
                WHERE guardian_id = ?
            ");
            $updateGuardian->execute([
                $firstName,
                $lastName,
                $email,
                $phone !== '' ? $phone : null,
                $relationship !== '' ? $relationship : 'Other',
                $occupation !== '' ? $occupation : null,
                $address !== '' ? $address : null,
                $guardianId
            ]);

            $updateUser = $this->conn->prepare("
                UPDATE tbl_users
                SET username = ?, email = ?, first_name = ?, last_name = ?, phone = ?
                WHERE user_id = ?
            ");
            $updateUser->execute([
                $email,
                $email,
                $firstName,
                $lastName,
                $phone !== '' ? $phone : null,
                $userId
            ]);

            $this->conn->commit();
            $this->sendJSON(['success' => true, 'message' => 'Guardian profile updated successfully.']);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    /** Ensure tbl_session_packages exists for package selection flows */
    private function ensureSessionPackagesTable()
    {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS tbl_session_packages (
                    package_id INT AUTO_INCREMENT PRIMARY KEY,
                    package_name VARCHAR(100) NOT NULL,
                    sessions INT NOT NULL,
                    max_instruments TINYINT NOT NULL DEFAULT 1,
                    price DECIMAL(10,2) NOT NULL DEFAULT 0,
                    description TEXT,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )
            ");
            $stmt = $this->conn->query("SELECT COUNT(*) FROM tbl_session_packages");
            if ((int) $stmt->fetchColumn() === 0) {
                $this->conn->exec("
                    INSERT INTO tbl_session_packages (package_name, sessions, max_instruments, price, description) VALUES
                    ('Basic (12 Sessions)', 12, 1, 7450.00, '1 instrument only'),
                    ('Standard (20 Sessions)', 20, 2, 11800.00, 'Up to 2 instruments'),
                    ('Premium (50 Sessions)', 50, 3, 29500.00, 'Up to 3 instruments')
                ");
            }
        } catch (PDOException $e) {
            // Do not break API
        }
    }

    // Student dashboard meta for package + instrument + teacher availability request flow
    public function getStudentRequestMeta()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $email = trim($_GET['email'] ?? '');
        $requestedStudentId = (int)($_GET['student_id'] ?? 0);
        $staffContext = !empty($_GET['staff_context']);
        if ($email === '' && $requestedStudentId < 1) {
            $this->sendJSON(['error' => 'Email or student_id is required'], 400);
        }

        try {
            $actor = fas_require_authenticated_user($this->conn);
            $roleCategory = fas_normalize_role_category($actor['role_name'] ?? '');
            if ($requestedStudentId > 0 && $roleCategory === 'guardian') {
                $access = $this->conn->prepare("SELECT 1 FROM tbl_student_guardians sg INNER JOIN tbl_guardians g ON g.guardian_id=sg.guardian_id WHERE sg.student_id=? AND sg.can_enroll='Y' AND (g.guardian_user_id=? OR sg.guardian_user_id=? OR (g.guardian_user_id IS NULL AND g.email=?)) LIMIT 1");
                $access->execute([$requestedStudentId,(int)($actor['user_id']??0),(int)($actor['user_id']??0),trim((string)($actor['email']??''))]);
                if (!$access->fetchColumn()) $this->sendJSON(['error'=>'You are not authorized to enroll this student'],403);
            } elseif ($requestedStudentId > 0 && $roleCategory === 'student') {
                $access = $this->conn->prepare('SELECT 1 FROM tbl_students WHERE student_id=? AND (student_user_id=? OR email=?) LIMIT 1');
                $access->execute([$requestedStudentId,(int)($actor['user_id']??0),trim((string)($actor['email']??''))]);
                if (!$access->fetchColumn()) $this->sendJSON(['error'=>'You can only view your own enrollment choices'],403);
            }
            $stmtStudent = $this->conn->prepare("
                SELECT
                    s.student_id,
                    s.branch_id,
                    s.session_package_id,
                    b.branch_name,
                    s.status,
                    s.first_name,
                    s.last_name,
                    s.email,
                    s.phone,
                    s.date_of_birth,
                    s.address,
                    COALESCE(rf.registration_fee_amount, 1000.00) AS registration_fee_amount,
                    COALESCE(rf.registration_fee_paid, 0.00) AS registration_fee_paid,
                    GREATEST(0, COALESCE(rf.registration_fee_amount, 1000.00) - COALESCE(rf.registration_fee_paid, 0.00)) AS registration_fee_due,
                    COALESCE(rf.registration_status, 'Pending') AS registration_status
                FROM tbl_students s
                LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
                LEFT JOIN (
                    SELECT
                        rp.student_id,
                        1000.00 AS registration_fee_amount,
                        COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) AS registration_fee_paid,
                    CASE
                        WHEN COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) >= 1000.00 THEN 'Approved'
                        ELSE 'Pending'
                    END AS registration_status
                    FROM tbl_registration_payments rp
                    GROUP BY rp.student_id
                ) rf ON rf.student_id = s.student_id
                WHERE " . ($requestedStudentId > 0 ? "s.student_id = ?" : "s.email = ?") . "
                LIMIT 1
            ");
            $stmtStudent->execute([$requestedStudentId > 0 ? $requestedStudentId : $email]);
            $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendJSON(['error' => 'Student not found for this email'], 404);
            }

            $studentBranchId = (int) ($student['branch_id'] ?? 0);
            $studentBranchName = trim((string) ($student['branch_name'] ?? ''));
            $enrollmentContext = $this->getStudentEnrollmentContext((int)($student['student_id'] ?? 0));
            $isInitialEnrollment = !empty($enrollmentContext['is_initial_enrollment']);
            $packages = [];
            $instruments = [];
            $availabilities = [];
            $teacherCandidates = [];
            $latestRequest = null;

            // Packages (session packages first, then lesson packages fallback)
            try {
                if ($this->tableExists('tbl_session_packages')) {
                    $sessionPackagesHasBranch = $this->tableHasColumn('tbl_session_packages', 'branch_id');
                    if ($sessionPackagesHasBranch && $studentBranchId > 0) {
                        $stmtPackages = $this->conn->prepare("
                            SELECT
                                sp.package_id,
                                sp.package_name,
                                sp.sessions,
                                sp.max_instruments,
                                COALESCE(sp.price, 0) AS price,
                                sp.branch_id,
                                COALESCE(b.branch_name, '') AS branch_name
                            FROM tbl_session_packages sp
                            LEFT JOIN tbl_branches b ON sp.branch_id = b.branch_id
                            WHERE sp.branch_id = ?
                            ORDER BY sp.sessions ASC, sp.package_id ASC
                        ");
                        $stmtPackages->execute([$studentBranchId]);
                        $packages = $stmtPackages->fetchAll(PDO::FETCH_ASSOC);
                        if (empty($packages)) {
                            $stmtPackages = $this->conn->prepare("
                                SELECT
                                    package_id,
                                    package_name,
                                    sessions,
                                    max_instruments,
                                    COALESCE(price, 0) AS price,
                                    ? AS branch_id,
                                    ? AS branch_name
                                FROM tbl_session_packages
                                ORDER BY sessions ASC, package_id ASC
                            ");
                            $stmtPackages->execute([$studentBranchId, $studentBranchName]);
                            $packages = $stmtPackages->fetchAll(PDO::FETCH_ASSOC);
                        }
                    } else {
                        $stmtPackages = $this->conn->prepare("
                            SELECT
                                package_id,
                                package_name,
                                sessions,
                                max_instruments,
                                COALESCE(price, 0) AS price,
                                ? AS branch_id,
                                ? AS branch_name
                            FROM tbl_session_packages
                            ORDER BY sessions ASC, package_id ASC
                        ");
                        $stmtPackages->execute([$studentBranchId, $studentBranchName]);
                        $packages = $stmtPackages->fetchAll(PDO::FETCH_ASSOC);
                    }
                }

                if (empty($packages) && $this->tableExists('tbl_lesson_packages')) {
                    $lessonPackagesHasBranch = $this->tableHasColumn('tbl_lesson_packages', 'branch_id');
                    $lessonPackagesHasStatus = $this->tableHasColumn('tbl_lesson_packages', 'status');
                    $lessonSessionsCol = $this->tableHasColumn('tbl_lesson_packages', 'total_sessions') ? 'total_sessions' : 'sessions';

                    if ($lessonPackagesHasBranch && $studentBranchId > 0) {
                        $sqlLesson = "
                            SELECT
                                lp.package_id,
                                lp.package_name,
                                lp.{$lessonSessionsCol} AS sessions,
                                1 AS max_instruments,
                                COALESCE(lp.price, 0) AS price,
                                lp.branch_id,
                                COALESCE(b.branch_name, '') AS branch_name
                            FROM tbl_lesson_packages lp
                            LEFT JOIN tbl_branches b ON lp.branch_id = b.branch_id
                            WHERE lp.branch_id = ?
                        ";
                        if ($lessonPackagesHasStatus) {
                            $sqlLesson .= " AND lp.status = 'Active' ";
                        }
                        $sqlLesson .= " ORDER BY lp.{$lessonSessionsCol} ASC, lp.package_id ASC ";
                        $stmtPackages = $this->conn->prepare($sqlLesson);
                        $stmtPackages->execute([$studentBranchId]);
                    } else {
                        $sqlLesson = "
                            SELECT
                                package_id,
                                package_name,
                                {$lessonSessionsCol} AS sessions,
                                1 AS max_instruments,
                                COALESCE(price, 0) AS price,
                                ? AS branch_id,
                                ? AS branch_name
                            FROM tbl_lesson_packages
                        ";
                        if ($lessonPackagesHasStatus) {
                            $sqlLesson .= " WHERE status = 'Active' ";
                        }
                        $sqlLesson .= " ORDER BY {$lessonSessionsCol} ASC, package_id ASC ";
                        $stmtPackages = $this->conn->prepare($sqlLesson);
                        $stmtPackages->execute([$studentBranchId, $studentBranchName]);
                    }
                    $packages = $stmtPackages->fetchAll(PDO::FETCH_ASSOC);
                }
            } catch (PDOException $e) {
                $packages = [];
            }

            // Normal online enrollment always exposes the basic 12-session,
            // one-instrument product. Promotions remain staff-controlled.
            if (!$staffContext) {
                $packages = $this->filterInitialEnrollmentPackages($packages);
            }
            $defaultPackageId = $this->getDefaultEnrollmentPackageId($packages, !$staffContext);

            // Instruments for student's branch
            try {
                $stmtInstruments = $this->conn->prepare("
                    SELECT
                        i.instrument_id,
                        i.instrument_name,
                        i.type_id,
                        i.status,
                        it.type_name
                    FROM tbl_instruments i
                    LEFT JOIN tbl_instrument_types it ON i.type_id = it.type_id
                    WHERE i.branch_id = ?
                      AND i.status IN ('Available','In Use')
                    ORDER BY it.type_name ASC, i.instrument_name ASC
                ");
                $stmtInstruments->execute([(int) $student['branch_id']]);
                $instruments = $stmtInstruments->fetchAll(PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                $instruments = [];
            }

            // Teacher availability
            try {
                if ($this->tableExists('tbl_teacher_availability')) {
                    $stmtAvailability = $this->conn->prepare("
                        SELECT DISTINCT
                            ta.teacher_id,
                            ta.day_of_week,
                            ta.start_time,
                            ta.end_time,
                            t.first_name AS teacher_first_name,
                            t.last_name AS teacher_last_name
                        FROM tbl_teacher_availability ta
                        INNER JOIN tbl_teachers t ON t.teacher_id = ta.teacher_id
                        WHERE ta.branch_id = ?
                          AND ta.status = 'Available'
                          AND t.branch_id = ?
                          AND t.status = 'Active'
                        ORDER BY
                            FIELD(ta.day_of_week, 'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'),
                            ta.start_time ASC
                    ");
                    $stmtAvailability->execute([(int) $student['branch_id'], (int) $student['branch_id']]);
                    $availabilities = $stmtAvailability->fetchAll(PDO::FETCH_ASSOC);
                    $teacherCandidates = $this->buildTeacherCandidates((int) $student['branch_id']);
                }
            } catch (PDOException $e) {
                $availabilities = [];
                $teacherCandidates = [];
            }

            // Latest enrollment request (for status display)
            try {
                $stmtLatestRequest = $this->conn->prepare("
                    SELECT
                        e.enrollment_id AS request_id,
                        e.package_id,
                        e.preferred_schedule,
                        e.request_notes,
                        COALESCE(sp.price, 0) AS requested_amount,
                        e.status,
                        e.created_at,
                        COALESCE(sp.package_name, CONCAT('Package #', e.package_id)) AS package_name
                    FROM tbl_enrollments e
                    LEFT JOIN tbl_session_packages sp ON e.package_id = sp.package_id
                    WHERE e.student_id = ?
                    ORDER BY e.enrollment_id DESC
                    LIMIT 1
                ");
                $stmtLatestRequest->execute([(int) $student['student_id']]);
                $latestRequest = $stmtLatestRequest->fetch(PDO::FETCH_ASSOC) ?: null;
                if ($latestRequest) {
                    $meta = [];
                    if (!empty($latestRequest['request_notes'])) {
                        $decoded = json_decode((string)$latestRequest['request_notes'], true);
                        if (is_array($decoded)) $meta = $decoded;
                    }
                    $preferred = (string)($latestRequest['preferred_schedule'] ?? '');
                    $parts = explode('|', $preferred, 2);
                    $latestRequest['preferred_day_of_week'] = trim($parts[0] ?? '');
                    $latestRequest['preferred_date'] = trim($parts[1] ?? '');
                    $latestRequest['preferred_date'] = (string)($meta['preferred_date'] ?? $latestRequest['preferred_date']);
                    $latestRequest['preferred_day_of_week'] = (string)($meta['preferred_day_of_week'] ?? $latestRequest['preferred_day_of_week']);
                    $latestRequest['preferred_start_time'] = (string)($meta['preferred_start_time'] ?? '');
                    $latestRequest['preferred_end_time'] = (string)($meta['preferred_end_time'] ?? '');
                    $latestRequest['payment_type'] = (string)($meta['payment_type'] ?? 'Partial Payment');
                    $latestRequest['payment_method'] = (string)($meta['payment_method'] ?? '');
                    $latestRequest['reference_number'] = (string)($meta['reference_number'] ?? '');
                    $latestRequest['payable_now'] = (float)($meta['payable_now'] ?? 0);
                    $latestRequest['package_total_amount'] = (float)($meta['package_total_amount'] ?? 0);
                    $latestRequest['payment_proof_path'] = $meta['payment_proof_path'] ?? null;
                    $latestRequest['admin_notes'] = $meta['admin_notes'] ?? null;
                    $latestRequest['instrument_ids'] = is_array($meta['instrument_ids'] ?? null) ? $meta['instrument_ids'] : [];
                }
            } catch (PDOException $e) {
                $latestRequest = null;
            }

            $latestSessionExtensionRequest = $this->getLatestStudentSessionExtensionRequest((int)($student['student_id'] ?? 0));

            // Get student's most recent skill level from graded sessions
            $studentSkillLevel = null;
            try {
                if ($this->tableExists('tbl_student_progress')) {
                    $stmtSkillLevel = $this->conn->prepare("
                        SELECT skill_level
                        FROM tbl_student_progress
                        WHERE student_id = ? AND skill_level IS NOT NULL AND skill_level != ''
                        ORDER BY assessment_date DESC, updated_at DESC, progress_id DESC
                        LIMIT 1
                    ");
                    $stmtSkillLevel->execute([(int) $student['student_id']]);
                    $skillRow = $stmtSkillLevel->fetch(PDO::FETCH_ASSOC);
                    $studentSkillLevel = $skillRow ? trim((string)($skillRow['skill_level'] ?? '')) : null;
                }
            } catch (PDOException $e) {
                $studentSkillLevel = null;
            }

            $this->sendJSON([
                'success' => true,
                'student' => $student,
                'student_skill_level' => $studentSkillLevel,
                'packages' => $packages,
                'package_scope' => $isInitialEnrollment ? 'initial' : 'extension',
                'is_initial_enrollment' => $isInitialEnrollment,
                'default_package_id' => $defaultPackageId,
                'instruments' => $instruments,
                'availabilities' => $availabilities,
                'teacher_candidates' => $teacherCandidates,
                'latest_request' => $latestRequest,
                'latest_session_extension_request' => $latestSessionExtensionRequest
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function submitSessionExtensionRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $isMultipart = $this->isMultipartRequest();
        $data = $isMultipart ? ($_POST ?: []) : (json_decode(file_get_contents('php://input'), true) ?: []);
        $studentId = (int)($data['student_id'] ?? 0);
        $requestedSessions = (int)($data['requested_sessions'] ?? 0);
        $paymentMethod = $this->normalizeEnrollmentPaymentMethod((string)($data['payment_method'] ?? 'Cash'));
        $notes = trim((string)($data['notes'] ?? ''));
        $requestedAmount = $requestedSessions * 650.00;

        if ($studentId < 1) {
            $this->sendJSON(['error' => 'student_id is required'], 400);
        }
        if ($requestedSessions < 1 || $requestedSessions > 50) {
            $this->sendJSON(['error' => 'Choose between 1 and 50 additional sessions.'], 400);
        }
        if (!in_array($paymentMethod, ['Cash', 'GCash', 'Bank Transfer', 'Other'], true)) {
            $paymentMethod = 'Cash';
        }

        $paymentProofPath = null;
        if ($isMultipart && !empty($_FILES['session_payment_proof_file']['name']) && ($_FILES['session_payment_proof_file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            try {
                $paymentProofPath = $this->storePaymentProofUpload($_FILES['session_payment_proof_file'], 'session_extension_requests');
            } catch (Exception $e) {
                $this->sendJSON(['error' => $e->getMessage()], 400);
            }
        }
        if ($paymentMethod !== 'Cash' && !$paymentProofPath) {
            $this->sendJSON(['error' => 'Upload proof of payment for GCash or Bank Transfer requests.'], 400);
        }

        try {
            $stmtStudent = $this->conn->prepare("
                SELECT student_id, branch_id, status
                FROM tbl_students
                WHERE student_id = ?
                LIMIT 1
            ");
            $stmtStudent->execute([$studentId]);
            $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendJSON(['error' => 'Student not found'], 404);
            }
            if (strcasecmp((string)($student['status'] ?? ''), 'Active') !== 0) {
                $this->sendJSON(['error' => 'Student account is not active yet'], 400);
            }

            $stmtEnrollment = $this->conn->prepare("
                SELECT enrollment_id, status, total_sessions, completed_sessions
                FROM tbl_enrollments
                WHERE student_id = ? AND status IN ('Active','Completed')
                ORDER BY enrollment_id DESC
                LIMIT 1
            ");
            $stmtEnrollment->execute([$studentId]);
            $enrollment = $stmtEnrollment->fetch(PDO::FETCH_ASSOC);
            if (!$enrollment) {
                $this->sendJSON(['error' => 'An approved enrollment is required before requesting additional sessions.'], 400);
            }

            $totalSessions = max(0, (int)($enrollment['total_sessions'] ?? 0));
            $usedSessions = max(0, (int)($enrollment['completed_sessions'] ?? 0));
            if ($this->tableExists('tbl_sessions')) {
                $countedCondition = $this->tableHasColumn('tbl_sessions', 'counted_in')
                    ? "(COALESCE(counted_in, 0) = 1 OR status IN ('Completed', 'Late'))"
                    : "status IN ('Completed', 'Late')";
                $stmtUsedSessions = $this->conn->prepare("
                    SELECT COUNT(*)
                    FROM tbl_sessions
                    WHERE enrollment_id = ? AND {$countedCondition}
                ");
                $stmtUsedSessions->execute([(int)$enrollment['enrollment_id']]);
                $usedSessions = max($usedSessions, (int)($stmtUsedSessions->fetchColumn() ?: 0));
            }
            if ($totalSessions < 1 || $usedSessions < $totalSessions) {
                $remainingSessions = max(0, $totalSessions - $usedSessions);
                $this->sendJSON([
                    'error' => "Additional sessions can only be requested after all current package sessions are used. {$remainingSessions} session" . ($remainingSessions === 1 ? '' : 's') . ' remaining.'
                ], 400);
            }

            $this->ensureStudentSessionExtensionRequestsTable();

            $stmtPending = $this->conn->prepare("
                SELECT request_id
                FROM tbl_student_session_extension_requests
                WHERE student_id = ? AND status = 'Pending'
                ORDER BY request_id DESC
                LIMIT 1
            ");
            $stmtPending->execute([$studentId]);
            if ($stmtPending->fetchColumn()) {
                $this->sendJSON(['error' => 'You already have a pending session request. Please wait for approval.'], 400);
            }

            if ($this->tableExists('tbl_enrollments')) {
                $stmtPendingEnrollment = $this->conn->prepare("
                    SELECT enrollment_id
                    FROM tbl_enrollments
                    WHERE student_id = ? AND status = 'Pending'
                    ORDER BY enrollment_id DESC
                    LIMIT 1
                ");
                $stmtPendingEnrollment->execute([$studentId]);
                if ($stmtPendingEnrollment->fetchColumn()) {
                    $this->sendJSON(['error' => 'You already have a pending enrollment request. Please wait for approval.'], 400);
                }
            }

            if ($this->tableExists('tbl_student_package_requests')) {
                $stmtPendingPackage = $this->conn->prepare("
                    SELECT request_id
                    FROM tbl_student_package_requests
                    WHERE student_id = ? AND status = 'Pending'
                    ORDER BY request_id DESC
                    LIMIT 1
                ");
                $stmtPendingPackage->execute([$studentId]);
                if ($stmtPendingPackage->fetchColumn()) {
                    $this->sendJSON(['error' => 'You already have a pending package request. Please wait for approval.'], 400);
                }
            }

            $stmt = $this->conn->prepare("
                INSERT INTO tbl_student_session_extension_requests (
                    student_id,
                    branch_id,
                    enrollment_id,
                    requested_sessions,
                    requested_amount,
                    payment_method,
                    payment_proof_path,
                    notes,
                    status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')
            ");
            $stmt->execute([
                $studentId,
                (int)($student['branch_id'] ?? 0),
                (int)$enrollment['enrollment_id'],
                $requestedSessions,
                $requestedAmount,
                $paymentMethod,
                $paymentProofPath,
                $notes !== '' ? $notes : null
            ]);

            $requestId = (int)$this->conn->lastInsertId();
            $this->sendJSON([
                'success' => true,
                'message' => "Your request for {$requestedSessions} additional session" . ($requestedSessions === 1 ? '' : 's') . ' has been submitted for review.',
                'request_id' => $requestId,
                'requested_sessions' => $requestedSessions,
                'requested_amount' => $requestedAmount
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Student submits package+instrument+preferred schedule request for admin/desk review
    public function submitPackageRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $isMultipart = $this->isMultipartRequest();
        $data = $isMultipart ? ($_POST ?: []) : (json_decode(file_get_contents('php://input'), true) ?: []);
        $studentId = (int) ($data['student_id'] ?? 0);
        $packageId = (int) ($data['package_id'] ?? 0);
        $requestedSessionCount = (int) ($data['requested_session_count'] ?? 0);
        $paymentRaw = $data['payment_type'] ?? ($data['payment_mode'] ?? '');
        $paymentType = $this->normalizeEnrollmentPaymentType($paymentRaw);
        $paymentMethodRaw = $data['payment_method'] ?? '';
        $paymentMethod = $this->normalizeEnrollmentPaymentMethod($paymentMethodRaw);
        $referenceNumber = trim((string)($data['reference_number'] ?? ''));
        $isWalkinRequest = !empty($data['is_walkin_request']);
        $preferredDate = !empty($data['preferred_date']) ? $data['preferred_date'] : null;
        $preferredDay = trim($data['preferred_day_of_week'] ?? '');
        $preferredStartTime = trim((string)($data['preferred_start_time'] ?? ''));
        $preferredEndTime = trim((string)($data['preferred_end_time'] ?? ''));
        $preferredTeacherId = (int)($data['preferred_teacher_id'] ?? 0);
        $preferredSlots = [];
        if (!empty($data['preferred_slots_json'])) {
            $decodedPreferredSlots = json_decode((string)$data['preferred_slots_json'], true);
            $preferredSlots = is_array($decodedPreferredSlots) ? array_values($decodedPreferredSlots) : [];
        } elseif (is_array($data['preferred_slots'] ?? null)) {
            $preferredSlots = array_values($data['preferred_slots']);
        }
        if (!empty($data['instrument_ids_json'])) {
            $decoded = json_decode((string)$data['instrument_ids_json'], true);
            $instrumentIds = is_array($decoded) ? $decoded : [];
        } else {
            $instrumentIds = is_array($data['instrument_ids'] ?? null) ? $data['instrument_ids'] : [];
        }
        $instrumentIds = array_values(array_unique(array_map('intval', $instrumentIds)));
        $instrumentIds = array_filter($instrumentIds, function ($v) { return $v > 0; });

        if ($studentId < 1 || $packageId < 1) {
            $this->sendJSON(['error' => 'student_id and package_id are required'], 400);
        }
        $actor = fas_require_authenticated_user($this->conn);
        $roleCategory = fas_normalize_role_category($actor['role_name'] ?? '');
        if ($isWalkinRequest && !in_array($roleCategory, ['admin','owner','manager','staff'], true)) {
            $this->sendJSON(['error'=>'Promotional and walk-in packages can only be assigned by authorized staff'],403);
        }
        $guardianLinkId = 0;
        if ($roleCategory === 'guardian') {
            $access = $this->conn->prepare("SELECT sg.student_guardian_id FROM tbl_student_guardians sg INNER JOIN tbl_guardians g ON g.guardian_id=sg.guardian_id WHERE sg.student_id=? AND sg.can_enroll='Y' AND (g.guardian_user_id=? OR sg.guardian_user_id=? OR (g.guardian_user_id IS NULL AND g.email=?)) LIMIT 1");
            $access->execute([$studentId,(int)($actor['user_id']??0),(int)($actor['user_id']??0),trim((string)($actor['email']??''))]);
            $guardianLinkId = (int)($access->fetchColumn() ?: 0);
            if ($guardianLinkId < 1) $this->sendJSON(['error'=>'You are not authorized to enroll this student'],403);
        } elseif ($roleCategory === 'student') {
            $access = $this->conn->prepare('SELECT 1 FROM tbl_students WHERE student_id=? AND (student_user_id=? OR email=?) LIMIT 1');
            $access->execute([$studentId,(int)($actor['user_id']??0),trim((string)($actor['email']??''))]);
            if (!$access->fetchColumn()) $this->sendJSON(['error'=>'You can only submit your own enrollment request'],403);
        }
        $validDays = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
        if (in_array($roleCategory, ['student', 'guardian'], true)) {
            if (empty($preferredSlots)) {
                $this->sendJSON(['error' => 'Choose an instructor and at least one preferred class day'], 400);
            }
            if (count($preferredSlots) > 7) {
                $this->sendJSON(['error' => 'You can request up to 7 preferred class days'], 400);
            }

            $normalizedPreferredSlots = [];
            $seenPreferredDates = [];
            $seenRecurringDays = [];
            foreach ($preferredSlots as $slot) {
                if (!is_array($slot)) {
                    $this->sendJSON(['error' => 'Invalid preferred schedule entry'], 400);
                }
                $slotDate = trim((string)($slot['session_date'] ?? ''));
                $slotStart = trim((string)($slot['start_time'] ?? ''));
                $slotEnd = trim((string)($slot['end_time'] ?? ''));
                $slotTeacherId = (int)($slot['teacher_id'] ?? 0);
                $slotDateObject = $slotDate ? DateTime::createFromFormat('Y-m-d', $slotDate) : false;
                if (!$slotDateObject || $slotDateObject->format('Y-m-d') !== $slotDate || $slotDate < date('Y-m-d')) {
                    $this->sendJSON(['error' => 'Every preferred class day must have a valid upcoming date'], 400);
                }
                if ($slotTeacherId < 1 || !preg_match('/^\d{2}:\d{2}(?::\d{2})?$/', $slotStart)) {
                    $this->sendJSON(['error' => 'Every preferred class day must include an instructor and valid time'], 400);
                }
                $slotStartTimestamp = strtotime('2000-01-01 ' . $slotStart);
                if ($slotEnd === '' && $slotStartTimestamp !== false) {
                    $slotEnd = date('H:i:s', $slotStartTimestamp + 3600);
                }
                $slotEndTimestamp = strtotime('2000-01-01 ' . $slotEnd);
                if ($slotStartTimestamp === false || $slotEndTimestamp === false || ($slotEndTimestamp - $slotStartTimestamp) !== 3600) {
                    $this->sendJSON(['error' => 'Every requested class schedule must be a one-hour time slot'], 400);
                }
                $slotStart = date('H:i:s', $slotStartTimestamp);
                $slotEnd = date('H:i:s', $slotEndTimestamp);
                if (strtotime($slotDate . ' ' . $slotStart) <= time()) {
                    $this->sendJSON(['error' => 'Every preferred class time must still be upcoming'], 400);
                }
                $slotDay = $this->dayOfWeekFromDate($slotDate);
                if (isset($seenPreferredDates[$slotDate]) || isset($seenRecurringDays[$slotDay])) {
                    $this->sendJSON(['error' => 'Each preferred class day must use a different weekday'], 400);
                }
                $seenPreferredDates[$slotDate] = true;
                $seenRecurringDays[$slotDay] = true;
                $normalizedPreferredSlots[] = [
                    'teacher_id' => $slotTeacherId,
                    'teacher_name' => trim((string)($slot['teacher_name'] ?? '')),
                    'session_date' => $slotDate,
                    'day_of_week' => $slotDay,
                    'start_time' => $slotStart,
                    'end_time' => $slotEnd
                ];
            }
            $preferredSlots = $normalizedPreferredSlots;
            $preferredDate = $preferredSlots[0]['session_date'];
            $preferredDay = $preferredSlots[0]['day_of_week'];
            $preferredStartTime = $preferredSlots[0]['start_time'];
            $preferredEndTime = $preferredSlots[0]['end_time'];
            $preferredTeacherId = (int)$preferredSlots[0]['teacher_id'];

            $preferredDateObject = $preferredDate ? DateTime::createFromFormat('Y-m-d', (string)$preferredDate) : false;
            $dateIsValid = $preferredDateObject
                && $preferredDateObject->format('Y-m-d') === $preferredDate
                && $preferredDate >= date('Y-m-d');
            if (!$dateIsValid) {
                $this->sendJSON(['error' => 'Choose a valid preferred class date that is not in the past'], 400);
            }
            $preferredDay = $this->dayOfWeekFromDate($preferredDate);
            if (!preg_match('/^\d{2}:\d{2}(?::\d{2})?$/', $preferredStartTime)) {
                $this->sendJSON(['error' => 'Choose a valid preferred class time'], 400);
            }
            $startTimestamp = strtotime('2000-01-01 ' . $preferredStartTime);
            if ($preferredEndTime === '') {
                $preferredEndTime = date('H:i:s', $startTimestamp + 3600);
            }
            $endTimestamp = strtotime('2000-01-01 ' . $preferredEndTime);
            if ($startTimestamp === false || $endTimestamp === false || ($endTimestamp - $startTimestamp) !== 3600) {
                $this->sendJSON(['error' => 'The requested class schedule must be a one-hour time slot'], 400);
            }
            $preferredStartTime = date('H:i:s', $startTimestamp);
            $preferredEndTime = date('H:i:s', $endTimestamp);
            if (strtotime($preferredDate . ' ' . $preferredStartTime) <= time()) {
                $this->sendJSON(['error' => 'Choose a preferred class time that is still upcoming'], 400);
            }
        }
        if ($paymentType === '') {
            // Backward-compatible fallback for cached clients/forms.
            $paymentType = 'Partial Payment';
        }
        if ($paymentMethod === '') {
            $this->sendJSON(['error' => 'payment_method is required'], 400);
        }
        if (!$isWalkinRequest && $paymentMethod !== 'Cash' && $referenceNumber === '') {
            $this->sendJSON(['error' => 'reference_number is required for online enrollment payments'], 400);
        }

        $this->ensureStudentInstrumentsTable();
        $this->ensureStudentRegistrationFeesTable();

        $paymentProofPath = null;
        if ($isMultipart && !empty($_FILES['package_payment_proof_file']['name']) && ($_FILES['package_payment_proof_file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            try {
                $paymentProofPath = $this->storePaymentProofUpload($_FILES['package_payment_proof_file'], 'package_requests');
            } catch (Exception $e) {
                $this->sendJSON(['error' => $e->getMessage()], 400);
            }
        }

        try {
            $stmtStudent = $this->conn->prepare("
                SELECT
                    s.student_id,
                    s.branch_id,
                    s.session_package_id,
                    s.status,
                    COALESCE(rf.registration_status, 'Pending') AS registration_status
                FROM tbl_students s
                LEFT JOIN (
                    SELECT
                        rp.student_id,
                        1000.00 AS registration_fee_amount,
                        COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) AS registration_fee_paid,
                        CASE
                            WHEN COALESCE(SUM(CASE WHEN rp.status = 'Paid' THEN rp.amount ELSE 0 END), 0.00) >= 1000.00 THEN 'Approved'
                            ELSE 'Pending'
                        END AS registration_status
                    FROM tbl_registration_payments rp
                    GROUP BY rp.student_id
                ) rf ON rf.student_id = s.student_id
                WHERE s.student_id = ?
                LIMIT 1
            ");
            $stmtStudent->execute([$studentId]);
            $student = $stmtStudent->fetch(PDO::FETCH_ASSOC);
            if (!$student) {
                $this->sendJSON(['error' => 'Student not found'], 404);
            }
            if ($student['status'] !== 'Active') {
                $this->sendJSON(['error' => 'Student account is not active yet'], 400);
            }
            if (!in_array((string)($student['registration_status'] ?? ''), ['Approved', 'Fee Paid'], true)) {
                $this->sendJSON(['error' => 'The student registration fee must be approved before requesting enrollment'], 400);
            }

            $enrollmentContext = $this->getStudentEnrollmentContext($studentId);
            $isInitialEnrollment = !empty($enrollmentContext['is_initial_enrollment']);

            $stmtExisting = $this->conn->prepare("
                SELECT enrollment_id
                FROM tbl_enrollments
                WHERE student_id = ? AND status = 'Pending'
                ORDER BY enrollment_id DESC
                LIMIT 1
            ");
            $stmtExisting->execute([$studentId]);
            if ($stmtExisting->fetch()) {
                $this->sendJSON(['error' => 'You already have a pending request. Please wait for desk/admin approval.'], 400);
            }

            $sessionPackagesHasBranch = $this->tableHasColumn('tbl_session_packages', 'branch_id');
            if ($sessionPackagesHasBranch) {
                $stmtPackage = $this->conn->prepare("
                    SELECT package_id, package_name, sessions, max_instruments, COALESCE(price, 0) AS price
                    FROM tbl_session_packages
                    WHERE package_id = ?
                      AND branch_id = ?
                    LIMIT 1
                ");
                $stmtPackage->execute([$packageId, (int) $student['branch_id']]);
            } else {
                $stmtPackage = $this->conn->prepare("
                    SELECT package_id, package_name, sessions, max_instruments, COALESCE(price, 0) AS price
                    FROM tbl_session_packages
                    WHERE package_id = ?
                    LIMIT 1
                ");
                $stmtPackage->execute([$packageId]);
            }
            $package = $stmtPackage->fetch(PDO::FETCH_ASSOC);
            if (!$package) {
                $this->sendJSON(['error' => 'Selected package was not found'], 404);
            }

            $maxInstruments = (int) ($package['max_instruments'] ?? 1);
            $packageSessions = max(1, (int)($package['sessions'] ?? 1));
            $totalSessions = $requestedSessionCount > 0 ? $requestedSessionCount : $packageSessions;
            if ($totalSessions < $packageSessions) {
                $this->sendJSON(['error' => 'Session count cannot be lower than the selected package.'], 400);
            }
            if ($totalSessions > min(100, $packageSessions + 50)) {
                $this->sendJSON(['error' => 'You can add up to 50 extra sessions.'], 400);
            }
            $extraSessionCount = max(0, $totalSessions - $packageSessions);
            if (!$isWalkinRequest) {
                if ($packageSessions !== 12 || $totalSessions !== 12) {
                    $this->sendJSON(['error' => 'Normal online enrollment is limited to the 12-session basic package. Additional sessions must be requested from Enrollment Details after approval.'], 400);
                }
                if (count($instrumentIds) !== 1) {
                    $this->sendJSON(['error' => 'Normal online enrollment includes one instrument.'], 400);
                }
            }
            if ($isInitialEnrollment) {
                if ($packageSessions !== 12) {
                    $this->sendJSON(['error' => 'Initial enrollment must use the 12-session package.'], 400);
                }
                if (count($instrumentIds) !== 1) {
                    $this->sendJSON(['error' => 'Initial enrollment must start with one selected instrument.'], 400);
                }
            }
            if (count($instrumentIds) < 1) {
                $this->sendJSON(['error' => 'Select at least one instrument'], 400);
            }
            if (count($instrumentIds) > $maxInstruments) {
                $this->sendJSON(['error' => "Selected instruments exceed package limit of {$maxInstruments}"], 400);
            }

            $placeholders = implode(',', array_fill(0, count($instrumentIds), '?'));
            $params = array_merge([(int) $student['branch_id']], $instrumentIds);
            $stmtInstrumentCheck = $this->conn->prepare("
                SELECT instrument_id
                FROM tbl_instruments
                WHERE branch_id = ?
                  AND status IN ('Available','In Use')
                  AND instrument_id IN ({$placeholders})
            ");
            $stmtInstrumentCheck->execute($params);
            $validIds = $stmtInstrumentCheck->fetchAll(PDO::FETCH_COLUMN);
            if (count($validIds) !== count($instrumentIds)) {
                $this->sendJSON(['error' => 'One or more selected instruments are not available in your branch'], 400);
            }

            if (in_array($roleCategory, ['student', 'guardian'], true)) {
                $selectedTeacherIds = array_values(array_unique(array_map(function ($slot) {
                    return (int)($slot['teacher_id'] ?? 0);
                }, $preferredSlots)));
                if (count($selectedTeacherIds) !== 1 || $selectedTeacherIds[0] < 1) {
                    $this->sendJSON(['error' => 'All preferred class days must use the one instructor you selected'], 400);
                }
                $eligibleTeachers = $this->buildTeacherCandidates((int)$student['branch_id'], $instrumentIds, []);
                $eligibleTeacherIds = array_values(array_filter(array_map(function ($teacher) {
                    return (int)($teacher['teacher_id'] ?? 0);
                }, $eligibleTeachers), function ($teacherId) { return $teacherId > 0; }));
                if (!in_array($selectedTeacherIds[0], $eligibleTeacherIds, true)) {
                    $this->sendJSON(['error' => 'The selected instructor is not active in this branch or does not teach the selected instrument'], 400);
                }
            }

            if (!$this->tableExists('tbl_enrollments')) {
                $this->sendJSON(['error' => 'tbl_enrollments table not found'], 500);
            }
            $primaryInstrumentId = !empty($instrumentIds) ? (int)$instrumentIds[0] : null;
            $basePackagePrice = (float)($package['price'] ?? 0);
            $packagePrice = $basePackagePrice + ($extraSessionCount * 650.00);
            $payableNow = $this->computeEnrollmentPayableNow($packagePrice, $totalSessions, $paymentType);
            if ($payableNow <= 0) {
                $this->sendJSON(['error' => 'Unable to compute the enrollment payment amount. Please contact desk/admin.'], 400);
            }
            if (!$isWalkinRequest && $paymentMethod !== 'Cash' && !$paymentProofPath) {
                $this->sendJSON(['error' => 'Upload proof of payment for this enrollment request.'], 400);
            }
            $preferredSchedule = null;
            if ($preferredDay !== '' && in_array($preferredDay, $validDays, true)) {
                $preferredSchedule = $preferredDay . ($preferredDate ? '|' . $preferredDate : '');
            }
            $reservationExpiresAt = $isWalkinRequest ? null : date('Y-m-d H:i:s', time() + ($this->pendingReservationMinutes() * 60));
            $requestMetaData = [
                'payment_type' => $paymentType,
                'payment_method' => $paymentMethod,
                'reference_number' => $referenceNumber !== '' ? $referenceNumber : null,
                'payable_now' => $payableNow,
                'package_total_amount' => $packagePrice,
                'base_package_amount' => $basePackagePrice,
                'base_package_sessions' => $packageSessions,
                'requested_session_count' => $totalSessions,
                'extra_session_count' => $extraSessionCount,
                'extra_session_amount' => $extraSessionCount * 650.00,
                'instrument_ids' => array_values($instrumentIds),
                'payment_proof_path' => $paymentProofPath,
                'preferred_date' => $preferredDate,
                'preferred_day_of_week' => $preferredDay,
                'preferred_start_time' => $preferredStartTime,
                'preferred_end_time' => $preferredEndTime,
                'preferred_teacher_id' => $preferredTeacherId > 0 ? $preferredTeacherId : null,
                'preferred_slots' => $preferredSlots,
                'is_walkin_request' => $isWalkinRequest ? 1 : 0,
                'schedule_request_status' => 'Pending',
                'reservation_expires_at' => $reservationExpiresAt,
                'enrollment_mode' => $isInitialEnrollment ? 'initial' : 'extension'
            ];
            $requestMeta = json_encode($requestMetaData);

            // Acquiring the reservation and inserting its request are atomic. Locking all
            // pending request rows serializes simultaneous claims for the same instructor.
            if (!$this->conn->inTransaction()) $this->conn->beginTransaction();
            $this->conn->query("SELECT enrollment_id FROM tbl_enrollments WHERE status = 'Pending' FOR UPDATE")->fetchAll(PDO::FETCH_COLUMN);
            $this->expirePendingScheduleReservations();
            if (!$isWalkinRequest) {
                foreach ($this->projectRequestedSessionSlots($requestMetaData) as $slot) {
                    $slotConflicts = $this->getPendingReservationConflicts(
                        (int)$slot['teacher_id'],
                        (string)$slot['session_date'],
                        (string)$slot['day_of_week'],
                        (string)$slot['start_time'],
                        (string)$slot['end_time'],
                        [],
                        false
                    );
                    if ($slotConflicts
                        || !$this->teacherHasAvailabilityForSlot((int)$slot['teacher_id'], (string)$slot['session_date'], (string)$slot['start_time'], (string)$slot['end_time'], (int)$student['branch_id'])
                        || $this->hasTeacherScheduleConflict((int)$slot['teacher_id'], (string)$slot['session_date'], (string)$slot['start_time'], (string)$slot['end_time'])) {
                        $this->conn->rollBack();
                        $this->sendJSON(['error' => 'That instructor schedule was just reserved or occupied. Please choose another available slot.', 'conflict_type' => 'schedule'], 409);
                    }
                }
            }
            $stmtPendingEnrollment = $this->conn->prepare("
                INSERT INTO tbl_enrollments (
                    student_id,
                    package_id,
                    instrument_id,
                    preferred_schedule,
                    request_notes,
                    enrolled_by_type,
                    student_guardian_id,
                    start_date,
                    end_date,
                    total_sessions,
                    completed_sessions,
                    status,
                    schedule_request_status,
                    reservation_expires_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, NULL, NULL, ?, 0, 'Pending', 'Pending', ?)
            ");
            $stmtPendingEnrollment->execute([
                $studentId,
                $packageId,
                $primaryInstrumentId,
                ($preferredSchedule !== '' ? $preferredSchedule : null),
                $requestMeta,
                $roleCategory === 'guardian' ? 'Guardian' : 'Self',
                $guardianLinkId > 0 ? $guardianLinkId : null,
                $totalSessions,
                $reservationExpiresAt
            ]);
            $requestId = (int)$this->conn->lastInsertId();

            if ($this->conn->inTransaction()) $this->conn->commit();

            $this->sendJSON([
                'success' => true,
                'message' => 'Enrollment request submitted. The desk will confirm your preferred schedule or adjust it if there is a conflict.',
                'request_id' => $requestId,
                'payable_now' => $payableNow
            ]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function getPendingSessionExtensionRequests()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $branchId = isset($_GET['branch_id']) ? (int) $_GET['branch_id'] : 0;
        $this->ensureStudentSessionExtensionRequestsTable();

        try {
            $sql = "
                SELECT
                    r.request_id,
                    r.student_id,
                    r.branch_id,
                    r.requested_sessions,
                    r.requested_amount,
                    r.preferred_day_of_week,
                    r.preferred_start_time,
                    r.preferred_end_time,
                    r.payment_method,
                    r.payment_proof_path,
                    r.notes,
                    r.status,
                    r.admin_notes,
                    r.created_at,
                    r.updated_at,
                    s.first_name,
                    s.last_name,
                    s.email,
                    b.branch_name,
                    e.assigned_teacher_id,
                    e.instrument_id,
                    e.total_sessions,
                    CONCAT_WS(' ', t.first_name, t.last_name) AS teacher_name,
                    COALESCE(i.instrument_name, it.type_name, 'Instrument') AS instrument_name
                FROM tbl_student_session_extension_requests r
                INNER JOIN tbl_students s ON r.student_id = s.student_id
                LEFT JOIN tbl_branches b ON r.branch_id = b.branch_id
                LEFT JOIN tbl_enrollments e ON e.enrollment_id = r.enrollment_id
                LEFT JOIN tbl_teachers t ON t.teacher_id = e.assigned_teacher_id
                LEFT JOIN tbl_instruments i ON i.instrument_id = e.instrument_id
                LEFT JOIN tbl_instrument_types it ON it.type_id = i.type_id
                WHERE r.status = 'Pending'
            ";
            $params = [];
            if ($branchId > 0) {
                $sql .= " AND r.branch_id = ?";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY r.request_id DESC";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $this->sendJSON(['success' => true, 'requests' => $rows]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function approveSessionExtensionRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }
        $actor = fas_require_authenticated_user($this->conn);
        if (!in_array(fas_normalize_role_category($actor['role_name'] ?? ''), ['admin', 'owner', 'manager', 'staff'], true)) {
            $this->sendJSON(['error' => 'Only authorized desk staff can approve and schedule additional sessions'], 403);
        }
        if (!$this->tableExists('tbl_sessions')) {
            $this->sendJSON(['error' => 'Session scheduling is unavailable'], 500);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $requestId = (int)($data['request_id'] ?? 0);
        $branchId = (int)($data['branch_id'] ?? $data['desk_branch_id'] ?? 0);
        $adminNotes = trim((string)($data['admin_notes'] ?? ''));
        $scheduledSlots = is_array($data['scheduled_slots'] ?? null) ? $data['scheduled_slots'] : [];

        if ($requestId < 1) {
            $this->sendJSON(['error' => 'request_id is required'], 400);
        }

        $this->ensureStudentSessionExtensionRequestsTable();

        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                SELECT r.request_id, r.student_id, r.branch_id, r.enrollment_id,
                       r.requested_sessions, r.requested_amount, r.status, r.notes,
                       e.assigned_teacher_id, e.instrument_id, e.total_sessions, e.status AS enrollment_status
                FROM tbl_student_session_extension_requests r
                LEFT JOIN tbl_enrollments e ON e.enrollment_id = r.enrollment_id
                WHERE r.request_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->execute([$requestId]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$request) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Request not found'], 404);
            }

            if (strcasecmp((string)($request['status'] ?? ''), 'Pending') !== 0) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Only pending session requests can be approved'], 400);
            }

            if ($branchId > 0 && (int)($request['branch_id'] ?? 0) !== $branchId) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Request does not belong to your branch'], 403);
            }

            $enrollmentId = (int)($request['enrollment_id'] ?? 0);
            if ($enrollmentId < 1) {
                $stmtEnrollment = $this->conn->prepare("
                    SELECT enrollment_id
                    FROM tbl_enrollments
                    WHERE student_id = ? AND status IN ('Active','Completed')
                    ORDER BY enrollment_id DESC LIMIT 1
                    FOR UPDATE
                ");
                $stmtEnrollment->execute([(int)$request['student_id']]);
                $enrollmentId = (int)$stmtEnrollment->fetchColumn();
            }
            if ($enrollmentId < 1) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'The approved enrollment for this request no longer exists.'], 400);
            }

            $additionalSessions = max(1, (int)($request['requested_sessions'] ?? 1));
            if (!empty($scheduledSlots) && count($scheduledSlots) !== $additionalSessions) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => "Choose a schedule for all {$additionalSessions} additional session" . ($additionalSessions === 1 ? '' : 's') . '.'], 400);
            }

            $stmtEnrollmentDetails = $this->conn->prepare("
                SELECT e.student_id, e.assigned_teacher_id, e.instrument_id, e.total_sessions, e.status, s.branch_id
                FROM tbl_enrollments e
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                WHERE e.enrollment_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $stmtEnrollmentDetails->execute([$enrollmentId]);
            $enrollment = $stmtEnrollmentDetails->fetch(PDO::FETCH_ASSOC);
            if (!$enrollment || !in_array((string)($enrollment['status'] ?? ''), ['Active', 'Completed'], true)) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'The enrollment is no longer available for scheduling.'], 400);
            }
            $teacherId = (int)($enrollment['assigned_teacher_id'] ?? 0);
            if ($teacherId < 1) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Assign an instructor to this enrollment before approving additional sessions.'], 400);
            }
            $stmtTeacherLock = $this->conn->prepare("SELECT teacher_id FROM tbl_teachers WHERE teacher_id = ? FOR UPDATE");
            $stmtTeacherLock->execute([$teacherId]);

            // Older admin clients do not yet submit selected slots. Keep them safe
            // by assigning the earliest conflict-free slots instead of approving
            // sessions with no schedule.
            if (empty($scheduledSlots)) {
                $availableSlots = $this->buildTeacherAvailableSlots(
                    $teacherId,
                    (int)$enrollment['branch_id'],
                    (int)$enrollment['student_id'],
                    null,
                    [],
                    min(365, max(90, $additionalSessions * 14))
                );
                if (count($availableSlots) < $additionalSessions) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'There are not enough conflict-free instructor slots to schedule this request.'], 409);
                }
                $scheduledSlots = array_slice($availableSlots, 0, $additionalSessions);
            }

            $normalizedSlots = [];
            $slotKeys = [];
            foreach ($scheduledSlots as $slot) {
                $sessionDate = trim((string)($slot['session_date'] ?? ''));
                $startTime = trim((string)($slot['start_time'] ?? ''));
                $endTime = trim((string)($slot['end_time'] ?? ''));
                if ($sessionDate === '' || $startTime === '' || $endTime === ''
                    || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $sessionDate)
                    || !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $startTime)
                    || !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $endTime)
                    || strtotime($endTime) <= strtotime($startTime)
                    || !$this->isFutureOrTodayDate($sessionDate)
                    || strtotime($sessionDate . ' ' . $startTime) <= time()) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'One of the selected schedules is invalid or already in the past.'], 400);
                }
                $slotKey = $sessionDate . '|' . $startTime . '|' . $endTime;
                if (isset($slotKeys[$slotKey])) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'Each additional session must use a different schedule.'], 400);
                }
                foreach ($normalizedSlots as $selectedSlot) {
                    if ($sessionDate === $selectedSlot['sessionDate']
                        && $startTime < $selectedSlot['endTime']
                        && $endTime > $selectedSlot['startTime']) {
                        $this->conn->rollBack();
                        $this->sendJSON(['error' => 'Selected additional sessions cannot overlap each other.'], 400);
                    }
                }
                $slotKeys[$slotKey] = true;
                $dayOfWeek = $this->dayOfWeekFromDate($sessionDate);
                if (!$this->teacherHasAvailabilityForSlot($teacherId, $sessionDate, $startTime, $endTime, (int)$enrollment['branch_id'])
                    || $this->hasTeacherScheduleConflict($teacherId, $sessionDate, $startTime, $endTime)
                    || $this->hasTeacherRecurringScheduleConflict($teacherId, $dayOfWeek, $startTime, $endTime, [$enrollmentId])
                    || $this->hasStudentScheduleConflict((int)$enrollment['student_id'], $sessionDate, $startTime, $endTime)
                    || $this->hasStudentRecurringScheduleConflict((int)$enrollment['student_id'], $dayOfWeek, $startTime, $endTime, [$enrollmentId])
                    || !empty($this->getPendingReservationConflicts($teacherId, $sessionDate, $dayOfWeek, $startTime, $endTime))) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'A selected schedule is no longer available. Choose another slot and try again.'], 409);
                }
                $normalizedSlots[] = compact('sessionDate', 'startTime', 'endTime');
            }

            $oldTotalSessions = max(0, (int)($enrollment['total_sessions'] ?? 0));
            $stmtEnrollmentUpdate = $this->conn->prepare("
                UPDATE tbl_enrollments
                SET total_sessions = COALESCE(total_sessions, 0) + ?,
                    status = CASE WHEN status = 'Completed' THEN 'Active' ELSE status END,
                    schedule_status = CASE WHEN schedule_status = 'Ended' THEN 'Active' ELSE schedule_status END
                WHERE enrollment_id = ? AND student_id = ? AND status IN ('Active','Completed')
            ");
            $stmtEnrollmentUpdate->execute([$additionalSessions, $enrollmentId, (int)$request['student_id']]);
            if ($stmtEnrollmentUpdate->rowCount() === 0) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Unable to update the purchased session balance.'], 400);
            }

            $stmtInsertSession = $this->conn->prepare("
                INSERT INTO tbl_sessions (
                    enrollment_id, teacher_id, session_number, session_date, start_time, end_time,
                    session_type, instrument_id, status, notes
                ) VALUES (?, ?, ?, ?, ?, ?, 'Regular', ?, 'Scheduled', ?)
            ");
            foreach ($normalizedSlots as $index => $slot) {
                $stmtInsertSession->execute([
                    $enrollmentId,
                    $teacherId,
                    $oldTotalSessions + $index + 1,
                    $slot['sessionDate'],
                    $slot['startTime'],
                    $slot['endTime'],
                    !empty($enrollment['instrument_id']) ? (int)$enrollment['instrument_id'] : null,
                    'Scheduled during additional-session approval'
                ]);
            }

            $meta = [];
            if (!empty($request['notes'])) {
                $decoded = json_decode((string)$request['notes'], true);
                if (is_array($decoded)) {
                    $meta = $decoded;
                }
            }
            if ($adminNotes !== '') {
                $meta['admin_notes'] = $adminNotes;
            }

            $stmtUpdate = $this->conn->prepare("
                UPDATE tbl_student_session_extension_requests
                SET status = 'Approved',
                    admin_notes = ?
                WHERE request_id = ?
            ");
            $stmtUpdate->execute([
                $adminNotes !== '' ? $adminNotes : null,
                $requestId
            ]);

            $this->conn->commit();
            $this->sendJSON([
                'success' => true,
                'message' => "Approved and scheduled {$additionalSessions} additional session" . ($additionalSessions === 1 ? '' : 's') . '. The learning progress record was preserved.'
            ]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function rejectSessionExtensionRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $requestId = (int)($data['request_id'] ?? 0);
        $branchId = (int)($data['branch_id'] ?? $data['desk_branch_id'] ?? 0);
        $adminNotes = trim((string)($data['admin_notes'] ?? ''));

        if ($requestId < 1) {
            $this->sendJSON(['error' => 'request_id is required'], 400);
        }

        $this->ensureStudentSessionExtensionRequestsTable();

        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                SELECT request_id, branch_id, status
                FROM tbl_student_session_extension_requests
                WHERE request_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->execute([$requestId]);
            $request = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$request) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Request not found'], 404);
            }

            if (strcasecmp((string)($request['status'] ?? ''), 'Pending') !== 0) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Only pending session requests can be declined'], 400);
            }

            if ($branchId > 0 && (int)($request['branch_id'] ?? 0) !== $branchId) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Request does not belong to your branch'], 403);
            }

            $stmtUpdate = $this->conn->prepare("
                UPDATE tbl_student_session_extension_requests
                SET status = 'Rejected',
                    admin_notes = ?
                WHERE request_id = ?
            ");
            $stmtUpdate->execute([
                $adminNotes !== '' ? $adminNotes : null,
                $requestId
            ]);

            $this->conn->commit();
            $this->sendJSON([
                'success' => true,
                'message' => 'Session extension request declined.'
            ]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Admin/desk view of pending student package requests
    public function getPendingPackageRequests()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $branchId = isset($_GET['branch_id']) ? (int) $_GET['branch_id'] : 0;
        $this->ensureSessionPackagesTable();
        $this->ensureStudentCodesAssigned();
        try {
            $this->expirePendingScheduleReservations();
            $paymentsHasType = $this->tableExists('tbl_payments') && $this->tableHasColumn('tbl_payments', 'payment_type');
            $paySummaryPaymentTypeSelect = $paymentsHasType
                ? "SUBSTRING_INDEX(GROUP_CONCAT(p.payment_type ORDER BY p.payment_date DESC, p.payment_id DESC), ',', 1) AS payment_type"
                : "'—' AS payment_type";
            $sql = "
                SELECT
                    e.enrollment_id AS request_id,
                    e.student_id,
                    s.branch_id,
                    e.package_id,
                    e.instrument_id,
                    e.preferred_schedule,
                    e.request_notes,
                    e.status,
                    e.schedule_request_status,
                    e.reservation_expires_at,
                    e.created_at,
                    s.first_name,
                    s.last_name,
                    s.email,
                    b.branch_name,
                    COALESCE(sp.package_name, CONCAT('Package #', e.package_id)) AS package_name,
                    COALESCE(e.total_sessions, sp.sessions, 0) AS sessions,
                    COALESCE(sp.max_instruments, 1) AS max_instruments,
                    COALESCE(sp.price, 0) AS requested_amount
                FROM tbl_enrollments e
                INNER JOIN tbl_students s ON e.student_id = s.student_id
                LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
                LEFT JOIN tbl_session_packages sp ON e.package_id = sp.package_id
                WHERE e.status = 'Pending'
            ";
            $params = [];
            if ($branchId > 0) {
                $sql .= " AND s.branch_id = ?";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY e.enrollment_id DESC";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($rows as &$row) {
                $meta = [];
                if (!empty($row['request_notes'])) {
                    $decoded = json_decode((string)$row['request_notes'], true);
                    if (is_array($decoded)) $meta = $decoded;
                }
                $ids = is_array($meta['instrument_ids'] ?? null) ? array_values(array_map('intval', $meta['instrument_ids'])) : [];
                if (empty($ids) && !empty($row['instrument_id'])) $ids = [(int)$row['instrument_id']];
                $row['instrument_ids'] = $ids;
                $row['payment_type'] = (string)($meta['payment_type'] ?? 'Partial Payment');
                $row['payment_method'] = (string)($meta['payment_method'] ?? '');
                $row['reference_number'] = (string)($meta['reference_number'] ?? '');
                $row['payable_now'] = (float)($meta['payable_now'] ?? 0);
                $row['package_total_amount'] = (float)($meta['package_total_amount'] ?? ($row['requested_amount'] ?? 0));
                $row['payment_proof_path'] = $meta['payment_proof_path'] ?? null;
                $row['admin_notes'] = $meta['admin_notes'] ?? null;
                $row['schedule_request_status'] = (string)($row['schedule_request_status'] ?? $meta['schedule_request_status'] ?? 'Pending');
                $row['reservation_expires_at'] = $row['reservation_expires_at'] ?? $meta['reservation_expires_at'] ?? null;
                $row['suggested_slots'] = is_array($meta['suggested_slots'] ?? null) ? $meta['suggested_slots'] : [];
                $row['is_walkin_request'] = !empty($meta['is_walkin_request']);
                $row['assigned_teacher_id'] = null;
                $row['preferred_start_time'] = (string)($meta['preferred_start_time'] ?? '');
                $row['preferred_end_time'] = (string)($meta['preferred_end_time'] ?? '');
                $row['preferred_teacher_id'] = (int)($meta['preferred_teacher_id'] ?? 0);
                $row['preferred_slots'] = is_array($meta['preferred_slots'] ?? null)
                    ? array_values($meta['preferred_slots'])
                    : [];

                $preferred = (string)($row['preferred_schedule'] ?? '');
                $parts = explode('|', $preferred, 2);
                $row['preferred_day_of_week'] = trim($parts[0] ?? '');
                $row['preferred_date'] = trim($parts[1] ?? '');
                $row['preferred_date'] = (string)($meta['preferred_date'] ?? $row['preferred_date']);
                $row['preferred_day_of_week'] = (string)($meta['preferred_day_of_week'] ?? $row['preferred_day_of_week']);

                $row['instruments'] = [];
                $instrumentKeywords = [];
                if (!empty($ids)) {
                    $placeholders = implode(',', array_fill(0, count($ids), '?'));
                    $stmtInst = $this->conn->prepare("
                        SELECT i.instrument_id, i.instrument_name, i.type_id, it.type_name
                        FROM tbl_instruments i
                        LEFT JOIN tbl_instrument_types it ON i.type_id = it.type_id
                        WHERE i.instrument_id IN ({$placeholders})
                    ");
                    $stmtInst->execute($ids);
                    $instRows = $stmtInst->fetchAll(PDO::FETCH_ASSOC);
                    $detailsById = [];
                    foreach ($instRows as $instRow) {
                        $detailsById[(int) $instRow['instrument_id']] = [
                            'instrument_name' => $instRow['instrument_name'] ?? null,
                            'type_id' => (int) ($instRow['type_id'] ?? 0),
                            'type_name' => $instRow['type_name'] ?? null,
                        ];
                        if (!empty($instRow['instrument_name'])) $instrumentKeywords[] = $instRow['instrument_name'];
                        if (!empty($instRow['type_name'])) $instrumentKeywords[] = $instRow['type_name'];
                    }
                    foreach ($ids as $iid) {
                        if (isset($detailsById[$iid])) {
                            $row['instruments'][] = [
                                'instrument_id' => $iid,
                                'instrument_name' => $detailsById[$iid]['instrument_name'],
                                'type_id' => $detailsById[$iid]['type_id'],
                                'type_name' => $detailsById[$iid]['type_name'],
                            ];
                        }
                    }
                }
                $row['teacher_candidates'] = $this->buildTeacherCandidates((int)$row['branch_id'], $ids, $instrumentKeywords);
            }
            unset($row);

            $this->sendJSON(['success' => true, 'requests' => $rows]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Admin/desk view of all active enrolled students
    public function getActiveEnrollments()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $branchId = isset($_GET['branch_id']) ? (int) $_GET['branch_id'] : 0;
        $this->ensureSessionPackagesTable();

        try {
            $studentCodeSelect = $this->tableHasColumn('tbl_students', 'student_code')
                ? 's.student_code'
                : 'NULL AS student_code';
            $paymentsHasType = $this->tableExists('tbl_payments') && $this->tableHasColumn('tbl_payments', 'payment_type');
            $paySummaryPaymentTypeSelect = $paymentsHasType
                ? "SUBSTRING_INDEX(GROUP_CONCAT(p.payment_type ORDER BY p.payment_date DESC, p.payment_id DESC), ',', 1) AS payment_type"
                : "'—' AS payment_type";
            $freezePaymentStatusSelect = $this->tableExists('tbl_freeze_payments')
                ? "COALESCE((
                        SELECT fp.status
                        FROM tbl_freeze_payments fp
                        WHERE fp.enrollment_id = e.enrollment_id
                        ORDER BY fp.created_at DESC
                        LIMIT 1
                    ), 'None') AS freeze_payment_status,"
                : "'None' AS freeze_payment_status,";
            $sql = "
                SELECT
                    e.enrollment_id,
                    e.student_id,
                    {$studentCodeSelect},
                    s.first_name,
                    s.last_name,
                    s.email,
                    s.branch_id,
                    s.created_at AS student_created_at,
                    b.branch_name,
                    e.package_id,
                    e.instrument_id,
                    inst.type_id AS instrument_type_id,
                    COALESCE(inst.instrument_name, CONCAT('Instrument #', e.instrument_id)) AS instrument_name,
                    COALESCE(it.type_name, 'Other') AS type_name,
                    COALESCE(sp.package_name, CONCAT('Package #', e.package_id)) AS package_name,
                    COALESCE(e.total_sessions, sp.sessions, 0) AS sessions,
                    COALESCE(sp.price, 0) AS total_amount,
                    COALESCE(pay.paid_amount, 0) AS paid_amount,
                    COALESCE(pay.payment_type, '—') AS payment_type,
                    pay.latest_payment_date,
                    pay.latest_payment_id,
                    {$freezePaymentStatusSelect}
                    e.status,
                    e.assigned_teacher_id,
                    e.fixed_day_of_week,
                    e.fixed_start_time,
                    e.fixed_end_time,
                    e.fixed_room_id,
                    e.schedule_status,
                    e.allowed_absences,
                    e.used_absences,
                    e.consecutive_absences,
                    e.start_date,
                    e.end_date,
                    e.created_at,
                    e.request_notes,
                    fs.session_date AS first_session_date,
                    fs.start_time AS first_start_time,
                    fs.end_time AS first_end_time,
                    COALESCE(t.first_name, at.first_name) AS teacher_first_name,
                    COALESCE(t.last_name, at.last_name) AS teacher_last_name,
                    COALESCE(rm.room_name, NULLIF(TRIM(fs.notes), '')) AS assigned_room
                FROM tbl_enrollments e
                INNER JOIN tbl_students s ON e.student_id = s.student_id
                LEFT JOIN tbl_branches b ON s.branch_id = b.branch_id
                LEFT JOIN tbl_instruments inst ON inst.instrument_id = e.instrument_id
                LEFT JOIN tbl_instrument_types it ON it.type_id = inst.type_id
                LEFT JOIN tbl_session_packages sp ON e.package_id = sp.package_id
                LEFT JOIN (
                    SELECT
                        s1.enrollment_id,
                        s1.session_date,
                        s1.start_time,
                        s1.end_time,
                        s1.room_id,
                        s1.teacher_id,
                        s1.notes
                    FROM tbl_sessions s1
                    INNER JOIN (
                        SELECT enrollment_id, MIN(session_number) AS min_session_number
                        FROM tbl_sessions
                        GROUP BY enrollment_id
                    ) x ON x.enrollment_id = s1.enrollment_id
                       AND x.min_session_number = s1.session_number
                ) fs ON fs.enrollment_id = e.enrollment_id
                LEFT JOIN (
                    SELECT
                        p.enrollment_id,
                        SUM(CASE WHEN p.status = 'Paid' THEN p.amount ELSE 0 END) AS paid_amount,
                        MAX(CASE WHEN p.status = 'Paid' THEN COALESCE(p.payment_date, DATE(p.created_at)) END) AS latest_payment_date,
                        MAX(CASE WHEN p.status = 'Paid' THEN p.payment_id END) AS latest_payment_id,
                        {$paySummaryPaymentTypeSelect}
                    FROM tbl_payments p
                    GROUP BY p.enrollment_id
                ) pay ON pay.enrollment_id = e.enrollment_id
                LEFT JOIN tbl_teachers t ON t.teacher_id = fs.teacher_id
                LEFT JOIN tbl_teachers at ON at.teacher_id = e.assigned_teacher_id
                LEFT JOIN tbl_rooms rm ON rm.room_id = COALESCE(e.fixed_room_id, fs.room_id)
                WHERE e.status = 'Active'
            ";
            $params = [];
            if ($branchId > 0) {
                $sql .= " AND s.branch_id = ? ";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY e.enrollment_id DESC ";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // Attach session list per enrollment
            if (!empty($rows) && $this->tableExists('tbl_sessions')) {
                $enrollmentIds = array_values(array_filter(array_map(function ($r) {
                    return (int)($r['enrollment_id'] ?? 0);
                }, $rows)));
                if (!empty($enrollmentIds)) {
                    $placeholders = implode(',', array_fill(0, count($enrollmentIds), '?'));
                    $stmtSessions = $this->conn->prepare("
                        SELECT
                            s.session_id,
                            s.enrollment_id,
                            s.session_number,
                            s.session_date,
                            s.start_time,
                            s.end_time,
                            s.room_id,
                            s.instrument_id,
                            s.session_type,
                            s.status,
                            s.attendance_status,
                            s.absence_notice,
                            s.counted_in,
                            s.makeup_eligible,
                            s.makeup_required,
                            s.notes,
                            s.rescheduled_from_session_id,
                            s.rescheduled_to_session_id,
                            s.needs_rescheduling,
                            s.cancellation_reason,
                            s.cancelled_by_teacher_at,
                            s.rescheduled_at,
                            s.teacher_id,
                            t.first_name AS teacher_first_name,
                            t.last_name AS teacher_last_name,
                            r.room_name,
                            si.instrument_name,
                            sit.type_name AS instrument_type_name
                        FROM tbl_sessions s
                        LEFT JOIN tbl_teachers t ON t.teacher_id = s.teacher_id
                        LEFT JOIN tbl_rooms r ON r.room_id = s.room_id
                        LEFT JOIN tbl_instruments si ON si.instrument_id = s.instrument_id
                        LEFT JOIN tbl_instrument_types sit ON sit.type_id = si.type_id
                        WHERE s.enrollment_id IN ({$placeholders})
                        ORDER BY s.enrollment_id ASC, s.session_number ASC, s.session_id ASC
                    ");
                    $stmtSessions->execute($enrollmentIds);
                    $sessionRows = $stmtSessions->fetchAll(PDO::FETCH_ASSOC);
                    $sessionsByEnrollment = [];
                    foreach ($sessionRows as $sr) {
                        $eid = (int)($sr['enrollment_id'] ?? 0);
                        if ($eid < 1) continue;
                        if (!isset($sessionsByEnrollment[$eid])) $sessionsByEnrollment[$eid] = [];
                        $sessionsByEnrollment[$eid][] = $sr;
                    }
                    foreach ($rows as &$row) {
                        $eid = (int)($row['enrollment_id'] ?? 0);
                        $row['sessions_list'] = $sessionsByEnrollment[$eid] ?? [];
                    }
                    unset($row);
                }
            }

            if (!empty($rows) && $this->tableExists('tbl_enrollment_schedule_slots')) {
                foreach ($rows as &$row) {
                    $eid = (int)($row['enrollment_id'] ?? 0);
                    $slots = $this->getEnrollmentScheduleSlots($eid);
                    $row['schedule_slots'] = $slots;
                    $row['schedule_summary'] = $this->formatScheduleSlotsSummary($slots);
                }
                unset($row);
            }

            if (!empty($rows)) {
                foreach ($rows as &$row) {
                    $requestMeta = json_decode((string)($row['request_notes'] ?? ''), true);
                    if (is_array($requestMeta) && is_numeric($requestMeta['package_total_amount'] ?? null)) {
                        $row['total_amount'] = (float)$requestMeta['package_total_amount'];
                    }
                    $row['paid_amount'] = (float)($row['paid_amount'] ?? 0);
                    $balanceData = $this->balanceEnrollment((int)$row['enrollment_id']);
                    $row['balance_amount'] = $balanceData['balance_amount'] ?? max(0, (float)$row['total_amount'] - $row['paid_amount']);
                    if ($balanceData) {
                        foreach (['total_amount', 'paid_amount', 'deadline_session', 'sessions_used',
                            'sessions_remaining', 'payment_status'] as $field) $row[$field] = $balanceData[$field];
                    }
                    unset($row['request_notes']);
                    $instrumentIds = [];
                    if (!empty($row['instrument_id'])) {
                        $instrumentIds[] = (int)$row['instrument_id'];
                    }
                    $instrumentKeywords = [];
                    if (!empty($row['instrument_name'])) {
                        $instrumentKeywords[] = $row['instrument_name'];
                    }
                    if (!empty($row['type_name'])) {
                        $instrumentKeywords[] = $row['type_name'];
                    }
                    $row['teacher_candidates'] = $this->buildTeacherCandidatesForEnrollment(
                        (int)($row['branch_id'] ?? 0),
                        $instrumentIds,
                        $instrumentKeywords,
                        (int)($row['assigned_teacher_id'] ?? 0),
                        trim((string)(($row['teacher_first_name'] ?? '') . ' ' . ($row['teacher_last_name'] ?? '')))
                    );

                    $isFrozen = strcasecmp((string)($row['schedule_status'] ?? 'Active'), 'Frozen') === 0;
                    $row['schedule_freeze_required'] = $isFrozen ? 1 : 0;
                    $row['reservation_fee_amount'] = $isFrozen ? 100 : 0;
                }
                unset($row);
            }

            $this->sendJSON(['success' => true, 'enrollments' => $rows]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    private function ensureEnrollmentAssignedTeacherColumn()
    {
        if (!$this->tableExists('tbl_enrollments')) {
            return;
        }

        try {
            if (!$this->tableHasColumn('tbl_enrollments', 'assigned_teacher_id')) {
                $this->conn->exec("ALTER TABLE tbl_enrollments ADD COLUMN assigned_teacher_id INT NULL AFTER instrument_id");
            }
        } catch (PDOException $e) {
            return;
        }

        if (!$this->tableExists('tbl_sessions')) {
            return;
        }

        try {
            $this->conn->exec("
                UPDATE tbl_enrollments e
                LEFT JOIN (
                    SELECT s1.enrollment_id, s1.teacher_id
                    FROM tbl_sessions s1
                    INNER JOIN (
                        SELECT enrollment_id, MIN(session_id) AS first_session_id
                        FROM tbl_sessions
                        WHERE teacher_id IS NOT NULL
                        GROUP BY enrollment_id
                    ) x ON x.first_session_id = s1.session_id
                ) fs ON fs.enrollment_id = e.enrollment_id
                SET e.assigned_teacher_id = fs.teacher_id
                WHERE e.assigned_teacher_id IS NULL
                  AND fs.teacher_id IS NOT NULL
            ");
        } catch (PDOException $e) {
            // Keep API working even if backfill fails.
        }
    }

    private function ensureSessionRescheduleWorkflow()
    {
        if (!$this->tableExists('tbl_sessions')) {
            return;
        }

        try {
            $this->conn->exec("
                ALTER TABLE tbl_sessions
                MODIFY COLUMN status ENUM('Scheduled','Completed','Cancelled','No Show','Late','cancelled_by_teacher','rescheduled')
                NOT NULL DEFAULT 'Scheduled'
            ");
        } catch (PDOException $e) {
            // Ignore enum update failures on environments with differing definitions.
        }

        $columnSql = [
            "ALTER TABLE tbl_sessions ADD COLUMN rescheduled_from_session_id INT NULL AFTER notes",
            "ALTER TABLE tbl_sessions ADD COLUMN rescheduled_to_session_id INT NULL AFTER rescheduled_from_session_id",
            "ALTER TABLE tbl_sessions ADD COLUMN needs_rescheduling TINYINT(1) NOT NULL DEFAULT 0 AFTER rescheduled_to_session_id",
            "ALTER TABLE tbl_sessions ADD COLUMN cancellation_reason TEXT NULL AFTER needs_rescheduling",
            "ALTER TABLE tbl_sessions ADD COLUMN cancelled_by_teacher_at DATETIME NULL AFTER cancellation_reason",
            "ALTER TABLE tbl_sessions ADD COLUMN rescheduled_at DATETIME NULL AFTER cancelled_by_teacher_at"
        ];
        $columnNames = [
            'rescheduled_from_session_id',
            'rescheduled_to_session_id',
            'needs_rescheduling',
            'cancellation_reason',
            'cancelled_by_teacher_at',
            'rescheduled_at'
        ];

        foreach ($columnSql as $index => $sql) {
            try {
                if (!$this->tableHasColumn('tbl_sessions', $columnNames[$index])) {
                    $this->conn->exec($sql);
                }
            } catch (PDOException $e) {
                // Ignore column-level migration failures.
            }
        }

        try {
            $stmt = $this->conn->query("SHOW INDEX FROM tbl_sessions WHERE Key_name = 'unique_session_per_enrollment'");
            if ($stmt && $stmt->fetch(PDO::FETCH_ASSOC)) {
                $this->conn->exec("ALTER TABLE tbl_sessions DROP INDEX unique_session_per_enrollment");
            }
        } catch (PDOException $e) {
            // Ignore if index does not exist or cannot be dropped.
        }

        try { $this->conn->exec("CREATE INDEX idx_sessions_enrollment_number ON tbl_sessions(enrollment_id, session_number)"); } catch (PDOException $e) {}
        try { $this->conn->exec("CREATE INDEX idx_sessions_rescheduled_from ON tbl_sessions(rescheduled_from_session_id)"); } catch (PDOException $e) {}
        try { $this->conn->exec("CREATE INDEX idx_sessions_rescheduled_to ON tbl_sessions(rescheduled_to_session_id)"); } catch (PDOException $e) {}
        try { $this->conn->exec("CREATE INDEX idx_sessions_needs_rescheduling ON tbl_sessions(needs_rescheduling)"); } catch (PDOException $e) {}
    }

    // Available rooms for assignment modal dropdowns
    public function getAvailableRooms()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $branchId = isset($_GET['branch_id']) ? (int) $_GET['branch_id'] : 0;

        if (!$this->tableExists('tbl_rooms')) {
            $this->sendJSON(['success' => true, 'rooms' => []]);
        }

        try {
            $sql = "
                SELECT
                    room_id,
                    branch_id,
                    room_name,
                    capacity,
                    room_type,
                    status
                FROM tbl_rooms
                WHERE status = 'Available'
            ";
            $params = [];
            if ($branchId > 0) {
                $sql .= " AND branch_id = ? ";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY room_name ASC, room_id ASC ";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $rooms = $stmt->fetchAll(PDO::FETCH_ASSOC);

            $this->sendJSON(['success' => true, 'rooms' => $rooms]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function getCancelledSessions()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $branchId = isset($_GET['branch_id']) ? (int)$_GET['branch_id'] : 0;

        if (!$this->tableExists('tbl_sessions')) {
            $this->sendJSON(['success' => true, 'sessions' => []]);
        }

        try {
            $sql = "
                SELECT
                    ts.session_id,
                    ts.enrollment_id,
                    ts.session_number,
                    ts.session_date,
                    ts.start_time,
                    ts.end_time,
                    ts.status,
                    ts.notes,
                    ts.needs_rescheduling,
                    ts.cancellation_reason,
                    ts.cancelled_by_teacher_at,
                    ts.rescheduled_to_session_id,
                    ts.teacher_id,
                    e.assigned_teacher_id,
                    e.student_id,
                    s.branch_id,
                    s.first_name AS student_first_name,
                    s.last_name AS student_last_name,
                    t.first_name AS teacher_first_name,
                    t.last_name AS teacher_last_name,
                    rm.room_name,
                    COALESCE(sp.package_name, CONCAT('Package #', e.package_id)) AS package_name
                FROM tbl_sessions ts
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ts.enrollment_id
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                LEFT JOIN tbl_teachers t ON t.teacher_id = COALESCE(e.assigned_teacher_id, ts.teacher_id)
                LEFT JOIN tbl_rooms rm ON rm.room_id = ts.room_id
                LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id
                WHERE ts.status = 'cancelled_by_teacher'
                  AND ts.needs_rescheduling = 1
            ";
            $params = [];
            if ($branchId > 0) {
                $sql .= " AND s.branch_id = ? ";
                $params[] = $branchId;
            }
            $sql .= " ORDER BY ts.session_date ASC, ts.start_time ASC, ts.session_id ASC ";

            $stmt = $this->conn->prepare($sql);
            $stmt->execute($params);
            $this->sendJSON(['success' => true, 'sessions' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function getRescheduleSlots()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $sessionId = (int)($_GET['session_id'] ?? 0);
        $daysAhead = (int)($_GET['days_ahead'] ?? 30);
        $requestedTeacherId = (int)($_GET['override_teacher_id'] ?? 0);
        if ($sessionId < 1) {
            $this->sendJSON(['error' => 'session_id is required'], 400);
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT
                    ts.session_id,
                    ts.enrollment_id,
                    ts.session_number,
                    ts.teacher_id,
                    ts.room_id,
                    ts.status,
                    ts.needs_rescheduling,
                    e.student_id,
                    s.branch_id,
                    e.assigned_teacher_id,
                    e.instrument_id,
                    e.package_id,
                    s.first_name AS student_first_name,
                    s.last_name AS student_last_name,
                    t.first_name AS teacher_first_name,
                    t.last_name AS teacher_last_name,
                    COALESCE(inst.instrument_name, CONCAT('Instrument #', e.instrument_id)) AS instrument_name,
                    COALESCE(it.type_name, 'Other') AS type_name,
                    COALESCE(sp.package_name, CONCAT('Package #', e.package_id)) AS package_name
                FROM tbl_sessions ts
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ts.enrollment_id
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                LEFT JOIN tbl_teachers t ON t.teacher_id = COALESCE(e.assigned_teacher_id, ts.teacher_id)
                LEFT JOIN tbl_instruments inst ON inst.instrument_id = e.instrument_id
                LEFT JOIN tbl_instrument_types it ON it.type_id = inst.type_id
                LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id
                WHERE ts.session_id = ?
                LIMIT 1
            ");
            $stmt->execute([$sessionId]);
            $session = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$session) {
                $this->sendJSON(['error' => 'Session not found'], 404);
            }
            $status = (string)($session['status'] ?? '');
            $isTeacherCancelled = $status === 'cancelled_by_teacher' && (int)($session['needs_rescheduling'] ?? 0) === 1;
            $isStudentEmergencyReschedulable = $status === 'Scheduled' && $this->isFutureOrTodayDate((string)($session['session_date'] ?? ''));
            if (!$isTeacherCancelled && !$isStudentEmergencyReschedulable) {
                $this->sendJSON(['error' => 'This session cannot be rescheduled right now'], 400);
            }

            $teacherId = (int)($session['assigned_teacher_id'] ?? 0);
            if ($teacherId < 1) {
                $teacherId = (int)($session['teacher_id'] ?? 0);
            }
            if ($teacherId < 1) {
                $this->sendJSON(['error' => 'No fixed teacher is assigned to this enrollment'], 400);
            }

            $instrumentIds = [];
            if (!empty($session['instrument_id'])) {
                $instrumentIds[] = (int)$session['instrument_id'];
            }
            $instrumentKeywords = [];
            if (!empty($session['instrument_name'])) {
                $instrumentKeywords[] = $session['instrument_name'];
            }
            if (!empty($session['type_name'])) {
                $instrumentKeywords[] = $session['type_name'];
            }
            $teacherCandidates = $this->buildTeacherCandidatesForEnrollment(
                (int)($session['branch_id'] ?? 0),
                $instrumentIds,
                $instrumentKeywords,
                $teacherId,
                trim((string)(($session['teacher_first_name'] ?? '') . ' ' . ($session['teacher_last_name'] ?? '')))
            );

            if ($requestedTeacherId > 0) {
                $candidateIds = array_map(function ($candidate) {
                    return (int)($candidate['teacher_id'] ?? 0);
                }, $teacherCandidates);
                if (!in_array($requestedTeacherId, $candidateIds, true)) {
                    $this->sendJSON(['error' => 'Selected instructor does not match this package instrument'], 400);
                }
                $teacherId = $requestedTeacherId;
            }

            $slots = $this->buildTeacherAvailableSlots(
                $teacherId,
                (int)($session['branch_id'] ?? 0),
                (int)($session['student_id'] ?? 0),
                isset($session['room_id']) ? (int)$session['room_id'] : null,
                [$sessionId],
                $daysAhead
            );

            $this->sendJSON([
                'success' => true,
                'session' => $session,
                'slots' => $slots,
                'teacher_candidates' => $teacherCandidates,
                'selected_teacher_id' => $teacherId
            ]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    public function rescheduleCancelledSession()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $sessionId = (int)($data['session_id'] ?? 0);
        $sessionDate = trim((string)($data['session_date'] ?? ''));
        $startTime = trim((string)($data['start_time'] ?? ''));
        $endTime = trim((string)($data['end_time'] ?? ''));
        $this->ensureFutureOrTodayDateOrFail($sessionDate, 'Reschedule date cannot be in the past.');

        if ($sessionId < 1 || $sessionDate === '' || $startTime === '' || $endTime === '') {
            $this->sendJSON(['error' => 'session_id, session_date, start_time, and end_time are required'], 400);
        }

        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                SELECT
                    ts.*,
                    e.student_id,
                    e.assigned_teacher_id,
                    e.instrument_id,
                    e.package_id,
                    s.branch_id
                FROM tbl_sessions ts
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ts.enrollment_id
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                WHERE ts.session_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->execute([$sessionId]);
            $cancelledSession = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$cancelledSession) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Cancelled session not found'], 404);
            }
            if ((string)($cancelledSession['status'] ?? '') !== 'cancelled_by_teacher' || (int)($cancelledSession['needs_rescheduling'] ?? 0) !== 1) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'This session is not waiting for rescheduling'], 400);
            }

            $teacherId = (int)($cancelledSession['assigned_teacher_id'] ?? 0);
            if ($teacherId < 1) {
                $teacherId = (int)($cancelledSession['teacher_id'] ?? 0);
            }
            if ($teacherId < 1) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'No fixed teacher is assigned to this enrollment'], 400);
            }

            $instrumentIds = [];
            if (!empty($sourceSession['instrument_id'])) {
                $instrumentIds[] = (int)$sourceSession['instrument_id'];
            }
            $instrumentKeywords = [];
            if (!empty($sourceSession['instrument_id']) && $this->tableExists('tbl_instruments')) {
                try {
                    $stmtInstrument = $this->conn->prepare("
                        SELECT i.instrument_name, it.type_name
                        FROM tbl_instruments i
                        LEFT JOIN tbl_instrument_types it ON it.type_id = i.type_id
                        WHERE i.instrument_id = ?
                        LIMIT 1
                    ");
                    $stmtInstrument->execute([(int)$sourceSession['instrument_id']]);
                    $instrumentRow = $stmtInstrument->fetch(PDO::FETCH_ASSOC) ?: [];
                    if (!empty($instrumentRow['instrument_name'])) {
                        $instrumentKeywords[] = $instrumentRow['instrument_name'];
                    }
                    if (!empty($instrumentRow['type_name'])) {
                        $instrumentKeywords[] = $instrumentRow['type_name'];
                    }
                } catch (PDOException $e) {
                    // Fall back to the assigned teacher if instrument metadata cannot be loaded.
                }
            }
            $teacherCandidates = $this->buildTeacherCandidatesForEnrollment(
                (int)($sourceSession['branch_id'] ?? 0),
                $instrumentIds,
                $instrumentKeywords,
                $teacherId
            );
            if ($requestedTeacherId > 0) {
                $candidateIds = array_map(function ($candidate) {
                    return (int)($candidate['teacher_id'] ?? 0);
                }, $teacherCandidates);
                if (!in_array($requestedTeacherId, $candidateIds, true)) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'Selected instructor does not match this package instrument'], 400);
                }
                $teacherId = $requestedTeacherId;
            }

            if (!$this->teacherHasAvailabilityForSlot($teacherId, $sessionDate, $startTime, $endTime)) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Selected slot is outside the teacher availability'], 400);
            }
            if ($this->hasTeacherScheduleConflict($teacherId, $sessionDate, $startTime, $endTime, [$sessionId])) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Teacher already has another session at that time'], 400);
            }
            if ($this->hasStudentScheduleConflict((int)$cancelledSession['student_id'], $sessionDate, $startTime, $endTime, [$sessionId])) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Student already has another session at that time'], 400);
            }

            $roomId = null;

            $historyNote = 'Rescheduled from cancelled session #' . (int)$cancelledSession['session_id'];
            $stmtInsert = $this->conn->prepare("
                INSERT INTO tbl_sessions (
                    enrollment_id,
                    teacher_id,
                    session_number,
                    session_date,
                    start_time,
                    end_time,
                    session_type,
                    instrument_id,
                    school_instrument_id,
                    room_id,
                    status,
                    attendance_notes,
                    notes,
                    rescheduled_from_session_id,
                    rescheduled_to_session_id,
                    needs_rescheduling,
                    cancellation_reason,
                    cancelled_by_teacher_at,
                    rescheduled_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'rescheduled', ?, ?, ?, NULL, 0, NULL, NULL, NOW())
            ");
            $stmtInsert->execute([
                (int)$cancelledSession['enrollment_id'],
                $teacherId,
                (int)$cancelledSession['session_number'],
                $sessionDate,
                $startTime,
                $endTime,
                $cancelledSession['session_type'] ?? 'Regular',
                !empty($cancelledSession['instrument_id']) ? (int)$cancelledSession['instrument_id'] : null,
                !empty($cancelledSession['school_instrument_id']) ? (int)$cancelledSession['school_instrument_id'] : null,
                ($roomId !== null && $roomId > 0) ? $roomId : null,
                $cancelledSession['attendance_notes'] ?? null,
                $historyNote,
                (int)$cancelledSession['session_id']
            ]);
            $newSessionId = (int)$this->conn->lastInsertId();

            $stmtUpdate = $this->conn->prepare("
                UPDATE tbl_sessions
                SET needs_rescheduling = 0,
                    rescheduled_to_session_id = ?,
                    rescheduled_at = NOW()
                WHERE session_id = ?
            ");
            $stmtUpdate->execute([$newSessionId, $sessionId]);

            $this->conn->commit();
            $this->sendJSON([
                'success' => true,
                'message' => 'Cancelled session rescheduled successfully.',
                'new_session_id' => $newSessionId
            ]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Admin schedules a specific session for an active enrollment
    public function scheduleEnrollmentSession()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $enrollmentId = (int)($data['enrollment_id'] ?? 0);
        $sessionNumber = (int)($data['session_number'] ?? 0);
        $requestedTeacherId = (int)($data['teacher_id'] ?? 0);
        $sessionDate = trim((string)($data['session_date'] ?? ''));
        $startTime = trim((string)($data['start_time'] ?? '09:00:00'));
        $endTime = trim((string)($data['end_time'] ?? '10:00:00'));
        $isEditingExisting = filter_var(($data['edit_existing'] ?? false), FILTER_VALIDATE_BOOLEAN);
        $scopeBranchId = (int)($data['branch_id'] ?? $data['desk_branch_id'] ?? $data['manager_branch_id'] ?? 0);
        $editorRoleName = trim((string)($data['editor_role'] ?? ''));

        if ($enrollmentId < 1) {
            $this->sendJSON(['error' => 'enrollment_id is required'], 400);
        }
        if ($sessionNumber < 1) {
            $this->sendJSON(['error' => 'session_number is required'], 400);
        }
        if ($sessionDate === '') {
            $this->sendJSON(['error' => 'session_date is required'], 400);
        }
        $this->ensureFutureOrTodayDateOrFail($sessionDate, 'Schedule date cannot be in the past.');
        if ($startTime === '') $startTime = '09:00:00';
        if ($endTime === '') $endTime = '10:00:00';
        if (!preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $startTime) || !preg_match('/^\d{2}:\d{2}(:\d{2})?$/', $endTime)) {
            $this->sendJSON(['error' => 'Invalid time format'], 400);
        }
        $startTs = strtotime($startTime);
        $endTs = strtotime($endTime);
        if ($startTs === false || $endTs === false || $endTs <= $startTs) {
            $this->sendJSON(['error' => 'End time must be later than start time'], 400);
        }
        if (!$this->tableExists('tbl_sessions')) {
            $this->sendJSON(['error' => 'tbl_sessions table not found'], 500);
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT
                    e.enrollment_id,
                    e.student_id,
                    e.instrument_id,
                    e.assigned_teacher_id,
                    e.total_sessions,
                    e.start_date,
                    e.status,
                    s.branch_id
                FROM tbl_enrollments e
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                WHERE e.enrollment_id = ?
                LIMIT 1
            ");
            $stmt->execute([$enrollmentId]);
            $enrollment = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$enrollment) {
                $this->sendJSON(['error' => 'Enrollment not found'], 404);
            }
            if ((string)($enrollment['status'] ?? '') !== 'Active') {
                $this->sendJSON(['error' => 'Enrollment is not active'], 400);
            }
            $this->validateScheduleBranchAccess((int)($enrollment['branch_id'] ?? 0), $scopeBranchId, $editorRoleName);
            $totalSessions = (int)($enrollment['total_sessions'] ?? 0);

            $stmtCheck = $this->conn->prepare("
                SELECT session_id, session_date, status, attendance_status,
                       counted_in, instructor_completed_at
                FROM tbl_sessions
                WHERE enrollment_id = ?
                  AND session_number = ?
                  AND status <> 'cancelled_by_teacher'
                ORDER BY session_id DESC
                LIMIT 1
            ");
            $stmtCheck->execute([$enrollmentId, $sessionNumber]);
            $existingSession = $stmtCheck->fetch(PDO::FETCH_ASSOC) ?: [];
            $existingSessionId = (int)($existingSession['session_id'] ?? 0);
            $existingSessionDate = (string)($existingSession['session_date'] ?? '');
            $existingSessionStatus = (string)($existingSession['status'] ?? '');

            if ($isEditingExisting && $existingSessionId <= 0) {
                $this->sendJSON(['error' => 'Scheduled session not found for editing'], 404);
            }
            if ($existingSessionId > 0 && $this->sessionHasRecordedAttendance($existingSession, (int)$enrollment['student_id'])) {
                $this->sendJSON([
                    'error' => 'This session already has recorded attendance and its schedule cannot be changed.',
                    'error_code' => 'SESSION_ATTENDANCE_LOCKED'
                ], 409);
            }
            // Validate the database record whenever this request will update
            // it. Do not trust edit_existing: callers may omit or falsify it.
            if ($existingSessionId > 0 && !$this->canEditScheduledSession($existingSessionDate, $existingSessionStatus)) {
                $this->sendJSON(['error' => 'Only future scheduled sessions can be edited.'], 400);
            }

            $hasMultiSlots = !empty($this->getEnrollmentScheduleSlots($enrollmentId));
            $canEditRecurringPattern = $this->canEditEnrollmentScheduleBeforeFirstWeek($enrollmentId);
            if (
                ($hasMultiSlots || (
                    $this->tableHasColumn('tbl_enrollments', 'fixed_day_of_week') &&
                    $this->tableHasColumn('tbl_enrollments', 'fixed_start_time') &&
                    $this->tableHasColumn('tbl_enrollments', 'fixed_end_time')
                )) &&
                !empty($enrollment['assigned_teacher_id'])
            ) {
                $stmtFixed = $this->conn->prepare("
                    SELECT fixed_day_of_week, fixed_start_time, fixed_end_time, fixed_schedule_locked
                    FROM tbl_enrollments
                    WHERE enrollment_id = ?
                    LIMIT 1
                ");
                $stmtFixed->execute([$enrollmentId]);
                $fixed = $stmtFixed->fetch(PDO::FETCH_ASSOC) ?: [];
                if (
                    ($hasMultiSlots || (
                        !empty($fixed['fixed_day_of_week']) &&
                        !empty($fixed['fixed_start_time']) &&
                        !empty($fixed['fixed_end_time'])
                    )) &&
                    (int)($fixed['fixed_schedule_locked'] ?? 1) === 1
                ) {
                    if (!$isEditingExisting) {
                        $result = $this->generateFixedScheduleSessions($enrollmentId);
                        $generatedCount = (int)($result['created'] ?? 0) + (int)($result['updated'] ?? 0);
                        if ($generatedCount < $totalSessions) {
                            $this->sendJSON([
                                'error' => 'Selected instructor does not have enough available slots to generate the full package schedule.'
                            ], 400);
                        }
                        $this->sendJSON([
                            'success' => true,
                            'message' => 'Fixed weekly schedule is active. Sessions were refreshed automatically.',
                            'auto_generated' => $result
                        ]);
                    }
                }
            }
            if ($totalSessions > 0 && $sessionNumber > $totalSessions) {
                $this->sendJSON(['error' => 'Session number exceeds package total sessions'], 400);
            }

            $teacherId = (int)($enrollment['assigned_teacher_id'] ?? 0);
            if ($teacherId < 1 && $requestedTeacherId > 0) {
                $teacherId = $requestedTeacherId;
                try {
                    $stmtAssignTeacher = $this->conn->prepare("
                        UPDATE tbl_enrollments
                        SET assigned_teacher_id = ?
                        WHERE enrollment_id = ?
                          AND (assigned_teacher_id IS NULL OR assigned_teacher_id = 0)
                    ");
                    $stmtAssignTeacher->execute([$teacherId, $enrollmentId]);
                } catch (PDOException $e) {
                    // Keep scheduling flow working even if backfill update fails.
                }
            }
            if ($teacherId < 1) {
                $this->sendJSON(['error' => 'This enrollment does not have a fixed teacher assigned yet'], 400);
            }
            if ($requestedTeacherId > 0 && $requestedTeacherId !== $teacherId) {
                $this->sendJSON(['error' => 'Teacher is fixed for this package and cannot be changed here'], 400);
            }
            $roomId = null;
            $notes = null;

            $excludeSessionIds = [];
            if ($existingSessionId > 0) {
                $excludeSessionIds[] = $existingSessionId;
            }
            if ($this->hasStudentScheduleConflict((int)$enrollment['student_id'], $sessionDate, $startTime, $endTime, $excludeSessionIds)) {
                $this->sendJSON(['error' => 'Student already has another overlapping session at that time'], 400);
            }

            $instrumentId = (int)($enrollment['instrument_id'] ?? 0);
            if ($instrumentId < 1 && $this->tableExists('tbl_student_instruments')) {
                $stmtInst = $this->conn->prepare("
                    SELECT instrument_id
                    FROM tbl_student_instruments
                    WHERE student_id = ?
                    ORDER BY priority_order ASC, student_instrument_id ASC
                    LIMIT 1
                ");
                $stmtInst->execute([(int)$enrollment['student_id']]);
                $instrumentId = (int)($stmtInst->fetchColumn() ?: 0);
            }

            if ($existingSessionId > 0) {
                $stmtUpdate = $this->conn->prepare("
                    UPDATE tbl_sessions
                    SET teacher_id = ?,
                        instrument_id = ?,
                        session_date = ?,
                        start_time = ?,
                        end_time = ?,
                        room_id = ?,
                        notes = ?,
                        status = 'Scheduled'
                    WHERE session_id = ?
                ");
                $stmtUpdate->execute([
                    $teacherId,
                    $instrumentId > 0 ? $instrumentId : null,
                    $sessionDate,
                    $startTime,
                    $endTime,
                    $roomId,
                    $notes,
                    $existingSessionId
                ]);
            } else {
                $stmtInsert = $this->conn->prepare("
                    INSERT INTO tbl_sessions (
                        enrollment_id,
                        teacher_id,
                        session_number,
                        session_date,
                        start_time,
                        end_time,
                        session_type,
                        instrument_id,
                        room_id,
                        status,
                        notes
                    ) VALUES (?, ?, ?, ?, ?, ?, 'Regular', ?, ?, 'Scheduled', ?)
                ");
                $stmtInsert->execute([
                    $enrollmentId,
                    $teacherId,
                    $sessionNumber,
                    $sessionDate,
                    $startTime,
                    $endTime,
                    $instrumentId > 0 ? $instrumentId : null,
                    $roomId,
                    $notes
                ]);
            }

            $this->sendJSON(['success' => true, 'message' => 'Session scheduled successfully.']);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Admin/desk approves student package request and assigns package + instruments
    public function approvePackageRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }
        $actor = fas_require_authenticated_user($this->conn);
        if (!in_array(fas_normalize_role_category($actor['role_name'] ?? ''), ['admin','owner','manager','staff'], true)) {
            $this->sendJSON(['error' => 'Only authorized desk staff can approve schedules'], 403);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $requestId = (int) ($data['request_id'] ?? 0);
        $teacherId = (int) ($data['teacher_id'] ?? 0);
        $deskBranchId = (int) ($data['branch_id'] ?? $data['desk_branch_id'] ?? 0);
        $assignedDate = trim($data['assigned_date'] ?? '');
        $assignedRoom = trim($data['assigned_room'] ?? '');
        $assignedSlotsInput = is_array($data['assigned_slots'] ?? null) ? $data['assigned_slots'] : [];
        $adminNotes = trim($data['admin_notes'] ?? '');
        $overridePendingReservations = !empty($data['override_pending_reservations']);
        $conflictResolutions = is_array($data['conflict_resolutions'] ?? null) ? $data['conflict_resolutions'] : [];
        if ($requestId < 1) {
            $this->sendJSON(['error' => 'request_id is required'], 400);
        }
        if ($teacherId < 1) {
            $this->sendJSON(['error' => 'teacher_id is required'], 400);
        }
        if ($assignedDate === '') {
            $this->sendJSON(['error' => 'assigned_date is required'], 400);
        }
        $computedAssignedDay = $this->dayOfWeekFromDate($assignedDate);
        if ($computedAssignedDay === '') {
            $this->sendJSON(['error' => 'Invalid assigned_date'], 400);
        }

        $this->ensureSessionPackageColumn();
        $this->ensureStudentInstrumentsTable();
        $this->ensureStudentRegistrationFeesTable();
        $this->ensureEnrollmentPaymentTypeColumn();
        $this->ensurePaymentsPaymentTypeColumn();

        try {
            $this->conn->beginTransaction();

            // A deterministic lock order prevents two desk users from approving
            // overlapping requests at the same time.
            $this->conn->query("SELECT enrollment_id FROM tbl_enrollments WHERE status = 'Pending' ORDER BY enrollment_id FOR UPDATE")->fetchAll(PDO::FETCH_COLUMN);
            $this->expirePendingScheduleReservations();

            $stmtReq = $this->conn->prepare("
                SELECT
                    e.enrollment_id AS request_id,
                    e.student_id,
                    s.branch_id,
                    e.package_id,
                    e.instrument_id,
                    e.preferred_schedule,
                    e.request_notes,
                    e.status
                FROM tbl_enrollments e
                INNER JOIN tbl_students s ON e.student_id = s.student_id
                WHERE e.enrollment_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $stmtReq->execute([$requestId]);
            $req = $stmtReq->fetch(PDO::FETCH_ASSOC);
            if (!$req) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Request not found'], 404);
            }
            if ($req['status'] !== 'Pending') {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Only pending requests can be approved'], 400);
            }

            // Optional: enforce desk branch context when provided by the caller.
            if ($deskBranchId > 0 && (int)($req['branch_id'] ?? 0) !== $deskBranchId) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Request does not belong to your branch'], 403);
            }

            if (empty($assignedSlotsInput)) {
                $legacyStart = trim((string)($data['assigned_start_time'] ?? ''));
                $legacyEnd = trim((string)($data['assigned_end_time'] ?? ''));
                if ($legacyStart !== '' && $legacyEnd !== '') {
                    $assignedSlotsInput = [[
                        'day_of_week' => $computedAssignedDay,
                        'start_time' => $legacyStart,
                        'end_time' => $legacyEnd,
                        'room_name' => ''
                    ]];
                }
            }

            $requestMetaForConflict = $this->decodeRequestMeta($req['request_notes'] ?? '');
            $isWalkinRequestForConflict = !empty($requestMetaForConflict['is_walkin_request']);

            $instrumentIds = [];
            if (!empty($req['request_notes'])) {
                $decoded = json_decode((string)$req['request_notes'], true);
                if (is_array($decoded) && !empty($decoded['instrument_ids']) && is_array($decoded['instrument_ids'])) {
                    $instrumentIds = array_values(array_unique(array_map('intval', $decoded['instrument_ids'])));
                    $instrumentIds = array_filter($instrumentIds, function ($v) { return $v > 0; });
                }
            }
            if (empty($instrumentIds) && !empty($req['instrument_id'])) {
                $instrumentIds = [(int)$req['instrument_id']];
            }

            $instrumentKeywords = [];
            $instrumentLookup = [];
            if (!empty($instrumentIds)) {
                $placeholders = implode(',', array_fill(0, count($instrumentIds), '?'));
                $stmtInst = $this->conn->prepare("
                    SELECT i.instrument_id, i.instrument_name, i.type_id, it.type_name
                    FROM tbl_instruments i
                    LEFT JOIN tbl_instrument_types it ON i.type_id = it.type_id
                    WHERE i.instrument_id IN ({$placeholders})
                ");
                $stmtInst->execute($instrumentIds);
                $instRows = $stmtInst->fetchAll(PDO::FETCH_ASSOC);
                foreach ($instRows as $instRow) {
                    $instId = (int)($instRow['instrument_id'] ?? 0);
                    if ($instId < 1) continue;
                    $instrumentLookup[$instId] = [
                        'instrument_id' => $instId,
                        'instrument_name' => (string)($instRow['instrument_name'] ?? ''),
                        'type_id' => (int)($instRow['type_id'] ?? 0),
                        'type_name' => (string)($instRow['type_name'] ?? '')
                    ];
                    if (!empty($instRow['instrument_name'])) $instrumentKeywords[] = $instRow['instrument_name'];
                    if (!empty($instRow['type_name'])) $instrumentKeywords[] = $instRow['type_name'];
                }
            }

            try {
                $normalizedAssignedSlots = $this->normalizeAssignedScheduleSlots(
                    $assignedSlotsInput,
                    $teacherId,
                    (int)$req['branch_id'],
                    '',
                    (int)$req['student_id'],
                    [],
                    $instrumentLookup
                );
            } catch (InvalidArgumentException $e) {
                $isScheduleConflict = stripos($e->getMessage(), 'conflict') !== false || stripos($e->getMessage(), 'not available') !== false;
                if ($isScheduleConflict) {
                    $alternatives = $this->buildTeacherAvailableSlots($teacherId, (int)$req['branch_id'], (int)$req['student_id'], null, [], 45, date('Y-m-d'), [$requestId]);
                    if (!$isWalkinRequestForConflict) {
                        $requestMetaForConflict['schedule_request_status'] = 'Schedule Conflict';
                        $requestMetaForConflict['schedule_conflict_detected_at'] = date('Y-m-d H:i:s');
                        $requestMetaForConflict['reservation_expires_at'] = null;
                        $stmtConflict = $this->conn->prepare("UPDATE tbl_enrollments SET schedule_request_status = 'Schedule Conflict', reservation_expires_at = NULL, request_notes = ? WHERE enrollment_id = ? AND status = 'Pending'");
                        $stmtConflict->execute([json_encode($requestMetaForConflict), $requestId]);
                        $this->conn->commit();
                    } else {
                        $this->conn->rollBack();
                    }
                    $this->sendJSON([
                        'error' => $e->getMessage(),
                        'conflict_type' => 'occupied_or_unavailable',
                        'schedule_request_status' => $isWalkinRequestForConflict ? 'Pending' : 'Schedule Conflict',
                        'alternative_slots' => array_slice($alternatives, 0, 8)
                    ], 409);
                }
                $this->conn->rollBack();
                $this->sendJSON(['error' => $e->getMessage()], 400);
            }

            if (empty($normalizedAssignedSlots)) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Add at least one weekly schedule slot before approval'], 400);
            }

            $packagePrice = 0.0;
            $packageSessions = 0;
            $packageName = 'Lesson Package';
            if ($this->tableExists('tbl_session_packages')) {
                $stmtPackage = $this->conn->prepare("
                    SELECT package_name, sessions, COALESCE(price, 0) AS price
                    FROM tbl_session_packages
                    WHERE package_id = ?
                    LIMIT 1
                ");
                $stmtPackage->execute([(int)$req['package_id']]);
                $pkg = $stmtPackage->fetch(PDO::FETCH_ASSOC);
                if ($pkg) {
                    $packagePrice    = (float)($pkg['price']    ?? 0);
                    $packageSessions = max(1, (int)($pkg['sessions'] ?? 0)); // never 0
                    $packageName     = trim((string)($pkg['package_name'] ?? 'Lesson Package')) ?: 'Lesson Package';
                }
            }

            $pendingConflictsById = [];
            $hardScheduleConflict = '';
            $approvalSessionCount = max($packageSessions, (int)($requestMetaForConflict['requested_session_count'] ?? $packageSessions));
            $projectionSeeds = [];
            foreach ($normalizedAssignedSlots as $index => $normalizedSlot) {
                $inputSlot = is_array($assignedSlotsInput[$index] ?? null) ? $assignedSlotsInput[$index] : [];
                $seedDate = trim((string)($inputSlot['session_date'] ?? ''));
                if ($seedDate === '') {
                    $seedDate = (string)$this->nextDateForDayOfWeek($assignedDate, (string)($normalizedSlot['day_of_week'] ?? ''));
                }
                $normalizedSlot['session_date'] = $seedDate;
                $projectionSeeds[] = $normalizedSlot;
            }
            $projectedAssignedSlots = $this->projectRequestedSessionSlots([
                'preferred_slots' => $projectionSeeds,
                'requested_session_count' => $approvalSessionCount
            ]);
            foreach ($projectedAssignedSlots as $slot) {
                if (!is_array($slot)) continue;
                $slotTeacherId = (int)($slot['teacher_id'] ?? $teacherId);
                $slotDate = trim((string)($slot['session_date'] ?? $assignedDate));
                $slotDay = trim((string)($slot['day_of_week'] ?? $this->dayOfWeekFromDate($slotDate)));
                $slotStart = strlen(trim((string)($slot['start_time'] ?? ''))) === 5 ? trim((string)$slot['start_time']) . ':00' : trim((string)($slot['start_time'] ?? ''));
                $slotEnd = strlen(trim((string)($slot['end_time'] ?? ''))) === 5 ? trim((string)$slot['end_time']) . ':00' : trim((string)($slot['end_time'] ?? ''));
                $slotRoomId = !empty($slot['room_id']) ? (int)$slot['room_id'] : null;
                if ($slotTeacherId > 0 && $slotDate !== '' && $slotStart !== '' && $slotEnd !== '') {
                    if (!$this->teacherHasAvailabilityForSlot($slotTeacherId, $slotDate, $slotStart, $slotEnd, (int)$req['branch_id'])) {
                        $hardScheduleConflict = "Instructor is blocked or unavailable for {$slotDay} {$slotStart}-{$slotEnd}";
                    } elseif ($this->hasTeacherScheduleConflict($slotTeacherId, $slotDate, $slotStart, $slotEnd)) {
                        $hardScheduleConflict = "Instructor already has a scheduled session on {$slotDate} {$slotStart}-{$slotEnd}";
                    } elseif ($this->hasStudentScheduleConflict((int)$req['student_id'], $slotDate, $slotStart, $slotEnd)) {
                        $hardScheduleConflict = "Student already has a scheduled session on {$slotDate} {$slotStart}-{$slotEnd}";
                    } elseif ($slotRoomId !== null && $this->hasRoomScheduleConflict($slotRoomId, $slotDate, $slotStart, $slotEnd)) {
                        $hardScheduleConflict = "Room already has a scheduled session on {$slotDate} {$slotStart}-{$slotEnd}";
                    }
                }
                foreach ($this->getPendingReservationConflicts($slotTeacherId, $slotDate, $slotDay, $slotStart, $slotEnd, [$requestId]) as $conflict) {
                    $pendingConflictsById[(int)$conflict['request_id']] = $conflict;
                }
            }
            $pendingConflicts = array_values($pendingConflictsById);
            if ($pendingConflicts && (!$isWalkinRequestForConflict || !$overridePendingReservations)) {
                foreach ($pendingConflicts as &$conflict) {
                    $candidateSlots = $this->buildTeacherAvailableSlots(
                        (int)$conflict['teacher_id'],
                        (int)$conflict['branch_id'],
                        (int)$conflict['student_id'],
                        null,
                        [],
                        45,
                        date('Y-m-d'),
                        [(int)$conflict['request_id']]
                    );
                    $conflict['alternative_slots'] = array_slice(array_values(array_filter($candidateSlots, function ($candidate) use ($assignedSlotsInput) {
                        foreach ($assignedSlotsInput as $walkinSlot) {
                            $walkinTeacher = (int)($walkinSlot['teacher_id'] ?? 0);
                            $candidateTeacher = (int)($candidate['teacher_id'] ?? $walkinTeacher);
                            if ($candidateTeacher === $walkinTeacher
                                && (string)($candidate['session_date'] ?? '') === (string)($walkinSlot['session_date'] ?? '')
                                && (string)($candidate['start_time'] ?? '') < (string)($walkinSlot['end_time'] ?? '')
                                && (string)($candidate['end_time'] ?? '') > (string)($walkinSlot['start_time'] ?? '')) return false;
                        }
                        return true;
                    })), 0, 8);
                    foreach ($conflict['alternative_slots'] as &$alternative) {
                        $alternative['teacher_id'] = (int)$conflict['teacher_id'];
                    }
                    unset($alternative);
                }
                unset($conflict);
                if (!$isWalkinRequestForConflict) {
                    $requestMetaForConflict['schedule_request_status'] = 'Schedule Conflict';
                    $requestMetaForConflict['schedule_conflict_detected_at'] = date('Y-m-d H:i:s');
                    $requestMetaForConflict['reservation_expires_at'] = null;
                    $updateConflict = $this->conn->prepare("UPDATE tbl_enrollments SET schedule_request_status = 'Schedule Conflict', reservation_expires_at = NULL, request_notes = ? WHERE enrollment_id = ? AND status = 'Pending'");
                    $updateConflict->execute([json_encode($requestMetaForConflict), $requestId]);
                    $this->conn->commit();
                } else {
                    $this->conn->rollBack();
                }
                $this->sendJSON([
                    'error' => $isWalkinRequestForConflict ? 'This walk-in schedule overlaps a pending online reservation.' : 'This request can no longer be approved because the schedule is reserved.',
                    'conflict_type' => 'pending_online_request',
                    'requires_override' => $isWalkinRequestForConflict,
                    'conflicts' => $pendingConflicts
                ], 409);
            }
            if ($pendingConflicts && $isWalkinRequestForConflict && $overridePendingReservations) {
                $resolutionsById = [];
                foreach ($conflictResolutions as $resolution) {
                    if (is_array($resolution) && (int)($resolution['request_id'] ?? 0) > 0 && is_array($resolution['suggested_slot'] ?? null)) {
                        $resolutionsById[(int)$resolution['request_id']] = $resolution['suggested_slot'];
                    }
                }
                foreach ($pendingConflicts as $conflict) {
                    $conflictId = (int)$conflict['request_id'];
                    if (empty($resolutionsById[$conflictId])) {
                        $this->conn->rollBack();
                        $this->sendJSON(['error' => 'Suggest another available schedule for every affected online requester before continuing.'], 400);
                    }
                }
            }
            if ($hardScheduleConflict !== '') {
                $alternatives = $this->buildTeacherAvailableSlots($teacherId, (int)$req['branch_id'], (int)$req['student_id'], null, [], 45, date('Y-m-d'), [$requestId]);
                if (!$isWalkinRequestForConflict) {
                    $requestMetaForConflict['schedule_request_status'] = 'Schedule Conflict';
                    $requestMetaForConflict['schedule_conflict_detected_at'] = date('Y-m-d H:i:s');
                    $requestMetaForConflict['reservation_expires_at'] = null;
                    $stmtConflict = $this->conn->prepare("UPDATE tbl_enrollments SET schedule_request_status = 'Schedule Conflict', reservation_expires_at = NULL, request_notes = ? WHERE enrollment_id = ? AND status = 'Pending'");
                    $stmtConflict->execute([json_encode($requestMetaForConflict), $requestId]);
                    $this->conn->commit();
                } else {
                    $this->conn->rollBack();
                }
                $this->sendJSON(['error' => $hardScheduleConflict, 'conflict_type' => 'occupied_or_unavailable', 'schedule_request_status' => $isWalkinRequestForConflict ? 'Pending' : 'Schedule Conflict', 'alternative_slots' => array_slice($alternatives, 0, 8)], 409);
            }

            $basePackagePrice = $packagePrice;
            $basePackageSessions = $packageSessions;
            $requestMeta = [];
            if (!empty($req['request_notes'])) {
                $decoded = json_decode((string)$req['request_notes'], true);
                if (is_array($decoded)) $requestMeta = $decoded;
            }
            $requestedSessionCount = max($basePackageSessions, (int)($requestMeta['requested_session_count'] ?? $basePackageSessions));
            $extraSessionCount = max(0, $requestedSessionCount - $basePackageSessions);
            $packageSessions = $requestedSessionCount;
            $packagePrice = (float)($requestMeta['package_total_amount'] ?? ($basePackagePrice + ($extraSessionCount * 650.00)));

            $stmtUpdateStudent = $this->conn->prepare("
                UPDATE tbl_students
                SET session_package_id = ?
                WHERE student_id = ?
            ");
            $stmtUpdateStudent->execute([(int) $req['package_id'], (int) $req['student_id']]);

            $stmtDelete = $this->conn->prepare("DELETE FROM tbl_student_instruments WHERE student_id = ?");
            $stmtDelete->execute([(int) $req['student_id']]);

            if (!empty($instrumentIds)) {
                $stmtInsertInst = $this->conn->prepare("
                    INSERT INTO tbl_student_instruments (student_id, instrument_id, priority_order)
                    VALUES (?, ?, ?)
                ");
                $priority = 1;
                foreach ($instrumentIds as $iid) {
                    $stmtInsertInst->execute([(int) $req['student_id'], (int) $iid, $priority]);
                    $priority++;
                }
            }

            // Create enrollment record once request is finalized.
            $primaryInstrumentId = !empty($instrumentIds) ? (int)$instrumentIds[0] : 0;
            if ($primaryInstrumentId < 1) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'No instrument selected for enrollment'], 400);
            }
            $primaryTeacherId = (int)($normalizedAssignedSlots[0]['teacher_id'] ?? 0);
            if ($primaryTeacherId < 1) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'No teacher selected for the first instrument slot'], 400);
            }
            if (!$this->tableExists('tbl_enrollments')) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'tbl_enrollments table not found'], 500);
            }

            $endDate = $assignedDate;
            if ($packageSessions > 0) {
                $slotsPerWeek = max(1, count($normalizedAssignedSlots));
                $weeksNeeded = (int)ceil(max(0, $packageSessions - 1) / $slotsPerWeek);
                $endDate = date('Y-m-d', strtotime($assignedDate . ' +' . max(0, $weeksNeeded * 7) . ' days'));
            }

            $enrollmentMode = strtolower(trim((string)($requestMeta['enrollment_mode'] ?? 'extension')));
            $isInitialEnrollment = $enrollmentMode === 'initial';
            $paymentType = $this->normalizeEnrollmentPaymentType($requestMeta['payment_type'] ?? 'Partial Payment');
            if ($paymentType === '') {
                $paymentType = 'Partial Payment';
            }
            $paymentMethod = $this->normalizeEnrollmentPaymentMethod($requestMeta['payment_method'] ?? '');
            $referenceNumber = trim((string)($requestMeta['reference_number'] ?? ''));
            $paymentProofPath = trim((string)($requestMeta['payment_proof_path'] ?? ''));
            $isWalkinRequest = !empty($requestMeta['is_walkin_request']);
            $payableNow = (float)($requestMeta['payable_now'] ?? 0);
            if ($payableNow <= 0) {
                $payableNow = $this->computeEnrollmentPayableNow($packagePrice, $packageSessions, $paymentType);
            }
            if ($paymentMethod === '') {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'The student has not submitted an enrollment payment method yet.'], 400);
            }
            if ($payableNow <= 0) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'The enrollment payment amount is invalid.'], 400);
            }
            if ($isInitialEnrollment) {
                if ($basePackageSessions !== 12) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'Initial enrollment must use the 12-session package.'], 400);
                }
                if (count($instrumentIds) !== 1) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'Initial enrollment must start with one selected instrument.'], 400);
                }
            }
            if (!$isWalkinRequest && $paymentMethod !== 'Cash' && $paymentProofPath === '') {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Enrollment proof of payment is required before approval.'], 400);
            }
            if ($adminNotes !== '') {
                $requestMeta['admin_notes'] = $adminNotes;
            }
            $requestMeta['payment_type'] = $paymentType;
            $requestMeta['payment_method'] = $paymentMethod;
            $requestMeta['payable_now'] = $payableNow;
            $requestMeta['package_total_amount'] = (float)$packagePrice;
            $requestMeta['payment_proof_path'] = $paymentProofPath;
            $requestMeta['schedule_request_status'] = 'Approved';
            $requestMeta['reservation_expires_at'] = null;
            $requestMeta['approved_at'] = date('Y-m-d H:i:s');
            $enrollmentHasPaymentType = $this->tableHasColumn('tbl_enrollments', 'payment_type');
            $paymentTypeSql = $enrollmentHasPaymentType ? "payment_type = ?," : "";
            $allowedAbsences = $this->getAllowedAbsencesForSessionCount((int)$packageSessions);
            $firstSlot = $normalizedAssignedSlots[0];
            $fixedScheduleLabel = $this->formatScheduleSlotsSummary($normalizedAssignedSlots);
            $fixedRoomId = $firstSlot['room_id'] ?? null;
            $updateParams = [
                $primaryInstrumentId,
                $primaryTeacherId,
                ($fixedScheduleLabel !== '' ? $fixedScheduleLabel : null),
                json_encode($requestMeta),
                $assignedDate,
                $endDate,
                max(1, (int)$packageSessions),
                $firstSlot['day_of_week'],
                $firstSlot['start_time'],
                $firstSlot['end_time'],
                $fixedRoomId,
                $allowedAbsences,
            ];
            if ($enrollmentHasPaymentType) {
                $updateParams[] = $paymentType;
            }
            $updateParams[] = (int)$requestId;
            $stmtUpdateEnrollment = $this->conn->prepare("
                UPDATE tbl_enrollments
                SET instrument_id = ?,
                    assigned_teacher_id = ?,
                    preferred_schedule = ?,
                    request_notes = ?,
                    start_date = ?,
                    end_date = ?,
                    total_sessions = ?,
                    fixed_day_of_week = ?,
                    fixed_start_time = ?,
                    fixed_end_time = ?,
                    fixed_room_id = ?,
                    allowed_absences = ?,
                    used_absences = 0,
                    consecutive_absences = 0,
                    schedule_status = 'Active',
                    schedule_request_status = 'Approved',
                    reservation_expires_at = NULL,
                    fixed_schedule_locked = 1,
                    completed_sessions = 0,
                    {$paymentTypeSql}
                    status = 'Active'
                WHERE enrollment_id = ?
                  AND status = 'Pending'
            ");
            $stmtUpdateEnrollment->execute($updateParams);
            if ($stmtUpdateEnrollment->rowCount() === 0) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Pending enrollment request not found'], 404);
            }
            $newEnrollmentId = (int)$requestId;

            if ($this->tableExists('tbl_payments')) {
                $paymentColumns = [];
                $paymentValues = [];

                if ($this->tableHasColumn('tbl_payments', 'enrollment_id')) {
                    $paymentColumns[] = 'enrollment_id';
                    $paymentValues[] = $newEnrollmentId;
                }
                if ($this->tableHasColumn('tbl_payments', 'amount')) {
                    $paymentColumns[] = 'amount';
                    $paymentValues[] = $payableNow;
                }
                if ($this->tableHasColumn('tbl_payments', 'payment_method')) {
                    $paymentColumns[] = 'payment_method';
                    $paymentValues[] = $paymentMethod;
                }
                if ($this->tableHasColumn('tbl_payments', 'payment_type')) {
                    $paymentColumns[] = 'payment_type';
                    $paymentValues[] = $paymentType;
                }
                if ($this->tableHasColumn('tbl_payments', 'reference_number')) {
                    $paymentColumns[] = 'reference_number';
                    $paymentValues[] = $referenceNumber !== '' ? $referenceNumber : null;
                }
                if ($this->tableHasColumn('tbl_payments', 'status')) {
                    $paymentColumns[] = 'status';
                    $paymentValues[] = 'Paid';
                }
                if ($this->tableHasColumn('tbl_payments', 'payment_date')) {
                    $paymentColumns[] = 'payment_date';
                    $paymentValues[] = date('Y-m-d');
                }
                if ($this->tableHasColumn('tbl_payments', 'receipt_number')) {
                    $paymentColumns[] = 'receipt_number';
                    $paymentValues[] = 'ENR-' . $newEnrollmentId . '-' . time();
                }

                if (!empty($paymentColumns)) {
                    $placeholders = implode(', ', array_fill(0, count($paymentColumns), '?'));
                    $stmtPayment = $this->conn->prepare("
                        INSERT INTO tbl_payments (" . implode(', ', $paymentColumns) . ")
                        VALUES ({$placeholders})
                    ");
                    $stmtPayment->execute($paymentValues);
                }
            }

            if ($this->tableExists('tbl_enrollment_financials')) {
                $stmtFinancials = $this->conn->prepare("
                    INSERT INTO tbl_enrollment_financials (enrollment_id, total_amount, paid_amount, payment_deadline_session)
                    VALUES (?, ?, ?, ?)
                    ON DUPLICATE KEY UPDATE
                        total_amount = VALUES(total_amount),
                        paid_amount = VALUES(paid_amount),
                        payment_deadline_session = VALUES(payment_deadline_session)
                ");
                $deadlineSession = fas_balance_deadline_session((int)$basePackageSessions);
                $stmtFinancials->execute([
                    $newEnrollmentId,
                    (float)$packagePrice,
                    (float)$payableNow,
                    $deadlineSession
                ]);
            }

            $this->saveEnrollmentScheduleSlots($newEnrollmentId, $normalizedAssignedSlots);
            $generationResult = $this->generateFixedScheduleSessions($newEnrollmentId);
            $generatedCount = (int)($generationResult['created'] ?? 0) + (int)($generationResult['updated'] ?? 0);
            if ($generatedCount < $packageSessions) {
                $this->conn->rollBack();
                $this->sendJSON([
                    'error' => 'Selected instructor does not have enough available slots to complete the full package schedule. Please choose a different instructor or adjust the weekly slots.'
                ], 400);
            }

            if (!empty($pendingConflicts) && $isWalkinRequestForConflict && $overridePendingReservations) {
                $resolutionUpdate = $this->conn->prepare("SELECT request_notes FROM tbl_enrollments WHERE enrollment_id = ? AND status = 'Pending' FOR UPDATE");
                $saveResolution = $this->conn->prepare("UPDATE tbl_enrollments SET schedule_request_status = 'Schedule Conflict', reservation_expires_at = NULL, request_notes = ? WHERE enrollment_id = ? AND status = 'Pending'");
                foreach ($pendingConflicts as $conflict) {
                    $conflictId = (int)$conflict['request_id'];
                    $suggested = $resolutionsById[$conflictId] ?? [];
                    $suggestedTeacher = (int)($suggested['teacher_id'] ?? 0);
                    $suggestedDate = trim((string)($suggested['session_date'] ?? ''));
                    $suggestedStart = trim((string)($suggested['start_time'] ?? ''));
                    $suggestedEnd = trim((string)($suggested['end_time'] ?? ''));
                    $suggestedDay = $this->dayOfWeekFromDate($suggestedDate);
                    if ($suggestedTeacher < 1 || $suggestedDate === '' || $suggestedStart === '' || $suggestedEnd === ''
                        || !$this->teacherHasAvailabilityForSlot($suggestedTeacher, $suggestedDate, $suggestedStart, $suggestedEnd, (int)$conflict['branch_id'])
                        || $this->hasTeacherScheduleConflict($suggestedTeacher, $suggestedDate, $suggestedStart, $suggestedEnd)
                        || $this->hasTeacherRecurringScheduleConflict($suggestedTeacher, $suggestedDay, $suggestedStart, $suggestedEnd)
                        || $this->getPendingReservationConflicts($suggestedTeacher, $suggestedDate, $suggestedDay, $suggestedStart, $suggestedEnd, [$conflictId])) {
                        $this->conn->rollBack();
                        $this->sendJSON(['error' => 'A suggested replacement is no longer available. Choose another slot and try again.'], 409);
                    }
                    $resolutionUpdate->execute([$conflictId]);
                    $affectedMeta = $this->decodeRequestMeta($resolutionUpdate->fetchColumn());
                    $affectedMeta['schedule_request_status'] = 'Schedule Conflict';
                    $affectedMeta['reservation_expires_at'] = null;
                    $affectedMeta['schedule_conflict_detected_at'] = date('Y-m-d H:i:s');
                    $affectedMeta['conflicted_by_walkin_request_id'] = $requestId;
                    $affectedMeta['suggested_slots'] = [$suggested];
                    $saveResolution->execute([json_encode($affectedMeta), $conflictId]);
                }
            }

            $this->conn->commit();

            $this->sendJSON([
                'success' => true,
                'message' => 'Request approved and moved to enrollment'
            ]);
        } catch (PDOException $e) {
            $this->conn->rollBack();
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // Admin/desk rejects student package request
    public function rejectPackageRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }
        $actor = fas_require_authenticated_user($this->conn);
        if (!in_array(fas_normalize_role_category($actor['role_name'] ?? ''), ['admin','owner','manager','staff'], true)) {
            $this->sendJSON(['error' => 'Only authorized desk staff can reject requests'], 403);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $requestId = (int) ($data['request_id'] ?? 0);
        $adminNotes = trim($data['admin_notes'] ?? '');
        $deskBranchId = (int) ($data['branch_id'] ?? $data['desk_branch_id'] ?? 0);
        if ($requestId < 1) {
            $this->sendJSON(['error' => 'request_id is required'], 400);
        }

        try {
            if ($deskBranchId > 0) {
                // Validate the request belongs to the caller's branch.
                $stmtReq = $this->conn->prepare("
                    SELECT s.branch_id
                    FROM tbl_enrollments e
                    INNER JOIN tbl_students s ON e.student_id = s.student_id
                    WHERE e.enrollment_id = ?
                    LIMIT 1
                ");
                $stmtReq->execute([$requestId]);
                $reqRow = $stmtReq->fetch(PDO::FETCH_ASSOC);
                if (!$reqRow) {
                    $this->sendJSON(['error' => 'Request not found'], 404);
                }
                if ((int)($reqRow['branch_id'] ?? 0) !== $deskBranchId) {
                    $this->sendJSON(['error' => 'Request does not belong to your branch'], 403);
                }
            }

            $meta = [];
            $stmtGet = $this->conn->prepare("
                SELECT request_notes
                FROM tbl_enrollments
                WHERE enrollment_id = ?
                LIMIT 1
            ");
            $stmtGet->execute([$requestId]);
            $existingNotes = $stmtGet->fetchColumn();
            if ($existingNotes) {
                $decoded = json_decode((string)$existingNotes, true);
                if (is_array($decoded)) $meta = $decoded;
            }
            if ($adminNotes !== '') $meta['admin_notes'] = $adminNotes;
            $meta['schedule_request_status'] = 'Rejected';
            $meta['reservation_expires_at'] = null;
            $meta['rejected_at'] = date('Y-m-d H:i:s');
            $stmt = $this->conn->prepare("
                UPDATE tbl_enrollments
                SET status = 'Cancelled',
                    schedule_request_status = 'Rejected',
                    reservation_expires_at = NULL,
                    request_notes = ?
                WHERE enrollment_id = ?
                  AND status = 'Pending'
            ");
            $stmt->execute([json_encode($meta), $requestId]);
            if ($stmt->rowCount() === 0) {
                $this->sendJSON(['error' => 'Pending request not found'], 404);
            }
            $this->sendJSON(['success' => true, 'message' => 'Request rejected']);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    private function ensureStudentRegistrationFeesTable()
    {
        // Registration fee state now comes from tbl_registration_payments.
        return;
    }

    public function rescheduleSession()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }

        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $sessionId = (int)($data['session_id'] ?? 0);
        $sessionDate = trim((string)($data['session_date'] ?? ''));
        $startTime = trim((string)($data['start_time'] ?? ''));
        $endTime = trim((string)($data['end_time'] ?? ''));
        $requestedTeacherId = (int)($data['teacher_id'] ?? 0);

        $this->ensureFutureOrTodayDateOrFail($sessionDate, 'Reschedule date cannot be in the past.');
        $reason = trim((string)($data['reason'] ?? 'Student emergency reschedule'));

        if ($sessionId < 1 || $sessionDate === '' || $startTime === '' || $endTime === '') {
            $this->sendJSON(['error' => 'session_id, session_date, start_time, and end_time are required'], 400);
        }

        try {
            $this->conn->beginTransaction();

            $stmt = $this->conn->prepare("
                SELECT
                    ts.*,
                    e.student_id,
                    e.assigned_teacher_id,
                    s.branch_id
                FROM tbl_sessions ts
                INNER JOIN tbl_enrollments e ON e.enrollment_id = ts.enrollment_id
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                WHERE ts.session_id = ?
                LIMIT 1
                FOR UPDATE
            ");
            $stmt->execute([$sessionId]);
            $sourceSession = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$sourceSession) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Session not found'], 404);
            }

            if ($this->sessionHasRecordedAttendance($sourceSession, (int)($sourceSession['student_id'] ?? 0))) {
                $this->conn->rollBack();
                $this->sendJSON([
                    'error' => 'This session already has recorded attendance and cannot be rescheduled.',
                    'error_code' => 'SESSION_ATTENDANCE_LOCKED'
                ], 409);
            }

            $status = (string)($sourceSession['status'] ?? '');
            $isTeacherCancelled = $status === 'cancelled_by_teacher' && (int)($sourceSession['needs_rescheduling'] ?? 0) === 1;
            $isStudentEmergencyReschedulable = $status === 'Scheduled' && $this->isFutureOrTodayDate((string)($sourceSession['session_date'] ?? ''));
            if (!$isTeacherCancelled && !$isStudentEmergencyReschedulable) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Only teacher-cancelled or future scheduled sessions can be rescheduled'], 400);
            }

            $teacherId = (int)($sourceSession['assigned_teacher_id'] ?? 0);
            if ($teacherId < 1) {
                $teacherId = (int)($sourceSession['teacher_id'] ?? 0);
            }
            if ($teacherId < 1) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'No fixed teacher is assigned to this enrollment'], 400);
            }

            $instrumentIds = [];
            if (!empty($sourceSession['instrument_id'])) {
                $instrumentIds[] = (int)$sourceSession['instrument_id'];
            }
            $instrumentKeywords = [];
            if (!empty($sourceSession['instrument_id']) && $this->tableExists('tbl_instruments')) {
                try {
                    $stmtInstrument = $this->conn->prepare("
                        SELECT i.instrument_name, it.type_name
                        FROM tbl_instruments i
                        LEFT JOIN tbl_instrument_types it ON it.type_id = i.type_id
                        WHERE i.instrument_id = ?
                        LIMIT 1
                    ");
                    $stmtInstrument->execute([(int)$sourceSession['instrument_id']]);
                    $instrumentRow = $stmtInstrument->fetch(PDO::FETCH_ASSOC) ?: [];
                    if (!empty($instrumentRow['instrument_name'])) {
                        $instrumentKeywords[] = $instrumentRow['instrument_name'];
                    }
                    if (!empty($instrumentRow['type_name'])) {
                        $instrumentKeywords[] = $instrumentRow['type_name'];
                    }
                } catch (PDOException $e) {
                    // Use the existing teacher if instrument metadata lookup fails.
                }
            }
            $teacherCandidates = $this->buildTeacherCandidatesForEnrollment(
                (int)($sourceSession['branch_id'] ?? 0),
                $instrumentIds,
                $instrumentKeywords,
                $teacherId
            );
            if ($requestedTeacherId > 0) {
                $candidateIds = array_map(function ($candidate) {
                    return (int)($candidate['teacher_id'] ?? 0);
                }, $teacherCandidates);
                if (!in_array($requestedTeacherId, $candidateIds, true)) {
                    $this->conn->rollBack();
                    $this->sendJSON(['error' => 'Selected instructor does not match this package instrument'], 400);
                }
                $teacherId = $requestedTeacherId;
            }

            if (!$this->teacherHasAvailabilityForSlot($teacherId, $sessionDate, $startTime, $endTime)) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Selected slot is outside the teacher availability'], 400);
            }
            if ($this->hasTeacherScheduleConflict($teacherId, $sessionDate, $startTime, $endTime, [$sessionId])) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Teacher already has another session at that time'], 400);
            }
            if ($this->hasStudentScheduleConflict((int)$sourceSession['student_id'], $sessionDate, $startTime, $endTime, [$sessionId])) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'Student already has another session at that time'], 400);
            }

            $roomId = null;

            $historyNote = 'Rescheduled from session #' . (int)$sourceSession['session_id'] . ($reason !== '' ? ' - ' . $reason : '');
            $newStatus = $isTeacherCancelled ? 'rescheduled' : 'Scheduled';
            $stmtInsert = $this->conn->prepare("
                INSERT INTO tbl_sessions (
                    enrollment_id,
                    teacher_id,
                    session_number,
                    session_date,
                    start_time,
                    end_time,
                    session_type,
                    instrument_id,
                    school_instrument_id,
                    room_id,
                    status,
                    attendance_notes,
                    notes,
                    rescheduled_from_session_id,
                    rescheduled_to_session_id,
                    needs_rescheduling,
                    cancellation_reason,
                    cancelled_by_teacher_at,
                    rescheduled_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 0, NULL, NULL, NOW())
            ");
            $stmtInsert->execute([
                (int)$sourceSession['enrollment_id'],
                $teacherId,
                (int)$sourceSession['session_number'],
                $sessionDate,
                $startTime,
                $endTime,
                $sourceSession['session_type'] ?? 'Regular',
                !empty($sourceSession['instrument_id']) ? (int)$sourceSession['instrument_id'] : null,
                !empty($sourceSession['school_instrument_id']) ? (int)$sourceSession['school_instrument_id'] : null,
                ($roomId !== null && $roomId > 0) ? $roomId : null,
                $newStatus,
                $sourceSession['attendance_notes'] ?? null,
                $historyNote,
                (int)$sourceSession['session_id']
            ]);
            $newSessionId = (int)$this->conn->lastInsertId();

            if ($isTeacherCancelled) {
                $stmtUpdate = $this->conn->prepare("
                    UPDATE tbl_sessions
                    SET needs_rescheduling = 0,
                        rescheduled_to_session_id = ?,
                        rescheduled_at = NOW()
                    WHERE session_id = ?
                ");
                $stmtUpdate->execute([$newSessionId, $sessionId]);
            } else {
                $stmtUpdate = $this->conn->prepare("
                    UPDATE tbl_sessions
                    SET status = 'rescheduled',
                        cancellation_reason = ?,
                        rescheduled_to_session_id = ?,
                        rescheduled_at = NOW()
                    WHERE session_id = ?
                ");
                $stmtUpdate->execute([$reason !== '' ? $reason : 'Student emergency reschedule', $newSessionId, $sessionId]);
            }

            $this->conn->commit();
            $this->sendJSON([
                'success' => true,
                'message' => 'Session rescheduled successfully.',
                'new_session_id' => $newSessionId
            ]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    private function ensureStudentAgeVerificationProofColumn()
    {
        if ($this->hasStudentColumn('age_verification_proof_path')) return;
        try {
            if ($this->hasStudentColumn('registration_proof_path')) {
                $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN age_verification_proof_path VARCHAR(255) NULL AFTER registration_proof_path");
            } else {
                $this->conn->exec("ALTER TABLE tbl_students ADD COLUMN age_verification_proof_path VARCHAR(255) NULL");
            }
        } catch (PDOException $e) {
            // Keep API working even if alter fails
        }
    }

    // ── Freeze Payment: ensure table exists ───────────────────────
    private function ensureFreezePaymentsTable() {
        try {
            $this->conn->exec("
                CREATE TABLE IF NOT EXISTS `tbl_freeze_payments` (
                    `freeze_payment_id` INT NOT NULL AUTO_INCREMENT,
                    `enrollment_id`     INT NOT NULL,
                    `student_id`        INT NOT NULL,
                    `amount`            DECIMAL(10,2) NOT NULL DEFAULT 100.00,
                    `payment_method`    ENUM('Cash','GCash','Bank Transfer','Other') NOT NULL DEFAULT 'Cash',
                    `reference_number`  VARCHAR(100) NULL,
                    `proof_path`        VARCHAR(255) NULL,
                    `status`            ENUM('Pending','Paid','Rejected') NOT NULL DEFAULT 'Pending',
                    `receipt_number`    VARCHAR(50) NULL,
                    `notes`             TEXT NULL,
                    `reviewed_by`       INT NULL,
                    `reviewed_at`       DATETIME NULL,
                    `payment_date`      DATE NULL,
                    `source`            ENUM('online','walkin') NOT NULL DEFAULT 'online',
                    `created_at`        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`freeze_payment_id`),
                    KEY `idx_fp_enrollment` (`enrollment_id`),
                    KEY `idx_fp_student`    (`student_id`),
                    KEY `idx_fp_status`     (`status`)
                ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
            ");
        } catch (PDOException $e) { /* table may already exist */ }

        // Preserve old attendance records while starting a new absence cycle
        // whenever the reservation/freeze payment is settled.
        try {
            if ($this->tableExists('tbl_enrollments') && !$this->tableHasColumn('tbl_enrollments', 'absence_reset_at')) {
                $this->conn->exec("ALTER TABLE tbl_enrollments ADD COLUMN absence_reset_at DATETIME NULL AFTER consecutive_absences");
            }
        } catch (PDOException $e) { /* keep payment endpoints available */ }
    }

    public function suggestPackageRequest()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->sendJSON(['error' => 'Method not allowed'], 405);
        $actor = fas_require_authenticated_user($this->conn);
        if (!in_array(fas_normalize_role_category($actor['role_name'] ?? ''), ['admin','owner','manager','staff'], true)) {
            $this->sendJSON(['error' => 'Only authorized desk staff can suggest schedules'], 403);
        }
        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $requestId = (int)($data['request_id'] ?? 0);
        $deskBranchId = (int)($data['branch_id'] ?? 0);
        $suggested = is_array($data['suggested_slot'] ?? null) ? $data['suggested_slot'] : [];
        $teacherId = (int)($suggested['teacher_id'] ?? 0);
        $date = trim((string)($suggested['session_date'] ?? ''));
        $start = trim((string)($suggested['start_time'] ?? ''));
        $end = trim((string)($suggested['end_time'] ?? ''));
        $day = $this->dayOfWeekFromDate($date);
        if ($requestId < 1 || $teacherId < 1 || $date === '' || $start === '' || $end === '') {
            $this->sendJSON(['error' => 'request_id and a complete suggested_slot are required'], 400);
        }
        try {
            $this->conn->beginTransaction();
            $this->conn->query("SELECT enrollment_id FROM tbl_enrollments WHERE status = 'Pending' ORDER BY enrollment_id FOR UPDATE")->fetchAll(PDO::FETCH_COLUMN);
            $stmt = $this->conn->prepare("SELECT e.request_notes, s.branch_id FROM tbl_enrollments e INNER JOIN tbl_students s ON s.student_id = e.student_id WHERE e.enrollment_id = ? AND e.status = 'Pending' FOR UPDATE");
            $stmt->execute([$requestId]);
            $requestRow = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$requestRow) { $this->conn->rollBack(); $this->sendJSON(['error' => 'Pending request not found'], 404); }
            if ($deskBranchId > 0 && (int)$requestRow['branch_id'] !== $deskBranchId) { $this->conn->rollBack(); $this->sendJSON(['error' => 'Request does not belong to your branch'], 403); }
            $notes = $requestRow['request_notes'] ?? '';
            if (!$this->teacherHasAvailabilityForSlot($teacherId, $date, $start, $end, (int)$requestRow['branch_id'])
                || $this->hasTeacherScheduleConflict($teacherId, $date, $start, $end)
                || $this->hasTeacherRecurringScheduleConflict($teacherId, $day, $start, $end)
                || $this->getPendingReservationConflicts($teacherId, $date, $day, $start, $end, [$requestId])) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'That suggested schedule is no longer available.'], 409);
            }
            $meta = $this->decodeRequestMeta($notes);
            $suggested['day_of_week'] = $day;
            $meta['schedule_request_status'] = 'Suggested';
            $meta['suggested_slots'] = [$suggested];
            $meta['reservation_expires_at'] = null;
            $meta['suggested_at'] = date('Y-m-d H:i:s');
            $update = $this->conn->prepare("UPDATE tbl_enrollments SET schedule_request_status = 'Suggested', reservation_expires_at = NULL, request_notes = ? WHERE enrollment_id = ? AND status = 'Pending'");
            $update->execute([json_encode($meta), $requestId]);
            $this->conn->commit();
            $this->sendJSON(['success' => true, 'message' => 'A new schedule was suggested to the requester.']);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // ── Student submits freeze payment (online or walkin intent) ──
    public function submitFreezePayment() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { $this->sendJSON(['error' => 'Method not allowed'], 405); }
        $this->ensureFreezePaymentsTable();

        $isMultipart = $this->isMultipartRequest();
        $data        = $isMultipart ? ($_POST ?: []) : (json_decode(file_get_contents('php://input'), true) ?: []);

        $enrollmentId    = (int)($data['enrollment_id'] ?? 0);
        $studentId       = (int)($data['student_id']    ?? 0);
        $paymentMethod   = trim((string)($data['payment_method']   ?? 'Cash'));
        $referenceNumber = trim((string)($data['reference_number'] ?? ''));
        $notes           = trim((string)($data['notes']            ?? ''));
        $source          = in_array($data['source'] ?? '', ['online','walkin']) ? $data['source'] : 'online';

        if ($enrollmentId < 1 || $studentId < 1) {
            $this->sendJSON(['error' => 'enrollment_id and student_id are required'], 400);
        }

        $actor = fas_require_authenticated_user($this->conn);
        $roleCategory = fas_normalize_role_category($actor['role_name'] ?? '');
        $staffRoles = ['admin', 'owner', 'manager', 'staff'];

        $stmtEnrollmentOwner = $this->conn->prepare("
            SELECT 1 FROM tbl_enrollments
            WHERE enrollment_id = ? AND student_id = ?
            LIMIT 1
        ");
        $stmtEnrollmentOwner->execute([$enrollmentId, $studentId]);
        if (!$stmtEnrollmentOwner->fetchColumn()) {
            $this->sendJSON(['error' => 'Enrollment does not belong to this student'], 400);
        }

        if ($roleCategory === 'guardian') {
            $stmtGuardianAccess = $this->conn->prepare("
                SELECT 1
                FROM tbl_student_guardians sg
                INNER JOIN tbl_guardians g ON g.guardian_id = sg.guardian_id
                WHERE sg.student_id = ?
                  AND (g.guardian_user_id = ? OR sg.guardian_user_id = ? OR (g.guardian_user_id IS NULL AND g.email = ?))
                LIMIT 1
            ");
            $stmtGuardianAccess->execute([
                $studentId,
                (int)($actor['user_id'] ?? 0),
                (int)($actor['user_id'] ?? 0),
                trim((string)($actor['email'] ?? ''))
            ]);
            if (!$stmtGuardianAccess->fetchColumn()) {
                $this->sendJSON(['error' => 'You are not authorized to pay for this student'], 403);
            }
        } elseif ($roleCategory === 'student') {
            $stmtStudentAccess = $this->conn->prepare("
                SELECT 1 FROM tbl_students
                WHERE student_id = ? AND (student_user_id = ? OR email = ?)
                LIMIT 1
            ");
            $stmtStudentAccess->execute([
                $studentId,
                (int)($actor['user_id'] ?? 0),
                trim((string)($actor['email'] ?? ''))
            ]);
            if (!$stmtStudentAccess->fetchColumn()) {
                $this->sendJSON(['error' => 'You can only pay for your own account'], 403);
            }
        } elseif (!in_array($roleCategory, $staffRoles, true)) {
            $this->sendJSON(['error' => 'You are not authorized to submit this payment'], 403);
        }

        // Student and guardian portals are online-only. Walk-in confirmation is
        // reserved for authorized staff at the branch.
        if (!in_array($roleCategory, $staffRoles, true)) {
            $source = 'online';
            if ($paymentMethod === 'Cash') {
                $this->sendJSON(['error' => 'Student and guardian payments must use an online payment method'], 400);
            }
        }

        // Handle proof upload
        $proofPath = null;
        if ($isMultipart && !empty($_FILES['proof_file']['name']) && ($_FILES['proof_file']['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
            try { $proofPath = $this->storePaymentProofUpload($_FILES['proof_file'], 'freeze_payments'); }
            catch (Exception $e) { $this->sendJSON(['error' => $e->getMessage()], 400); }
        }

        $status      = ($source === 'walkin') ? 'Paid' : 'Pending';
        $receiptNum  = ($source === 'walkin') ? 'FREEZE-WALKIN-' . time() : null;
        $reviewedAt  = ($source === 'walkin') ? date('Y-m-d H:i:s') : null;
        $payDate     = ($source === 'walkin') ? date('Y-m-d') : null;

        try {
            $this->conn->beginTransaction();

            // Serialize submissions for this enrollment. A successful payment
            // restores the account, so another request must not charge it again.
            $stmtState = $this->conn->prepare("
                SELECT schedule_status FROM tbl_enrollments
                WHERE enrollment_id = ? AND student_id = ? FOR UPDATE
            ");
            $stmtState->execute([$enrollmentId, $studentId]);
            if (strcasecmp((string)$stmtState->fetchColumn(), 'Frozen') !== 0) {
                $this->conn->rollBack();
                $this->sendJSON(['error' => 'This account is no longer frozen. Refresh the page before paying again.'], 409);
            }

            $this->conn->prepare("
                UPDATE tbl_freeze_payments SET status = 'Rejected', notes = 'Superseded by new submission'
                WHERE enrollment_id = ? AND status = 'Pending'
            ")->execute([$enrollmentId]);

            $stmt = $this->conn->prepare("
                INSERT INTO tbl_freeze_payments
                    (enrollment_id, student_id, amount, payment_method, reference_number, proof_path,
                     status, receipt_number, notes, source, payment_date, reviewed_at)
                VALUES (?, ?, 100.00, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->execute([
                $enrollmentId, $studentId, $paymentMethod, $referenceNumber ?: null,
                $proofPath, $status, $receiptNum, $notes ?: null, $source, $payDate, $reviewedAt
            ]);
            $newId = (int)$this->conn->lastInsertId();

            // Walk-in: immediately unfreeze
            if ($source === 'walkin') {
                $this->unfreezeEnrollment($enrollmentId);
            }

            $this->conn->commit();
            $this->sendJSON([
                'success'          => true,
                'freeze_payment_id' => $newId,
                'status'           => $status,
                'message'          => $source === 'walkin'
                    ? 'Payment confirmed. Account has been unfrozen.'
                    : 'Payment submitted. Waiting for desk approval.'
            ]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // ── Desk: get list of freeze payment requests (by branch) ─────
    public function getFreezePayments() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') { $this->sendJSON(['error' => 'Method not allowed'], 405); }
        $this->ensureFreezePaymentsTable();

        $branchId  = (int)($_GET['branch_id'] ?? 0);
        $statusFilter = trim($_GET['status'] ?? '');
        $params    = [];
        $where     = 'WHERE 1=1';

        if ($branchId > 0) { $where .= ' AND s.branch_id = ?'; $params[] = $branchId; }
        if (in_array($statusFilter, ['Pending','Paid','Rejected'])) { $where .= ' AND fp.status = ?'; $params[] = $statusFilter; }

        try {
            $stmt = $this->conn->prepare("
                SELECT fp.*,
                       s.first_name, s.last_name, s.email, s.branch_id,
                       b.branch_name,
                       COALESCE(sp.package_name, CONCAT('Package #', e.package_id)) AS package_name,
                       e.used_absences, e.schedule_status
                FROM tbl_freeze_payments fp
                INNER JOIN tbl_students s  ON s.student_id  = fp.student_id
                INNER JOIN tbl_enrollments e ON e.enrollment_id = fp.enrollment_id
                LEFT JOIN tbl_branches b   ON b.branch_id   = s.branch_id
                LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id
                $where
                ORDER BY fp.status = 'Pending' DESC, fp.created_at DESC
            ");
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];
            $this->sendJSON(['success' => true, 'payments' => $rows]);
        } catch (Throwable $e) {
            if (method_exists($this->conn, 'inTransaction') && $this->conn->inTransaction()) {
                $this->conn->rollBack();
            }
            $this->sendJSON([
                'error' => 'Schedule session failed: ' . $e->getMessage()
            ], 500);
        }
    }

    // ── Desk: get frozen student accounts ─────────────────────────
    public function getFrozenStudents() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') { $this->sendJSON(['error' => 'Method not allowed'], 405); }
        $this->ensureFreezePaymentsTable();

        $branchId = (int)($_GET['branch_id'] ?? 0);
        $params = [];
        $where = "WHERE e.schedule_status = 'Frozen'";
        if ($branchId > 0) {
            $where .= ' AND s.branch_id = ?';
            $params[] = $branchId;
        }

        try {
            $stmt = $this->conn->prepare("
                SELECT e.enrollment_id,
                       e.student_id,
                       e.package_id,
                       e.used_absences,
                       e.consecutive_absences,
                       e.total_sessions,
                       e.completed_sessions,
                       e.allowed_absences,
                       e.schedule_status,
                       e.status AS enrollment_status,
                       e.created_at AS enrollment_created_at,
                       s.first_name,
                       s.last_name,
                       s.email,
                       s.phone,
                       s.branch_id,
                       b.branch_name,
                       COALESCE(sp.package_name, CONCAT('Package #', e.package_id)) AS package_name,
                       COALESCE((
                           SELECT fp.freeze_payment_id
                           FROM tbl_freeze_payments fp
                           WHERE fp.enrollment_id = e.enrollment_id
                           ORDER BY fp.created_at DESC
                           LIMIT 1
                       ), 0) AS freeze_payment_id,
                       COALESCE((
                           SELECT fp.status
                           FROM tbl_freeze_payments fp
                           WHERE fp.enrollment_id = e.enrollment_id
                           ORDER BY fp.created_at DESC
                           LIMIT 1
                       ), 'None') AS freeze_payment_status,
                       (
                           SELECT fp.payment_method
                           FROM tbl_freeze_payments fp
                           WHERE fp.enrollment_id = e.enrollment_id
                           ORDER BY fp.created_at DESC
                           LIMIT 1
                       ) AS freeze_payment_method,
                       (
                           SELECT fp.created_at
                           FROM tbl_freeze_payments fp
                           WHERE fp.enrollment_id = e.enrollment_id
                           ORDER BY fp.created_at DESC
                           LIMIT 1
                       ) AS freeze_payment_created_at
                FROM tbl_enrollments e
                INNER JOIN tbl_students s ON s.student_id = e.student_id
                LEFT JOIN tbl_branches b ON b.branch_id = s.branch_id
                LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id
                $where
                ORDER BY e.used_absences DESC, e.created_at DESC, s.last_name ASC, s.first_name ASC
            ");
            $stmt->execute($params);
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

            // Include the actual absence events which led to the freeze. Counts alone
            // are not enough for staff to explain the account state to a family.
            $rowsByEnrollment = [];
            $enrollmentIds = [];
            foreach ($rows as $index => &$row) {
                $row['absence_records'] = [];
                $enrollmentId = (int)($row['enrollment_id'] ?? 0);
                if ($enrollmentId > 0) {
                    $enrollmentIds[] = $enrollmentId;
                    $rowsByEnrollment[$enrollmentId] = $index;
                }
            }
            unset($row);

            if ($enrollmentIds && $this->tableExists('tbl_sessions')) {
                $placeholders = implode(',', array_fill(0, count($enrollmentIds), '?'));
                $absenceStmt = $this->conn->prepare("
                    SELECT session_id, enrollment_id, session_number, session_date,
                           attendance_status, absence_notice, attendance_notes, status
                    FROM tbl_sessions
                    WHERE enrollment_id IN ($placeholders)
                      AND (
                          attendance_status IN ('Absent', 'CI')
                          OR status IN ('No Show', 'Cancelled')
                      )
                    ORDER BY session_date DESC, session_number DESC, session_id DESC
                ");
                $absenceStmt->execute($enrollmentIds);
                foreach (($absenceStmt->fetchAll(PDO::FETCH_ASSOC) ?: []) as $absence) {
                    $enrollmentId = (int)($absence['enrollment_id'] ?? 0);
                    if (isset($rowsByEnrollment[$enrollmentId])) {
                        $rows[$rowsByEnrollment[$enrollmentId]]['absence_records'][] = $absence;
                    }
                }
            }
            $this->sendJSON(['success' => true, 'students' => $rows]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // ── Desk: approve a freeze payment ────────────────────────────
    public function approveFreezePayment() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { $this->sendJSON(['error' => 'Method not allowed'], 405); }
        $this->ensureFreezePaymentsTable();
        $data    = json_decode(file_get_contents('php://input'), true) ?: [];
        $fpId    = (int)($data['freeze_payment_id'] ?? 0);
        $userId  = (int)($data['user_id'] ?? 0);
        if ($fpId < 1) { $this->sendJSON(['error' => 'freeze_payment_id required'], 400); }

        try {
            $this->conn->beginTransaction();
            $stmt = $this->conn->prepare("SELECT * FROM tbl_freeze_payments WHERE freeze_payment_id = ? LIMIT 1 FOR UPDATE");
            $stmt->execute([$fpId]);
            $fp = $stmt->fetch(PDO::FETCH_ASSOC);
            if (!$fp) { $this->conn->rollBack(); $this->sendJSON(['error' => 'Payment not found'], 404); }
            if ($fp['status'] !== 'Pending') { $this->conn->rollBack(); $this->sendJSON(['error' => 'Only Pending payments can be approved'], 400); }

            $receipt = 'FREEZE-' . time();
            $this->conn->prepare("
                UPDATE tbl_freeze_payments
                SET status = 'Paid', receipt_number = ?, reviewed_by = ?, reviewed_at = NOW(), payment_date = CURDATE()
                WHERE freeze_payment_id = ?
            ")->execute([$receipt, $userId ?: null, $fpId]);

            $this->unfreezeEnrollment((int)$fp['enrollment_id']);
            $this->conn->commit();
            $this->sendJSON(['success' => true, 'message' => 'Payment approved. Account unfrozen.', 'receipt_number' => $receipt]);
        } catch (PDOException $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // ── Desk: reject a freeze payment ─────────────────────────────
    public function rejectFreezePayment() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') { $this->sendJSON(['error' => 'Method not allowed'], 405); }
        $this->ensureFreezePaymentsTable();
        $data   = json_decode(file_get_contents('php://input'), true) ?: [];
        $fpId   = (int)($data['freeze_payment_id'] ?? 0);
        $userId = (int)($data['user_id'] ?? 0);
        $reason = trim((string)($data['reason'] ?? ''));
        if ($fpId < 1) { $this->sendJSON(['error' => 'freeze_payment_id required'], 400); }

        try {
            $this->conn->prepare("
                UPDATE tbl_freeze_payments
                SET status = 'Rejected', notes = ?, reviewed_by = ?, reviewed_at = NOW()
                WHERE freeze_payment_id = ? AND status = 'Pending'
            ")->execute([$reason ?: null, $userId ?: null, $fpId]);
            $this->sendJSON(['success' => true, 'message' => 'Payment rejected.']);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // ── Desk walk-in: instantly pay and unfreeze ──────────────────
    // (reuses submitFreezePayment with source=walkin above)

    // ── Student: get current freeze payment status ────────────────
    public function getStudentFreezePaymentStatus() {
        if ($_SERVER['REQUEST_METHOD'] !== 'GET') { $this->sendJSON(['error' => 'Method not allowed'], 405); }
        $this->ensureFreezePaymentsTable();
        $enrollmentId = (int)($_GET['enrollment_id'] ?? 0);
        if ($enrollmentId < 1) { $this->sendJSON(['error' => 'enrollment_id required'], 400); }
        try {
            $stmt = $this->conn->prepare("
                SELECT freeze_payment_id, status, payment_method, source, reference_number,
                       receipt_number, payment_date, created_at
                FROM tbl_freeze_payments
                WHERE enrollment_id = ?
                ORDER BY created_at DESC
                LIMIT 1
            ");
            $stmt->execute([$enrollmentId]);
            $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
            $this->sendJSON(['success' => true, 'payment' => $row]);
        } catch (PDOException $e) {
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }

    // ── Helper: unfreeze an enrollment ────────────────────────────
    private function unfreezeEnrollment(int $enrollmentId) {
        if ($enrollmentId < 1) return;
        try {
            $this->conn->prepare("
                UPDATE tbl_enrollments
                SET schedule_status      = 'Active',
                    used_absences        = 0,
                    consecutive_absences = 0,
                    absence_reset_at     = NOW(),
                    current_operation_id = NULL
                WHERE enrollment_id = ?
            ")->execute([$enrollmentId]);
        } catch (PDOException $e) {
            // Payment approval must not succeed unless the account and counters
            // were actually restored.
            throw $e;
        }
    }

    private function balanceEnrollment(int $enrollmentId, bool $lock = false): ?array
    {
        $stmt = $this->conn->prepare("SELECT e.enrollment_id, e.student_id, e.status, e.request_notes,
                e.total_sessions, e.completed_sessions, s.first_name, s.last_name, s.email,
                s.branch_id, COALESCE(sp.price, 0) AS package_price,
                COALESCE(sp.sessions, e.total_sessions, 0) AS package_sessions
            FROM tbl_enrollments e
            JOIN tbl_students s ON s.student_id = e.student_id
            LEFT JOIN tbl_session_packages sp ON sp.package_id = e.package_id
            WHERE e.enrollment_id = ?" . ($lock ? ' FOR UPDATE' : ''));
        $stmt->execute([$enrollmentId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) return null;
        $meta = $this->decodeRequestMeta($row['request_notes']);
        $total = is_numeric($meta['package_total_amount'] ?? null)
            ? (float)$meta['package_total_amount'] : (float)$row['package_price'];
        $payments = $this->conn->prepare("SELECT payment_id, amount, payment_method, payment_type,
                payment_date, status, reference_number, receipt_number, notes, created_at
            FROM tbl_payments WHERE enrollment_id = ? ORDER BY payment_id ASC");
        $payments->execute([$enrollmentId]);
        $history = $payments->fetchAll(PDO::FETCH_ASSOC) ?: [];
        $paid = 0.0;
        $pending = false;
        foreach ($history as &$payment) {
            if ($payment['status'] === 'Paid') $paid += (float)$payment['amount'];
            $paymentMeta = $this->decodeRequestMeta($payment['notes'] ?? '');
            if ($payment['status'] === 'Pending' && ($paymentMeta['kind'] ?? '') === 'balance_online') $pending = true;
            $payment['purpose'] = ($paymentMeta['kind'] ?? '') === 'balance_online' || ($paymentMeta['kind'] ?? '') === 'balance_desk'
                ? 'Balance Payment' : 'Initial Payment';
            unset($payment['notes']);
        }
        unset($payment);
        $sessions = (int)$row['package_sessions'];
        $deadline = fas_balance_deadline_session($sessions);
        $used = (int)$row['completed_sessions'];
        $usedStmt = $this->conn->prepare("SELECT COUNT(*) FROM tbl_sessions WHERE enrollment_id = ?
            AND (COALESCE(counted_in, 0) = 1 OR status IN ('Completed', 'Late'))");
        $usedStmt->execute([$enrollmentId]);
        $used = max($used, (int)$usedStmt->fetchColumn());
        $row['total_amount'] = round($total, 2);
        $row['paid_amount'] = round($paid, 2);
        $row['balance_amount'] = round(max(0, $total - $paid), 2);
        $row['deadline_session'] = $deadline;
        $row['sessions_used'] = $used;
        $row['sessions_remaining'] = max(0, (int)$row['total_sessions'] - $used);
        $row['payment_status'] = fas_enrollment_payment_status($total, $paid, $pending, $used, $deadline);
        $row['payment_history'] = $history;
        unset($row['request_notes']);
        return $row;
    }

    private function authorizeBalanceEnrollment(array $row, array $actor): void
    {
        $role = fas_normalize_role_category($actor['role_name'] ?? '');
        $email = trim((string)($actor['email'] ?? ''));
        if ($role === 'student' && strcasecmp($email, (string)$row['email']) === 0) return;
        if ($role === 'guardian') {
            $stmt = $this->conn->prepare("SELECT 1 FROM tbl_student_guardians sg
                JOIN tbl_guardians g ON g.guardian_id = sg.guardian_id
                WHERE sg.student_id = ? AND g.email = ? LIMIT 1");
            $stmt->execute([(int)$row['student_id'], $email]);
            if ($stmt->fetchColumn()) return;
        }
        if (in_array($role, ['admin', 'owner', 'manager', 'staff'], true)) {
            if (in_array($role, ['admin', 'owner'], true) || (int)($actor['branch_id'] ?? 0) === (int)$row['branch_id']) return;
        }
        $this->sendJSON(['error' => 'You cannot access this enrollment payment'], 403);
    }

    public function getEnrollmentBalance(): void
    {
        $id = (int)($_GET['enrollment_id'] ?? 0);
        $row = $id > 0 ? $this->balanceEnrollment($id) : null;
        if (!$row) $this->sendJSON(['error' => 'Enrollment not found'], 404);
        $this->authorizeBalanceEnrollment($row, fas_require_authenticated_user($this->conn));
        $this->sendJSON(['success' => true, 'enrollment' => $row]);
    }

    public function submitEnrollmentBalancePayment(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->sendJSON(['error' => 'Method not allowed'], 405);
        $actor = fas_require_authenticated_user($this->conn);
        $role = fas_normalize_role_category($actor['role_name'] ?? '');
        if (!in_array($role, ['student', 'guardian'], true)) $this->sendJSON(['error' => 'Student or guardian access required'], 403);
        $id = (int)($_POST['enrollment_id'] ?? 0);
        $method = trim((string)($_POST['payment_method'] ?? ''));
        $reference = trim((string)($_POST['reference_number'] ?? ''));
        if ($id < 1 || !in_array($method, ['GCash', 'Bank Transfer'], true) || $reference === '') {
            $this->sendJSON(['error' => 'Enrollment, payment method and reference are required'], 400);
        }
        if (empty($_FILES['proof_file']['name'])) $this->sendJSON(['error' => 'Payment proof is required'], 400);
        $proofPath = null;
        try {
            $this->conn->beginTransaction();
            $row = $this->balanceEnrollment($id, true);
            if (!$row || $row['status'] !== 'Active') $this->sendJSON(['error' => 'Active enrollment not found'], 404);
            $this->authorizeBalanceEnrollment($row, $actor);
            if ($row['balance_amount'] <= 0) $this->sendJSON(['error' => 'This enrollment is fully paid'], 409);
            if ($row['payment_status'] === 'Pending Online Payment') $this->sendJSON(['error' => 'A balance payment is already awaiting review'], 409);
            $proofPath = $this->storePaymentProofUpload($_FILES['proof_file'], 'enrollment_balances');
            $notes = json_encode(['kind' => 'balance_online', 'proof_path' => $proofPath]);
            $stmt = $this->conn->prepare("INSERT INTO tbl_payments
                (enrollment_id, amount, payment_method, payment_type, payment_date, status, reference_number, notes)
                VALUES (?, ?, ?, 'Installment', CURDATE(), 'Pending', ?, ?)");
            $stmt->execute([$id, $row['balance_amount'], $method, $reference, $notes]);
            $paymentId = (int)$this->conn->lastInsertId();
            $this->conn->commit();
            $this->sendJSON(['success' => true, 'payment_id' => $paymentId, 'status' => 'Pending Online Payment',
                'amount' => $row['balance_amount'], 'message' => 'Payment submitted for staff review.']);
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            if ($proofPath) @unlink(dirname(__DIR__) . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $proofPath));
            error_log('submitEnrollmentBalancePayment: ' . $e->getMessage());
            $this->sendJSON(['error' => 'Unable to submit balance payment'], 500);
        }
    }

    public function getPendingEnrollmentBalancePayments(): void
    {
        $actor = fas_require_authenticated_user($this->conn, ['owner', 'manager', 'staff']);
        $stmt = $this->conn->query("SELECT p.payment_id, p.enrollment_id, p.amount, p.payment_method,
                p.reference_number, p.notes, p.created_at, s.first_name, s.last_name, s.branch_id
            FROM tbl_payments p JOIN tbl_enrollments e ON e.enrollment_id = p.enrollment_id
            JOIN tbl_students s ON s.student_id = e.student_id WHERE p.status = 'Pending'
            ORDER BY p.payment_id DESC");
        $rows = [];
        $role = fas_normalize_role_category($actor['role_name'] ?? '');
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) ?: [] as $row) {
            $meta = $this->decodeRequestMeta($row['notes']);
            if (($meta['kind'] ?? '') !== 'balance_online') continue;
            if (!in_array($role, ['admin', 'owner'], true) && (int)$row['branch_id'] !== (int)($actor['branch_id'] ?? 0)) continue;
            $row['proof_path'] = $meta['proof_path'] ?? null;
            unset($row['notes']);
            $rows[] = $row;
        }
        $this->sendJSON(['success' => true, 'payments' => $rows]);
    }

    public function reviewEnrollmentBalancePayment(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') $this->sendJSON(['error' => 'Method not allowed'], 405);
        $actor = fas_require_authenticated_user($this->conn, ['owner', 'manager', 'staff']);
        $data = json_decode(file_get_contents('php://input'), true) ?: [];
        $paymentId = (int)($data['payment_id'] ?? 0);
        $decision = (string)($data['decision'] ?? '');
        if ($paymentId < 1 || !in_array($decision, ['approve', 'reject'], true)) $this->sendJSON(['error' => 'Invalid payment or decision'], 400);
        try {
            $this->conn->beginTransaction();
            $stmt = $this->conn->prepare('SELECT enrollment_id, amount, status, notes FROM tbl_payments WHERE payment_id = ? FOR UPDATE');
            $stmt->execute([$paymentId]);
            $payment = $stmt->fetch(PDO::FETCH_ASSOC);
            $meta = $this->decodeRequestMeta($payment['notes'] ?? '');
            if (!$payment || $payment['status'] !== 'Pending' || ($meta['kind'] ?? '') !== 'balance_online') $this->sendJSON(['error' => 'Pending payment not found'], 404);
            $row = $this->balanceEnrollment((int)$payment['enrollment_id'], true);
            $this->authorizeBalanceEnrollment($row, $actor);
            if ($decision === 'approve' && !fas_balance_payment_allowed((float)$payment['amount'], (float)$row['balance_amount'])) {
                $this->sendJSON(['error' => 'Payment exceeds the current balance. Reject and request a new submission.'], 409);
            }
            $newStatus = $decision === 'approve' ? 'Paid' : 'Failed';
            $this->conn->prepare('UPDATE tbl_payments SET status = ? WHERE payment_id = ? AND status = \'Pending\'')->execute([$newStatus, $paymentId]);
            if ($newStatus === 'Paid' && $this->tableExists('tbl_enrollment_financials')) {
                $this->conn->prepare('UPDATE tbl_enrollment_financials SET paid_amount = ? WHERE enrollment_id = ?')
                    ->execute([(float)$row['paid_amount'] + (float)$payment['amount'], (int)$payment['enrollment_id']]);
            }
            $this->conn->commit();
            $this->sendJSON(['success' => true, 'status' => $newStatus]);
        } catch (Throwable $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            error_log('reviewEnrollmentBalancePayment: ' . $e->getMessage());
            $this->sendJSON(['error' => 'Unable to review payment'], 500);
        }
    }

    // ── Admin: Record a payment against an active enrollment ─────────
    public function recordEnrollmentPayment()
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $this->sendJSON(['error' => 'Method not allowed'], 405);
        }
        $actor = fas_require_authenticated_user($this->conn, ['owner', 'manager', 'staff']);
        $data = json_decode(file_get_contents('php://input'), true) ?: [];

        $enrollmentId  = isset($data['enrollment_id'])  ? (int)$data['enrollment_id']         : 0;
        $amount        = isset($data['amount'])          ? (float)$data['amount']               : 0;
        $paymentDate   = trim((string)($data['payment_date']   ?? date('Y-m-d')));
        $paymentMethod = trim((string)($data['payment_method'] ?? 'Cash'));
        $receiptNumber = trim((string)($data['receipt_number'] ?? ''));
        $notes         = trim((string)($data['notes']          ?? ''));

        if ($enrollmentId <= 0) {
            $this->sendJSON(['error' => 'enrollment_id is required'], 400);
        }
        if (!is_finite($amount) || $amount <= 0 || round($amount, 2) != $amount) {
            $this->sendJSON(['error' => 'Amount must be greater than 0'], 400);
        }
        if (!in_array($paymentMethod, ['Cash', 'GCash', 'Bank Transfer'], true)) {
            $this->sendJSON(['error' => 'Invalid payment method'], 400);
        }
        if (strlen($receiptNumber) > 50) $this->sendJSON(['error' => 'Receipt number is too long'], 400);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $paymentDate)) {
            $paymentDate = date('Y-m-d');
        }

        try {
            $this->conn->beginTransaction();
            $enrollment = $this->balanceEnrollment($enrollmentId, true);
            if (!$enrollment || $enrollment['status'] !== 'Active') {
                $this->sendJSON(['error' => 'Active enrollment not found'], 404);
            }
            $this->authorizeBalanceEnrollment($enrollment, $actor);

            $balance = (float)$enrollment['balance_amount'];
            if (!fas_balance_payment_allowed($amount, $balance)) {
                $this->sendJSON(['error' => sprintf('Amount exceeds outstanding balance of ₱%.2f', $balance)], 400);
            }

            // Auto-generate receipt if not provided
            if ($receiptNumber === '') {
                $receiptNumber = 'BAL-' . $enrollmentId . '-' . bin2hex(random_bytes(5));
            }
            $duplicate = $this->conn->prepare('SELECT 1 FROM tbl_payments WHERE receipt_number = ? LIMIT 1');
            $duplicate->execute([$receiptNumber]);
            if ($duplicate->fetchColumn()) $this->sendJSON(['error' => 'Receipt number already recorded'], 409);

            // Build insert dynamically to handle any schema
            $cols = ['enrollment_id', 'amount', 'payment_method', 'payment_date', 'status'];
            $vals = [$enrollmentId, $amount, $paymentMethod, $paymentDate, 'Paid'];

            if ($this->tableHasColumn('tbl_payments', 'receipt_number')) {
                $cols[] = 'receipt_number';
                $vals[] = $receiptNumber;
            }
            if ($this->tableHasColumn('tbl_payments', 'notes') && $notes !== '') {
                $cols[] = 'notes';
                $vals[] = json_encode(['kind' => 'balance_desk', 'note' => $notes]);
            } elseif ($this->tableHasColumn('tbl_payments', 'notes')) {
                $cols[] = 'notes';
                $vals[] = json_encode(['kind' => 'balance_desk']);
            }
            if ($this->tableHasColumn('tbl_payments', 'payment_type')) {
                $cols[] = 'payment_type';
                $vals[] = 'Installment';
            }

            $placeholders = implode(', ', array_fill(0, count($cols), '?'));
            $this->conn->prepare(
                "INSERT INTO tbl_payments (" . implode(', ', $cols) . ") VALUES ({$placeholders})"
            )->execute($vals);

            $paymentId = (int)$this->conn->lastInsertId();

            // Update enrollment_financials if it exists
            if ($this->tableExists('tbl_enrollment_financials')) {
                $this->conn->prepare("
                    UPDATE tbl_enrollment_financials
                    SET paid_amount = ?
                    WHERE enrollment_id = ?
                ")->execute([(float)$enrollment['paid_amount'] + $amount, $enrollmentId]);
            }

            $newPaid    = (float)$enrollment['paid_amount'] + $amount;
            $newBalance = max(0, (float)$enrollment['total_amount'] - $newPaid);
            $studentName = trim($enrollment['first_name'] . ' ' . $enrollment['last_name']);

            $this->conn->commit();
            $this->sendJSON([
                'success'        => true,
                'message'        => "Payment of ₱" . number_format($amount, 2) . " recorded for {$studentName}.",
                'payment_id'     => $paymentId,
                'receipt_number' => $receiptNumber,
                'new_paid'       => $newPaid,
                'new_balance'    => $newBalance,
            ]);
        } catch (\PDOException $e) {
            if ($this->conn->inTransaction()) $this->conn->rollBack();
            $this->sendJSON(['error' => 'Database error: ' . $e->getMessage()], 500);
        }
    }
}

$studentsApi = new StudentsApi($conn);
$action = $_GET['action'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true) ?: [];
    $action = $_POST['action'] ?? $input['action'] ?? $_GET['action'] ?? '';
}

fas_require_authenticated_user($conn);

switch ($action) {
    case 'get-all-students':
        $studentsApi->getAllStudents();
        break;
    case 'get-student':
        $studentsApi->getStudent();
        break;
    case 'update-student':
        $studentsApi->updateStudent();
        break;
    case 'delete-student':
        $studentsApi->deleteStudent();
        break;
    case 'set-student-status':
        $studentsApi->setStudentStatus();
        break;
    case 'get-active-students':
        $studentsApi->getActiveStudents();
        break;
    case 'assign-package':
        $studentsApi->assignPackage();
        break;
    case 'get-student-portal':
        $studentsApi->getStudentPortal();
        break;
    case 'find-guardian':
        $studentsApi->findGuardianByEmail();
        break;
    case 'set-guardian-mode':
        $studentsApi->setGuardianMode();
        break;
    case 'guardian-register-child':
        $studentsApi->guardianRegisterChild();
        break;
    case 'get-guardian-portal':
        $studentsApi->getGuardianPortal();
        break;
    case 'update-guardian-profile':
        $studentsApi->updateGuardianProfile();
        break;
    case 'get-student-request-meta':
        $studentsApi->getStudentRequestMeta();
        break;
    case 'submit-package-request':
        $studentsApi->submitPackageRequest();
        break;
    case 'submit-session-extension-request':
        $studentsApi->submitSessionExtensionRequest();
        break;
    case 'get-pending-session-extension-requests':
        $studentsApi->getPendingSessionExtensionRequests();
        break;
    case 'get-pending-package-requests':
        $studentsApi->getPendingPackageRequests();
        break;
    case 'get-active-enrollments':
        $studentsApi->getActiveEnrollments();
        break;
    case 'get-available-rooms':
        $studentsApi->getAvailableRooms();
        break;
    case 'get-teacher-available-slots':
        $studentsApi->getTeacherAvailableSlots();
        break;
    case 'get-cancelled-sessions':
        $studentsApi->getCancelledSessions();
        break;
    case 'get-reschedule-slots':
        $studentsApi->getRescheduleSlots();
        break;
    case 'approve-package-request':
        $studentsApi->approvePackageRequest();
        break;
    case 'approve-session-extension-request':
        $studentsApi->approveSessionExtensionRequest();
        break;
    case 'reject-session-extension-request':
        $studentsApi->rejectSessionExtensionRequest();
        break;
    case 'repair-fixed-schedule-sessions':
        $studentsApi->repairFixedScheduleSessions();
        break;
    case 'reject-package-request':
        $studentsApi->rejectPackageRequest();
        break;
    case 'suggest-package-request':
        $studentsApi->suggestPackageRequest();
        break;
    case 'schedule-session':
        $studentsApi->scheduleEnrollmentSession();
        break;
    case 'reschedule-session':
        $studentsApi->rescheduleSession();
        break;
    case 'reschedule-cancelled-session':
        $studentsApi->rescheduleCancelledSession();
        break;
    case 'submit-freeze-payment':
        $studentsApi->submitFreezePayment();
        break;
    case 'get-freeze-payments':
        $studentsApi->getFreezePayments();
        break;
    case 'get-frozen-students':
        $studentsApi->getFrozenStudents();
        break;
    case 'approve-freeze-payment':
        $studentsApi->approveFreezePayment();
        break;
    case 'reject-freeze-payment':
        $studentsApi->rejectFreezePayment();
        break;
    case 'get-student-freeze-payment-status':
        $studentsApi->getStudentFreezePaymentStatus();
        break;
    case 'record-enrollment-payment':
        $studentsApi->recordEnrollmentPayment();
        break;
    case 'get-enrollment-balance':
        $studentsApi->getEnrollmentBalance();
        break;
    case 'submit-enrollment-balance-payment':
        $studentsApi->submitEnrollmentBalancePayment();
        break;
    case 'get-pending-enrollment-balance-payments':
        $studentsApi->getPendingEnrollmentBalancePayments();
        break;
    case 'review-enrollment-balance-payment':
        $studentsApi->reviewEnrollmentBalancePayment();
        break;
    default:
        $studentsApi->sendJSON(['error' => 'Invalid action'], 400);
}
